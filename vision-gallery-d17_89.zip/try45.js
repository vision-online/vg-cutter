/* try45.js -- THE 45-DEGREE TRY-ON ENGINE (d17.23, 1 Oct 2026)

   What it does: puts the frame's own 45-degree cut-out (the robot's photographed near
   arm, the far arm already removed) on a customer's turned face, at the frame's true
   size. No drawn arms: the arm is the photographed one, faded out behind the ear.

   What it never does: touch the front try-on. This file stands on its own; nothing in
   onface.js or the front flow calls it. It reads the face the same way the front does
   (VGOnFace.findFace / faceFromLandmarks give the face object) and only adds placing.

   The pieces
     fitPointsFromImage(img)   where the bridge and the two lens openings are in a
                               cut-out (the same rule the robot uses; used when the
                               robot's own fit points are missing)
     frontReference(frontImg, sizes, frontFace)
                               true size from the FRONT cut-out and the face's own
                               scale from the FRONT photo, carried over to the turned view
     pickView(face, views)     which of the frame's two 45 views belongs to this turn
     fit45(o)                  the placing; returns {canvas, report} or {error, advice}
     headTurn(face)            for the guide: turn more / good / turn back

   Everything that depends on how a real face looks is a named constant below, so it
   can be tuned from the numbers the test page prints, not by guessing. */
(function (global) {
  'use strict';

  var VERSION = '2026-10-08 try45.26';

  /* THE HEAD-TURN WINDOW. yaw is the engine's own number: (distance nose-to-far-cheek minus
     nose-to-near-cheek) / face width, 0 square on, about 0.6 at most. 0.20 to 0.58 is a
     starting window around "halfway"; the test page prints the real number for each photo
     so it can be set from the six AI models. */
  /* d17.40: the window for a half turn (about 25 to 55 degrees) on the uncapped turn measure; it used to end at 0.58,
     so a real 45-degree turn (about 0.75) was refused as 'turned too far' */
  var YAW_MIN = 0.32, YAW_MAX = 0.99;   /* d17.67: frames are shot at 30 degrees now; a customer's 30-degree turn reads about 0.5-0.6; 45-degree photos still work */
  var ROLL_MAX = 14 * Math.PI / 180;
  var IRIS_MM = 12.0;                 /* the same figure the front uses */
  var SEAT_DROP_MM = 2.0;             /* lens centre sits this far below the pupil line (the front's rule) */
  var FADE_START = 0.84;   /* d17.54 (shop): the temple runs straight back and reaches the ear; it slips into the hair only over the last stretch */              /* the arm is full strength this far (as a share of eye-to-ear) ... */
  var FADE_END = 1.00;                /* ... and gone by the ear root, plus a little */
  var ASSUMED_LENS_H_RATIO = 0.78;    /* only when the front cut-out is missing: lens height / lens width */
  var ASSUMED_FACE_LEN_MM = 188;      /* only when no front photo is available: brow to chin */

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function isNum(v) { return typeof v === 'number' && isFinite(v); }

  /* ---------- fit points from a cut-out (the JavaScript twin of the robot's angle_anchors) ---------- */
  function alphaOf(img, maxSide, thr) {
    var w0 = img.naturalWidth || img.width, h0 = img.naturalHeight || img.height;
    if (!w0 || !h0) return null;
    var k = Math.min(1, (maxSide || 640) / Math.max(w0, h0)), t = thr == null ? 127 : thr;
    var w = Math.max(1, Math.round(w0 * k)), h = Math.max(1, Math.round(h0 * k));
    var c = document.createElement('canvas'); c.width = w; c.height = h;
    var x = c.getContext('2d'); x.drawImage(img, 0, 0, w, h);
    var d = x.getImageData(0, 0, w, h).data, a = new Uint8Array(w * h);
    for (var i = 0, j = 3; i < a.length; i++, j += 4) a[i] = d[j] > t ? 1 : 0;
    return { a: a, w: w, h: h, k: k, w0: w0, h0: h0 };
  }

  function floodOutside(a, w, h) {
    var out = new Uint8Array(w * h), stack = [], i;
    function push(p) { if (!a[p] && !out[p]) { out[p] = 1; stack.push(p); } }
    for (i = 0; i < w; i++) { push(i); push((h - 1) * w + i); }
    for (i = 0; i < h; i++) { push(i * w); push(i * w + w - 1); }
    while (stack.length) {
      var p = stack.pop(), x = p % w, y = (p - x) / w;
      if (x > 0) push(p - 1); if (x < w - 1) push(p + 1);
      if (y > 0) push(p - w); if (y < h - 1) push(p + w);
    }
    return out;
  }
  /* d17.72 square dilate / erode (separable), for closing small breaks in a thin rim */
  function morph(a, w, h, r, grow) {
    var t = new Uint8Array(w * h), o = new Uint8Array(w * h), x, y, k, v;
    for (y = 0; y < h; y++) for (x = 0; x < w; x++) {
      v = grow ? 0 : 1;
      for (k = -r; k <= r; k++) { var xx = x + k; var q = (xx < 0 || xx >= w) ? 0 : a[y * w + xx]; if (grow ? q : !q) { v = grow ? 1 : 0; break; } }
      t[y * w + x] = v;
    }
    for (y = 0; y < h; y++) for (x = 0; x < w; x++) {
      v = grow ? 0 : 1;
      for (k = -r; k <= r; k++) { var yy = y + k; var q2 = (yy < 0 || yy >= h) ? 0 : t[yy * w + x]; if (grow ? q2 : !q2) { v = grow ? 1 : 0; break; } }
      o[y * w + x] = v;
    }
    return o;
  }

  /* the lens openings in a mask: [{cx,cy,x0,x1,y0,y1,w,h,area}], biggest first */
  function lensBoxes(a, w, h, fx0, fy0, fx1, fy1) {
    var n = w * h, i, out = floodOutside(a, w, h), lab = new Int32Array(n), comps = [], stack = [];
    for (i = 0; i < n; i++) {
      if (a[i] || out[i] || lab[i]) continue;
      var id = comps.length + 1, c = { area: 0, sx: 0, sy: 0, x0: w, x1: -1, y0: h, y1: -1 };
      lab[i] = id; stack.push(i);
      while (stack.length) {
        var p = stack.pop(), px = p % w, py = (p - px) / w;
        c.area++; c.sx += px; c.sy += py;
        if (px < c.x0) c.x0 = px; if (px > c.x1) c.x1 = px; if (py < c.y0) c.y0 = py; if (py > c.y1) c.y1 = py;
        var nb = [px > 0 ? p - 1 : -1, px < w - 1 ? p + 1 : -1, py > 0 ? p - w : -1, py < h - 1 ? p + w : -1];
        for (var q = 0; q < 4; q++) { var m = nb[q]; if (m >= 0 && !a[m] && !out[m] && !lab[m]) { lab[m] = id; stack.push(m); } }
      }
      comps.push(c);
    }
    var fh = fy1 - fy0 + 1, fw = fx1 - fx0 + 1, boxes = [];
    comps.sort(function (p, q) { return q.area - p.area; });
    for (i = 0; i < Math.min(6, comps.length); i++) {
      var c2 = comps[i], bh = c2.y1 - c2.y0 + 1, bw = c2.x1 - c2.x0 + 1;
      if (bh < 0.25 * fh || c2.area < 0.015 * fh * fw || bw < 0.06 * fw) continue;       /* a lens, not a speck */
      boxes.push({ cx: c2.sx / c2.area, cy: c2.sy / c2.area, x0: c2.x0, x1: c2.x1, y0: c2.y0, y1: c2.y1, w: bw, h: bh, area: c2.area });
    }
    return boxes;
  }
  /* d17.72 (VG-1019): an opening can be only PART of the lens -- the far temple runs across the far lens and the glass above
     it was left solid, so the opening is the lower half. The lens's real top and bottom are found from the solid run right
     above and below the opening (rim + glass + arm, up to the background), minus one rim thickness. */
  function trueLensSpan(a, w, h, b) {
    var tops = [], bots = [], rims = [];
    var xa = Math.round(b.x0 + b.w * 0.3), xb = Math.round(b.x1 - b.w * 0.3);
    for (var x = xa; x <= xb; x++) {
      var y0 = -1, y1 = -1, y;
      for (y = b.y0; y < b.y1; y++) if (!a[y * w + x]) { y0 = y; break; }                    /* first open pixel of the opening in this column */
      for (y = b.y1; y > b.y0; y--) if (!a[y * w + x]) { y1 = y; break; }
      if (y0 < 0 || y1 < 0) continue;
      var up = 0; for (y = y0 - 1; y >= 0 && a[y * w + x]; y--) up++;
      var dn = 0; for (y = y1 + 1; y < h && a[y * w + x]; y++) dn++;
      if (!up || !dn) continue;
      tops.push(y0 - up); bots.push(y1 + dn); rims.push(Math.min(up, dn));
    }
    if (tops.length < 3) return null;
    var med = function (v) { v = v.slice().sort(function (p, q) { return p - q; }); return v[v.length >> 1]; };
    var t = med(rims), top = med(tops) + t, bot = med(bots) - t;
    return bot > top ? { y0: top, y1: bot, h: bot - top + 1, cy: (top + bot) / 2 } : null;
  }

  function fitPointsFromImage(img) {
    try {
      /* strict first (as the robot), then -- d17.72, thin metal rims (VG-1019) -- a softer edge and small breaks closed */
      var passes = [{ thr: 127, close: 0 }, { thr: 40, close: 1 }];
      for (var pi = 0; pi < passes.length; pi++) {
        var A = alphaOf(img, 640, passes[pi].thr); if (!A) return null;
        var a = A.a, w = A.w, h = A.h, n = w * h, i;
        var solid = 0, fx0 = w, fy0 = h, fx1 = -1, fy1 = -1;
        for (i = 0; i < n; i++) if (a[i]) { solid++; var x = i % w, y = (i - x) / w; if (x < fx0) fx0 = x; if (x > fx1) fx1 = x; if (y < fy0) fy0 = y; if (y > fy1) fy1 = y; }
        if (solid < 200) return null;
        if (passes[pi].close) { var r = Math.max(2, Math.round((fy1 - fy0 + 1) * 0.0125)); a = morph(morph(a, w, h, r, true), w, h, r, false); }
        var boxes = lensBoxes(a, w, h, fx0, fy0, fx1, fy1), fh = fy1 - fy0 + 1;
        if (boxes.length < 2) continue;
        boxes = boxes.slice(0, 2);
        /* a lens cut short by solid glass above an arm gets its real height back (never taller than the other lens) */
        for (var bi = 0; bi < 2; bi++) {
          var other = boxes[1 - bi], sp = trueLensSpan(a, w, h, boxes[bi]);
          if (sp && sp.h > boxes[bi].h * 1.2 && sp.h <= Math.max(other.h, boxes[bi].h) * 1.08) { boxes[bi].y0 = sp.y0; boxes[bi].y1 = sp.y1; boxes[bi].h = sp.h; boxes[bi].cy = sp.cy; boxes[bi].fixed = true; }
        }
        boxes.sort(function (p, q) { return (q.w * q.h) - (p.w * p.h); });                    /* the near lens is the bigger one */
        if (boxes[1].area < 0.12 * boxes[0].area && !boxes[1].fixed) continue;                /* the far lens is not really visible */
        if (Math.abs(boxes[0].cy - boxes[1].cy) > 0.35 * fh) continue;                       /* not two lenses side by side */
        var near = boxes[0], far = boxes[1];
        var left = near.cx < far.cx ? near : far, right = near.cx < far.cx ? far : near;
        var s = 1 / A.k;                                                                      /* back to the picture's own pixels */
        var sc = function (b) { return { cx: b.cx * s, cy: b.cy * s, w: b.w * s, h: b.h * s }; };
        return {
          w: A.w0, h: A.h0, frame: [fx0 * s, fy0 * s, fx1 * s, fy1 * s],
          bridge: [((left.x1 + right.x0) / 2) * s, ((left.cy + right.cy) / 2) * s],
          near: sc(near), far: sc(far), nearSide: near === left ? 'left' : 'right',
          lensHeightPx: near.h * s, lensLine: ((near.cy + far.cy) / 2) * s, source: pi ? 'page (thin rim)' : 'page'
        };
      }
      return null;
    } catch (e) { return null; }
  }

  /* the robot writes its own fit points (in the cut-out's own pixels, with w and h); use them when they are sound */
  function usableFit(fit, img) {
    if (!fit || !fit.bridge || !fit.near || !fit.far || !isNum(fit.bridge[0])) return null;
    var w0 = img.naturalWidth || img.width, h0 = img.naturalHeight || img.height, k = (fit.w && w0) ? w0 / fit.w : 1;
    function sc(b) { return { cx: b.cx * k, cy: b.cy * k, w: b.w * k, h: b.h * k }; }
    return {
      w: w0, h: h0, frame: (fit.frame || [0, 0, w0, h0]).map(function (v) { return v * k; }),
      bridge: [fit.bridge[0] * k, fit.bridge[1] * k], near: sc(fit.near), far: sc(fit.far),
      nearSide: fit.nearSide, lensHeightPx: (fit.lensHeightPx || fit.near.h) * k, lensLine: (fit.lensLine || fit.bridge[1]) * k, source: 'robot', robotClean: fit.robotClean || null
    };
  }

  function fitFor(img, robotFit) {
    var f = usableFit(robotFit, img) || fitPointsFromImage(img);
    if (f && robotFit && robotFit.robotClean) f.robotClean = robotFit.robotClean;   /* d17.82: kept after a hand FIX too */
    return f;
  }

  /* ---------- scale: the face's own scale, and the frame's true size, both from the FRONT ---------- */
  function perMMFromFace(face) {                       /* pixels per millimetre on a square-on face: the front's own rule */
    if (!face) return 0;
    if (face.irisPx > 0) { var share = face.irisPx / (face.pd || 1); if (share > 0.10 && share < 0.40) return face.irisPx / IRIS_MM; }
    return face.pd > 0 ? face.pd / 63 : 0;
  }

  /* frontImg: the FRONT cut-out; sizes: {lens, bridge} as typed in admin (mm); frontFace: the face measured on the FRONT photo */
  function frontReference(frontImg, sizes, frontFace, frontRobotFit) {
    var ref = { face: frontFace || null, perMM: perMMFromFace(frontFace), mmppFront: 0, lensHpx: 0, source: [] };
    var fp = frontImg ? fitFor(frontImg, frontRobotFit) : null;
    if (fp && sizes && sizes.lens && isNum(+sizes.lens) && sizes.bridge != null) {
      var centres = Math.abs(fp.near.cx - fp.far.cx);                      /* lens centre to lens centre, in the cut-out's pixels */
      if (centres > 10) { ref.mmppFront = (Number(sizes.lens) + Number(sizes.bridge)) / centres; ref.lensHpx = (fp.near.h + fp.far.h) / 2; ref.source.push('front cut-out + typed lens/bridge'); }
    }
    return ref;
  }


  /* ---------- d17.68 THE REAL TEMPLE from the side (90) cut-out ---------- */
  /* templeStrip(img): the arm out of a side cut-out -- the front is the tall slab at one end; the arm is the top run of
     the long low strip after it (the lower arm of an opened frame is left out). Returns {canvas, hingeFirst, slabH, thickPx}. */
  function templeStrip(img) {
    var W = img.naturalWidth || img.width, H = img.naturalHeight || img.height, c = document.createElement('canvas'); c.width = W; c.height = H;
    var x = c.getContext('2d'); x.drawImage(img, 0, 0); var d = x.getImageData(0, 0, W, H).data;
    var top = new Int16Array(W), run = new Int16Array(W), hgt = new Int16Array(W), maxH = 0;
    for (var cx = 0; cx < W; cx++) { var t = -1, bt = -1, rl = 0; for (var y = 0; y < H; y++) { var on = d[(y * W + cx) * 4 + 3] > 100; if (on) { if (t < 0) t = y; bt = y; if (rl >= 0) rl++; } else if (t >= 0 && rl > 0) { rl = -rl; } }
      top[cx] = t; run[cx] = Math.abs(rl); hgt[cx] = t < 0 ? 0 : bt - t + 1; if (hgt[cx] > maxH) maxH = hgt[cx]; }
    if (maxH < 10) return null;
    var tall = function (i) { return hgt[i] >= maxH * 0.6; };
    var leftTall = 0, rightTall = 0; for (var i = 0; i < Math.round(W * 0.3); i++) { if (tall(i)) leftTall++; if (tall(W - 1 - i)) rightTall++; }
    var dir = leftTall >= rightTall ? 1 : -1, e = dir > 0 ? 0 : W - 1; while (e >= 0 && e < W && tall(e)) e += dir;
    var a0 = dir > 0 ? e : 0, a1 = dir > 0 ? W : e + 1, cols = []; for (var k = a0; k < a1; k++) if (hgt[k] > 0 && run[k] > 0) cols.push(k);
    if (cols.length < 10) return null;
    /* d17.72 (VG-1019): the arm's thickness is read along its MIDDLE (the hinge end carries the nose pad and rims hanging
       below it). d17.73 (shop: "something like a trigger at the hinge"): the arm is followed as a LINE fitted through its
       middle, and each column takes only a band around that line -- the rims seen edge-on and the nose pad near the hinge,
       which used to come along as a squiggle, stay out. */
    var m0 = Math.round(cols.length * 0.25), m1 = Math.max(m0 + 3, Math.round(cols.length * 0.65)), midC = cols.slice(m0, m1);
    var mid = midC.map(function (k) { return run[k]; }).sort(function (p, q) { return p - q; });
    var thick = mid.length ? mid[mid.length >> 1] : 0;
    if (!thick) return null;
    var sx = 0, sy = 0, sxx = 0, sxy = 0, nn = 0;
    midC.forEach(function (k) { if (run[k] > 0 && run[k] <= thick * 1.6) { sx += k; sy += top[k]; sxx += k * k; sxy += k * top[k]; nn++; } });
    var slope = nn > 2 && (nn * sxx - sx * sx) ? (nn * sxy - sx * sy) / (nn * sxx - sx * sx) : 0, icpt = nn ? (sy - slope * sx) / nn : top[cols[0]];
    var line = function (k) { return icpt + slope * k; };
    var bandA = Math.round(thick * 0.35), bandH = Math.round(thick * 1.7);
    var y0 = H, y1 = 0; cols.forEach(function (k) { var a = Math.round(line(k)) - bandA; if (a < y0) y0 = a; if (a + bandH > y1) y1 = a + bandH; });
    y0 = Math.max(0, y0); y1 = Math.min(H, y1);
    var out = document.createElement('canvas'); out.width = cols[cols.length - 1] - cols[0] + 1; out.height = Math.max(2, y1 - y0); var ox = out.getContext('2d');
    cols.forEach(function (k) { var a = Math.max(0, Math.round(line(k)) - bandA), hh = Math.min(H - a, bandH); if (hh > 0) ox.drawImage(c, k, a, 1, hh, k - cols[0], a - y0, 1, hh); });
    var k0 = dir > 0 ? cols[0] : cols[cols.length - 1];
    var hingeYpx = line(k0) - y0 + thick / 2;                                                   /* d17.73: the arm's centre at its hinge end, in strip px */
    return { canvas: out, hingeFirst: dir > 0, slabH: maxH, thickPx: thick, lenPx: out.width, hingeYpx: hingeYpx };
  }
  /* d17.69 TWO SIDE PHOTOS (shop, 7 Oct: "option 2"): the 90 photo of the LEFT temple and, when the shop took it, the 90
     photo of the RIGHT temple. Each side of the head gets the photo whose arm runs the same way as it is drawn, so a
     printed logo reads the right way round; with only one photo it is mirrored for the other side (the old way).
     Which photo is which is read from the photo itself (where the front slab is), never from its label. */
  function templeUrls(p) {
    var hid = (p && Array.isArray(p.hideViews)) ? p.hideViews : [], pend = (p && Array.isArray(p.pendingViews)) ? p.pendingViews : [], out = [];
    [['side', 'tryOnSideUrl'], ['side2', 'tryOnSide2Url']].forEach(function (a) { var u = p && p[a[1]]; if (u && hid.indexOf(a[0]) < 0 && pend.indexOf(a[0]) < 0) out.push(u); });
    return out;
  }
  function loadTemples(p, load) {
    return Promise.all(templeUrls(p).map(function (u) { return Promise.resolve().then(function () { return load(u); }).then(templeStrip).catch(function () { return null; }); }))
      .then(function (a) { return a.filter(Boolean); });
  }
  /* drawDir +1 = the arm is drawn towards the right of the picture, -1 = towards the left */
  function pickTemple(temples, drawDir) {
    var list = Array.isArray(temples) ? temples.filter(Boolean) : (temples ? [temples] : []);
    if (!list.length) return null;
    for (var i = 0; i < list.length; i++) if ((list[i].hingeFirst ? 1 : -1) === drawDir) return { t: list[i], mirror: false };
    return { t: list[0], mirror: true };
  }
  /* paints the strip with its hinge at (0,0) of the current transform, the arm running along drawDir * x;
     the fade starts from the HINGE end whichever way the photo was taken.
     d17.73 (shop, 7 Oct: "the side is very thin, faded, and the hinge is up and down"): `thick` is the arm's TRUE
     thickness on the face, so the arm itself (not the strip's box) is drawn that thick; only the front part of the arm
     -- hinge to about the ear, the part that shows -- is used, so it is not squeezed; the arm's centre sits on the hinge. */
  var TEMPLE_SHOWN = 0.62;
  function paintTemple(ctx, pick, drawDir, len, thick, fadeFrom) {
    var t = pick.t, photoDir = t.hingeFirst ? 1 : -1, cw = t.canvas.width, ch = t.canvas.height;
    var ky = Math.max(0.05, thick / Math.max(1, t.thickPx || ch));
    var tmp = document.createElement('canvas'); tmp.width = Math.max(2, Math.round(len)); tmp.height = Math.max(2, Math.round(ch * ky));
    var sw = Math.max(2, Math.round(cw * TEMPLE_SHOWN)), sx = photoDir > 0 ? 0 : cw - sw;
    var tx = tmp.getContext('2d'); tx.drawImage(t.canvas, sx, 0, sw, ch, 0, 0, tmp.width, tmp.height);
    var g = photoDir > 0 ? tx.createLinearGradient(0, 0, tmp.width, 0) : tx.createLinearGradient(tmp.width, 0, 0, 0);
    g.addColorStop(0, 'rgba(0,0,0,1)'); g.addColorStop(fadeFrom, 'rgba(0,0,0,1)'); g.addColorStop(1, 'rgba(0,0,0,0)');
    tx.globalCompositeOperation = 'destination-in'; tx.fillStyle = g; tx.fillRect(0, 0, tmp.width, tmp.height);
    if (pick.mirror) ctx.scale(-1, 1);                       /* only when the photo shows the other arm (one photo only) */
    var hy = (t.hingeYpx != null ? t.hingeYpx : (t.thickPx || ch) / 2) * ky;
    ctx.drawImage(tmp, photoDir > 0 ? 0 : -tmp.width, -hy);
  }
  /* d17.81 (shop: "the rim is zigzag up and down at the bottom; the top is very good"): around each lens the rim's
     inner and outer edges are read along rays from the lens centre, one per degree. The rim's true thickness is the one
     read along the top. Along the bottom (4 to 8 o'clock) the rim's middle line is smoothed -- a local curve over +-26
     degrees that ignores teeth and bites -- and the rim is painted again there as one even band of the top's thickness,
     in the rim's own colour, edges soft. Towards the sides it blends back into the original rim (no step); the nose-pad
     side and the hinge are not touched. Same as the robot's build 2026-10-07r, so a robot-cleaned picture stays as it is. */
  function smoothBottoms(d, W, H, lenses, R, G, B) {
    var n = W * H, al = new Float32Array(n), i, changed = 0, SPAN = 26, d0 = d.slice(0);   /* d0: the picture before any change */
    for (i = 0; i < n; i++) al[i] = d[i * 4 + 3];
    var med = function (v) { var t = v.slice().sort(function (p, q) { return p - q; }); var m = t.length >> 1; return t.length % 2 ? t[m] : (t[m - 1] + t[m]) / 2; };
    lenses.forEach(function (L) {
      var cx = +L.cx, cy = +L.cy, w = +L.w, h = +L.h, k, q;
      if (!(w >= 20 && h >= 20)) return;
      if (bottomRimShare(d, W, H, L) < 0.6) return;                            /* d17.84: no rim along the bottom (supra / rimless) */
      var r0 = 0.3 * Math.min(w, h) / 2, nR = Math.ceil((0.8 * Math.max(w, h) - r0) / 0.25), rin = [], tk = [];
      var a = new Float32Array(nR);
      for (k = 0; k < 360; k++) {
        rin[k] = NaN; tk[k] = NaN;
        var th = (k - 180) * Math.PI / 180, co = Math.cos(th), si = Math.sin(th), first = -1;
        for (q = 0; q < nR; q++) {
          var rr = r0 + q * 0.25, fx = cx + rr * co, fy = cy + rr * si;
          if (fx >= 0 && fx < W - 1 && fy >= 0 && fy < H - 1) {
            var ix = Math.floor(fx), iy = Math.floor(fy), ux = fx - ix, uy = fy - iy, o = iy * W + ix;
            a[q] = al[o] * (1 - ux) * (1 - uy) + al[o + 1] * ux * (1 - uy) + al[o + W] * (1 - ux) * uy + al[o + W + 1] * ux * uy;
          } else a[q] = 0;
          if (first < 0 && a[q] > 127.5) first = q;
        }
        if (first < 0) continue;
        /* d17.82: every run along the ray; the RIM is the outermost one starting where the opening's own outline is,
           so a nose pad seen inside the lens is never read as the rim */
        var runs = [], st0 = first, j, gap;
        while (st0 >= 0) {
          j = st0; gap = 0;
          while (j < nR) { if (a[j] > 127.5) gap = 0; else { gap++; if (gap > 8) { j -= gap - 1; break; } } j++; }
          runs.push([st0, j]);
          var nx = -1; for (q = j; q < nR; q++) if (a[q] > 127.5) { nx = q; break; }
          st0 = nx;
        }
        var re_ = 1 / Math.sqrt(Math.pow(co / (w / 2), 2) + Math.pow(si / (h / 2), 2)), pick = runs[0];
        for (q = 0; q < runs.length; q++) { var rs = r0 + runs[q][0] * 0.25; if (rs >= 0.85 * re_ && rs <= 1.15 * re_) pick = runs[q]; }
        first = pick[0]; j = pick[1];
        var cross = function (p, qq) {
          if (p < 0 || qq >= nR || a[p] === a[qq]) return r0 + Math.min(Math.max(qq, 0), nR - 1) * 0.25;
          return r0 + p * 0.25 + (127.5 - a[p]) / (a[qq] - a[p]) * 0.25;
        };
        var eIn = cross(first - 1, first), eOut = j < nR ? cross(j - 1, j) : r0 + (nR - 1) * 0.25;
        rin[k] = eIn; tk[k] = Math.max(0, eOut - eIn);
      }
      var tops = [];
      for (k = 45; k <= 135; k++) if (!isNaN(tk[k])) tops.push(tk[k]);          /* -135..-45 degrees: the top of the lens */
      if (tops.length < 20) return;
      var T = med(tops);
      if (!(T >= 1.5 && T <= 0.12 * Math.min(w, h))) return;
      var mid = [], wt = [];
      for (k = 0; k < 360; k++) {
        mid[k] = NaN; wt[k] = 0; if (isNaN(rin[k])) continue;
        var t = tk[k];
        if (t >= 0.6 * T && t <= 1.5 * T) { mid[k] = rin[k] + t / 2; wt[k] = 1; }
        else if (t > 1.5 * T) { mid[k] = rin[k] + T / 2; wt[k] = 0.7; }      /* shadow outside: the inner edge is right */
        else { mid[k] = rin[k] + T / 2; wt[k] = 0.25; }                       /* bitten: a guess */
      }
      var NA = 171, sm = new Array(NA), rob = [], it, nn;
      for (k = 0; k < 360; k++) rob[k] = 1;
      var interpA = function (arr, x) {                                     /* arr over 5..175 degrees, ends held */
        if (x <= 5) return arr[0]; if (x >= 175) return arr[NA - 1];
        var f = x - 5, i0 = Math.floor(f), u = f - i0; return arr[i0] * (1 - u) + arr[Math.min(NA - 1, i0 + 1)] * u;
      };
      for (it = 0; it < 4; it++) {
        for (nn = 0; nn < NA; nn++) {
          var thc = 5 + nn, s0 = 0, s1 = 0, s2 = 0, s3 = 0, s4 = 0, t0 = 0, t1 = 0, t2 = 0, cnt = 0;
          for (k = 0; k < 360; k++) {
            var dd = (k - 180) - thc; if (Math.abs(dd) > SPAN || isNaN(mid[k]) || !(wt[k] > 0)) continue;
            cnt++;
            var uu = Math.abs(dd) / SPAN, ww = Math.pow(1 - uu * uu * uu, 3) * wt[k] * rob[k], X = dd / SPAN, Y = mid[k];
            s0 += ww; s1 += ww * X; s2 += ww * X * X; s3 += ww * X * X * X; s4 += ww * X * X * X * X; t0 += ww * Y; t1 += ww * X * Y; t2 += ww * X * X * Y;
          }
          sm[nn] = NaN;
          if (cnt < 6 || s0 <= 1e-6) continue;
          /* the local curve's value at the centre: solve [s0 s1 s2; s1 s2 s3; s2 s3 s4] c = [t0 t1 t2] for c0 */
          var det = s0 * (s2 * s4 - s3 * s3) - s1 * (s1 * s4 - s3 * s2) + s2 * (s1 * s3 - s2 * s2);
          if (Math.abs(det) < 1e-12) { sm[nn] = t0 / s0; continue; }
          sm[nn] = (t0 * (s2 * s4 - s3 * s3) - s1 * (t1 * s4 - s3 * t2) + s2 * (t1 * s3 - s2 * t2)) / det;
        }
        var okv = sm.filter(function (v) { return !isNaN(v); });
        if (!okv.length) return;
        var fill = med(okv), smf = sm.map(function (v) { return isNaN(v) ? fill : v; }), res = [], band = [];
        for (k = 0; k < 360; k++) { res[k] = mid[k] - interpA(smf, k - 180); if (k - 180 >= 0 && !isNaN(res[k])) band.push(Math.abs(res[k])); }
        var sc = Math.max(0.75, (band.length ? med(band) : 1) * 1.4826);
        for (k = 0; k < 360; k++) { var uv = isNaN(res[k]) ? 9 : Math.abs(res[k]) / (4 * sc); rob[k] = uv < 1 ? (1 - uv * uv) * (1 - uv * uv) : 0; }
      }
      var bad = 0, gx = [], gy = [];
      for (nn = 0; nn < NA; nn++) { if (isNaN(sm[nn])) bad++; else { gx.push(nn); gy.push(sm[nn]); } }
      if (bad > 20 || gx.length < 2) return;
      for (nn = 0; nn < NA; nn++) if (isNaN(sm[nn])) {                       /* holes filled along the curve */
        var pI = -1, nI = -1, m2;
        for (m2 = 0; m2 < gx.length; m2++) { if (gx[m2] < nn) pI = m2; else { nI = m2; break; } }
        sm[nn] = pI < 0 ? gy[nI] : nI < 0 ? gy[pI] : gy[pI] + (gy[nI] - gy[pI]) * (nn - gx[pI]) / (gx[nI] - gx[pI]);
      }
      var smax = Math.max.apply(null, sm), rmx = smax + T * 3.5 + 3;
      var x0 = Math.max(0, Math.trunc(cx - rmx)), x1 = Math.min(W, Math.trunc(cx + rmx) + 1), y0 = Math.max(0, Math.trunc(cy)), y1 = Math.min(H, Math.trunc(cy + rmx) + 1);
      for (var y = y0; y < y1; y++) for (var x = x0; x < x1; x++) {
        var dx = x - cx, dy = y - cy, TH = Math.atan2(dy, dx) * 180 / Math.PI;
        if (TH < 12 || TH > 168) continue;
        var Rr = Math.sqrt(dx * dx + dy * dy), M = interpA(sm, TH), inner = M - T / 2, outer = M + T / 2;
        if (Rr < inner - ((TH >= 30 && TH <= 150) ? 4 : 1) || Rr > outer + 2.5 * T + 2) continue;
        var wg = Math.min(1, Math.max(0, Math.min(TH - 12, 168 - TH) / 18)); wg = 0.5 - 0.5 * Math.cos(Math.PI * wg);
        var cov = Math.min(1, Math.max(0, Math.min(Rr + 0.5, outer) - Math.max(Rr - 0.5, inner)));
        var o4 = (y * W + x) * 4, a0 = d[o4 + 3], na = wg * cov * 255 + (1 - wg) * a0;
        if (cov <= 0 && a0 > 0 && 0.299 * d[o4] + 0.587 * d[o4 + 1] + 0.114 * d[o4 + 2] > 150) continue;   /* light: a clear nose pad, kept */
        var mix = a0 > 0 ? wg * (cov > 0 ? 1 : 0) : 1;
        if (Math.abs(na - a0) > 20) changed++;
        /* d17.84: the frame's own colours -- a pixel that was rim keeps its colour (a tortoise or two-tone rim keeps its
           pattern); a filled gap takes the colour of the nearest rim pixel that was there */
        var tR = R, tG = G, tB = B;
        if (a0 > 200) { tR = d0[o4]; tG = d0[o4 + 1]; tB = d0[o4 + 2]; }
        else if (mix > 0) {
          var found = false, rad;
          for (rad = 1; rad <= Math.ceil(T) + 3 && !found; rad++) {
            for (var oy = -rad; oy <= rad && !found; oy++) for (var ox = -rad; ox <= rad; ox++) {
              if (Math.max(Math.abs(ox), Math.abs(oy)) !== rad) continue;
              var xx2 = x + ox, yy2 = y + oy; if (xx2 < 0 || yy2 < 0 || xx2 >= W || yy2 >= H) continue;
              var q4 = (yy2 * W + xx2) * 4; if (d0[q4 + 3] <= 200) continue;
              var dxq = xx2 - cx, dyq = yy2 - cy, Rq = Math.sqrt(dxq * dxq + dyq * dyq);
              if (Rq < inner - 3 || Rq > outer + 3) continue;
              tR = d0[q4]; tG = d0[q4 + 1]; tB = d0[q4 + 2]; found = true; break;
            }
          }
        }
        d[o4] = Math.round(d[o4] * (1 - mix) + tR * mix); d[o4 + 1] = Math.round(d[o4 + 1] * (1 - mix) + tG * mix); d[o4 + 2] = Math.round(d[o4 + 2] * (1 - mix) + tB * mix);
        d[o4 + 3] = Math.max(0, Math.min(255, Math.round(na)));
      }
    });
    return changed;
  }
  /* d17.84 (shop, 8 Oct: "it must work for every frame -- metal, TR, supra, rimless"): does this lens have a rim along
     its bottom? Each ray from the centre over the bottom (4 to 8 o'clock) is checked for a solid, rim-coloured piece
     where the lens outline is. A full rim gives nearly every ray; a supra or rimless lens only has its thin bright edge
     there, and its bottom is then never "healed" or "smoothed" (that would paint a rim the frame does not have). */
  function bottomRimShare(d, W, H, L) {
    var hits = 0, tot = 0;
    for (var th = 40; th <= 140; th += 2) {
      var t = th * Math.PI / 180, co = Math.cos(t), si = Math.sin(t);
      var re = 1 / Math.sqrt(Math.pow(co / (L.w / 2), 2) + Math.pow(si / (L.h / 2), 2)), any = false, inside = false;
      for (var r = 0.88 * re; r < 1.2 * re; r += 0.5) {
        var x = Math.round(L.cx + r * co), y = Math.round(L.cy + r * si);
        if (x < 0 || y < 0 || x >= W || y >= H) continue;
        inside = true;
        var o = (y * W + x) * 4;
        if (d[o + 3] > 100 && 0.3 * d[o] + 0.59 * d[o + 1] + 0.11 * d[o + 2] < 225) { any = true; break; }
      }
      if (inside) { tot++; if (any) hits++; }
    }
    return tot ? hits / tot : 0;
  }
  function healRims(cm, fit) {
    var W = fit.w, H = fit.h; if (!(W > 10 && H > 10)) return;
    var img = cm.getImageData(0, 0, W, H), d = img.data, n = W * H, a = new Uint8Array(n), i;
    var lenses = [fit.near, fit.far].filter(function (L) { return L && L.w > 8 && L.h > 8; });
    if (!lenses.length) return;
    lenses.forEach(function (L) { L._noBottom = bottomRimShare(d, W, H, L) < 0.6; });   /* d17.84: supra / rimless */
    /* d17.77 (shop: "check the entire rim"): the whole ring, except the inner side (nose pads, bridge joint) and the
       outer top (hinge, end piece) -- closing there turned pads into blocks. Glare is removed along the bottom only. */
    var zone = function (x, y, bottomOnly) {
      for (var k = 0; k < lenses.length; k++) {
        var L = lenses[k], O = lenses[1 - k] || L, ex = (x - L.cx) / (L.w / 2), ey = (y - L.cy) / (L.h / 2), q = Math.sqrt(ex * ex + ey * ey);
        if (!(q > 0.97 && q < 1.15)) continue;
        var ux = ex / q, uy = ey / q, inward = O.cx > L.cx ? 1 : -1;
        if (ux * inward > 0.45 || (ux * inward < -0.6 && uy < 0.25)) continue;
        if (L._noBottom && uy > -0.1) continue;                                  /* d17.84: a supra / rimless bottom is left alone */
        if (bottomOnly && uy <= 0.4) continue;
        return true;
      }
      return false;
    };
    var inRing = function (x, y) { return zone(x, y, false); };
    var lum = function (o) { return 0.3 * d[o] + 0.59 * d[o + 1] + 0.11 * d[o + 2]; };
    /* the rim's own colour: the darker half of the solid pixels on the rings (light speckles are glare from the floor) */
    var px = [];
    for (i = 0; i < n; i += 2) { if (d[i * 4 + 3] <= 100) continue; var x = i % W, y = (i - x) / W; if (inRing(x, y)) px.push(i * 4); }
    if (px.length < 20) return;
    px.sort(function (p, q) { return lum(p) - lum(q); });
    var dark = px.slice(0, Math.max(10, px.length >> 1)), mid = dark[dark.length >> 1];
    var R = d[mid], G = d[mid + 1], B = d[mid + 2], rimLum = lum(mid), darkFrame = rimLum < 110;
    /* solid = opaque and (on a dark frame) not a light speckle */
    for (i = 0; i < n; i++) { var o = i * 4; a[i] = d[o + 3] > 30 && (!darkFrame || lum(o) < rimLum + 70) ? 1 : 0; }   /* a faint rim pixel counts too */
    var r = Math.max(2, Math.round(Math.min.apply(null, lenses.map(function (L) { return L.h; })) * 0.035));
    var c = morph(morph(a, W, H, r, true), W, H, r, false), changed = 0;
    for (i = 0; i < n; i++) {
      if (a[i]) {                                                          /* a faint rim pixel BETWEEN solid ones is a crack: made solid */
        var o4 = i * 4; if (d[o4 + 3] >= 250) continue;
        var xa = i % W, ya = (i - xa) / W; if (xa < 1 || ya < 1 || xa >= W - 1 || ya >= H - 1 || !inRing(xa, ya)) continue;
        var nb2 = 0; for (var dy2 = -1; dy2 <= 1; dy2++) for (var dx2 = -1; dx2 <= 1; dx2++) if ((dx2 || dy2) && d[((ya + dy2) * W + xa + dx2) * 4 + 3] > 140) nb2++;
        if (nb2 >= 4) { var al4 = d[o4 + 3] / 255; d[o4] = Math.round(d[o4] * al4 + R * (1 - al4)); d[o4 + 1] = Math.round(d[o4 + 1] * al4 + G * (1 - al4)); d[o4 + 2] = Math.round(d[o4 + 2] * al4 + B * (1 - al4)); d[o4 + 3] = 255; changed++; }
        continue;
      }
      var x2 = i % W, y2 = (i - x2) / W; if (!inRing(x2, y2)) continue;
      var o2 = i * 4;
      if (c[i]) { d[o2] = R; d[o2 + 1] = G; d[o2 + 2] = B; d[o2 + 3] = 255; changed++; }          /* a break in the rim: closed */
      else if (darkFrame && d[o2 + 3] > 0 && zone(x2, y2, true)) { d[o2 + 3] = 0; changed++; }   /* a light speckle beside the bottom rim: glare, gone */
    }
    /* d17.80 (shop: "the shadow at the bottom is very heavy"): the rim's thickness is read at the top of each lens (the
       thinner of the two); along the bottom, a rim thicker than that by a third is the table's shadow -- trimmed */
    var runs = function (L) {
      var tops = [], bots = [];
      for (var x = Math.round(L.cx - L.w * 0.25); x <= Math.round(L.cx + L.w * 0.25); x += 2) {
        if (x < 0 || x >= W) continue;
        var y0 = -1, y1 = -1, y;
        for (y = 0; y < H; y++) if (d[(y * W + x) * 4 + 3] > 100) { y0 = y; break; }
        for (y = H - 1; y >= 0; y--) if (d[(y * W + x) * 4 + 3] > 100) { y1 = y; break; }
        if (y0 < 0 || y1 <= y0 + 3) continue;
        var nt = 0; while (y0 + nt < H && d[((y0 + nt) * W + x) * 4 + 3] > 100) nt++;
        var nb = 0; while (y1 - nb >= 0 && d[((y1 - nb) * W + x) * 4 + 3] > 100) nb++;
        tops.push(nt); bots.push([x, y1, nb]);
      }
      return [tops, bots];
    };
    var refs = [], per = [];
    lenses.forEach(function (L) { var rr = runs(L); per.push(L._noBottom ? [] : rr[1]); if (rr[0].length) { var t = rr[0].slice().sort(function (p, q) { return p - q; }); refs.push(t[t.length >> 1]); } });
    if (refs.length) {
      var rimT = Math.max(2, Math.min.apply(null, refs));
      per.forEach(function (bl) { bl.forEach(function (b) {
        if (b[2] > rimT * 1.35) { var cutN = Math.round(b[2] - rimT * 1.1);
          for (var yy = b[1] - cutN + 1; yy <= b[1]; yy++) for (var xx = b[0] - 1; xx <= b[0] + 1; xx++) if (xx >= 0 && xx < W && yy >= 0) { d[(yy * W + xx) * 4 + 3] = 0; changed++; } }
      }); });
    }
    try { changed += smoothBottoms(d, W, H, lenses, R, G, B); } catch (e) {}   /* d17.81: bottom rim smooth and even */
    if (changed) cm.putImageData(img, 0, 0);
  }
  /* drawRealTemple: from the near hinge (the near lens's outer top corner in the picture) back to the hair line at the
     top of the ear, with the temple's true thickness and colour, slipping into the hair over its last third. */
  function drawRealTemple(lx, temples, q) {
    var fit = q.fit, s = q.s, cr = Math.cos(q.roll), sr = Math.sin(q.roll);
    var side = q.nearIsRight ? 1 : -1;
    var hxC = fit.near.cx + side * fit.near.w * 0.5, hyC = isNum(q.hingeY) ? q.hingeY : fit.near.cy - fit.near.h * 0.30;   /* hinge in cut-out px: d17.73 where the 30° photo's own arm starts */
    var dx = (hxC - fit.bridge[0]) * s, dy = (hyC - fit.bridge[1]) * s;
    var hx = q.ax + dx * cr - dy * sr, hy = q.ayLine + dx * sr + dy * cr;                             /* hinge in the picture */
    var hair = q.nearIsRight ? (q.face.templeL || q.face.cheekL) : (q.face.templeR || q.face.cheekR);
    var ear = q.nearIsRight ? (q.face.cheekL || q.face.templeL) : (q.face.cheekR || q.face.templeR);
    var endX = hair && isFinite(hair.x) ? hair.x + side * (Math.abs((ear && ear.x != null ? ear.x : hair.x) - hair.x) * 0.5 + 4 * q.perMM) : hx + side * q.templeMM * q.perMM * 0.5;   /* d17.75: 4 mm further */
    var pupil = q.nearIsRight ? q.face.pupilL : q.face.pupilR;
    var endY = pupil && isFinite(pupil.y) ? pupil.y + (q.face.irisPx || 10) * 0.3 : hy;              /* at the top of the ear: eye level */
    var len = Math.hypot(endX - hx, endY - hy); if (len < 8) return null;
    var ang = Math.atan2(endY - hy, endX - hx), drawDir = Math.cos(ang) >= 0 ? 1 : -1;
    var pick = pickTemple(temples, drawDir); if (!pick) return null;
    var thick = isNum(q.armThick) && q.armThick > 0 ? Math.max(2, q.armThick * s) : Math.max(2, (pick.t.thickPx / pick.t.slabH) * fit.near.h * s * 1.25);   /* d17.73: as thick as the arm in the 30° photo */
    lx.save(); lx.translate(hx, hy); lx.rotate(drawDir > 0 ? ang : ang - Math.PI);                  /* never upside down */
    lx.globalAlpha = 0.98; paintTemple(lx, pick, drawDir, len, thick, 0.8); lx.restore();
    return { mirrored: pick.mirror, photos: Array.isArray(temples) ? temples.filter(Boolean).length : 1, drawDir: drawDir, hingeFrom: isNum(q.hingeY) ? '30-degree photo' : 'estimate', thickPx: Math.round(thick * 10) / 10 };
  }
  /* ---------- the guide: how turned is this head? ---------- */
  function headTurn(face) {
    if (!face) return { state: 'no-face', yaw: 0, text: 'I cannot see your face. Hold the phone at eye level.' };
    var y = face.yaw || 0, ay = Math.abs(y);
    if (ay < YAW_MIN) return { state: 'turn-more', yaw: y, text: 'Turn your head a little more, until you can see your ear in the picture\u2019s edge.' };
    if (ay > YAW_MAX) return { state: 'turn-less', yaw: y, text: 'That is too far \u2014 turn back a little so both eyes still show.' };
    return { state: 'ok', yaw: y, text: 'Good \u2014 hold it there.' };
  }

  var ADVICE = {
    'no-face': 'I could not find your face in that photo. Take it again at eye level with good light.',
    'turn-more': 'Your head is not turned enough for a side look. Turn it a little more (about 30\u00b0) and take it again.',
    'turn-less': 'Your head is turned too far. Turn back until both eyes still show, then take it again.',
    'no-ear': 'I could not see your ear on the near side. Tuck your hair back and take it again.',
    'no-view': 'This frame has no 45\u00b0 picture for that side yet.',
    'no-fit': 'This frame\u2019s 45\u00b0 picture cannot be placed (no lens openings found).',
    'tilted': 'Your head is tilted. Keep it level and take it again.'
  };

  function pickView(face, views) {
    if (!face || !views) return null;
    var want = (face.yaw || 0) > 0 ? 'right' : 'left';              /* the near eye is the image-right one when yaw > 0 */
    for (var i = 0; i < views.length; i++) if (views[i] && views[i].fit && views[i].fit.nearSide === want) return views[i];
    return null;
  }

  /* ---------- the placing ----------
     o = { faceImg, face, cutImg, fit, frontRef, sizes:{lens,bridge}, perMM (optional override) } */
  function fit45(o) {
    try {
      var face = o.face, cut = o.cutImg, notes = [];
      if (!face || !o.faceImg) return { error: 'no-face', advice: ADVICE['no-face'] };
      var fit = cut ? fitFor(cut, o.fit) : null;                 /* d17.63: the robot's fit points, or the page's own from the cut-out */
      if (!cut || !fit) return { error: 'no-fit', advice: ADVICE['no-fit'] };
      var yaw = face.yaw || 0, ay = Math.abs(yaw);
      if (ay < YAW_MIN) return { error: 'turn-more', advice: ADVICE['turn-more'], report: { yaw: yaw } };
      if (ay > YAW_MAX) return { error: 'turn-less', advice: ADVICE['turn-less'], report: { yaw: yaw } };
      var roll = face.roll || 0;
      if (Math.abs(roll) > ROLL_MAX) return { error: 'tilted', advice: ADVICE.tilted, report: { yaw: yaw, roll: roll } };

      var temples = Array.isArray(o.temple) ? o.temple.filter(Boolean) : (o.temple ? [o.temple] : []), templeInfo = null;   /* d17.69: one or two side photos */
      var nearIsRight = yaw > 0, sgn = nearIsRight ? 1 : -1;
      var pupilNear = nearIsRight ? face.pupilL : face.pupilR;           /* the engine names pupils by image side: pupilL is the image-RIGHT one */
      var earNear = nearIsRight ? face.templeL : face.templeR;
      if (!pupilNear) return { error: 'no-face', advice: ADVICE['no-face'] };
      if (!earNear) return { error: 'no-ear', advice: ADVICE['no-ear'] };
      var wantSide = nearIsRight ? 'right' : 'left';
      if (fit.nearSide !== wantSide) return { error: 'no-view', advice: ADVICE['no-view'], report: { needs: wantSide, has: fit.nearSide } };

      /* 1. pixels per millimetre ON THIS TURNED FACE */
      var ref = o.frontRef || {}, perMM = 0, perMMsrc = '';
      if (isNum(o.perMM) && o.perMM > 0) { perMM = o.perMM; perMMsrc = 'given'; }
      else if (ref.face && ref.perMM > 0 && ref.face.faceL > 0 && face.faceL > 0) {
        perMM = ref.perMM * (face.faceL / ref.face.faceL); perMMsrc = 'front photo scale x (face length turned / front)';   /* length is not shortened by a turn */
      } else if (face.irisUsed && face.irisPx > 0) {
        var th = Math.asin(clamp(ay / 0.85, 0, 0.95)); perMM = (face.irisPx / Math.max(0.6, Math.cos(th * 0.5))) / IRIS_MM; perMMsrc = 'iris, corrected for the turn (rough)';
        notes.push('no front photo: scale is rough');
      } else if (face.faceL > 0) { perMM = face.faceL / ASSUMED_FACE_LEN_MM; perMMsrc = 'face length, assumed 188 mm (rough)'; notes.push('no front photo: scale is rough'); }
      if (!(perMM > 0)) return { error: 'no-face', advice: ADVICE['no-face'] };

      /* 2. millimetres per pixel of THIS 45 cut-out, from the lens height (a turn does not change heights) */
      var mmpp = 0, mmppSrc = '';
      /* d17.68 (shop: "the frame looks almost double"): the studio photo is taken close, so its NEAR lens is inflated by
         perspective (near 236 px against far 191 px on VG-1015); scaling by the near lens alone drew the whole frame too
         big. The frame's true size is between the two, so the mean of the near and far lens heights is used. */
      var hMean = (fit.near && fit.near.h > 0 && fit.far && fit.far.h > 0) ? (fit.near.h + fit.far.h) / 2 : (fit.near && fit.near.h) || 0;
      if (ref.mmppFront > 0 && ref.lensHpx > 0 && hMean > 0) { mmpp = ref.lensHpx * ref.mmppFront / hMean; mmppSrc = 'front cut-out lens height (mean of near and far)'; }
      else {
        var lensMM = Number(o.sizes && o.sizes.lens) || 52;
        mmpp = (ASSUMED_LENS_H_RATIO * lensMM) / (hMean || fit.near.h); mmppSrc = 'assumed lens height (' + ASSUMED_LENS_H_RATIO + ' x lens width) (rough)'; notes.push('no front cut-out: frame size is rough');
      }
      var s = mmpp * perMM;                                         /* cut-out pixel -> picture pixel */

      /* 3. where: the bridge on the nose midline, the lens line a little below the pupil line (the front's rule) */
      /* d17.55 (shop: "the nose pads have to sit ON the nose"): on a turned face the nose ridge further down sticks out
         towards the far side, so the old average along the nose (168, 6, 197, 195) pulled the bridge off the nose. The
         bridge now sits on the nose ROOT between the eyes (point 6), where the pads rest. */
      var ax = (face.noseSeat && isFinite(face.noseSeat.x) && face.noseSeat.x) || face.noseAxisX || ((pupilNear.x + (nearIsRight ? face.pupilR : face.pupilL).x) / 2);
      var ayLine = pupilNear.y + (ax - pupilNear.x) * Math.tan(roll) + SEAT_DROP_MM * perMM;
      var W = (o.faceImg.naturalWidth || o.faceImg.width) || face.w, H = (o.faceImg.naturalHeight || o.faceImg.height) || face.h;     /* the picture's own size */

      var layer = document.createElement('canvas'); layer.width = W; layer.height = H;
      var lx = layer.getContext('2d'); lx.imageSmoothingEnabled = true; if ('imageSmoothingQuality' in lx) lx.imageSmoothingQuality = 'high';
      /* d17.41 (shop): ONLY THE FRONT AND THE STRAIGHT ARM. Beside the near lens, a 45 photo also shows the far arm seen
         through the glass and the arms' hanging ear tips; on a face those land on the cheek. So, in the cut-out: past the
         near lens's outer edge only the arm's own band (from the top of the lens to just above its middle, where hinges
         sit) is kept, and past the far lens's outer edge nothing (the far arm is behind the head). */
      var cutM = document.createElement('canvas'); cutM.width = fit.w; cutM.height = fit.h;
      var cm = cutM.getContext('2d'); cm.drawImage(cut, 0, 0, fit.w, fit.h);
      /* d17.76 (shop, 7 Oct: "the bottom part of the rim is cut"): a thin metal rim can come out of the robot with small
         breaks, mostly along the bottom. Only along each lens's rim, breaks of a few pixels are closed with the rim's own
         colour; nothing else in the picture is touched. */
      /* d17.82 (shop: "the nose pad is not visible -- compare with the original"): a 30° picture the robot has already
         cleaned (rims healed and smoothed, glass and far temple cleared, nose pads put back from the photo; build 07s on)
         says so in its fit points. The page then does NOT clean it again -- its clean-ups were made for older cut-outs and
         would cut the nose pads away. Only the arm and far-temple stub steps run. */
      var RC = !!fit.robotClean;
      if (!RC) try { healRims(cm, fit); } catch (e) {}
      cm.globalCompositeOperation = 'destination-out';
      var nW = fit.near.w, nH = fit.near.h, fW = fit.far.w;
      var armRight = fit.near.cx > fit.far.cx;                       /* the near lens is on the right of the cut-out: its arm goes right */
      var bandTop = fit.near.cy - nH * 0.56, bandBot = fit.near.cy - nH * 0.04;
      var armYfound = null, armThickFound = null, armDbg = null;
      /* find the arm itself: beside the near lens, the row where the straight arm runs (the median height of what the
         cut-out kept there); then keep only a slim band around it, so a diagonal piece near the hinge goes too */
      try {
        var armSide = fit.near.cx > fit.far.cx ? 1 : -1;
        var ax0 = armSide > 0 ? Math.round(fit.near.cx + nW / 2 + nW * 0.06) : Math.round(fit.near.cx - nW / 2 - nW * 0.06 - nW * 0.6);
        var aw = Math.round(nW * 0.6), ay0 = Math.max(0, Math.round(bandTop)), ah = Math.max(1, Math.round(bandBot - bandTop));
        ax0 = Math.max(0, Math.min(fit.w - 1, ax0)); aw = Math.max(1, Math.min(fit.w - ax0, aw)); ah = Math.min(fit.h - ay0, ah);
        if (aw > 4 && ah > 4) {
          /* d17.54: the arm is the LONGEST straight horizontal run beside the lens -- the row (band of rows) holding the
             most frame pixels; an average was pulled down by the far temple's dark tip and missed the real arm */
          var ad = cm.getImageData(ax0, ay0, aw, ah).data, rowN = new Array(ah).fill(0);
          for (var cyy = 0; cyy < ah; cyy++) for (var cxx = 0; cxx < aw; cxx++) if (ad[(cyy * aw + cxx) * 4 + 3] > 100) rowN[cyy]++;
          var bestY = -1, bestN = 0, win = Math.max(2, Math.round(nH * 0.03));
          for (var r0 = 0; r0 < ah; r0++) { var sN = 0; for (var k = -win; k <= win; k++) { var rr = r0 + k; if (rr >= 0 && rr < ah) sN += rowN[rr]; } if (sN > bestN) { bestN = sN; bestY = r0; } }
          if (bestY >= 0 && bestN > aw * 0.25) {
            var armY = ay0 + bestY, half = Math.max(4, nH * 0.06);
            bandTop = Math.max(bandTop, armY - half); bandBot = Math.min(bandBot, armY + half);
            /* d17.73: the arm's own height and thickness in this 30° photo -- where the real temple is hung, and how thick */
            var peak = rowN[bestY], ta = bestY, tb = bestY;
            while (ta > 0 && rowN[ta - 1] > peak * 0.45) ta--;
            while (tb < ah - 1 && rowN[tb + 1] > peak * 0.45) tb++;
            /* d17.74: it only counts as THE ARM if it really runs back from the hinge -- solid across most of the window at
               that height (an end piece or the rim alone is not an arm) */
            var hh = Math.max(2, Math.round((tb - ta + 1) / 2 + nH * 0.02)), cyA = Math.round((ta + tb) / 2), cov = 0;
            for (var cx2 = 0; cx2 < aw; cx2++) { var hit = false; for (var ry = Math.max(0, cyA - hh); ry <= Math.min(ah - 1, cyA + hh) && !hit; ry++) if (ad[(ry * aw + cx2) * 4 + 3] > 100) hit = true; if (hit) cov++; }
            armDbg = { aw: aw, cov: cov, nW: Math.round(nW), ta: ta, tb: tb, ay0: ay0, ax0: ax0, ncx: Math.round(fit.near.cx), fcx: Math.round(fit.far.cx), fw: fit.w };
            if (aw >= nW * 0.3 && cov >= aw * 0.6) { armYfound = ay0 + (ta + tb + 1) / 2; armThickFound = Math.min(nH * 0.12, tb - ta + 1); }
          }
        }
      } catch (e) {}
      /* d17.74 (shop, 7 Oct: "use the 30 degree photo's own arm -- front and side together, the actual frame"): the near arm
         as photographed in this 30° picture is used whenever it is there -- same photo as the front, so hinge, thickness,
         colour and shine are the frame's own. The 90° photo's arm is only a backup, for a 30° picture with no arm in it. */
      var usePhotoArm = armYfound != null;
      if (!usePhotoArm && temples.length) { bandTop = bandBot = -1; }        /* backup: the 90° arm replaces a missing one */
      if (armRight) {
        var xa = fit.near.cx + nW / 2 + nW * 0.04;
        cm.fillRect(xa, 0, fit.w - xa, Math.max(0, bandTop)); cm.fillRect(xa, bandBot, fit.w - xa, fit.h - bandBot);
        var xf = fit.far.cx - fW / 2 - fW * 0.20; if (xf > 0) cm.fillRect(0, 0, xf, fit.h);
      } else {
        var xb = fit.near.cx - nW / 2 - nW * 0.04;
        cm.fillRect(0, 0, xb, Math.max(0, bandTop)); cm.fillRect(0, bandBot, xb, fit.h - bandBot);
        var xg = fit.far.cx + fW / 2 + fW * 0.20; if (xg < fit.w) cm.fillRect(xg, 0, fit.w - xg, fit.h);
      }
      /* d17.49 (shop): ONLY THE NEAR ARM. Beside the near lens the 45 photo also shows the far arm's dark tip crossing
         at hinge height; on a face it looked like a black stub on the cheek. The near arm is the same colour as the
         frame's end piece beside it, so in the arm band only pixels of that colour stay. */
      var R0, G0, B0;
      try {
        cm.globalCompositeOperation = 'source-over';
        var armSide2 = fit.near.cx > fit.far.cx ? 1 : -1, edgeX = fit.near.cx + armSide2 * (nW / 2);
        var y0b = Math.max(0, Math.floor(bandTop)), hb = Math.max(1, Math.min(fit.h, Math.ceil(bandBot)) - y0b);
        /* the frame's own colour: the OUTER SIDE of the near rim at mid-height -- no arm crosses it there (the top rim can
           carry the far temple's dark line seen through the glass, which made the near temple look "foreign" and erased it) */
        var refW = Math.max(3, Math.round(nW * 0.07)), refX0 = Math.round(armSide2 > 0 ? edgeX - refW : edgeX);
        refX0 = Math.max(0, Math.min(fit.w - refW, refX0));
        var refY0 = Math.max(0, Math.round(fit.near.cy - nH * 0.25)), refH = Math.max(2, Math.min(fit.h - refY0, Math.round(nH * 0.5)));
        var rd = cm.getImageData(refX0, refY0, refW, refH).data, rs = [];
        for (var q = 0; q < rd.length; q += 4) if (rd[q + 3] > 160) rs.push([rd[q], rd[q + 1], rd[q + 2]]);
        if (rs.length > 8) {
          var med = function (k) { var a = rs.map(function (c) { return c[k]; }).sort(function (u, v) { return u - v; }); return a[a.length >> 1]; };
          R0 = med(0); G0 = med(1); B0 = med(2);
          var ax0 = armSide2 > 0 ? Math.round(edgeX + nW * 0.03) : 0, aw0 = armSide2 > 0 ? fit.w - ax0 : Math.round(edgeX - nW * 0.03);
          if (aw0 > 2) {
            var ad = cm.getImageData(ax0, y0b, aw0, hb), dd = ad.data;
            for (var q2 = 0; q2 < dd.length; q2 += 4) { if (dd[q2 + 3] < 8) continue;
              var dist = Math.abs(dd[q2] - R0) + Math.abs(dd[q2 + 1] - G0) + Math.abs(dd[q2 + 2] - B0);
              if (dist > 150) dd[q2 + 3] = 0; }                       /* a different colour beside the near lens: the far arm */
            cm.putImageData(ad, ax0, y0b);
          }
        }
      } catch (e) {}
      /* d17.50 (shop: "when they turn, the far temple is disturbing on the face"): the far temple is also seen THROUGH
         the lenses at 45 -- a dark line across the glass. Inside each lens opening only the nose pads (on the bridge
         side, lower part) are kept; everything else seen through the glass is cleared, so only the near temple shows. */
      if (!RC) try {
        cm.globalCompositeOperation = 'destination-out';
        [fit.near, fit.far].forEach(function (L) {
          if (!L || !L.w || !L.h) return;
          var bridgeSide = (fit.bridge[0] > L.cx) ? 1 : -1;
          var px0 = Math.round(bridgeSide > 0 ? L.cx + L.w * 0.12 : L.cx - L.w * 0.5), pw = Math.round(L.w * 0.38);
          var py0 = Math.round(L.cy - L.h * 0.12), ph = Math.round(L.h * 0.62);
          px0 = Math.max(0, Math.min(fit.w - 1, px0)); pw = Math.max(1, Math.min(fit.w - px0, pw));
          py0 = Math.max(0, Math.min(fit.h - 1, py0)); ph = Math.max(1, Math.min(fit.h - py0, ph));
          var pads = cm.getImageData(px0, py0, pw, ph);
          cm.beginPath(); cm.ellipse(L.cx, L.cy, L.w * 0.47, L.h * 0.47, 0, 0, Math.PI * 2); cm.fill();
          cm.putImageData(pads, px0, py0);
          /* and right under the rims, inside the lens box: anything NOT the frame's own colour (the far temple's dark
             tip runs along the top rim there) goes; the rim itself is the frame's colour and stays */
          if (typeof R0 === 'number') {
            var bx0 = Math.max(0, Math.round(L.cx - L.w / 2)), by0 = Math.max(0, Math.round(L.cy - L.h / 2));
            var bw = Math.max(1, Math.min(fit.w - bx0, Math.round(L.w))), bh = Math.max(1, Math.min(fit.h - by0, Math.round(L.h)));
            var bd = cm.getImageData(bx0, by0, bw, bh), bdd = bd.data;
            for (var yy = 0; yy < bh; yy++) for (var xx = 0; xx < bw; xx++) {
              var gx = bx0 + xx, gy = by0 + yy;
              if (gx >= px0 && gx < px0 + pw && gy >= py0 && gy < py0 + ph) continue;      /* the nose pads */
              var q3 = (yy * bw + xx) * 4; if (bdd[q3 + 3] < 8) continue;
              if (Math.abs(bdd[q3] - R0) + Math.abs(bdd[q3 + 1] - G0) + Math.abs(bdd[q3 + 2] - B0) > 150) bdd[q3 + 3] = 0;
            }
            cm.putImageData(bd, bx0, by0);
          }
        });
        cm.globalCompositeOperation = 'source-over';
      } catch (e) {}
      /* d17.57 (shop) A. THE FAR TEMPLE SEEN THROUGH THE GLASS: a straight bar crossing each lens just under its top rim.
         The robot's lens box is the big opening BELOW that bar, so look from a little above the box: top rim (a long run),
         a thin strip of glass, then the bar (another long run) right on top of the opening -- that lower run goes. */
      if (!RC) try {
        [fit.near, fit.far].forEach(function (L) {
          if (!L || !L.w || !L.h) return;
          var bx = Math.max(0, Math.round(L.cx - L.w / 2)), bw = Math.max(4, Math.min(fit.w - bx, Math.round(L.w)));
          var top = Math.round(L.cy - L.h / 2), by = Math.max(0, Math.round(top - L.h * 0.40)), bh = Math.max(4, Math.min(fit.h - by, Math.round(top + L.h * 0.12) - by));
          var id = cm.getImageData(bx, by, bw, bh), d = id.data, m0 = Math.round(bw * 0.08), cnt = [];
          for (var y = 0; y < bh; y++) { var c = 0; for (var x = m0; x < bw - m0; x++) if (d[(y * bw + x) * 4 + 3] > 100) c++; cnt.push(c); }
          /* the opening continues ABOVE its box (side rims still crossing those rows, nothing long across) only when a
             bar splits the lens: then the band at the box's top edge is that bar -- the far temple -- and goes. A normal
             lens has nothing above its top rim (outside the frame), so it is never touched. */
          var innerW = bw - 2 * m0, topRow = top - by;
          var a0 = Math.max(0, Math.round(topRow - L.h * 0.20)), a1 = Math.max(0, Math.round(topRow - L.h * 0.08));
          var above = cnt.slice(a0, a1).sort(function (u, v) { return u - v; }), med = above.length ? above[above.length >> 1] : 0;
          /* or (the narrow far lens): the real top rim a little higher up, with clear glass between it and the bar */
          var rimAbove = false;
          for (var ry = Math.max(0, Math.round(topRow - L.h * 0.38)); ry < Math.max(0, Math.round(topRow - L.h * 0.12)); ry++) {
            if (cnt[ry] >= innerW * 0.45) { var clear = true;
              for (var qy = ry + 3; qy < Math.round(topRow - L.h * 0.07); qy++) if (cnt[qy] > innerW * 0.15) { clear = false; break; }
              if (clear) { rimAbove = true; break; } } }
          if (above.length && ((med >= 6 && med < innerW * 0.3) || rimAbove)) {
            var c0 = Math.max(0, Math.round(topRow - L.h * 0.06)), c1 = Math.min(bh, Math.round(topRow + L.h * 0.10));
            for (var yy = c0; yy < c1; yy++) for (var xx = m0; xx < bw - m0; xx++) d[(yy * bw + xx) * 4 + 3] = 0;
            cm.putImageData(id, bx, by);
          }
        });
      } catch (e) {}
      /* B. THE NEAR TEMPLE RESTS ON THE EAR: it is lifted out of the picture and drawn again turned slightly down about its
         hinge, so that at the ear it is at eye level (the top of the ear) instead of up at the hinge's height. */
      /* d17.75 (shop, 7 Oct: "the centre part is not clean"): whatever shows THROUGH the lenses in the 30° photo -- the far
         arm, its tip, solid glass -- is behind the face on a real head. Each lens opening is cleared inside, keeping a
         margin of 8% so the rim itself is never touched. */
      /* ... and the far arm seen BETWEEN the lenses, under the bridge (behind the nose on a real head): in the gap between
         the two lenses, the bars running across it are found; the top one inside the lens height is the bridge and stays
         (a brow bar above the lenses is not even looked at); a thin bar below it is the far arm and goes. */
      if (!RC) try {
        var F = fit.far, N = fit.near;
        if (F && N && F.w > 8 && N.w > 8) {   /* (d17.80: light glass is cleared only between the bridge and that bar -- the clear nose pads hang lower) */
          var lft = F.cx < N.cx ? F : N, rgt = F.cx < N.cx ? N : F;
          var gx0 = Math.round(lft.cx + lft.w / 2 + 2), gx1 = Math.round(rgt.cx - rgt.w / 2 - 2), gw = gx1 - gx0;
          var top = Math.round(Math.min(F.cy - F.h / 2, N.cy - N.h / 2)), bot = Math.round(Math.max(F.cy, N.cy) + Math.min(F.h, N.h) * 0.1);
          top = Math.max(0, top); bot = Math.min(fit.h, bot);
          if (gw > 6 && bot - top > 6) {
            /* the frame's own darkness, from the near rim; light see-through glass in the gap does not count as a bar */
            var lums = [], nd = cm.getImageData(0, 0, fit.w, fit.h).data;
            for (var ang = 0; ang < 72; ang++) { var tt = ang / 72 * Math.PI * 2;
              for (var rr2 = 1.03; rr2 <= 1.12; rr2 += 0.03) { var px2 = Math.round(N.cx + Math.cos(tt) * N.w / 2 * rr2), py2 = Math.round(N.cy + Math.sin(tt) * N.h / 2 * rr2);
                if (px2 < 0 || py2 < 0 || px2 >= fit.w || py2 >= fit.h) continue; var o4 = (py2 * fit.w + px2) * 4; if (nd[o4 + 3] > 160) lums.push(0.3 * nd[o4] + 0.59 * nd[o4 + 1] + 0.11 * nd[o4 + 2]); } }
            lums.sort(function (p, q) { return p - q; });
            var fLum = lums.length ? lums[lums.length >> 1] : 60, darkFrame = fLum < 130;
            var gd = cm.getImageData(gx0, top, gw, bot - top).data, gr = [], gh = bot - top;
            var isBar = function (o) { return gd[o + 3] > 100 && (!darkFrame || (0.3 * gd[o] + 0.59 * gd[o + 1] + 0.11 * gd[o + 2]) < fLum + 55); };
            for (var gy = 0; gy < gh; gy++) { var gn = 0; for (var gx = 0; gx < gw; gx++) if (isBar((gy * gw + gx) * 4)) gn++; gr.push(gn); }
            var bands = [], inB = false, b0 = 0;
            for (var gy2 = 0; gy2 <= gh; gy2++) { var on = gy2 < gh && gr[gy2] > gw * 0.6; if (on && !inB) { inB = true; b0 = gy2; } else if (!on && inB) { inB = false; bands.push([b0, gy2 - 1]); } }
            var thinMax = Math.min(F.h, N.h) * 0.12;
            bands = bands.filter(function (b) { return (b[1] - b[0] + 1) <= thinMax; });
            if (bands.length >= 2) {
              cm.save(); cm.globalCompositeOperation = 'destination-out';
              var rimT = Math.max(3, Math.round(Math.min(F.h, N.h) * 0.045));            /* keep clear of the two rims */
              for (var bi2 = 1; bi2 < bands.length; bi2++) cm.fillRect(gx0 + rimT, top + bands[bi2][0] - 2, Math.max(0, gw - 2 * rimT), bands[bi2][1] - bands[bi2][0] + 5);
              cm.restore();
              if (darkFrame) {                                    /* the light glass left between the bridge and that arm goes too */
                var cy0 = bands[0][1] + 1, cy1 = Math.min(gh, bands[bands.length - 1][1] + 5), im2 = cm.getImageData(gx0, top + cy0, gw, Math.max(1, cy1 - cy0)), d2 = im2.data;
                for (var q2 = 0; q2 < d2.length; q2 += 4) if (d2[q2 + 3] > 0 && (0.3 * d2[q2] + 0.59 * d2[q2 + 1] + 0.11 * d2[q2 + 2]) >= fLum + 55) d2[q2 + 3] = 0;
                cm.putImageData(im2, gx0, top + cy0);
                /* d17.80: lower down are the clear silicone nose pads -- light, so they are made see-through (as they are) */
                var py0 = top + cy1, ph = Math.max(1, bot - py0 + Math.round(Math.min(F.h, N.h) * 0.25));
                var im3 = cm.getImageData(gx0 - Math.round(gw * 0.3), py0, Math.round(gw * 1.6), Math.min(fit.h - py0, ph)), d3 = im3.data;
                for (var q3 = 0; q3 < d3.length; q3 += 4) if (d3[q3 + 3] > 80 && (0.3 * d3[q3] + 0.59 * d3[q3 + 1] + 0.11 * d3[q3 + 2]) >= fLum + 55) d3[q3 + 3] = 80;
                cm.putImageData(im3, gx0 - Math.round(gw * 0.3), py0);
              }
            }
          }
        }
      } catch (e) {}
      /* d17.77 (shop, 7 Oct: "keep the far temple a little from the hinge, so it looks like it goes back behind the head,
         not cut at the hinge"): the far end piece's height is read, and the first ~7 mm of the far temple behind it is
         kept from the photo -- fading out as it goes behind the face -- although the far lens is cleared inside. */
      var farStub = null;
      /* d17.79 (shop: "don't cut it at the edge -- keep 5 to 6 mm more, then it looks natural"): the far temple keeps
         its first 5.5 mm behind the hinge, fading out; the rest across the demo goes */
      var FAR_STUB_ON = true;
      try {
        var Fs = fit.far, Ns = fit.near;
        if (FAR_STUB_ON && Fs && Ns && Fs.w > 8 && mmpp > 0) {
          var outS = Fs.cx < Ns.cx ? -1 : 1, edgeF = Fs.cx + outS * Fs.w / 2;
          var ex0 = Math.round(outS > 0 ? edgeF + 2 : edgeF - 2 - Fs.w * 0.2), ew = Math.max(2, Math.round(Fs.w * 0.2));
          var ey0 = Math.max(0, Math.round(Fs.cy - Fs.h * 0.6)), eh = Math.max(2, Math.round(Fs.h * 0.7));
          ex0 = Math.max(0, Math.min(fit.w - 2, ex0)); ew = Math.min(fit.w - ex0, ew); eh = Math.min(fit.h - ey0, eh);
          var ed = cm.getImageData(ex0, ey0, ew, eh).data, er = [];
          for (var yy3 = 0; yy3 < eh; yy3++) { var cnt = 0; for (var xx3 = 0; xx3 < ew; xx3++) if (ed[(yy3 * ew + xx3) * 4 + 3] > 100) cnt++; er.push(cnt); }
          var bestT = -1, bestB = -1, curT = -1;
          for (var yy4 = 0; yy4 <= eh; yy4++) { var onr = yy4 < eh && er[yy4] > ew * 0.5;
            if (onr && curT < 0) curT = yy4; else if (!onr && curT >= 0) { if (bestT < 0 || (yy4 - curT) > (bestB - bestT + 1)) { bestT = curT; bestB = yy4 - 1; } curT = -1; } }
          if (bestT >= 0 && (bestB - bestT + 1) <= Fs.h * 0.15) {
            var sT = ey0 + bestT - 2, sH = bestB - bestT + 5, sLen = Math.round(5.5 / mmpp);
            var sX = outS > 0 ? Math.round(edgeF - sLen) : Math.round(edgeF);
            sX = Math.max(0, sX); sLen = Math.min(fit.w - sX, sLen);
            if (sLen > 3 && sH > 2) {
              var snap = document.createElement('canvas'); snap.width = sLen; snap.height = sH;
              var kx = (cut.naturalWidth || cut.width) / fit.w, ky2 = (cut.naturalHeight || cut.height) / fit.h;   /* from the photo's own cut-out, before anything was cleared */
              var sx2 = snap.getContext('2d'); sx2.drawImage(cut, sX * kx, sT * ky2, sLen * kx, sH * ky2, 0, 0, sLen, sH);
              var gF = outS > 0 ? sx2.createLinearGradient(sLen, 0, 0, 0) : sx2.createLinearGradient(0, 0, sLen, 0);
              gF.addColorStop(0, 'rgba(0,0,0,1)'); gF.addColorStop(0.6, 'rgba(0,0,0,1)'); gF.addColorStop(1, 'rgba(0,0,0,0)');
              sx2.globalCompositeOperation = 'destination-in'; sx2.fillStyle = gF; sx2.fillRect(0, 0, sLen, sH);
              farStub = { c: snap, x: sX, y: sT };
            }
          }
        }
      } catch (e) { farStub = null; }
      if (!RC) try {
        cm.save(); cm.globalCompositeOperation = 'destination-out'; cm.fillStyle = '#000';
        [fit.near, fit.far].forEach(function (L) {
          if (!L || !(L.w > 4) || !(L.h > 4)) return;
          /* d17.80 (shop: "where is the nose pad"): the inner side of each lens, from just above the middle to near the
             bottom, is left alone -- the nose pads sit there. The ellipse is cleared except that wedge. */
          var O = L === fit.near ? fit.far : fit.near, inward = O && O.cx > L.cx ? 1 : -1;
          var a0 = Math.atan2(-0.45, 0.89 * inward), a1 = Math.atan2(0.85, 0.53 * inward);   /* the pad wedge, in angles */
          cm.save(); cm.beginPath(); cm.ellipse(L.cx, L.cy, L.w / 2 * 0.92, L.h / 2 * 0.92, 0, 0, Math.PI * 2); cm.clip();
          cm.beginPath(); cm.rect(0, 0, fit.w, fit.h);                                  /* everything... */
          cm.moveTo(L.cx, L.cy);                                                         /* ...minus the pad wedge (outer 30%) */
          var R = Math.max(L.w, L.h);
          var st = inward > 0 ? a0 : a1, en = inward > 0 ? a1 : a0;
          cm.arc(L.cx, L.cy, R, st, en, false); cm.closePath();
          cm.fill('evenodd'); cm.restore();
          /* the centre of the wedge (inner 70%) is still cleared */
          cm.beginPath(); cm.ellipse(L.cx, L.cy, L.w / 2 * 0.92 * 0.7, L.h / 2 * 0.92 * 0.7, 0, 0, Math.PI * 2); cm.fill();
        });
        cm.restore();
      } catch (e) {}
      if (farStub) try { cm.drawImage(farStub.c, farStub.x, farStub.y); } catch (e) {}
      var armCv = null, hinge = null, armTurn = 0;
      try {
        var aSide = fit.near.cx > fit.far.cx ? 1 : -1, eX = fit.near.cx + aSide * (nW / 2);
        var hingeY = (bandTop + bandBot) / 2;
        hinge = [eX, hingeY];
        armCv = document.createElement('canvas'); armCv.width = fit.w; armCv.height = fit.h;
        var ac = armCv.getContext('2d'), x0a = aSide > 0 ? Math.round(eX + nW * 0.02) : 0, wa = aSide > 0 ? fit.w - x0a : Math.round(eX - nW * 0.02);
        if (wa > 2) {
          ac.drawImage(cutM, x0a, 0, wa, fit.h, x0a, 0, wa, fit.h);
          cm.save(); cm.globalCompositeOperation = 'destination-out'; cm.fillRect(x0a, 0, wa, fit.h); cm.restore();
          /* where the hinge lands on the face, and how far down the ear's top is from there */
          var cr0 = Math.cos(roll), sr0 = Math.sin(roll);
          var hdx = (eX - fit.bridge[0]) * s, hdy = (hingeY - fit.bridge[1]) * s;
          var hFaceX = ax + hdx * cr0 - hdy * sr0, hFaceY = ayLine + hdx * sr0 + hdy * cr0;
          var earX = (nearIsRight ? face.cheekL : face.cheekR) ? (nearIsRight ? face.cheekL : face.cheekR).x : earNear.x;
          var hairP = nearIsRight ? (face.templeL || face.cheekL) : (face.templeR || face.cheekR);
          if (hairP && isFinite(hairP.x)) earX = hairP.x + (nearIsRight ? 1 : -1) * Math.abs(earX - hairP.x) * 0.5;   /* d17.74: the hair line, as the backup arm */
          var run = Math.abs(earX - hFaceX), drop = (pupilNear.y + (face.irisPx || 10) * 0.3) - hFaceY;
          if (run > 10 && drop > 0) armTurn = aSide * Math.atan2(drop, run);
        } else armCv = null;
      } catch (e) { armCv = null; }
      lx.save(); lx.translate(ax, ayLine); lx.rotate(roll); lx.scale(s, s); lx.translate(-fit.bridge[0], -fit.bridge[1]);
      lx.drawImage(cutM, 0, 0, fit.w, fit.h);
      if (armCv && hinge && (usePhotoArm || !temples.length)) { lx.translate(hinge[0], hinge[1]); lx.rotate(armTurn); lx.translate(-hinge[0], -hinge[1]); lx.drawImage(armCv, 0, 0, fit.w, fit.h); }
      lx.restore();
      if (temples.length && !usePhotoArm) try { templeInfo = drawRealTemple(lx, temples, { ax: ax, ayLine: ayLine, roll: roll, s: s, fit: fit, nearIsRight: nearIsRight, face: face, perMM: perMM, templeMM: Number(o.sizes && o.sizes.temple) || 140, yaw: yaw, hingeY: armYfound, armThick: armThickFound }); } catch (e) {}
      if (o.debugMask) o.debugMask.canvas = cutM;

      /* 4. the near arm runs straight back to the EAR (shop, 5 Oct): the ear's front edge is the face point at ear level
         (234 / 454) -- further back than the temple point at eye level, where the arm used to stop. It is not drawn lower
         than that, nor past the ear, nor bent behind it; over the last stretch it slips into the hair. */
      var cheekNear = nearIsRight ? face.cheekL : face.cheekR;
      if (cheekNear && Math.abs(cheekNear.x - pupilNear.x) > Math.abs(earNear.x - pupilNear.x)) earNear = cheekNear;
      var dist = Math.abs(earNear.x - pupilNear.x);
      var f0 = pupilNear.x + sgn * FADE_START * dist, f1 = pupilNear.x + sgn * (FADE_END * dist + 0.04 * (face.faceW || dist));
      if (usePhotoArm || temples.length) {                    /* d17.74: the arm reaches the hair line and slips into the hair over its last fifth */
        var hairN = nearIsRight ? (face.templeL || face.cheekL) : (face.templeR || face.cheekR);
        if (hairN && isFinite(hairN.x)) {
          /* d17.75 (shop: "let it go 3 to 4 mm further, then cut"): 4 mm past the hair line before it fades out */
          var endN = hairN.x + sgn * (Math.abs(earNear.x - hairN.x) * 0.5 + 4 * perMM), dN = Math.abs(endN - pupilNear.x);
          f0 = pupilNear.x + sgn * dN * 0.86; f1 = pupilNear.x + sgn * dN * 1.0;
        }
      }
      var mask = document.createElement('canvas'); mask.width = W; mask.height = H;
      var mx = mask.getContext('2d'), g = mx.createLinearGradient(f0, 0, f1, 0);
      g.addColorStop(0, 'rgba(0,0,0,1)'); g.addColorStop(1, 'rgba(0,0,0,0)');
      mx.fillStyle = g; mx.fillRect(0, 0, W, H);
      lx.globalCompositeOperation = 'destination-in'; lx.drawImage(mask, 0, 0);

      var out = document.createElement('canvas'); out.width = W; out.height = H;
      var ox = out.getContext('2d'); ox.imageSmoothingEnabled = true; if ('imageSmoothingQuality' in ox) ox.imageSmoothingQuality = 'high';
      ox.drawImage(o.faceImg, 0, 0, W, H); ox.drawImage(layer, 0, 0);

      /* how well does the near lens sit on the near pupil? (a check, not a correction) */
      var cr = Math.cos(roll), sr = Math.sin(roll), dxc = (fit.near.cx - fit.bridge[0]) * s, dyc = (fit.near.cy - fit.bridge[1]) * s;
      var lensX = ax + dxc * cr - dyc * sr, lensY = ayLine + dxc * sr + dyc * cr;
      var offX = lensX - pupilNear.x, offY = lensY - pupilNear.y;
      var report = {
        engine: VERSION, yaw: +yaw.toFixed(3), yawWindow: [YAW_MIN, YAW_MAX], rollDeg: +(roll * 180 / Math.PI).toFixed(1),
        nearSide: wantSide, farStub: farStub ? { x: Math.round(farStub.x), y: Math.round(farStub.y), w: farStub.c.width, h: farStub.c.height } : null, armCheck: armDbg, arm: usePhotoArm ? '30-degree photo' : (templeInfo ? '90-degree backup' : 'none'), temple: templeInfo, fitSource: fit.source || '?', perMM: +perMM.toFixed(3), perMMsource: perMMsrc,
        mmPerCutPx: +mmpp.toFixed(4), mmPerCutPxSource: mmppSrc, scale: +s.toFixed(4),
        anchor: { x: Math.round(ax), y: Math.round(ayLine) },
        nearLensVsPupil: { dxPx: Math.round(offX), dyPx: Math.round(offY), dxMM: +(offX / perMM).toFixed(1), dyMM: +(offY / perMM).toFixed(1) },
        earRootDistPx: Math.round(dist), armFadePx: [Math.round(f0), Math.round(f1)], notes: notes
      };
      if (Math.abs(report.nearLensVsPupil.dxMM) > 14) report.notes.push('near lens is far from the near eye: frame size or head turn may be off');
      return { canvas: out, report: report };
    } catch (e) { return { error: 'failed', advice: 'Something went wrong placing the frame.', detail: String(e && e.message || e) }; }
  }

  global.VG45 = { VERSION: VERSION, YAW_MIN: YAW_MIN, YAW_MAX: YAW_MAX, fitPointsFromImage: fitPointsFromImage, usableFit: usableFit, fitFor: fitFor,
                  perMMFromFace: perMMFromFace, frontReference: frontReference, templeStrip: templeStrip, templeUrls: templeUrls, loadTemples: loadTemples, pickTemple: pickTemple, paintTemple: paintTemple, headTurn: headTurn, pickView: pickView, fit45: fit45, ADVICE: ADVICE };
})(typeof window !== 'undefined' ? window : this);

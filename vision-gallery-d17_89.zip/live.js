/* VG LIVE TRY-ON (test) -- d17.58, shop 6 Oct.
   The camera stays on and the frame follows the face. When the head turns, the picture switches between the shop's
   REAL cut-outs: 0-~20 degrees the front cut-out, ~25-55 degrees the robot's 45-degree cut-out (with its fit points),
   with a 0.1-second fade so there is no jump. Nothing is invented: every angle shown is a studio photo of the frame.
   Only for the shop while testing: open the shop with ?live=1 (this tab only); ?live=0 ends it. */
(function (g) {
  'use strict';
  try { if (/[?&]live=1\b/.test(g.location.search)) g.sessionStorage.setItem('vg_live', '1'); if (/[?&]live=0\b/.test(g.location.search)) g.sessionStorage.setItem('vg_live', '0'); } catch (e) {}
  /* d17.59 (shop: "set the entire flow first"): LIVE VIDEO is offered on every try-on now; ?live=0 hides it in a tab */
  function enabled() { try { return g.sessionStorage.getItem('vg_live') !== '0'; } catch (e) { return true; } }
  var FRONT_MAX = 0.30, SIDE_MIN = 0.42, FADE_MS = 100, STEP_MS = 70;
  var S = { on: false, p: null, video: null, stream: null, cv: null, busy: false, last: 0, zone: '', prev: null, fadeAt: 0, cuts: {}, mirror: true };
  function load(src) { return new Promise(function (res, rej) { var i = new Image(); i.crossOrigin = 'anonymous'; i.onload = function () { res(i); }; i.onerror = rej; i.src = src; }); }
  function widthMM(p) { return (typeof g.frameWidthMM === 'function') ? g.frameWidthMM(p) : 140; }
  /* d17.63: a 45 cut-out is enough -- the page finds the fit points itself when the robot stored none (the robot rule's twin) */
  function has45(p) { return !!(p.tryOnAngleUrl || p.tryOnAngleRUrl || p.tryOnSideUrl); }
  async function prepare(p) {
    var c = {};
    var front = (typeof g.tryOnURL === 'function') ? g.tryOnURL(p) : p.tryOnUrl;
    c.front = g.VGOnFace.cutout(await load(front), { alreadyCut: true, fullRim: /full/i.test(String(p.rim || '')) });
    c.frontImg = await load(front);
    if (p.tryOnAngleUrl) try { c.a = await load(p.tryOnAngleUrl); } catch (e) {}
    if (p.tryOnAngleRUrl) try { c.b = await load(p.tryOnAngleRUrl); } catch (e) {}
    /* d17.65: the TEMPLE from the side (90) cut-out -- the real thick arm, to swing out when the head turns */
    /* d17.69: BOTH 90 photos when the shop took two (left temple, right temple) -- each side gets its own arm, logo the right way round */
    /* d17.89: the real arm for the front view, from the 30-degree cut-out */
    try { var A30 = c.a || c.b; c.realArm = (A30 && g.VGOnFace.realArmFrom30) ? g.VGOnFace.realArmFrom30(A30, c.front, widthMM(p)) : null; } catch (e) { c.realArm = null; }
    c.temple = [];
    var tu = (g.VG45 && g.VG45.templeUrls) ? g.VG45.templeUrls(p) : (p.tryOnSideUrl ? [p.tryOnSideUrl] : []);
    for (var ti = 0; ti < tu.length; ti++) try { var ts = templeStrip(await load(tu[ti])); if (ts) c.temple.push(ts); } catch (e) {}
    if (!c.temple.length) c.temple = null;
    return c;
  }
  /* the temple out of the side cut-out: the front is the tall slab at one end; the arm is the long low strip after it */
  function templeStrip(img) {
    if (g.VG45 && g.VG45.templeStrip) return g.VG45.templeStrip(img);          /* d17.73: one arm reader for the whole site */
    var W = img.naturalWidth, H = img.naturalHeight, c = document.createElement('canvas'); c.width = W; c.height = H;
    var x = c.getContext('2d'); x.drawImage(img, 0, 0); var d = x.getImageData(0, 0, W, H).data;
    var top = new Int16Array(W), run = new Int16Array(W), hgt = new Int16Array(W), maxH = 0;
    for (var cx = 0; cx < W; cx++) { var t = -1, bt = -1, rl = 0; for (var y = 0; y < H; y++) { var on = d[(y * W + cx) * 4 + 3] > 100; if (on) { if (t < 0) t = y; bt = y; if (rl >= 0) rl++; } else if (t >= 0 && rl > 0) { rl = -rl; } }
      top[cx] = t; run[cx] = Math.abs(rl); hgt[cx] = t < 0 ? 0 : bt - t + 1; if (hgt[cx] > maxH) maxH = hgt[cx]; }
    if (maxH < 10) return null;
    /* the front slab is the tall block at ONE end (the first 30% or the last 30% of the width) */
    var tall = function (i) { return hgt[i] >= maxH * 0.6; };
    var leftTall = 0, rightTall = 0; for (var i = 0; i < Math.round(W * 0.3); i++) { if (tall(i)) leftTall++; if (tall(W - 1 - i)) rightTall++; }
    var dir = leftTall >= rightTall ? 1 : -1;                     /* +1: slab on the left, arm runs to the right */
    var e = dir > 0 ? 0 : W - 1; while (e >= 0 && e < W && tall(e)) e += dir;        /* first column past the slab */
    var a0 = dir > 0 ? e : 0, a1 = dir > 0 ? W : e + 1;
    /* the arm = the TOP run of each arm column (the second, lower arm of an opened frame is left out) */
    var cols = []; for (var k = a0; k < a1; k++) if (hgt[k] > 0 && run[k] > 0) cols.push(k);
    if (cols.length < 10) return null;
    /* d17.72 (VG-1019): the arm's thickness is read along its MIDDLE (the hinge end carries the nose pad and rims hanging
       below it), and every column is kept to that thickness (+60%), so a pad or the bent tip never makes the arm a block */
    var mid = cols.slice(Math.round(cols.length * 0.25), Math.max(Math.round(cols.length * 0.25) + 3, Math.round(cols.length * 0.65))).map(function (k) { return run[k]; }).sort(function (p, q) { return p - q; });
    var thick = mid.length ? mid[mid.length >> 1] : 0, lim = Math.max(3, Math.round(thick * 1.6));
    var rk = function (k) { return Math.min(run[k], lim); };
    var y0 = H, y1 = 0; cols.forEach(function (k) { if (top[k] < y0) y0 = top[k]; if (top[k] + rk(k) > y1) y1 = top[k] + rk(k); });
    var out = document.createElement('canvas'); out.width = cols[cols.length - 1] - cols[0] + 1; out.height = Math.max(2, y1 - y0); var ox = out.getContext('2d');
    cols.forEach(function (k) { ox.drawImage(c, k, top[k], 1, rk(k), k - cols[0], top[k] - y0, 1, rk(k)); });
    var hc = dir > 0 ? cols.slice(0, Math.max(3, Math.round(cols.length * 0.08))) : cols.slice(-Math.max(3, Math.round(cols.length * 0.08)));
    var ht = hc.map(function (k) { return top[k]; }).sort(function (p, q) { return p - q; });
    return { canvas: out, hingeFirst: dir > 0, slabH: maxH, thickPx: thick || out.height, lenPx: out.width, hingeYpx: (ht.length ? ht[ht.length >> 1] : y0) - y0 + (thick || 2) / 2 };
  }
  /* d17.65 THE HYBRID SIDE VIEW (shop: "the front sits on the nose -- add the side to it and let it move with me"):
     the front cut-out stays where the front engine put it (on the nose), and the REAL temple from the side photo swings
     out from the near hinge towards the ear as the head turns; the far temple stays hidden behind the head. */
  function drawTemple(canvas, dbg, face, p, temple) {
    var r = dbg && dbg.frameRect; if (!r || !temple) return;
    var yaw = face.yaw || 0, a = Math.abs(yaw); if (a < 0.12) return;
    var th = Math.min(35 * Math.PI / 180, a * (Math.PI / 4) / 0.9);                   /* d17.66 (shop): we show up to about 35 degrees, no further */
    var nearRight = yaw > 0;                                                             /* nose points left -> the near side is the right of the picture */
    var hx = r.cx + (nearRight ? 1 : -1) * r.w * 0.49, hy = r.cy - r.h * 0.30;          /* the hinge: outer top corner of the near rim */
    var mmppFront = (typeof g.frameWidthMM === 'function' ? (g.frameWidthMM(p) || 0) : 0) / r.w || (p.size && p.size.lens ? (2 * Number(p.size.lens) + Number(p.size.bridge || 18) + 11) / r.w : 135 / r.w);   /* d17.86: the same front width as the try-on */   /* mm per picture px of the frame */
    var templeMM = Number(p.size && p.size.temple) || 140;
    var lenPx = templeMM / mmppFront * Math.sin(th) * 0.92;                              /* foreshortened by the turn, a little inside the ear */
    /* d17.66 (shop): the temple goes back as far as the HAIR (the temple point at eye level), not all the way to the ear */
    var hairPt = nearRight ? (face.templeL || face.cheekL) : (face.templeR || face.cheekR);
    if (hairPt && hairPt.x != null) { var toHair = Math.abs(hairPt.x - hx) * 1.08; if (toHair > 10) lenPx = Math.min(lenPx, toHair); }
    var drop = (nearRight ? face.pupilL : face.pupilR); var dy = drop && drop.y != null ? (drop.y - hy) * 0.6 : r.h * 0.12;   /* down to the ear's top */
    var drawDir = nearRight ? 1 : -1;
    var pick = pickTemple(temple, drawDir); if (!pick) return;
    var thickPx = (pick.t.thickPx / pick.t.slabH) * r.h * 1.15;                         /* the arm's real thickness, from the side photo */
    var x = canvas.getContext('2d'); x.save(); x.translate(hx, hy); x.rotate(r.roll + Math.atan2(dy, lenPx) * (nearRight ? 1 : -1));
    x.globalAlpha = 0.96;
    if (g.VG45 && g.VG45.paintTemple) g.VG45.paintTemple(x, pick, drawDir, lenPx, thickPx, 0.8);   /* d17.73: true thickness, fades only over the last fifth */
    else paintTemple(x, pick, drawDir, lenPx, thickPx, 0.8);
    x.restore();
    S.lastTemple = { mirrored: pick.mirror, drawDir: drawDir };
  }
  /* the twins of VG45.pickTemple / paintTemple, for a page without try45.js */
  function pickTemple(temples, drawDir) {
    var list = Array.isArray(temples) ? temples.filter(Boolean) : (temples ? [temples] : []);
    if (!list.length) return null;
    for (var i = 0; i < list.length; i++) if ((list[i].hingeFirst ? 1 : -1) === drawDir) return { t: list[i], mirror: false };
    return { t: list[0], mirror: true };
  }
  function paintTemple(ctx, pick, drawDir, len, thick, fadeFrom) {
    var t = pick.t, photoDir = t.hingeFirst ? 1 : -1, cw = t.canvas.width, ch = t.canvas.height;
    var ky = Math.max(0.05, thick / Math.max(1, t.thickPx || ch));
    var tmp = document.createElement('canvas'); tmp.width = Math.max(2, Math.round(len)); tmp.height = Math.max(2, Math.round(ch * ky));
    var sw = Math.max(2, Math.round(cw * 0.62)), sx = photoDir > 0 ? 0 : cw - sw;
    var tx = tmp.getContext('2d'); tx.drawImage(t.canvas, sx, 0, sw, ch, 0, 0, tmp.width, tmp.height);
    var gr = photoDir > 0 ? tx.createLinearGradient(0, 0, tmp.width, 0) : tx.createLinearGradient(tmp.width, 0, 0, 0);
    gr.addColorStop(0, 'rgba(0,0,0,1)'); gr.addColorStop(fadeFrom, 'rgba(0,0,0,1)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
    tx.globalCompositeOperation = 'destination-in'; tx.fillStyle = gr; tx.fillRect(0, 0, tmp.width, tmp.height);
    if (pick.mirror) ctx.scale(-1, 1);
    var hy = (t.hingeYpx != null ? t.hingeYpx : (t.thickPx || ch) / 2) * ky;
    ctx.drawImage(tmp, photoDir > 0 ? 0 : -tmp.width, -hy);
  }

  /* one picture: the face in `src` (a canvas or image), the zone it is in, and the frame drawn on it */
  async function step(src, p, cuts, frontRef, given) {
    var face = given !== undefined ? given : await g.VGOnFace.findFace(src, { runs: 1 });
    if (!face || face.estimated) return { zone: 'none' };
    var a = Math.abs(face.yaw || 0), zone = a <= FRONT_MAX ? 'front' : (a >= SIDE_MIN && has45(p) ? 'side' : (S.zone || 'front'));
    var out = null;
    /* d17.64: THE FRAME'S SIZE ON A TURNED FACE comes from the same face seen STRAIGHT a moment ago (the front rule:
       iris = 12 mm), carried over by the face's length, which a turn does not shorten. Without it the side view guessed
       the scale from a half-turned iris and drew the frame far too big, off the nose. */
    /* d17.87: with the face locked, the turned views carry the LOCKED scale, not one picture's iris */
    if (zone === 'front' && S.perMMNow > 0) { S.frontFace = face; S.frontPerMM = S.perMMNow; }
    else if (zone === 'front' && face.irisUsed && face.irisPx > 0) { S.frontFace = face; S.frontPerMM = g.VG45 ? g.VG45.perMMFromFace(face) : 0; }
    var ref = frontRef ? Object.assign({}, frontRef) : {};
    if (S.frontFace && S.frontPerMM > 0) { ref.face = S.frontFace; ref.perMM = S.frontPerMM; }
    if (zone === 'side' && cuts.temple) {
      /* the hybrid: front on the nose + the real temple swinging out */
      var dbg = {}; var o2 = g.VGOnFace.compose(src, face, cuts.front, widthMM(p), { drawSyntheticArms: false, debug: dbg, perMM: S.perMMNow > 0 ? S.perMMNow : undefined });
      out = o2 && (o2.canvas || o2);
      if (out) try { drawTemple(out, dbg, face, p, cuts.temple); } catch (e) {}
    }
    if (!out && zone === 'side' && g.VG45) {
      var sizes = { lens: p.size && p.size.lens, bridge: p.size && p.size.bridge };
      var tries = [[cuts.a, p.tryOnAngleFit], [cuts.b, p.tryOnAngleRFit]];
      for (var i = 0; i < tries.length && !out; i++) {
        if (!tries[i][0]) continue;
        var r = g.VG45.fit45({ faceImg: src, face: face, cutImg: tries[i][0], fit: tries[i][1], frontRef: ref, sizes: sizes });
        if (r && r.canvas) out = r.canvas;
      }
      if (!out) zone = 'front';
    }
    if (!out) { var o = g.VGOnFace.compose(src, face, cuts.front, widthMM(p), { drawSyntheticArms: false, perMM: S.perMMNow > 0 ? S.perMMNow : undefined,
      armsToHair: !!cuts.realArm, realArm: cuts.realArm || undefined }); out = o && (o.canvas || o); }        /* d17.89: front view with the real arm */
    return { zone: zone, canvas: out, face: face };
  }

  /* d17.87 THE FACE LOCK: measured over the first second (eyes open, straight on), then locked -- see VGOnFace.faceLock */
  function lockStep(face) {
    if (!S.lock && g.VGOnFace.faceLock) S.lock = g.VGOnFace.faceLock({ pdMM: (typeof g.knownPD === 'function') ? g.knownPD() : 0 });
    if (!S.lock) { S.perMMNow = 0; return; }
    var was = S.lock.locked();
    /* d17.88 THE OVAL: measuring only counts while the face sits in the oval at a good distance, straight, eyes open */
    S.hint = was ? '' : gateHint(face);
    if (face && !S.hint) S.lock.add(face, Date.now());
    else if (face && !face.estimated) S.lock.add(Object.assign({}, face, { eyeOpen: 0 }), Date.now());   /* seen, not measured */
    S.perMMNow = face ? S.lock.perMM(face) : 0;
    if (!was && S.lock.locked()) {
      try { g.sessionStorage.setItem('vg_face_lock', JSON.stringify(Object.assign(S.lock.lock(), { at: Date.now() }))); } catch (e) {}
      S.adviceFor = '';
    }
    if (S.lock.locked() && face && S.p && S.cuts && S.cuts.front && S.adviceFor !== S.p.id) advise(face);
  }
  /* the size advice, ONCE per frame from the locked measurement -- it does not change while the customer moves.
     d17.88: in plain words, the customer's own frame size beside it, and their own glasses first when they gave them */
  function advise(face) {
    S.adviceFor = S.p.id; var el = document.getElementById('vgLiveFit'); if (!el) return;
    try {
      var r = (typeof g.glassesFit === 'function' && g.glassesFit(S.p)) || g.VGOnFace.fitReport(face, S.cuts.front, widthMM(S.p), { perMM: S.perMMNow });
      S.advice = r; el.hidden = !r; if (!r) return;
      var word = typeof g.fitWord === 'function' ? g.fitWord(r.status) : r.status;
      var mine = '', gl = typeof g.myGlasses === 'function' ? g.myGlasses() : null;
      if (gl) mine = 'Your size ' + gl.lens + '\u25a1' + gl.bridge;
      else if (r.faceMM && typeof g.bandOfWidth === 'function') { var b = g.bandOfWidth(r.faceMM); if (b) mine = 'Your size: ' + b.name; }
      el.textContent = word + (mine ? ' \u00b7 ' + mine : '');
      el.className = 'vgl-fit ' + (/^GOOD/.test(r.status) ? 'ok' : 'chk');
    } catch (e) { el.hidden = true; }
  }
  /* what to tell the customer while measuring (empty = all good, measuring) */
  function gateHint(face) {
    if (!face || face.estimated) return 'Put your face in the oval';
    var W = face.w || 0, frac = W ? (face.faceW || 0) / W : 0.45;
    var cx = (face.pupilL && face.pupilR && W) ? ((face.pupilL.x + face.pupilR.x) / 2) / W : 0.5;
    if (frac && frac < 0.28) return 'Come a little closer';
    if (frac > 0.80) return 'Move the phone back a little';
    if (cx < 0.30 || cx > 0.70) return 'Move your face into the oval';
    if (Math.abs(face.yaw || 0) > 0.12) return 'Look straight at the camera';
    if (Math.abs(face.roll || 0) > 0.10) return 'Hold your head straight';
    if (face.eyeOpen != null && face.eyeOpen < 0.18) return 'Keep your eyes open';
    return '';
  }
  function lockLabel(zone) {
    var lbl = document.getElementById('vgLiveLbl'), ov = document.getElementById('vgLiveOval'), hint = document.getElementById('vgLiveHint');
    if (!S.lock) return;
    var locked = S.lock.locked(), pct = Math.round(S.lock.progress() * 100);
    if (lbl && !locked) lbl.textContent = 'MEASURING YOUR FACE ' + pct + '%';
    if (ov) {
      if (!locked) { ov.hidden = false; ov.className = 'vgl-oval' + (S.hint ? '' : ' ok'); if (hint) hint.textContent = S.hint || ('Hold still \u2014 measuring ' + pct + '%'); S.ovDoneAt = 0; }
      else if (!ov.hidden) { if (!S.ovDoneAt) { S.ovDoneAt = Date.now(); ov.className = 'vgl-oval ok'; if (hint) hint.textContent = '\u2713 Measured'; } else if (Date.now() - S.ovDoneAt > 1200) ov.hidden = true; }
    }
  }
  function draw(res) {
    var cv = S.cv, x = cv.getContext('2d'), now = performance.now();
    if (!res.canvas) return;
    if (cv.width !== res.canvas.width || cv.height !== res.canvas.height) { cv.width = res.canvas.width; cv.height = res.canvas.height; }
    if (res.zone !== S.zone && S.zone && S.prev) S.fadeAt = now;           /* the view changed: fade from the last picture */
    S.zone = res.zone;
    x.save(); if (S.mirror) { x.translate(cv.width, 0); x.scale(-1, 1); }
    var k = S.fadeAt ? Math.min(1, (now - S.fadeAt) / FADE_MS) : 1;
    if (k < 1 && S.prev) { x.globalAlpha = 1; x.drawImage(S.prev, 0, 0, cv.width, cv.height); x.globalAlpha = k; }
    x.drawImage(res.canvas, 0, 0, cv.width, cv.height); x.restore();
    if (k >= 1) S.fadeAt = 0;
    var keep = document.createElement('canvas'); keep.width = cv.width; keep.height = cv.height; keep.getContext('2d').drawImage(res.canvas, 0, 0); S.prev = keep;
    var lbl = document.getElementById('vgLiveLbl'); if (lbl) lbl.textContent = res.zone === 'side' ? 'SIDE VIEW' : 'FRONT';
  }
  async function ensureMesh() {
    if (S.mesh) return S.mesh;
    if (typeof g.FaceMesh === 'undefined' && g.loadFaceMesh) { try { await g.loadFaceMesh(); } catch (e) {} }
    if (typeof g.FaceMesh === 'undefined') return null;
    var m = new g.FaceMesh({ locateFile: function (f) { return (g.FACEMESH_BASE || 'https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh@0.4/') + f; } });
    m.setOptions({ maxNumFaces: 1, refineLandmarks: true, minDetectionConfidence: 0.5, minTrackingConfidence: 0.5 });
    m.onResults(function (r) { S.lm = (r && r.multiFaceLandmarks && r.multiFaceLandmarks[0]) || null; });
    try { if (m.initialize) await m.initialize(); } catch (e) {}
    S.mesh = m; return m;
  }
  function drawRaw(f) {                                   /* no face yet: still show the camera, never a black screen */
    var cv = S.cv, x = cv.getContext('2d');
    if (cv.width !== f.width || cv.height !== f.height) { cv.width = f.width; cv.height = f.height; }
    x.save(); if (S.mirror) { x.translate(cv.width, 0); x.scale(-1, 1); } x.drawImage(f, 0, 0); x.restore();
  }
  async function loop() {
    if (!S.on) return;
    var now = performance.now();
    if (!S.busy && now - S.last >= STEP_MS && S.video.readyState >= 2 && S.video.videoWidth > 0) {
      S.busy = true; S.last = now;
      try {
        var f = S.frame || (S.frame = document.createElement('canvas'));
        f.width = S.video.videoWidth; f.height = S.video.videoHeight; f.getContext('2d').drawImage(S.video, 0, 0);
        var face = null;
        if (S.mesh && S.cuts && S.cuts.front) {
          var sm = S.small || (S.small = document.createElement('canvas')); var k = Math.min(1, 480 / f.width); sm.width = Math.round(f.width * k); sm.height = Math.round(f.height * k);
          sm.getContext('2d').drawImage(f, 0, 0, sm.width, sm.height);
          S.lm = null; await S.mesh.send({ image: sm });
          if (S.lm) face = g.VGOnFace.faceFromLandmarks(S.lm, f.width, f.height, false);
        }
        lockStep(face);
        var res = face ? await step(f, S.p, S.cuts, S.frontRef, face) : { zone: 'none' };
        if (res.zone === 'none' || !res.canvas) { drawRaw(f); try { lockLabel('none'); } catch (e) {} var lb = document.getElementById('vgLiveLbl'); if (lb) lb.textContent = S.mesh ? 'LOOK AT THE CAMERA' : 'STARTING\u2026'; }
        else { draw(res); lockLabel(res.zone); var note = document.getElementById('vgLiveNote'); if (note) { var turned = Math.abs(face.yaw || 0) >= SIDE_MIN && !has45(S.p); note.hidden = !turned; if (turned) note.textContent = 'Side view coming soon for this frame'; } }
      } catch (e) {}
      S.busy = false;
    }
    requestAnimationFrame(loop);
  }
  function ui() {
    var box = document.getElementById('vgLive'); if (box) return box;
    box = document.createElement('div'); box.id = 'vgLive';
    box.innerHTML = '<div class="vgl-top"><b>LIVE VIDEO TRY-ON</b><span id="vgLiveLbl">STARTING\u2026</span><button type="button" id="vgLiveX">CLOSE</button></div>' +
      '<canvas id="vgLiveCv"></canvas><video id="vgLiveV" playsinline muted autoplay style="position:absolute;width:2px;height:2px;opacity:0;pointer-events:none;left:0;top:0"></video>' +
      '<div class="vgl-note" id="vgLiveNote" hidden></div>' +
      '<div class="vgl-fit" id="vgLiveFit" hidden></div>' +
      '<div class="vgl-oval" id="vgLiveOval" hidden><span id="vgLiveHint">Put your face in the oval</span></div>' +
      '<div class="vgl-strip" id="vgLiveStrip"></div>' +
      '<div class="vgl-bot"><button type="button" id="vgLiveAdd">ADD TO BASKET</button><button type="button" id="vgLiveShare">SHARE</button><button type="button" id="vgLiveShot">SAVE PHOTO</button></div>';
    var css = document.createElement('style');
    css.textContent = '#vgLive{position:fixed;inset:0;z-index:9500;background:#0C0B0A;color:#F4EFE6;display:flex;flex-direction:column}#vgLive[hidden]{display:none}' +
      '#vgLive .vgl-top,#vgLive .vgl-bot{display:flex;align-items:center;gap:10px;padding:10px 12px}#vgLive .vgl-top b{flex:1;letter-spacing:.08em}#vgLive .vgl-top span{color:#D9B26B;font-size:.75rem;letter-spacing:.1em}' +
      '#vgLive canvas{flex:1;min-height:0;width:100%;object-fit:contain}#vgLive button{min-height:44px;padding:0 14px;border-radius:10px;border:1px solid #2E2A25;background:#1C1A17;color:#F4EFE6;font-weight:700}' +
      '#vgLive #vgLiveShot{background:#D9B26B;color:#0C0B0A;border:0}#vgLive .vgl-bot button{flex:1}' +
      '#vgLive .vgl-strip{display:flex;gap:8px;overflow-x:auto;padding:6px 10px;flex:0 0 auto}#vgLive .vgl-strip button{flex:0 0 auto;width:74px;height:56px;padding:0;border-radius:10px;border:2px solid #2E2A25;background:#fff;overflow:hidden}' +
      '#vgLive .vgl-strip button.on{border-color:#D9B26B}#vgLive .vgl-strip img{width:100%;height:100%;object-fit:cover;display:block}' +
      '#vgLive .vgl-note{position:absolute;left:50%;transform:translateX(-50%);bottom:150px;background:rgba(12,11,10,.75);color:#F4EFE6;font-size:.78rem;padding:6px 12px;border-radius:14px;white-space:nowrap}#vgLive .vgl-note[hidden]{display:none}';
    css.textContent += '#vgLive .vgl-fit{position:absolute;left:50%;transform:translateX(-50%);top:62px;white-space:nowrap;font-size:.74rem;font-weight:700;letter-spacing:.06em;padding:5px 12px;border-radius:14px;background:rgba(12,11,10,.75)}#vgLive .vgl-fit.ok{color:#8FD19E}#vgLive .vgl-fit.chk{color:#D9B26B}#vgLive .vgl-fit[hidden]{display:none}' +
      '#vgLive .vgl-oval{position:absolute;left:50%;top:46%;transform:translate(-50%,-50%);width:min(62vw,340px);aspect-ratio:3/4;border:3px dashed rgba(244,239,230,.75);border-radius:50%;pointer-events:none;display:flex;align-items:flex-end;justify-content:center}' +
      '#vgLive .vgl-oval.ok{border-color:#8FD19E;border-style:solid}#vgLive .vgl-oval[hidden]{display:none}' +
      '#vgLive .vgl-oval span{transform:translateY(130%);background:rgba(12,11,10,.8);color:#F4EFE6;font-size:.82rem;font-weight:600;padding:6px 12px;border-radius:14px;white-space:nowrap}';
    document.head.appendChild(css); document.body.appendChild(box);
    box.querySelector('#vgLiveX').addEventListener('click', close);
    box.querySelector('#vgLiveAdd').addEventListener('click', function () { if (!S.p) return; try { if (g.VGBasket && !g.VGBasket.has(S.p.id)) g.VGBasket.add(S.p); } catch (e) {} close(); try { if (g.openBasket) g.openBasket(true); } catch (e) {} });
    box.querySelector('#vgLiveShare').addEventListener('click', async function () {
      if (!S.cv || S.cv.width <= 300) { alert('The camera picture is not showing yet.'); return; }
      try { var blob = await new Promise(function (r) { S.cv.toBlob(r, 'image/jpeg', 0.92); }); var file = new File([blob], 'vision-gallery-tryon.jpg', { type: 'image/jpeg' });
        if (navigator.canShare && navigator.canShare({ files: [file] })) { await navigator.share({ files: [file], title: 'Vision Gallery', text: (S.p && S.p.name || 'This frame') + ' on me \u2014 what do you think?' }); return; } } catch (e) {}
      try { var a = document.createElement('a'); a.href = S.cv.toDataURL('image/jpeg', 0.92); a.download = 'vision-gallery-tryon.jpg'; a.click(); } catch (e) {}
    });
    box.querySelector('#vgLiveStrip').addEventListener('click', function (e) { var b = e.target.closest('button[data-pid]'); if (!b) return; var pp = (g.allProducts ? g.allProducts() : []).find(function (x) { return x.id === b.dataset.pid; }); if (pp) switchTo(pp); });
    g.addEventListener('popstate', function () { if (S.on) close(true); });
    box.querySelector('#vgLiveShot').addEventListener('click', function () {
      if (!S.cv || S.cv.width <= 300) { alert('The camera picture is not showing yet. Wait for it, then save.'); return; }
      try { var a = document.createElement('a'); a.href = S.cv.toDataURL('image/jpeg', 0.92); a.download = 'vision-gallery-tryon.jpg'; a.click(); } catch (e) {} });
    return box;
  }
  function strip(p) {
    var el = document.getElementById('vgLiveStrip'); if (!el) return;
    var list = (g.allProducts ? g.allProducts() : []).filter(function (x) { return x && x.url && (g.tryOnURL ? g.tryOnURL(x) : x.tryOnUrl) && x.tryOnOk !== false; });
    var i = list.findIndex(function (x) { return x.id === p.id; }); if (i > 0) { list.splice(i, 1); list.unshift(p); }
    el.innerHTML = list.slice(0, 40).map(function (x) { return '<button type="button" data-pid="' + x.id + '"' + (x.id === p.id ? ' class="on"' : '') + ' title="' + (x.name || '') + '"><img src="' + (g.vgImg ? g.vgImg(x.url, 160) : x.url) + '" alt=""></button>'; }).join('');
  }
  async function switchTo(p) {
    S.p = p; S.zone = ''; S.prev = null; S.cuts = {}; S.adviceFor = '';           /* d17.87: same face, same lock; new frame, new advice */
    var el = document.getElementById('vgLiveStrip'); if (el) el.querySelectorAll('button').forEach(function (b) { b.classList.toggle('on', b.dataset.pid === p.id); });
    try { S.cuts = await prepare(p); } catch (e) { S.cuts = {}; }
    try { S.frontRef = g.VG45 && S.cuts.frontImg ? g.VG45.frontReference(S.cuts.frontImg, { lens: p.size && p.size.lens, bridge: p.size && p.size.bridge }, null) : null; } catch (e) { S.frontRef = null; }
  }
  async function open(p) {
    if (!p || !g.VGOnFace) return;
    try { history.pushState({ vgLive: 1 }, ''); } catch (e) {}
    var box = ui(); box.hidden = false; S.cv = box.querySelector('#vgLiveCv'); S.video = box.querySelector('#vgLiveV'); S.p = p; S.zone = ''; S.prev = null; S.cuts = {}; S.frontFace = null; S.frontPerMM = 0;
    S.lock = null; S.perMMNow = 0; S.adviceFor = ''; S.hint = ''; S.ovDoneAt = 0; var ov0 = document.getElementById('vgLiveOval'); if (ov0) ov0.hidden = true; var fe = document.getElementById('vgLiveFit'); if (fe) fe.hidden = true;     /* d17.87: every live session measures afresh */
    strip(p);
    var lbl = document.getElementById('vgLiveLbl'); lbl.textContent = 'STARTING CAMERA\u2026';
    try { S.stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: { ideal: 720 }, height: { ideal: 960 } }, audio: false }); }
    catch (e) {
      lbl.textContent = 'CAMERA BLOCKED';
      alert('The camera did not start: ' + ((e && e.name) || 'blocked') + '.\n\nAllow the camera for visiongallery.me: tap the lock icon in the address bar \u2192 Permissions \u2192 Camera \u2192 Allow, then tap LIVE VIDEO again.');
      return;
    }
    S.video.srcObject = S.stream; try { await S.video.play(); } catch (e) {}
    S.on = true; requestAnimationFrame(loop);                     /* the camera shows at once ... */
    lbl.textContent = 'LOADING\u2026';
    try { S.cuts = await prepare(p); } catch (e) { S.cuts = {}; }
    try { S.frontRef = g.VG45 && S.cuts.frontImg ? g.VG45.frontReference(S.cuts.frontImg, { lens: p.size && p.size.lens, bridge: p.size && p.size.bridge }, null) : null; } catch (e) { S.frontRef = null; }
    try { await ensureMesh(); } catch (e) {}                       /* ... and the frame joins as soon as the face finder is ready */
  }
  function close(fromBack) { if (!fromBack) { try { if (history.state && history.state.vgLive) history.back(); } catch (e) {} } S.on = false; try { (S.stream && S.stream.getTracks() || []).forEach(function (t) { t.stop(); }); } catch (e) {} var b = document.getElementById('vgLive'); if (b) b.hidden = true; }
  g.VGLive = { _S: S, lockStep: lockStep, enabled: enabled, open: open, close: close, step: step, prepare: prepare, has45: has45, lastTemple: function () { return S.lastTemple || null; }, FRONT_MAX: FRONT_MAX, SIDE_MIN: SIDE_MIN };
})(window);

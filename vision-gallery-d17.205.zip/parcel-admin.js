/* Vision Gallery Admin -- DELIVERY (d17.205, shop 2 Nov).
   Orders -> DELIVERY on any order: send it by COURIER (Shiprocket), by a same-day RIDER (Borzo), or BY HAND (any other
   courier or app). After that the same button shows where the parcel is. Settings -> Delivery holds each branch's
   address and phone (the rider collects from there) and the parcel size.
   The website's server does the booking (api/parcel.js); this file is only the buttons. */
(function () {
  'use strict';
  const SITE = 'https://visiongallery.me';
  const H = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const $id = id => document.getElementById(id);
  const inr = n => '₹' + (Math.round(Number(n) * 100) / 100).toLocaleString('en-IN');
  let CHECK = null, OPEN = null, BUSY = false, QUOTE = null, PICKUPS = null, MODE = '';

  /* ---------- styles ---------- */
  const css = document.createElement('style');
  css.textContent = `
  .dlv-chip{display:inline-flex;align-items:center;gap:4px;font-size:.68rem;font-weight:800;letter-spacing:.06em;padding:3px 8px;border-radius:999px;background:#E7EEFF;color:#1741B3;white-space:nowrap}
  .dlv-chip.ok{background:#DDF3E6;color:#17834F}.dlv-chip.bad{background:#FFE6E2;color:#B3261E}.dlv-chip.out{background:#C8FF1A;color:#06143E}
  #dlv{position:fixed;inset:0;z-index:400;background:rgba(6,20,62,.55);display:flex;align-items:flex-end;justify-content:center}
  #dlv[hidden]{display:none}
  #dlv .dv{background:#fff;color:#0F1E3D;width:100%;max-width:640px;max-height:94vh;overflow:auto;border-radius:20px 20px 0 0;padding:16px 16px 28px;font-size:15px;line-height:1.5;box-shadow:0 -8px 40px rgba(0,0,0,.25)}
  @media(min-width:700px){#dlv{align-items:center}#dlv .dv{border-radius:20px}}
  #dlv .dv-top{display:flex;justify-content:space-between;align-items:center;gap:10px;position:sticky;top:-16px;background:#fff;padding:4px 0 10px;margin-top:-4px;z-index:2;border-bottom:1px solid #E3E9F4}
  #dlv h3{margin:0;font-size:1.02rem;letter-spacing:.04em}
  #dlv .x{border:0;background:#EEF2FA;border-radius:50%;width:38px;height:38px;font-size:1.3rem;cursor:pointer;color:#06143E}
  #dlv .who{margin:12px 0 4px;font-size:.92rem}
  #dlv .warn{background:#FFF3DF;color:#5C3A00;border-radius:12px;padding:10px 12px;margin:10px 0;font-size:.88rem;font-weight:600}
  #dlv .info{background:#EEF3FF;color:#1B2F66;border-radius:12px;padding:10px 12px;margin:10px 0;font-size:.86rem}
  #dlv .err{background:#FFE6E2;color:#8C1D14;border-radius:12px;padding:10px 12px;margin:10px 0;font-size:.88rem;font-weight:700}
  #dlv .good{background:#DDF3E6;color:#0E5A35;border-radius:12px;padding:10px 12px;margin:10px 0;font-size:.88rem;font-weight:700}
  #dlv label{display:block;font-weight:800;font-size:.8rem;margin:10px 0 4px;color:#06143E}
  #dlv input,#dlv textarea,#dlv select{width:100%;box-sizing:border-box;font:inherit;font-size:16px;border:1.5px solid #CDD8EC;border-radius:10px;padding:10px;background:#fff;color:#0F1E3D}
  #dlv textarea{min-height:64px;resize:vertical}
  #dlv .g2{display:grid;grid-template-columns:1fr 1fr;gap:8px}
  #dlv .g4{display:grid;grid-template-columns:repeat(4,1fr);gap:6px}
  #dlv .ways{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin:14px 0 4px}
  #dlv .ways button{border:1.5px solid #CDD8EC;background:#fff;border-radius:12px;padding:10px 6px;font:800 .78rem/1.25 inherit;letter-spacing:.03em;cursor:pointer;color:#06143E;min-height:58px}
  #dlv .ways button small{display:block;font-weight:600;color:#5A6987;font-size:.7rem;letter-spacing:0;margin-top:2px}
  #dlv .ways button.on{border-color:#06143E;background:#06143E;color:#fff}#dlv .ways button.on small{color:#C8FF1A}
  #dlv .ways button:disabled{opacity:.45}
  #dlv .act{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}
  #dlv .act button,#dlv .act a{flex:1 1 auto;min-height:46px;border-radius:12px;border:1.5px solid #06143E;background:#fff;color:#06143E;font:800 .8rem inherit;letter-spacing:.05em;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;text-decoration:none;padding:0 12px}
  #dlv .act .main{background:#06143E;color:#fff}
  #dlv .act .lime{background:#C8FF1A;border-color:#C8FF1A;color:#06143E;flex-direction:column}
  #dlv .act .red{border-color:#C2352A;color:#C2352A}
  #dlv .act button:disabled{opacity:.5;cursor:default}
  #dlv .rates{margin:10px 0 0;border:1.5px solid #CDD8EC;border-radius:12px;overflow:hidden}
  #dlv .rates label{display:flex;align-items:center;gap:10px;margin:0;padding:10px 12px;border-bottom:1px solid #E3E9F4;font-weight:700;font-size:.9rem;cursor:pointer}
  #dlv .rates label:last-child{border-bottom:0}
  #dlv .rates input{width:auto}
  #dlv .rates .r{margin-left:auto;font-weight:800}
  #dlv .rates small{display:block;font-weight:600;color:#5A6987;font-size:.76rem}
  #dlv .now{font-size:1.05rem;font-weight:800;margin:12px 0 2px;color:#06143E}
  #dlv dl{display:grid;grid-template-columns:auto 1fr;gap:4px 12px;margin:10px 0;font-size:.9rem}
  #dlv dt{color:#5A6987;font-weight:700}#dlv dd{margin:0;font-weight:700;word-break:break-word}
  #dlv ul.ev{list-style:none;margin:8px 0 0;padding:0;border-top:1px solid #E3E9F4}
  #dlv ul.ev li{padding:7px 0;border-bottom:1px solid #E3E9F4;font-size:.84rem}
  #dlv ul.ev span{color:#5A6987;font-size:.76rem;display:block}
  #dlv .muted{color:#5A6987;font-size:.8rem}
  #dlvCard .bt{width:100%;border-collapse:collapse;font-size:.86rem}
  #dlvCard .bt td,#dlvCard .bt th{padding:6px 4px;border-bottom:1px solid rgba(127,140,170,.3);vertical-align:top;text-align:left}
  #dlvCard .bt input{width:100%;box-sizing:border-box}
  #dlvCard code{word-break:break-all;font-size:.78rem}
  @media(max-width:640px){#dlvCard .bt thead{display:none}#dlvCard .bt tr{display:block;padding:8px 0;border-bottom:1px solid rgba(127,140,170,.4)}#dlvCard .bt td{display:block;border:0;padding:3px 0}}
  `;
  document.head.appendChild(css);

  /* ---------- talking to the server ---------- */
  async function api(body) {
    let tok = null; try { tok = window.VGAuth ? await VGAuth.token() : null; } catch (e) {}
    try {
      const r = await fetch('/api/parcel', { method: 'POST', cache: 'no-store', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + (tok || '') },
        body: JSON.stringify(Object.assign({ by: (window.ME && ME.name) || (typeof ME !== 'undefined' && ME && ME.name) || '' }, body)) });
      let d = {}; try { d = await r.json(); } catch (e) {}
      if (r.status === 404 && !d.error) d.error = 'The delivery part of the website is not uploaded yet';
      if (r.status === 401) d.error = d.error || 'Please sign in to Admin again';
      return Object.assign({ status: r.status }, d, { ok: r.ok && d.ok !== false });
    } catch (e) { return { ok: false, status: 0, error: 'Could not reach the website -- check the internet' }; }
  }
  async function check(force) {
    if (CHECK && !force) return CHECK;
    try { const r = await fetch('/api/parcel?do=check', { cache: 'no-store' }); CHECK = r.ok ? await r.json() : { shiprocket: false, borzo: false, news: false, missing: r.status === 404 }; }
    catch (e) { CHECK = { shiprocket: false, borzo: false, news: false, offline: true }; }
    return CHECK;
  }

  /* ---------- the chip on each order ---------- */
  const CHIP = { booking: ['BOOKING…', ''], created: ['NOT BOOKED YET', 'bad'], none: ['', ''], booked: ['BOOKED', ''], picked: ['PICKED UP', ''], transit: ['ON THE WAY', ''], out: ['OUT FOR DELIVERY', 'out'], delivered: ['DELIVERED', 'ok'],
    failed: ['NOT DELIVERED', 'bad'], returning: ['COMING BACK', 'bad'], returned: ['RETURNED', 'bad'], problem: ['DELAYED', 'bad'], cancelled: ['', ''] };
  /* which parcel records on this phone the website has confirmed as its own (ref -> "rev|sig"): a record in an order a
     stranger made up is never shown as booked or delivered */
  const VERIFIED = {};
  const vkey = s => (s && typeof s === 'object') ? String(s.rev) + '|' + String(s.sig) : '';
  const trusted = o => !!(o && o.ship && VERIFIED[o.ref] && VERIFIED[o.ref] === vkey(o.ship));
  const fresh = s => !!(s && s.lockAt && Date.now() - new Date(s.lockAt).getTime() < 150e3);
  window.dlvChip = function (o) {
    if (!trusted(o)) return '';
    const s = o.ship;
    if (s.step === 'booking' && !fresh(s) && s.bzTry && !s.bzOrderId) return '<span class="dlv-chip bad">\u{1F6F5} CHECK BORZO APP</span>';
    if (s.step === 'created' || (s.step === 'booking' && !fresh(s) && s.srOrderId && !s.awb)) return '<span class="dlv-chip bad">\u{1F69A} NOT BOOKED YET</span>';
    if (!s.step || s.step === 'cancelled' || s.step === 'none' || s.step === 'booking' && !fresh(s)) return '';
    const c = CHIP[s.step] || ['ON THE WAY', ''];
    if (!c[0]) return '';
    return '<span class="dlv-chip ' + c[1] + '">' + (s.kind === 'rider' ? '\u{1F6F5} ' : '\u{1F69A} ') + H(c[0]) + '</span>';
  };
  const SENT_STEPS = ['booked', 'picked', 'transit', 'out', 'failed', 'returning', 'problem', 'delivered'];
  window.dlvButton = function (o) {
    const s = o && o.ship, on = !!(trusted(o) && SENT_STEPS.indexOf(s.step) >= 0);
    return '<button class="btn ' + (on ? 'btn-line' : 'btn-dark') + ' btn-sm dlvBtn" data-ref="' + H(o.ref) + '">' + (on ? 'DELIVERY STATUS' : 'DELIVERY') + '</button>';
  };

  /* ---------- the panel ---------- */
  function order(ref) { try { return (typeof getOrders === 'function' ? getOrders() : []).find(x => x.ref === ref) || null; } catch (e) { return null; } }
  function branches() { const st = (window.SET && SET.stores) || (typeof SET !== 'undefined' && SET.stores) || []; return st.filter(s => s && !/deliver/i.test(s)); }
  function shopSet() { return typeof SET !== 'undefined' ? SET : (window.SET || {}); }
  function cityState(pin) {
    pin = String(pin || '');
    if (/^4006\d\d$/.test(pin)) return ['Thane', 'Maharashtra'];
    if (/^400\d{3}$/.test(pin)) return ['Mumbai', 'Maharashtra'];
    if (/^403\d{3}$/.test(pin)) return ['', 'Goa'];
    if (/^4[0-4]\d{4}$/.test(pin)) return ['', 'Maharashtra'];
    return ['', ''];
  }
  function addrOf(o) {
    const a = o.addr && typeof o.addr === 'object' ? o.addr : null;
    const pin = String((a && a.pin) || (/(\d{6})(?!.*\d{6})/.exec(String(o.address || '')) || [])[1] || '');
    const line = a ? [a.line1, a.line2].filter(Boolean).join(', ') : String(o.address || '').replace(/,?\s*near [^,]*/i, '').replace(/,?\s*\d{6}\s*$/, '');
    const landmark = a ? (a.landmark || '') : ((/near ([^,]*)/i.exec(String(o.address || '')) || [])[1] || '');
    const cs = cityState(pin);
    return { line, pin, landmark, city: cs[0], state: cs[1] };
  }
  const remember = (k, v) => { try { localStorage.setItem('vg_dlv_' + k, v); } catch (e) {} };
  const recall = k => { try { return localStorage.getItem('vg_dlv_' + k) || ''; } catch (e) { return ''; } };
  function wrap() {
    let w = $id('dlv');
    if (!w) { w = document.createElement('div'); w.id = 'dlv'; w.hidden = true; w.innerHTML = '<div class="dv" role="dialog" aria-modal="true" aria-label="Delivery"></div>'; document.body.appendChild(w);
      w.addEventListener('click', e => { if (e.target === w) close(); }); }
    return w;
  }
  function close() { const w = $id('dlv'); if (w) w.hidden = true; OPEN = null; QUOTE = null; }
  window.dlvOpen = async function (ref) {
    const o = order(ref); if (!o) return;
    OPEN = ref; QUOTE = null; MODE = '';
    const w = wrap(); w.hidden = false;
    paint('<p class="muted">Loading&hellip;</p>');
    await check(true);
    const g = await api({ do: 'get', ref });
    if (OPEN !== ref) return;
    if (g.ok) keep(ref, { ship: g.ship || null, trackKey: g.trackKey }, true);
    draw();
    if (!g.ok && g.status !== 404) msg('err', 'Could not check with the website: ' + (g.error || 'no answer') + ' -- close and open again.');
  };
  function paint(inner) {
    const o = order(OPEN) || {};
    wrap().querySelector('.dv').innerHTML = '<div class="dv-top"><h3>DELIVERY &mdash; ' + H(o.ref || '') + '</h3><button type="button" class="x" data-d="close" aria-label="Close">&times;</button></div>' + inner;
  }
  function msg(kind, text) { const m = $id('dvMsg'); if (m) { m.className = kind; m.textContent = text; m.hidden = !text; } }
  function canEdit() { try { return typeof can === 'function' ? can('orders.edit') : true; } catch (e) { return true; } }

  function draw() {
    const o = order(OPEN); if (!o) return close();
    /* only a record the website confirmed counts (anything else on this phone is shown as not booked) */
    const s = trusted(o) && typeof o.ship === 'object' ? o.ship : null;
    if (s && fresh(s)) return drawBusy(o, s);
    if (s && SENT_STEPS.indexOf(s.step) >= 0) return drawBooked(o, s);
    drawNew(o, s);
  }
  function drawBusy(o, s) {
    paint('<div class="now">' + (s.lockVia === 'cancel' ? 'Being cancelled right now' : 'Being booked right now') + '</div><div class="info">' + H(s.lockBy || 'Another phone') + ' started this a moment ago. Wait a minute, then tap CHECK AGAIN.</div>' +
      '<div class="act"><button type="button" data-d="reopen">CHECK AGAIN</button></div><div id="dvMsg" hidden></div>');
  }
  function waysHtml(c) {
    const b = (k, t, sm) => '<button type="button" data-way="' + k + '" class="' + (MODE === k ? 'on' : '') + '">' + t + '<small>' + sm + '</small></button>';
    return '<div class="ways">' + b('borzo', 'SAME-DAY RIDER', c.borzo ? 'Borzo' + (c.borzoTest ? ' (TEST)' : '') : 'not connected', c.borzo) + b('shiprocket', 'COURIER', c.shiprocket ? 'Shiprocket' : 'not connected', c.shiprocket) + b('hand', 'BY HAND', 'Porter, Rapido, our staff…', true) + '</div>';
  }
  function drawNew(o, part) {
    const c = CHECK || {}, a = addrOf(o), st = shopSet(), br = branches();
    if (!MODE) MODE = c.borzo && /^(400\d{3}|4011\d\d)$/.test(a.pin) ? 'borzo' : c.shiprocket ? 'shiprocket' : 'hand';   /* Mumbai, Thane, Navi Mumbai, Mira Road */
    const from = recall('from') && br.indexOf(recall('from')) >= 0 ? recall('from') : (br.indexOf(o.store) >= 0 ? o.store : (br.find(b => st.branchAddr && st.branchAddr[b] && st.branchAddr[b].address) || br[0] || ''));
    const box = Object.assign({ l: 20, b: 12, h: 8, kg: 0.5 }, (st.parcel && st.parcel.box) || {});
    let h = '';
    h += '<div class="who"><b>' + H(o.name || 'Customer') + '</b> &middot; ' + H(o.phone || 'no mobile') + (o.total ? ' &middot; ' + inr(o.total) : '') + '</div>';
    if ((o.payStatus || 'Unpaid') !== 'Paid') h += '<div class="warn">Not marked PAID (' + H(o.payStatus || 'Unpaid') + '). The courier does not collect money &mdash; take the payment first.</div>';
    if (o.fulfil === 'pickup') h += '<div class="warn">The customer chose to COLLECT from ' + H(o.store || 'a shop') + '. Send it only if they asked.</div>';
    if (o.status && ['Ready', 'Delivered'].indexOf(o.status) < 0) h += '<div class="info">This order is still <b>' + H(o.status) + '</b>. Usually you send it once it is Ready (QC passed).</div>';
    const pend = part && part.via === 'shiprocket' && part.srOrderId && !part.awb && (part.step === 'created' || part.step === 'booking');
    if (pend) h += '<div class="warn">A Shiprocket order (no. ' + H(part.srOrderId) + ') was made for this but has <b>no courier yet</b>' + (part.note ? ': ' + H(part.note) : '') + '.<br>BOOK COURIER again uses that order (if you change the address it is cancelled and made again). Choosing RIDER or BY HAND cancels it first.' +
      (canEdit() ? '<div class="act"><button type="button" class="red" data-d="cancel">CANCEL THAT SHIPROCKET ORDER</button><button type="button" class="red" data-d="closerec">CLOSE (NO COURIER CALL)</button></div><p class="muted" style="margin:6px 0 0">CLOSE only if it is already cancelled in the Shiprocket panel.</p>' : '') + '</div>';
    if (part && part.step === 'booking' && part.bzTry && !part.bzOrderId) h += '<div class="warn">The last rider booking may have gone through (the website lost Borzo\u2019s answer). <b>Look in the Borzo app first.</b> If a rider is booked, save it with BY HAND (Borzo + its number). If not, tap CLEAR and book again.' +
      (canEdit() ? '<div class="act"><button type="button" class="red" data-d="closerec">CLEAR</button></div>' : '') + '</div>';
    if (part && part.step === 'returned') h += '<div class="warn">The last parcel came back to the shop' + (part.courier ? ' (' + H(part.courier) + (part.awb ? ' ' + H(part.awb) : '') + ')' : '') + '. You can send it again below.</div>';
    if (c.missing) h += '<div class="err">The delivery part of the website is not uploaded yet.</div>';
    h += waysHtml(c);
    h += '<label for="dvAddr">Deliver to</label><textarea id="dvAddr">' + H(a.line) + '</textarea>';
    h += '<div class="g2"><div><label for="dvLand">Landmark</label><input id="dvLand" value="' + H(a.landmark) + '"></div><div><label for="dvPin">Pincode</label><input id="dvPin" inputmode="numeric" maxlength="6" value="' + H(a.pin) + '"></div></div>';
    h += '<div class="g2"><div><label for="dvCity">City</label><input id="dvCity" value="' + H(a.city) + '"></div><div><label for="dvState">State</label><input id="dvState" value="' + H(a.state) + '"></div></div>';
    if (MODE !== 'hand') {
      h += '<label for="dvFrom">Send from</label><select id="dvFrom">' + br.map(b => '<option' + (b === from ? ' selected' : '') + '>' + H(b) + '</option>').join('') + '</select>';
      if (MODE === 'borzo') { const ba = st.branchAddr && st.branchAddr[from]; if (!ba || !ba.address) h += '<div class="warn">The rider needs this shop&rsquo;s address and phone: <b>Settings &rarr; Delivery</b>.</div>'; }
      h += '<label>Box (cm) and weight (kg)</label><div class="g4"><input id="dvL" inputmode="decimal" value="' + H(box.l) + '" aria-label="Length cm"><input id="dvB" inputmode="decimal" value="' + H(box.b) + '" aria-label="Breadth cm"><input id="dvH" inputmode="decimal" value="' + H(box.h) + '" aria-label="Height cm"><input id="dvKg" inputmode="decimal" value="' + H(box.kg) + '" aria-label="Weight kg"></div>';
    }
    if (MODE === 'shiprocket') {
      h += '<label for="dvPick">Shiprocket pickup address</label><select id="dvPick"><option value="">' + (PICKUPS ? 'Matched to the shop above' : 'Loading…') + '</option>' + (PICKUPS || []).map(p => '<option value="' + H(p.name) + '" data-pin="' + H(p.pin) + '">' + H(p.name) + ' (' + H(p.pin) + ')' + (p.primary ? ' · main' : '') + '</option>').join('') + '</select>';
      h += '<div id="dvRates"></div>';
      h += '<div class="act"><button type="button" data-d="quote">SEE PRICES</button><button type="button" class="main" data-d="book"' + (c.shiprocket && canEdit() ? '' : ' disabled') + '>BOOK COURIER</button></div>';
      if (!c.shiprocket) h += '<div class="info">Shiprocket is not connected yet &mdash; see the setup guide (Vercel settings).</div>';
    } else if (MODE === 'borzo') {
      h += '<label for="dvNote">Note for the rider <span class="muted">(optional)</span></label><input id="dvNote" maxlength="200" placeholder="e.g. Call before coming">';
      h += '<div id="dvRates"></div>';
      h += '<div class="act"><button type="button" data-d="quote">SEE PRICE</button><button type="button" class="main" data-d="book"' + (c.borzo && canEdit() ? '' : ' disabled') + '>BOOK RIDER</button></div>';
      if (!c.borzo) h += '<div class="info">Borzo is not connected yet &mdash; see the setup guide (Vercel settings).</div>';
      else if (c.borzoTest) h += '<div class="info"><b>TEST MODE</b> &mdash; Borzo&rsquo;s test system: no real rider comes and nothing is charged. Remove BORZO_TEST in Vercel to go live.</div>';
    } else {
      h += '<div class="g2"><div><label for="dvKind">How</label><select id="dvKind"><option value="rider">Rider / same day</option><option value="courier">Courier</option></select></div>' +
        '<div><label for="dvCo">Who is delivering</label><input id="dvCo" list="dvCoList" placeholder="e.g. Porter"><datalist id="dvCoList"><option>Porter</option><option>Shiprocket Quick</option><option>Rapido</option><option>Uber</option><option>Our staff</option><option>Delhivery</option><option>DTDC</option><option>Blue Dart</option><option>India Post</option></datalist></div></div>';
      h += '<label for="dvAwb">Tracking number <span class="muted">(if any)</span></label><input id="dvAwb" maxlength="40">';
      h += '<label for="dvUrl">Tracking link <span class="muted">(if the app gave one &mdash; starts with https://)</span></label><input id="dvUrl" inputmode="url" placeholder="https://">';
      h += '<div class="act"><button type="button" class="main" data-d="hand"' + (canEdit() ? '' : ' disabled') + '>SAVE &amp; TELL THE CUSTOMER</button></div>';
      h += '<p class="muted">You move it along yourself (PICKED UP / OUT FOR DELIVERY / DELIVERED). The customer gets a WhatsApp with their tracking page.</p>';
    }
    h += '<div id="dvMsg" hidden></div>';
    paint(h);
    if (MODE === 'shiprocket' && !PICKUPS && c.shiprocket) loadPickups();
    if (QUOTE && QUOTE.ref === OPEN) showQuote();
  }
  async function loadPickups() {
    const r = await api({ do: 'pickups' });
    PICKUPS = r.ok && Array.isArray(r.list) ? r.list : [];
    if (OPEN && MODE === 'shiprocket') { const keepF = form(); draw(); restore(keepF); }
    if (!r.ok) msg('err', r.error || 'Could not read your Shiprocket pickup addresses');
  }
  function form() { const v = id => ($id(id) ? $id(id).value : undefined); return { addr: v('dvAddr'), land: v('dvLand'), pin: v('dvPin'), city: v('dvCity'), state: v('dvState'), from: v('dvFrom'), l: v('dvL'), b: v('dvB'), h: v('dvH'), kg: v('dvKg'), note: v('dvNote'), pick: v('dvPick') }; }
  function restore(f) { const put = (id, v) => { if (v !== undefined && $id(id)) $id(id).value = v; }; put('dvAddr', f.addr); put('dvLand', f.land); put('dvPin', f.pin); put('dvCity', f.city); put('dvState', f.state); put('dvFrom', f.from); put('dvL', f.l); put('dvB', f.b); put('dvH', f.h); put('dvKg', f.kg); put('dvNote', f.note); put('dvPick', f.pick); }
  function reqBody() {
    const f = form(), sel = $id('dvPick'), opt = sel && sel.selectedOptions && sel.selectedOptions[0];
    if (f.from) remember('from', f.from);
    return { from: f.from, to: { address: (f.addr || '').trim(), landmark: (f.land || '').trim(), pin: (f.pin || '').replace(/\D/g, ''), city: (f.city || '').trim(), state: (f.state || '').trim() },
      box: { l: f.l, b: f.b, h: f.h, kg: f.kg }, note: (f.note || '').trim(), pickup: f.pick || '', pickupPin: opt && opt.dataset.pin || '' };
  }
  function showQuote() {
    const el = $id('dvRates'); if (!el || !QUOTE || QUOTE.ref !== OPEN) return;
    let h = '';
    if (MODE === 'shiprocket') {
      const q = QUOTE.shiprocket;
      if (!q) h = '<div class="info">Shiprocket is not connected.</div>';
      else if (!q.ok) h = '<div class="err">' + H(q.error) + '</div>';
      else if (!q.couriers.length) h = '<div class="err">No courier delivers to this pincode.</div>';
      else h = '<div class="rates">' + q.couriers.map((c, i) => '<label><input type="radio" name="dvCourier" value="' + H(c.id) + '"' + ((q.recommended ? c.id === q.recommended : i === 0) ? ' checked' : '') + '><span>' + H(c.name) + (c.id === q.recommended ? ' &middot; <i>recommended</i>' : '') +
        '<small>' + (c.days ? H(c.days) + ' day' + (String(c.days) === '1' ? '' : 's') : '') + (c.etd ? ' &middot; by ' + H(c.etd) : '') + '</small></span><span class="r">' + inr(c.rate) + '</span></label>').join('') + '</div>';
    } else if (MODE === 'borzo') {
      const q = QUOTE.borzo;
      if (!q) h = '<div class="info">Borzo is not connected.</div>';
      else if (!q.ok) h = '<div class="err">' + H(q.error) + '</div>';
      else h = '<div class="good">Rider price: ' + inr(q.price) + (q.test ? ' (TEST &mdash; nothing charged)' : '') + '</div>';
    }
    el.innerHTML = h;
  }
  function drawBooked(o, s) {
    const rider = s.kind === 'rider', link = o.trackKey ? SITE + '/track?o=' + encodeURIComponent(o.ref) + '&k=' + encodeURIComponent(o.trackKey) : '';
    const ago = t => { const m = Math.round((Date.now() - new Date(t).getTime()) / 60000); return !t || isNaN(m) ? '' : m < 1 ? 'just now' : m < 60 ? m + ' min ago' : m < 1440 ? Math.round(m / 60) + ' h ago' : Math.round(m / 1440) + ' days ago'; };
    let h = '<div class="now">' + H(s.text || (CHIP[s.step] || [s.step])[0]) + '</div>';
    h += '<div class="muted">' + (s.checkedAt ? 'Checked ' + ago(s.checkedAt) : '') + (s.at ? ' &middot; last change ' + ago(s.at) : '') + '</div>';
    if (s.test) h += '<div class="info"><b>TEST booking</b> on Borzo&rsquo;s test system &mdash; no real rider.</div>';
    if (s.note) h += '<div class="warn">' + H(s.note) + '</div>';
    h += '<dl>';
    const row = (k, v) => { if (v) h += '<dt>' + H(k) + '</dt><dd>' + v + '</dd>'; };
    row(rider ? 'Rider' : 'Courier', H(s.courier || (s.via === 'borzo' ? 'Borzo' : '')) + (s.via === 'hand' ? ' <span class="muted">(by hand)</span>' : ''));
    if (s.rider && s.rider.name) row('Rider', H(s.rider.name) + (s.rider.phone ? ' &middot; <a href="tel:+' + H(s.rider.phone) + '">CALL</a>' : ''));
    row('Tracking no.', H(s.awb));
    row('From', H(s.from));
    row('Pickup', H(s.pickupAt));
    if (s.eta && s.step !== 'delivered') row('Expected', H(new Date(s.eta).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })));
    if (s.price) row('Price', inr(s.price));
    if (s.bzOrderId) row('Borzo no.', H(s.bzOrderId));
    if (s.srOrderId) row('Shiprocket no.', H(s.srOrderId));
    row('Booked', H((s.bookedAt ? new Date(s.bookedAt).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' }) : '') + (s.bookedBy ? ' by ' + s.bookedBy : '')));
    h += '</dl>';
    /* every link says where it goes (a link typed by hand, or one in an order a stranger made up, is never hidden behind a button) */
    const host = u => { try { const x = new URL(u); return x.protocol === 'https:' ? x.hostname.replace(/^www\./, '') : ''; } catch (e) { return ''; } };
    const th = host(s.trackUrl), lh = host(s.label);
    h += '<div class="act">' + (th ? '<a class="lime" href="' + H(s.trackUrl) + '" target="_blank" rel="noopener noreferrer">' + (rider ? 'RIDER LIVE MAP' : 'COURIER TRACKING') + ' &#8599;<small style="display:block;font-weight:600;font-size:.66rem;letter-spacing:0">' + H(th) + '</small></a>' : '') +
      (lh && (/(^|\.)shiprocket\.(in|co)$/.test(lh) || /^kr-shipmultichannel(-mum)?\.s3(\.[a-z0-9-]+)?\.amazonaws\.com$/.test(lh)) ? '<a href="' + H(s.label) + '" target="_blank" rel="noopener noreferrer">LABEL PDF &#8599;</a>' : '') +
      (link ? '<a href="' + H(link) + '" target="_blank" rel="noopener">CUSTOMER&rsquo;S PAGE &#8599;</a><button type="button" data-d="copy">COPY LINK</button>' : '') + '</div>';
    if (canEdit()) {
      h += '<div class="act">';
      if (s.via !== 'hand') h += '<button type="button" data-d="refresh">CHECK NOW</button>';
      if (s.via === 'shiprocket' && s.live && (!s.pickupAt || /pickup not booked/i.test(s.note || ''))) h += '<button type="button" class="main" data-d="pickup">BOOK PICKUP</button>';
      if (s.via === 'shiprocket' && s.live && !s.label) h += '<button type="button" data-d="label">GET LABEL</button>';
      if (s.via === 'hand' && s.live) h += '<button type="button" data-step="picked">PICKED UP</button><button type="button" data-step="out">OUT FOR DELIVERY</button><button type="button" class="main" data-step="delivered">DELIVERED</button><button type="button" data-step="failed">NOT DELIVERED</button>';
      if (s.via === 'hand' && s.live) h += '<button type="button" data-d="edithand">CHANGE NUMBER / LINK</button>';
      if (s.live) h += '<button type="button" class="red" data-d="cancel">CANCEL BOOKING</button>';
      /* lost, damaged, came back, or "delivered" by mistake: closed here without asking the courier -- then it can be sent again */
      h += '<button type="button" class="red" data-d="closerec">CLOSE (NO COURIER CALL)</button>';
      h += '</div>';
    }
    h += '<div id="dvMsg" hidden></div>';
    const list = s.scans && s.scans.length ? s.scans : (s.events || []).slice().reverse();
    if (list.length) h += '<ul class="ev">' + list.slice(0, 12).map(e => '<li>' + H(e.text) + '<span>' + H([e.at ? new Date(e.at).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' }) : '', e.place].filter(Boolean).join(' · ')) + '</span></li>').join('') + '</ul>';
    if (s.history && s.history.length) h += '<p class="muted">Earlier booking' + (s.history.length > 1 ? 's' : '') + ' cancelled: ' + s.history.map(x => H([x.courier || x.via, x.awb || x.bzOrderId].filter(Boolean).join(' '))).join(', ') + '</p>';
    paint(h);
  }
  /* the order on this phone takes the parcel record the server sent (truth = null: the server has no real record --
     anything else on this phone, e.g. a record planted in a stranger's order, is dropped) */
  function keep(ref, d, truth) {
    if (!d || (!d.ship && !truth)) return;
    try {
      const list = getOrders(), o = list.find(x => x.ref === ref); if (!o) return;
      if (d.ship) { o.ship = d.ship; VERIFIED[ref] = vkey(d.ship); } else { delete o.ship; delete VERIFIED[ref]; }
      if (d.trackKey) o.trackKey = d.trackKey;
      if (d.link) { try { const k = new URL(d.link).searchParams.get('k'); if (k) o.trackKey = k; } catch (e) {} }
      if (d.ship && d.ship.step === 'delivered' && !d.ship.test && o.status !== 'Delivered') o.status = 'Delivered';
      if (d.orderStatus && typeof d.orderStatus === 'string') o.status = d.orderStatus;
      saveOrders(list);
    } catch (e) {}
  }
  /* one action at a time PER ORDER (another order's panel stays usable); whatever comes back is shown only on the
     panel of the order it belongs to */
  const BUSYSET = new Set();
  async function act(what, extra) {
    const ref = OPEN, o = order(ref); if (!o) return;
    if (BUSYSET.has(ref)) return;
    if (['book', 'hand', 'cancel', 'close', 'step', 'pickup', 'label', 'refresh'].indexOf(what) >= 0 && typeof need === 'function' && !need('orders.edit')) return;
    BUSYSET.add(ref);
    document.querySelectorAll('#dlv .act button').forEach(b => { b.disabled = true; });
    msg('info', what === 'book' ? 'Booking… (this can take up to half a minute)' : 'Working…');
    let r;
    try {
      if (what === 'quote') {
        r = await api(Object.assign({ do: 'quote', ref }, reqBody()));
        if (OPEN !== ref) return;
        if (!r.ok) { draw(); restore(LASTF); msg('err', r.error || 'Could not get prices'); return; }
        QUOTE = Object.assign({ ref }, r); const f = form(); draw(); restore(f); showQuote(); msg('', ''); return;
      }
      if (what === 'book') {
        const b = reqBody(), ch = document.querySelector('#dlv input[name="dvCourier"]:checked');
        r = await api(Object.assign({ do: 'book', ref, via: MODE, courierId: ch && QUOTE && QUOTE.ref === ref ? ch.value : '' }, b));
      } else if (what === 'hand') {
        const v = id => ($id(id) ? $id(id).value.trim() : '');
        r = await api({ do: 'hand', ref, kind: v('dvKind') || (extra && extra.kind) || 'rider', courier: v('dvCo') || (extra && extra.courier), awb: v('dvAwb'), url: v('dvUrl'), from: recall('from') });
      } else if (what === 'step') r = await api({ do: 'step', ref, step: extra });
      else r = await api({ do: what, ref });
      if (r.ship || (r.ok && r.ship === null)) keep(ref, r, r.ok && r.ship === null);
      if (!r.ok) {
        /* what is really on the order now (e.g. a Shiprocket order made before the courier was refused) */
        if (r.status && r.status !== 401) { const g = await api({ do: 'get', ref }); if (g.ok) keep(ref, { ship: g.ship || null, trackKey: g.trackKey }, true); }
        if (OPEN !== ref) { try { if (typeof toast === 'function') toast(ref + ': ' + (r.error || 'It did not work')); } catch (e) {} return; }
        const f = form(); draw(); restore(f);
        msg('err', r.error || 'It did not work -- try again');
        return;
      }
      const told = r.test ? ' (TEST: the message went to the manager’s WhatsApp, not the customer.)' : r.whatsapp ? ' The customer got a WhatsApp with the tracking link.' : ' The WhatsApp to the customer did not go -- COPY LINK and send it yourself.';
      const said = { book: 'Booked.' + told, hand: 'Saved.' + (r.whatsapp ? ' The customer got a WhatsApp with the tracking link.' : ''),
        cancel: 'Cancelled.', close: 'Closed. You can send it again.', refresh: 'Checked.', pickup: 'Pickup booked.', label: 'Label ready.', step: 'Saved.' }[what] || 'Done.';
      try { if (typeof toast === 'function') toast(ref + ': ' + said); } catch (e) {}
      if (OPEN !== ref) return;
      draw();
      msg('good', said);
    } finally {
      BUSYSET.delete(ref);
      if (OPEN === ref) document.querySelectorAll('#dlv .act button').forEach(b => { if (b.dataset.locked !== '1') b.disabled = false; });
    }
  }
  let LASTF = {};

  document.addEventListener('click', e => {
    const t = e.target.closest && e.target.closest('.dlvBtn');
    if (t) { e.preventDefault(); e.stopPropagation(); window.dlvOpen(t.dataset.ref); return; }
    const w = $id('dlv'); if (!w || w.hidden || !w.contains(e.target)) return;
    const d = e.target.closest('[data-d],[data-way],[data-step]'); if (!d) return;
    if (d.dataset.way) { LASTF = form(); MODE = d.dataset.way; QUOTE = null; draw(); restore(LASTF); return; }
    if (d.dataset.step) {
      if (d.dataset.step === 'delivered' && !confirm('Mark ' + OPEN + ' DELIVERED? The customer gets a WhatsApp.')) return;
      return act('step', d.dataset.step);
    }
    const k = d.dataset.d;
    if (k === 'close') return close();
    if (k === 'reopen') return window.dlvOpen(OPEN);
    if (k === 'copy') { const o = order(OPEN); const link = SITE + '/track?o=' + encodeURIComponent(o.ref) + '&k=' + encodeURIComponent(o.trackKey || ''); try { navigator.clipboard.writeText(link); msg('good', 'Link copied: ' + link); } catch (x) { msg('info', link); } return; }
    if (k === 'cancel') { const oc = order(OPEN), byHand = oc && oc.ship && oc.ship.via === 'hand';
      if (!confirm('Cancel the delivery booking for ' + OPEN + '? ' + (byHand ? 'This only clears it here -- tell the courier / rider yourself.' : 'The courier / rider is told.'))) return; return act('cancel'); }
    if (k === 'closerec') { if (!confirm('CLOSE the delivery record of ' + OPEN + ' WITHOUT telling the courier?\n\nOnly for a parcel that is lost, damaged, came back, or was marked delivered by mistake. If the courier still has to be stopped, use CANCEL BOOKING instead.')) return; return act('close'); }
    if (k === 'edithand') { const o = order(OPEN), s = o.ship; MODE = 'hand'; drawNew(o, null);
      if ($id('dvCo')) $id('dvCo').value = s.courier || ''; if ($id('dvAwb')) $id('dvAwb').value = s.awb || ''; if ($id('dvUrl')) $id('dvUrl').value = /^https:/.test(s.trackUrl || '') ? s.trackUrl : ''; if ($id('dvKind')) $id('dvKind').value = s.kind === 'courier' ? 'courier' : 'rider'; return; }
    if (k === 'book' && MODE === 'shiprocket' && !document.querySelector('#dlv input[name="dvCourier"]:checked') && !confirm('No courier chosen -- let Shiprocket choose the courier?')) return;
    if (k === 'book' && !confirm('Book ' + (MODE === 'borzo' ? 'a rider (Borzo)' : 'the courier (Shiprocket)') + ' for ' + OPEN + '? This spends money from your ' + (MODE === 'borzo' ? 'Borzo' : 'Shiprocket') + ' account.')) return;
    LASTF = form();
    act(k);
  });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && OPEN) close(); });
  /* a new pincode fills in the city and state (only empty boxes) */
  document.addEventListener('input', e => {
    if (!e.target || e.target.id !== 'dvPin') return;
    const v = e.target.value.replace(/\D/g, ''); if (v.length !== 6) return;
    const cs = cityState(v); if ($id('dvCity') && !$id('dvCity').value) $id('dvCity').value = cs[0]; if ($id('dvState') && !$id('dvState').value) $id('dvState').value = cs[1];
  });

  /* ---------- the order list keeps itself fresh ---------- */
  /* parcels with no news for 20 minutes are asked about (the courier's updates usually come by themselves) */
  async function refreshAll() {
    try {
      if (document.hidden || typeof getOrders !== 'function') return;
      const live = getOrders().filter(o => trusted(o) && o.ship.live && o.ship.via !== 'hand');
      if (!live.length) return;
      const r = await api({ do: 'refresh-all' });
      if (r.ok && Array.isArray(r.ships) && r.ships.length) r.ships.forEach(x => { if (x && x.ship) keep(x.ref, { ship: x.ship }); });
    } catch (e) {}
  }
  setTimeout(refreshAll, 20e3); setInterval(refreshAll, 15 * 60e3);
  /* every parcel record that arrives on this phone (with the orders, every 30 seconds) is confirmed with the website
     before it shows as booked, or the bill goes -- a record in an order a stranger made up is dropped here */
  let VERIFYING = false;
  async function verifyRound() {
    if (VERIFYING || typeof getOrders !== 'function') return;
    if (!(window.VGAuth && VGAuth.signedIn && VGAuth.signedIn())) return;
    const need = getOrders().filter(o => o && o.ref && o.ship && !trusted(o)).map(o => o.ref).slice(0, 60);
    if (!need.length) return;
    VERIFYING = true;
    try {
      const r = await api({ do: 'verify', refs: need });
      if (!r.ok || !r.ships) return;
      const list = getOrders(); let changed = false;
      need.forEach(ref => {
        const o = list.find(x => x.ref === ref); if (!o) return;
        const g = r.ships[ref];
        if (g) { o.ship = g; VERIFIED[ref] = vkey(g); changed = true; }
        else if (o.ship) { delete o.ship; delete VERIFIED[ref]; changed = true; }
      });
      if (changed) saveOrders(list);
    } catch (e) {} finally { VERIFYING = false; }
  }
  setTimeout(verifyRound, 3e3); setInterval(verifyRound, 30e3);
  window.dlvVerify = verifyRound;

  /* DELIVERED by the courier -> the shop's usual "Delivered" WhatsApp (thank-you, review link, the bill), sent once by
     whichever Admin phone sees it first (the server hands it to one phone only). Only for parcels delivered in the last
     3 days -- older ones have the SEND BILL button. */
  const DONE_TRY = {};
  async function sendDone() {
    try {
      if (typeof getOrders !== 'function' || typeof waAuto !== 'function') return;
      if (!(window.VGAuth && VGAuth.signedIn && VGAuth.signedIn())) return;
      const fresh = getOrders().filter(o => trusted(o) && o.ship.step === 'delivered' && !o.ship.test && !o.doneSent && !DONE_TRY[o.ref] &&
        Date.now() - new Date((o.ship.told && o.ship.told.delivered) || o.ship.at || 0).getTime() < 3 * 86400e3);
      for (const o of fresh.slice(0, 5)) {
        DONE_TRY[o.ref] = 1;
        const r = await api({ do: 'claim', ref: o.ref });
        /* no answer (no internet, website busy): nothing is marked -- this phone asks again in a minute */
        if (!r.ok) { delete DONE_TRY[o.ref]; continue; }
        const list = getOrders(), x = list.find(y => y.ref === o.ref);
        if (x) { x.doneSent = x.doneSent || { at: new Date().toISOString(), here: !!r.claimed }; saveOrders(list); }
        /* the customer already had "delivered" + the review link from the website: this is the bill */
        if (r.claimed && x) { try { await waAuto(x, 'bill'); } catch (e) {} try { if (typeof waStaff === 'function') waStaff(x, 'done'); } catch (e) {} }
      }
    } catch (e) {}
  }
  setInterval(sendDone, 60e3); setTimeout(sendDone, 25e3);
  window.dlvSendDone = sendDone;
  /* staff marked an order Delivered by hand: that phone sends the message (as always) and this keeps a courier's
     "delivered" later from sending it a second time */
  window.dlvClaimManual = function (o) { if (o && o.ref) { DONE_TRY[o.ref] = 1; api({ do: 'claim', ref: o.ref, mode: 'manual' }).catch(() => {}); } };

  /* ---------- Settings -> Delivery ---------- */
  function settingsCard() {
    const panel = $id('panel-settings'); if (!panel || $id('dlvCard')) return;
    const card = document.createElement('div'); card.className = 'card'; card.id = 'dlvCard';
    const first = $id('upiCard'); if (first) panel.insertBefore(card, first); else panel.appendChild(card);
    fillCard();
  }
  async function fillCard() {
    const card = $id('dlvCard'); if (!card) return;
    const st = shopSet(), ba = st.branchAddr || {}, p = st.parcel || {}, box = Object.assign({ l: 20, b: 12, h: 8, kg: 0.5 }, p.box || {});
    card.innerHTML = '<div class="card-head"><h3>Delivery (courier, rider, Track my order)</h3></div>' +
      '<p class="muted" style="margin:0 0 10px">Orders &rarr; <b>DELIVERY</b> sends an order by courier (Shiprocket), by a same-day rider (Borzo) or by hand. The customer gets WhatsApp updates and a <b>Track my order</b> page. The rider collects from the branch address below.</p>' +
      '<p class="lens-hint" id="dlvState" style="margin:0 0 12px">Checking&hellip;</p>' +
      '<table class="bt"><thead><tr><th>Branch</th><th>Full address (for the rider)</th><th>Pincode</th><th>Phone</th></tr></thead><tbody>' +
      branches().map(b => { const x = ba[b] || {}; return '<tr data-b="' + H(b) + '"><td><b>' + H(b) + '</b></td><td><input class="dA" value="' + H(x.address || '') + '" placeholder="Shop no., building, street, area, Mumbai"></td><td><input class="dP" inputmode="numeric" maxlength="6" value="' + H(x.pin || '') + '" placeholder="400098"></td><td><input class="dF" inputmode="tel" value="' + H(x.phone || '') + '" placeholder="98xxxxxxxx"></td></tr>'; }).join('') +
      '</tbody></table>' +
      '<div class="row2" style="margin-top:10px"><div class="fld"><label>Usual box (cm) and weight (kg)</label><div style="display:grid;grid-template-columns:repeat(4,1fr);gap:6px"><input id="dBl" value="' + H(box.l) + '" aria-label="Length"><input id="dBb" value="' + H(box.b) + '" aria-label="Breadth"><input id="dBh" value="' + H(box.h) + '" aria-label="Height"><input id="dBk" value="' + H(box.kg) + '" aria-label="Weight kg"></div><div class="hint">A pair in a hard case + bubble wrap fits 20 &times; 12 &times; 8 cm, 0.5 kg (the cheapest slab).</div></div>' +
      '<div class="fld"><label for="dPay">How Borzo is paid</label><select id="dPay"><option value="">Borzo account&rsquo;s own setting</option><option value="non_cash"' + (p.borzoPay === 'non_cash' ? ' selected' : '') + '>From the Borzo balance</option><option value="cash"' + (p.borzoPay === 'cash' ? ' selected' : '') + '>Cash to the rider at the shop</option></select></div></div>' +
      '<div style="display:flex;gap:8px;align-items:center;margin-top:10px;flex-wrap:wrap"><button type="button" class="btn btn-dark btn-sm" id="dlvSave">SAVE</button><span id="dlvSaved" class="pe-hint"></span></div>' +
      '<details style="margin-top:14px"><summary style="cursor:pointer;font-weight:700">Addresses for automatic updates (paste these once in Shiprocket and Borzo)</summary>' +
      '<p class="lens-hint" style="margin:8px 0 4px"><b>Shiprocket</b> &rarr; Settings &rarr; API &rarr; Webhooks: URL <code>' + SITE + '/api/parcel?do=news&amp;from=courier</code> and token = your <b>PARCEL_HOOK_KEY</b> (the one in Vercel).</p>' +
      '<p class="lens-hint" style="margin:4px 0"><b>Borzo</b> &rarr; API settings &rarr; Callback URL: <code>' + SITE + '/api/parcel?do=news&amp;from=rider&amp;k=</code> followed by your PARCEL_HOOK_KEY.</p>' +
      '<p class="lens-hint" style="margin:4px 0">Without these the website still checks each parcel every 20 minutes while Admin is open, and whenever a customer opens their tracking page.</p></details>';
    const c = await check(true), el = $id('dlvState'); if (!el) return;
    const yes = (b, t) => (b ? '<b style="color:#17834F">&#10003; ' : '<b style="color:#B3261E">&#10007; ') + t + '</b>';
    el.innerHTML = c.missing ? '<b>The delivery part of the website is not uploaded yet.</b>' :
      [yes(c.shiprocket, 'Shiprocket'), yes(c.borzo, 'Borzo' + (c.borzoTest ? ' (TEST mode)' : '')), yes(c.news, 'automatic updates'), yes(c.whatsapp, 'WhatsApp to customers')].join(' &nbsp; ') +
      (!c.shiprocket || !c.borzo || !c.news ? '<br><span class="muted">Each one is switched on in Vercel &rarr; Settings &rarr; Environment Variables (see the setup guide). BY HAND works without any of them.</span>' : '');
  }
  document.addEventListener('click', e => {
    if (e.target && e.target.closest && e.target.closest('.tab[data-tab="settings"]')) setTimeout(() => { settingsCard(); fillCard(); }, 50);
    if (!e.target || e.target.id !== 'dlvSave') return;
    if (typeof need === 'function' && !need('settings.edit')) return;
    const said = $id('dlvSaved');
    /* the same rule as every other setting: never saved before the account's settings have arrived on this phone */
    if (typeof SHOP_READY !== 'undefined' && !SHOP_READY) { if (said) said.textContent = 'NOT SAVED — your settings have not loaded from your account yet. Reload the page and try again.'; return; }
    if (!(window.VGSync && VGSync.ready() && window.VGAuth && VGAuth.signedIn())) { if (said) said.textContent = 'NOT SAVED — you are signed out. Sign in and try again.'; return; }
    const next = Object.assign({}, shopSet(), window.dlvReadCard());
    try { SET = next; } catch (x) { window.SET = next; }
    write(LS.settings, next);
    if (said) said.textContent = 'Saved to your account — riders collect from these addresses.';
  });
  /* what Settings -> Delivery holds right now: the boxes as typed when the card is on screen, otherwise what is saved.
     Branches no longer in the shop list keep their saved address (a renamed branch is not wiped). */
  window.dlvReadCard = function () {
    const st = shopSet();
    const card = $id('dlvCard');
    if (!card || !card.querySelector('tr[data-b]')) return { branchAddr: st.branchAddr, parcel: st.parcel };
    const ba = Object.assign({}, st.branchAddr && typeof st.branchAddr === 'object' ? st.branchAddr : {});
    card.querySelectorAll('tr[data-b]').forEach(tr => {
      const a = tr.querySelector('.dA').value.trim(), p = tr.querySelector('.dP').value.replace(/\D/g, '').slice(0, 6), f = tr.querySelector('.dF').value.replace(/[^\d+ ]/g, '').trim();
      if (a || p || f) ba[tr.dataset.b] = { address: a.slice(0, 300), pin: p, phone: f.slice(0, 16) }; else delete ba[tr.dataset.b];
    });
    const num = (id, d, lo, hi) => { const v = Number(($id(id) || {}).value); return v >= lo && v <= hi ? v : d; };
    return { branchAddr: ba, parcel: Object.assign({}, st.parcel || {}, { box: { l: num('dBl', 20, 1, 100), b: num('dBb', 12, 1, 100), h: num('dBh', 8, 1, 100), kg: num('dBk', 0.5, 0.05, 20) }, borzoPay: ($id('dPay') || {}).value || '' }) };
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', settingsCard); else settingsCard();
})();

/* =====================================================================
   Vision Gallery — order sync

   Until now an order only existed on the customer's phone, and reached
   you only if they remembered to press send in WhatsApp. If they did
   not, you never knew the order happened at all.

   This saves every order to a small database the moment it is placed —
   BEFORE WhatsApp opens — so it is in your admin panel whether or not
   the customer completes the message. You see it while you are on the
   shop floor, without touching anything.

   Supabase is used because it needs no server to run or maintain, the
   free tier is far more than an optical shop will use, and a static
   site can talk to it directly.

   If it is not configured, or the network is down, everything falls
   back to the old behaviour rather than losing the order.
   ===================================================================== */

(function (global) {
  'use strict';

  /* Where the credentials come from.

     This used to read old static config ONLY. The admin Settings box, though,
     saves to localStorage. So pressing SAVE in admin changed nothing
     until the whole site was rebuilt and re-uploaded — and if the two
     ever disagreed, the panel reported on one key while actually
     using the other. That is why fixing the key appeared to do
     nothing. A key saved in admin now takes effect immediately;
     old static config remains the fallback and is what customers' phones use. */
  function saved(){
    try {
      const s = JSON.parse(localStorage.getItem('vg_sync') || 'null');
      if (s && s.url && s.key) return s;
    } catch(e){}
    return null;
  }
  /* The project this site belongs to.

     These used to live in old static config, which is no longer shipped --
     and that quietly broke the shop. Admin kept working, because
     pressing SAVE in Settings writes the same values into the
     browser. A customer opening the shop had neither, so the page
     could not reach the database at all: it showed nothing and said
     nothing. Built in here, there is no file left to forget.

     The publishable key is meant to be public -- it sits in the page
     source of every Supabase site. What protects the data is the
     database rules: the public may read products and place an order,
     and nothing else. Reading a customer's order, or changing a
     price, needs a signed-in account. */
  const DEFAULTS = {
    url: 'https://oscpunukbyosckrmopeh.supabase.co',
    key: 'sb_publishable_WWAPQTu0lo-X51T4kDlgng_LR39PPkU'
  };

  const CFG = () => saved() || DEFAULTS;
  const ready = () => { const c = CFG(); return !!(c.url && c.key); };

  /* A legacy anon key is a JWT and looks like eyJ... . The newer
     sb_publishable_... keys are NOT JWTs, and Supabase rejects them
     when they arrive in Authorization: Bearer — even when the value
     matches the apikey header exactly. Sending Bearer unconditionally
     made every request come back 401, which the admin then reported
     as "the key was rejected" although the key was perfectly good.
     So: apikey always, Bearer only when the key really is a JWT. */
  function isJwt(k){ return typeof k === 'string' && /^ey[A-Za-z0-9_-]+\./.test(k); }

  /* Which token goes in Authorization.

     Three cases, and getting them confused is what caused the 401s:

     1. Signed in  -> the account's access token. This is what makes
        the database rules treat you as staff rather than as a
        stranger, so it must win over everything else.
     2. Legacy anon key (eyJ...) -> itself. It IS a JWT, so Supabase
        accepts it there.
     3. New sb_publishable_... key -> nothing at all. It is not a JWT
        and Supabase rejects it in Authorization even when it matches
        the apikey header exactly. */
  async function headers(extra){
    const c = CFG();
    const h = {
      'apikey': c.key,
      'Content-Type': 'application/json',
      'Prefer': 'return=representation'
    };
    let tok = null;
    try { tok = global.VGAuth ? await global.VGAuth.token() : null; } catch(e){}
    if (tok)                h['Authorization'] = 'Bearer ' + tok;
    else if (isJwt(c.key))  h['Authorization'] = 'Bearer ' + c.key;
    if (extra) Object.assign(h, extra);
    return h;
  }

  /* Supabase says exactly what is wrong in the body -- "permission
     denied for table orders", "Invalid API key", and so on. Throwing
     that away and showing only a status code turned every failure
     into a guess. Carry it through. */
  async function fail(res){
    let detail = '', code = '';
    try {
      const b = await res.json();
      detail = b.message || b.error_description || b.error || b.hint || '';
      code = b.code ? ' [' + b.code + ']' : '';
    } catch(e){
      try { detail = (await res.text()).slice(0,200); } catch(e2){}
    }
    const err = new Error('HTTP ' + res.status + (detail ? ' \u2014 ' + detail + code : ''));
    err.status = res.status; err.detail = detail; err.code = code;
    return err;
  }

  /* ---- customer side: save the order ---------------------------- */

  async function saveOrder(order, again){
    if (!ready()) return { ok:false, reason:'not-configured' };
    const c = CFG();
    try {
      /* d17.203 SECURITY: the public may ADD an order but not read one back, so the order is sent without asking for it back */
      const res = await fetch(c.url + '/rest/v1/orders', {
        method: 'POST',
        headers: await headers({ 'Prefer': 'return=minimal' }),
        body: JSON.stringify([{
          ref: order.ref,
          name: order.name || '',
          phone: order.phone || '',
          total: Number(order.total) || 0,
          status: order.status || 'New',
          channel: 'website',
          payload: order,
          created_at: new Date().toISOString()
        }])
      });
      if (res.status === 409 && !again){
        /* d17.203: two customers got the same number at the same moment -- this one takes the next number */
        const fresh = (await nextRef()) || ('VG-' + Date.now().toString(36).toUpperCase().slice(-5) + Math.floor(Math.random()*90+10));
        order.ref = fresh;
        const r2 = await saveOrder(order, true);
        return Object.assign({}, r2, { ref: fresh, renumbered: true });
      }
      if (!res.ok) throw new Error('HTTP ' + res.status);
      try { if (global.vgTrack) global.vgTrack('order_placed', { total: Number(order.total) || 0, power: order.powerType || '', lens: order.lensPackage || '' }); } catch(e){}   /* d17.155: no name, no phone */
      return { ok:true };
    } catch (err){
      console.warn('order sync failed', err);
      /* d17.153: Admin -> HEALTH hears about it (the order ref only -- no name, no phone) */
      try { if (global.VGHealth) global.VGHealth.report('order', 'An order could not be saved to the database (' + ((err && err.message) || err) + '). It stays on the customer\'s phone and is sent again when they next open the site.', { ref: String(order && order.ref || '') }); } catch(e){}
      // Keep it locally so nothing is lost; admin can pull it later.
      try {
        const q = JSON.parse(localStorage.getItem('vg_pending') || '[]');
        q.push(order);
        localStorage.setItem('vg_pending', JSON.stringify(q));
      } catch(e){}
      return { ok:false, reason:'network' };
    }
  }

  /* Retry anything that failed to send earlier. */
  async function flushPending(){
    if (!ready()) return 0;
    let q = [];
    try { q = JSON.parse(localStorage.getItem('vg_pending') || '[]'); } catch(e){ return 0; }
    if (!q.length) return 0;
    const left = [];
    for (const o of q){
      const r = await saveOrder(o);
      if (!r.ok) left.push(o);
    }
    localStorage.setItem('vg_pending', JSON.stringify(left));
    return q.length - left.length;
  }

  /* ---- the next order number ------------------------------------

     Orders used to be stamped VG-K3M9F42 -- a random string that is
     painful to read over the phone and impossible to file in order.
     The shop wants VG-1001, VG-1002.

     There is no counter table, so the next number is worked out from
     the newest orders already saved. Two hundred is plenty: they come
     back newest first, so the highest number is always among them.

     If this cannot be reached for any reason, it returns null and the
     order page falls back to the old random reference. An order must
     never be blocked by a numbering problem. */
  /* d17.203 SECURITY: the public can no longer read orders, so the website's own server works the number out */
  async function nextRef(){
    if (!ready()) return null;
    try {
      const res = await fetch('/api/order?do=ref', { cache: 'no-store' });
      if (!res.ok) return null;
      const d = await res.json();
      return (d && /^VG-\d{4,6}$/.test(String(d.ref || ''))) ? d.ref : null;
    } catch (err){
      return null;
    }
  }

  /* ---- customer side: read/update one order safely ----------------
     Used by the post-payment prescription page. The customer must know
     both the order reference and the mobile number saved on the order.
     If Supabase RLS blocks customer reads/updates, the caller gets a
     normal error and can fall back to store support; nothing is exposed
     by reference number alone. */
  async function fetchOrder(ref, phone){
    if (!ready()) return null;
    const c = CFG();
    const q = '/rest/v1/orders?select=ref,name,phone,status,payload&ref=eq.' + encodeURIComponent(ref) +
              '&phone=eq.' + encodeURIComponent(phone) + '&limit=1';
    const res = await fetch(c.url + q, { headers: await headers() });
    if (!res.ok) throw await fail(res);
    const rows = await res.json();
    return rows && rows[0] ? rows[0] : null;
  }

  /* Admin (signed in as the shop) changes an order's details straight in the database: EXPRESS, fit, Pair 2, stock.
     d17.203: only the shop's own sign-in may do this now -- the public cannot change orders any more. */
  async function updateOrderPayload(ref, phone, patch, status){
    if (!ready()) return {ok:false, reason:'not-configured'};
    /* d17.205: the website writes courier news onto the same order (payload.ship). This edit is written only if that
       parcel record is still the one read just before -- otherwise read again and tried again, so neither the staff
       change nor the courier's news is lost. */
    for (let i = 0; i < 4; i++){
      const row = await fetchOrder(ref, phone);
      if (!row) return {ok:false, reason:'not-found'};
      const payload = Object.assign({}, row.payload || {}, patch || {});
      /* the staff edit counter: the website's courier news checks it too, so neither write is lost */
      const er = row.payload && row.payload.editRev;
      payload.editRev = (Number.isSafeInteger(er) && er >= 0 && er < 1e9 ? er : 0) + 1;
      const body = { payload:payload };
      if (status) body.status = status;
      const sh = row.payload && row.payload.ship, rv = sh && typeof sh === 'object' && !Array.isArray(sh) ? sh.rev : undefined;
      let guard = rv == null ? '&payload->ship->>rev=is.null' : (Number.isSafeInteger(rv) ? '&payload->ship->>rev=eq.' + rv : '');
      guard += er == null ? '&payload->>editRev=is.null' : (Number.isSafeInteger(er) && er >= 0 && er < 1e9 ? '&payload->>editRev=eq.' + er : '');
      if (i === 3) guard = '';                       /* an odd value planted in an order never blocks the shop's own edit */
      const c = CFG();
      const q = '/rest/v1/orders?ref=eq.' + encodeURIComponent(ref) + '&phone=eq.' + encodeURIComponent(phone) + guard + '&select=ref';
      const res = await fetch(c.url + q, { method:'PATCH', headers:await headers({'Prefer':'return=representation'}), body:JSON.stringify(body) });
      if (!res.ok) throw await fail(res);
      let rows = null; try { rows = await res.json(); } catch(e){}
      if (!Array.isArray(rows) || rows.length) return {ok:true, payload:payload};
    }
    return {ok:false, reason:'busy'};
  }

  /* d17.203 SECURITY: a CUSTOMER attaches a prescription through the website's own server, which checks the order
     number AND the mobile number and changes only the prescription */
  async function attachPrescription(ref, phone, patch){
    const res = await fetch('/api/order', { method:'POST', headers:{ 'Content-Type':'application/json' }, cache:'no-store',
      body: JSON.stringify({ do:'attach', ref:ref, phone:phone, patch:patch || {} }) });
    let d = {}; try { d = await res.json(); } catch(e){}
    if (res.status === 404) return {ok:false, reason:'not-found'};
    if (!res.ok || !d.ok) throw new Error(d.error || ('HTTP ' + res.status));
    return {ok:true};
  }


  /* ---- shop side: read orders ----------------------------------- */

  async function fetchOrders(sinceISO){
    if (!ready()) return null;
    const c = CFG();
    let url = c.url + '/rest/v1/orders?select=*&order=created_at.desc&limit=200';
    if (sinceISO) url += '&created_at=gt.' + encodeURIComponent(sinceISO);
    const res = await fetch(url, { headers: await headers() });
    if (!res.ok) throw await fail(res);
    return await res.json();
  }

  async function updateStatus(ref, status){
    if (!ready()) return false;
    const c = CFG();
    const res = await fetch(c.url + '/rest/v1/orders?ref=eq.' + encodeURIComponent(ref), {
      method: 'PATCH',
      headers: await headers(),
      body: JSON.stringify({ status: status })
    });
    return res.ok;
  }


  /* ---- the catalogue -------------------------------------------- */

  /* Products are stored one row per frame:

       id          text     the same id the admin panel already uses
       data        jsonb    the whole product object, untouched
       updated_at  timestamp

     The whole object goes into one jsonb column deliberately. Mapping
     twenty-odd fields into twenty-odd columns means a mapping bug
     every time a field is added, and silently dropped data when one
     is missed. This way anything the admin panel invents tomorrow
     survives the round trip without a migration. */

  async function fetchProducts(){
    if (!ready()) return null;
    const c = CFG();
    /* Whole-catalogue fetch. Kept for admin's backup and migration,
       and for a small shop where downloading everything is cheaper
       than paging. The shop pages use searchProducts instead -- this
       one has a ceiling, and above it the answer is quietly
       incomplete, which is the worst kind of wrong. */
    /* d17.204: page by page. The database answers at most 1,000 rows to one request (Supabase "max rows"), so one big
       request quietly returned only the first 1,000 frames once the shop grew. */
    const rows = [], seenIds = new Set(), SIZE = 500;
    for (let off = 0; off < 200000; off += SIZE){
      const res = await fetch(c.url + '/rest/v1/products?select=id,data&order=id.asc&limit=' + SIZE + '&offset=' + off,
                              { headers: await headers() });
      if (!res.ok) throw await fail(res);
      const part = await res.json();
      if (!Array.isArray(part)) throw new Error('the frame list came back in an unexpected form');
      part.forEach(r => { if (r && !seenIds.has(r.id)) { seenIds.add(r.id); rows.push(r); } });   /* each frame once (a frame added meanwhile can shift a page) */
      if (part.length < SIZE) break;
    }
    return rows
      /* Rows whose id starts with __ are settings, not stock. Sharing
         the table means no second table and no extra SQL for the shop
         owner to run -- but they must never reach a shelf. */
      .filter(r => !String(r.id).startsWith('__'))
      .filter(r => !(r.data && r.data.deleted))
      .map(r => {
      /* Trust the row id over anything inside the blob -- the id is
         the primary key and the blob is just cargo. */
      const o = (r.data && typeof r.data === 'object') ? r.data : {};
      o.id = r.id;
      return o;
    });
  }

  /* Save the catalogue as the admin panel currently has it.

     Upsert every frame, then delete rows that are no longer in the
     list. Done in that order on purpose: if the delete fails you are
     left with an extra frame, which you can see and remove. If it ran
     first and the upsert failed, you would be left with nothing. */
  async function saveProducts(list){
    if (!ready()) return { ok:false, reason:'not-configured' };
    if (!Array.isArray(list)) return { ok:false, reason:'bad-input' };
    const c = CFG();

    const rows = list
      .filter(p => p && p.id)
      .map(p => ({ id: String(p.id), data: p, updated_at: new Date().toISOString() }));

    try {
      if (rows.length){
        const res = await fetch(c.url + '/rest/v1/products?on_conflict=id', {
          method: 'POST',
          headers: await headers({ 'Prefer': 'resolution=merge-duplicates,return=minimal' }),
          body: JSON.stringify(rows)
        });
        if (!res.ok) throw await fail(res);
      }

      /* d17.204: NOTHING IS DELETED HERE ANY MORE. This save used to end with "delete every frame not in my list" -- written
         with a filter (id=not.like.__*) that the database reads differently ("_" = any one character), so it never deleted
         anything. Fixed, it would delete every frame added on another phone since this page was opened. Frames are removed
         only by DELETE in Admin (deleteProduct), one by one, on purpose. */

      return { ok:true, count: rows.length };
    } catch (err){
      return { ok:false, reason:'error', error: err, message: err.message || String(err) };
    }
  }


  /* ---- keeping the shop pages up to date ------------------------

     The customer-facing pages used to read products from old static config
     only. That meant every price change or new frame needed the file
     downloaded from admin and re-uploaded to the host by hand, and
     until that happened the shop showed the old list. In practice
     that step gets skipped, and the website quietly goes stale.

     So: the page still renders from old static config immediately -- fast,
     and it still works if the database is unreachable -- and then
     quietly replaces the catalogue with the live one and re-draws.
     A missed download can no longer leave the shop wrong.        */

  /* Is this frame allowed on the website? Yes only when its try-on
     picture exists -- cut by the robot, or supplied ready-made. */
  function shopReady(p){
    if (!p) return false;
    if (p.tryOnFails === undefined || p.tryOnFails === null) return true;   /* saved before the robot existed: unchanged */
    return !!(p.tryOnLocked || (p.tryOnReady && p.tryOnUrl));
  }

  async function refreshCatalogue(onUpdate){
    if (!ready()) return false;
    let rows;
    try { rows = await fetchProducts(); }
    catch (err){
      console.warn('catalogue refresh failed', err.message || err);
      return false;             // keep whatever old static config had
    }
    if (!rows) return false;
    rows = rows.filter(shopReady);   /* d16.62: no cut-out, not on the website */

    /* An empty table almost always means "not set up yet" rather than
       "the shop has no frames". Wiping a working old static config list on
       that basis would empty the website for a customer who is
       looking at it right now. */
    const current = (global.VG_CONFIG && global.VG_CONFIG.products) || [];
    if (!rows.length && current.length) return false;

    if (!global.VG_CONFIG) global.VG_CONFIG = {};
    global.VG_CONFIG.products = rows;
    try { if (typeof onUpdate === 'function') onUpdate(rows); } catch(e){ console.warn(e); }
    try {
      global.dispatchEvent(new CustomEvent('vg:catalogue', { detail: rows }));
    } catch(e){}
    return true;
  }


  /* ---- shop settings that customers must be able to read ---------

     Things like the home page pictures. They live as reserved rows in
     the same table, so they arrive on every device the same way the
     catalogue does and need no extra setup. */

  async function fetchSetting(key){
    if (!ready()) return null;
    const c = CFG();
    const id = '__' + key;
    const res = await fetch(c.url + '/rest/v1/products?select=id,data&id=eq.' + encodeURIComponent(id),
                            { headers: await headers() });
    if (!res.ok) throw await fail(res);
    const rows = await res.json();
    return (rows && rows[0] && rows[0].data) || null;
  }

  async function saveSetting(key, value){
    if (!ready()) return { ok:false, reason:'not-configured' };
    const c = CFG();
    try {
      const res = await fetch(c.url + '/rest/v1/products?on_conflict=id', {
        method: 'POST',
        headers: await headers({ 'Prefer': 'resolution=merge-duplicates,return=minimal' }),
        body: JSON.stringify([{ id: '__' + key, data: value, updated_at: new Date().toISOString() }])
      });
      if (!res.ok) throw await fail(res);
      return { ok:true };
    } catch (err){
      return { ok:false, error:err, message: err.message || String(err) };
    }
  }


  /* ---- private shop settings (d17.155) ---------------------------
     Staff passcodes, roles and the WhatsApp sender key used to sit in the
     __shop row, which every visitor can read (the website needs the prices
     and offers in it). They now live in their own table, shop_private, which
     only a signed-in member of staff can read or change. Returns
     { ok, missing } -- missing:true means the table is not set up yet. */
  async function fetchPrivate(key){
    if (!ready()) return { ok:false, missing:false, data:null };
    const c = CFG();
    const res = await fetch(c.url + '/rest/v1/shop_private?select=data&id=eq.' + encodeURIComponent(key), { headers: await headers() });
    if (res.status === 404) return { ok:false, missing:true, data:null };
    if (!res.ok){ let code = ''; try { code = (await res.clone().json()).code || ''; } catch(e){}
      return { ok:false, missing: code === 'PGRST205' || code === '42P01', data:null, status:res.status }; }
    const rows = await res.json();
    return { ok:true, missing:false, data: (rows && rows[0] && rows[0].data) || null };
  }
  /* d17.203: the customers' reviews waiting for the shop's OK (rows rv:...), read and removed by Admin only */
  async function listPrivate(prefix){
    if (!ready()) return [];
    const c = CFG();
    const res = await fetch(c.url + '/rest/v1/shop_private?select=id,data&id=like.' + encodeURIComponent(prefix) + '*&order=id.desc&limit=200', { headers: await headers() });
    if (!res.ok) throw await fail(res);
    return (await res.json()) || [];
  }
  async function deletePrivate(id){
    if (!ready()) return { ok:false };
    const c = CFG();
    const res = await fetch(c.url + '/rest/v1/shop_private?id=eq.' + encodeURIComponent(id), { method:'DELETE', headers: await headers({ 'Prefer':'return=minimal' }) });
    if (!res.ok) throw await fail(res);
    return { ok:true };
  }
  async function savePrivate(key, value){
    if (!ready()) return { ok:false, reason:'not-configured' };
    const c = CFG();
    try {
      const res = await fetch(c.url + '/rest/v1/shop_private?on_conflict=id', {
        method: 'POST',
        headers: await headers({ 'Prefer': 'resolution=merge-duplicates,return=minimal' }),
        body: JSON.stringify([{ id: key, data: value, updated_at: new Date().toISOString() }])
      });
      if (!res.ok) throw await fail(res);
      return { ok:true };
    } catch (err){
      return { ok:false, error:err, message: err.message || String(err) };
    }
  }


  /* ---- searching in the database, not the browser ----------------

     The old fetchProducts pulled the whole catalogue down and let the
     page filter it. That is the right shape for a few hundred frames
     and the wrong one for forty thousand: eleven megabytes before the
     home page draws, and a browser storage limit that gives out around
     seventeen thousand.

     This asks the database for one page of already-filtered results.
     The work happens where the indexes are, and the phone receives
     twenty-four frames instead of forty thousand. */

  const PAGE = 24;

  /* Raised from 2000. Anything at or above this is being truncated, so
     the caller is told rather than left with a short list it believes
     is complete. */
  const WHOLE_CATALOGUE_CAP = 10000;

  function esc(v){ return encodeURIComponent(String(v == null ? '' : v)); }

  async function searchProducts(opts){
    if (!ready()) return null;
    opts = opts || {};
    const c = CFG();
    const page = Math.max(0, Number(opts.page) || 0);
    const size = Math.max(1, Math.min(60, Number(opts.pageSize) || PAGE));

    const qs = ['select=id,data'];

    /* Only what a customer could actually buy. Computed in the
       database, so a hidden frame never crosses the wire. */
    if (opts.includeHidden !== true) qs.push('p_visible=is.true');
    /* A frame is on the website only once its try-on picture exists
       (d16.62). The robot writes tryOnReady when it has cut the photo;
       a ready-made PNG from the shop sets it at save time. Until then
       the frame is invisible to customers -- never half-working.
       Frames saved before the robot existed carry no tryOnFails field
       and are left exactly as they were. */
    if (opts.includeHidden !== true) qs.push('or=(data->>tryOnReady.eq.true,data->>tryOnFails.is.null)');

    if (opts.cat)    qs.push('p_cat=eq.'    + esc(opts.cat));
    if (opts.shape)  qs.push('p_shape=eq.'  + esc(String(opts.shape).toLowerCase()));
    if (opts.colour) qs.push('p_colour=eq.' + esc(String(opts.colour).toLowerCase()));
    if (opts.maxPrice) qs.push('p_price=lte.' + esc(opts.maxPrice));

    /* These filters are stored in the product JSON. Querying the JSON
       directly means Metal / Plastic / Supra / Rimless / 1+1 work on
       the live Supabase catalogue without another migration. */
    if (opts.material) qs.push('data->>material=eq.' + esc(opts.material));
    if (opts.rim)      qs.push('data->>rim=eq.' + esc(opts.rim));
    if (opts.offer)    qs.push('data->>offerCode=eq.' + esc(opts.offer));
    if (opts.size){
      const z=String(opts.size).toLowerCase();
      if (z==='extra narrow'){qs.push('p_width=gte.126');qs.push('p_width=lte.129');}
      else if (z==='narrow'){qs.push('p_width=gte.130');qs.push('p_width=lte.133');}
      else if (z==='medium'){qs.push('p_width=gte.134');qs.push('p_width=lte.137');}
      else if (z==='wide'){qs.push('p_width=gte.138');qs.push('p_width=lte.141');}
      else if (z==='extra wide')qs.push('p_width=gte.142');
    }

    /* An untagged frame is unisex, so "Men" must also return the ones
       with no wearer set -- otherwise filtering hides most of the
       shop. Kids is different and is handled by category. */
    if (opts.wearer){
      const w = String(opts.wearer).toLowerCase();
      /* Kids must be tagged, or on the kids shelf. Untagged adult
         stock falling into a children's search is how a parent ends
         up buying a frame that cannot fit their child. Every other
         heading treats untagged as unisex, which it is. */
      if (w === 'kids') qs.push('or=(p_wearer.eq.kids,p_cat.eq.kids)');
      /* d17.43: a frame tagged Unisex belongs on the Men page and the Women page too -- it was left out, so
         "Men" showed only the frames tagged Men or left blank (3 of 15 on the shop) */
      else qs.push('or=(p_wearer.eq.' + esc(w) + ',p_wearer.eq.unisex,p_wearer.is.null,p_wearer.eq.)');
    }

    /* Contact-lens kind: Clear, Colour, Solution.

       These used to be a plain word search, so a clear lens named
       "Bausch & Lomb Monthly" matched nothing and the tile looked
       broken. Now the kind set in admin is what counts -- and the old
       name match is kept alongside it, so lenses added before the
       field existed still turn up. */
    if (opts.sub){
      const s = String(opts.sub).toLowerCase().replace(/[^a-z]/g, '');
      if (s) qs.push('or=(data->>sub.eq.' + esc(s) + ',p_name.ilike.*' + esc(s) + '*)');
    }

    if (opts.q){
      /* Every word must appear somewhere, so more words narrow the
         result rather than widening it. */
      const terms = String(opts.q).trim().toLowerCase()
        .split(/\s+/).filter(Boolean).map(w => w.replace(/[^a-z0-9]/g, ''))
        .filter(Boolean).join(' & ');
      if (terms) qs.push('p_search=fts(simple).' + esc(terms));
    }

    const order = opts.sort === 'low'  ? 'p_price.asc.nullslast'
                : opts.sort === 'high' ? 'p_price.desc.nullslast'
                : opts.sort === 'name' ? 'p_name.asc'
                : 'updated_at.desc';
    qs.push('order=' + order);

    const from = page * size, to = from + size - 1;
    const h = await headers({
      'Range-Unit': 'items',
      'Range': from + '-' + to,
      /* d17.204: an EXACT count. A planned (estimated) count can come back far too low (the database has no statistics for
         these filters -- 5 when there are 500), and the database then refuses page 2 as "beyond the end" (416), so SHOW MORE
         failed. An exact count of a few thousand frames is quick. */
      'Prefer': 'count=exact'
    });

    const res = await fetch(c.url + '/rest/v1/products?' + qs.join('&'), { headers: h });
    /* past the last frame (the list shrank since the last page): an empty page, not an error */
    if (res.status === 416) return { rows: [], total: null, page: page, pageSize: size, more: false };
    if (!res.ok && res.status !== 206) throw await fail(res);

    const rows = await res.json();
    /* Content-Range comes back as "0-23/1200". */
    let total = null;
    const cr = res.headers && res.headers.get ? res.headers.get('content-range') : null;
    if (cr){
      const m = /\/(\d+|\*)$/.exec(cr);
      if (m && m[1] !== '*') total = Number(m[1]);
    }

    return {
      rows: (rows || []).filter(r => !(r.data && (r.data.deleted || r.data.draft || r.data.awaitingCheck))).map(r => {
        const o = (r.data && typeof r.data === 'object') ? r.data : {};
        o.id = r.id;
        return o;
      }),
      total: total,
      page: page,
      pageSize: size,
      more: (rows || []).length === size
    };
  }

  async function fetchProduct(id, opts){
    if(!ready()||!id)return null;const c=CFG();
    const res=await fetch(c.url+'/rest/v1/products?select=id,data&id=eq.'+esc(id)+'&limit=1',{headers:await headers()});
    if(!res.ok)throw await fail(res);const rows=await res.json();if(!rows||!rows[0])return null;
    /* d17.146 (audit: the admin's "keep the robot's work" read came back empty for exactly the frames the robot was still
       working on): the admin asks with {any:true} and gets drafts and frames waiting in TO CHECK too; a customer never does */
    const anyRow = !!(opts && opts.any);
    if (rows[0].data && (rows[0].data.deleted || (!anyRow && (rows[0].data.draft || rows[0].data.awaitingCheck)))) return null;   /* a draft, or a frame not yet checked, is never shown to a customer */
    const o=(rows[0].data&&typeof rows[0].data==='object')?rows[0].data:{};o.id=rows[0].id;return o;
  }
  /* d17.202 COLOURS AND SIZES OF ONE MODEL (shop 30 Oct: "the model number tells you this belongs to this frame"): the Model
     number typed in Admin (e.g. "VG-1018 C2", "85401 DA", "ACE-90116") links every colour and size of one model under one card.
     The colour code at the end (C2, 02, DA, BLK ...) is left out; spaces, dashes and dots do not matter (VG-1018 = VG 1018). */
  function family(p){
    var raw = String((p && p.sku) || '').trim().toUpperCase();
    if (!raw) return '';
    var t = raw.split(/\s+/).filter(Boolean);
    if (t.length > 1){
      var last = t[t.length - 1], rest = t.slice(0, -1).join('');
      var code = /^(C|COL|CLR|COLOR|COLOUR)?[.#-]?\d{1,3}$/.test(last) || /^[A-Z]{1,4}$/.test(last);
      if (code && /\d/.test(rest)) t = t.slice(0, -1);
    }
    var s = t.join('');
    s = s.replace(/[-\/_.](C|COL|CLR)\.?\d{1,3}$/, '');           /* VG-1018-C2, 85401/C2 */
    s = s.replace(/(\d)C\d{1,2}$/, '$1');                          /* 85401C2 */
    s = s.replace(/[\s\-\/_.]/g, '');
    return (/\d/.test(s) && s.length >= 3) ? s : '';
  }
  async function fetchVariants(p){
    if(!ready()||!p)return [];const fam=family(p);const group=String(p.modelGroup||p.model||'').trim();if(!group&&!fam)return [p];const c=CFG();
    /* d17.204: a typed model number is QUOTED inside or=(...) -- a comma or bracket in it used to break the whole query */
    const qv=v=>esc('"'+String(v).replace(/\\/g,'\\\\').replace(/"/g,'\\"')+'"');
    const ors=[];if(group){ors.push('data->>modelGroup.eq.'+qv(group));ors.push('data->>model.eq.'+qv(group));}
    /* d17.202: every frame whose model number holds the same digits, then exactly the same family (VG-1018 C1, VG 1018 DA ...) */
    const dig=(fam.match(/\d{3,}/g)||[]).sort((a,b)=>b.length-a.length)[0];if(dig)ors.push('data->>sku.ilike.*'+esc(dig)+'*');
    const q='select=id,data&or=('+ors.join(',')+')&limit=300';
    const res=await fetch(c.url+'/rest/v1/products?'+q,{headers:await headers()});if(!res.ok)throw await fail(res);
    const all=(await res.json()).map(r=>{const o=(r.data&&typeof r.data==='object')?r.data:{};o.id=r.id;return o}).filter(o=>!o.draft&&!o.deleted&&!o.awaitingCheck);
    return fam?all.filter(o=>family(o)===fam||o.id===p.id):all;
  }

  /* ---- saving one frame, not all of them ----

     saveProducts sends the entire catalogue. At forty thousand rows
     that is minutes of upload to change one price, and it would run on
     every keystroke. */
  async function saveProduct(p){
    if (!ready()) return { ok:false, reason:'not-configured' };
    if (!p || !p.id) return { ok:false, reason:'no-id' };
    const c = CFG();
    try {
      const res = await fetch(c.url + '/rest/v1/products?on_conflict=id', {
        method: 'POST',
        headers: await headers({ 'Prefer':'resolution=merge-duplicates,return=minimal' }),
        body: JSON.stringify([{ id:String(p.id), data:p, updated_at:new Date().toISOString() }])
      });
      if (!res.ok) throw await fail(res);
      return { ok:true };
    } catch (err){
      return { ok:false, error:err, message: err.message || String(err) };
    }
  }

  async function deleteProduct(ids){
    if (!ready()) return { ok:false, reason:'not-configured' };
    const list = Array.isArray(ids) ? ids : [ids];
    if (!list.length) return { ok:true, count:0 };
    const c = CFG();
    try {
      const inList = list.map(i => '"' + String(i).replace(/"/g,'') + '"').join(',');
      /* return=representation, NOT return=minimal.

         With row-level security switched on and no DELETE policy on the
         table, PostgREST answers 204 and removes nothing. Asking only
         "did the request succeed?" gets a yes, the frame disappears from
         the admin screen, and it is still live on the website. That is
         exactly the silent failure that let deleted frames keep showing.

         Asking for the deleted rows back turns the lie into a number we
         can check. */
      const res = await fetch(c.url + '/rest/v1/products?id=in.(' + encodeURIComponent(inList) + ')', {
        method:'DELETE', headers: await headers({ 'Prefer':'return=representation' })
      });
      if (!res.ok) throw await fail(res);

      let rows = [];
      try { rows = await res.json(); } catch (e){ rows = null; }

      /* A server that genuinely cannot report back is not proof of
         failure, so only treat a real, readable count as evidence. */
      if (Array.isArray(rows)){
        /* DELETED MEANS GONE. (d16.21)

           With no DELETE policy on the table the request removes
           nothing. Until now that came back as a red warning and the
           frame stayed on the website. UPDATE is allowed, so the rows
           that would not delete are overwritten with a tombstone --
           deleted:true, qty:0, no photo -- and every reader of the
           catalogue skips tombstones. The frame leaves the website
           either way. delete-policy.sql still makes the real delete
           work; this makes the shop not depend on it. */
        const gone = new Set(rows.map(r => String(r.id)));
        const left = list.filter(i => !gone.has(String(i)));
        if (left.length){
          const stamp = new Date().toISOString();
          const tomb = left.map(i => ({ id:String(i), data:{ id:String(i), deleted:true, deletedAt:stamp, qty:0, url:'', name:'(deleted)' }, updated_at:stamp }));
          const up = await fetch(c.url + '/rest/v1/products?on_conflict=id', {
            method:'POST',
            headers: await headers({ 'Prefer':'resolution=merge-duplicates,return=minimal' }),
            body: JSON.stringify(tomb)
          });
          if (!up.ok) throw await fail(up);
          return { ok:true, count:list.length, soft:left.length,
                   message: left.length + ' removed by marking as deleted (no DELETE policy on the table \u2014 run delete-policy.sql once to delete for real).' };
        }
        return { ok:true, count:rows.length };
      }
      return { ok:true, count:list.length, verified:false };
    } catch (err){
      return { ok:false, error:err, message: err.message || String(err) };
    }
  }

  /* Upload in batches. One request carrying forty thousand rows is
     refused by the server; five hundred at a time is not. */
  async function saveProductsChunked(list, onProgress){
    if (!ready()) return { ok:false, reason:'not-configured' };
    const rows = (list || []).filter(p => p && p.id);
    const SIZE = 500;
    const c = CFG();
    let done = 0;
    for (let i = 0; i < rows.length; i += SIZE){
      const chunk = rows.slice(i, i + SIZE).map(p => ({
        id:String(p.id), data:p, updated_at:new Date().toISOString()
      }));
      try {
        const res = await fetch(c.url + '/rest/v1/products?on_conflict=id', {
          method:'POST',
          headers: await headers({ 'Prefer':'resolution=merge-duplicates,return=minimal' }),
          body: JSON.stringify(chunk)
        });
        if (!res.ok) throw await fail(res);
      } catch (err){
        /* Report how far it got. Half an upload is recoverable; a bare
           failure with no position is not. */
        return { ok:false, done, total:rows.length, error:err, message: err.message || String(err) };
      }
      done += chunk.length;
      if (typeof onProgress === 'function') onProgress(done, rows.length);
    }
    return { ok:true, count:done };
  }

  /* d17.147 1+1 ONLY (shop, 15 Oct): the lens levels of the 1+1 offer, and whether single frames are sold at all.
     Admin -> Settings -> 1+1 offer keeps them; these are the starting values until the shop saves its own. */
  const OFFER_TIER_DEFAULTS = {
    sv:   [ { name:'Blue Block', price:1500, on:true }, { name:'Premium HD', price:2500, on:true }, { name:'Premium Plus', price:3500, on:true }, { name:'Premium Max', price:4500, on:true } ],
    /* d17.152 (shop, 17 Oct): the four progressive levels are the four lens designs */
    prog: [ { name:'Adaptive', price:2800, on:true }, { name:'Easy View', price:4500, on:true }, { name:'Ultra View', price:5800, on:true }, { name:'Max Clarity', price:7000, on:true } ]
  };
  function offerTiers(shop){
    const t = shop && shop.offerTiers && typeof shop.offerTiers === 'object' ? shop.offerTiers : null;
    const pick = k => OFFER_TIER_DEFAULTS[k].map((d, i) => { const x = t && Array.isArray(t[k]) && t[k][i] ? t[k][i] : {};
      /* d17.152: levels still carrying the old built-in progressive names take the design names (and the 4th comes on) */
      const OLD = ['Progressive ARC','Progressive Blue Block','Progressive Premium','Progressive Max'];
      const oldName = k === 'prog' && x.name && x.name === OLD[i];
      const oldPrice = oldName && Number(x.price) === [2800,3800,4800,5800][i];   /* the old built-in price too -> the new one */
      return { name: oldName ? d.name : String(x.name || d.name), price: oldPrice ? d.price : (Number(x.price) > 0 ? Number(x.price) : d.price), on: i === 0 ? true : (x.on === undefined || oldName ? d.on : !!x.on) }; });
    return { sv: pick('sv'), prog: pick('prog') };
  }
  function oneOnly(shop){ return !(shop && shop.sellSingle === true); }   /* the default: 1+1 only */
  function offerFrom(shop, kind){ return offerTiers(shop)[kind === 'prog' ? 'prog' : 'sv'][0].price; }

  global.VGSync = { ready, saveOrder, offerTiers, oneOnly, offerFrom, nextRef, flushPending, fetchOrder, updateOrderPayload, attachPrescription, fetchOrders, updateStatus,
                    fetchProducts, saveProducts, refreshCatalogue, shopReady,
                    fetchSetting, saveSetting, fetchPrivate, savePrivate, listPrivate, deletePrivate,
                    searchProducts, fetchProduct, fetchVariants, family, saveProduct, deleteProduct, saveProductsChunked, PAGE };

})(window);

/* Vision Gallery -- DELIVERY AND "TRACK MY ORDER" (d17.205, shop 2 Nov: "build Shiprocket, the Track my order page,
   and Borzo -- so we can track automatically").

   Three ways to send an order, chosen in Admin -> Orders -> DELIVERY:
     - COURIER  (Shiprocket: Delhivery, Xpressbees, Blue Dart ... -- booked, label and pickup in one tap)
     - RIDER    (Borzo: a same-day bike rider in Mumbai, from the branch to the customer)
     - BY HAND  (any other courier or app -- Porter, Shiprocket Quick, the shop's own boy: staff type the name and number)

   The parcel's progress is kept on the order (payload.ship). It moves by itself: Shiprocket and Borzo tell the website
   each time the parcel moves (do=news), and the page asks them again when a customer looks and the news is old. The
   customer gets a WhatsApp when it is sent, out for delivery and delivered -- each once.

     GET  /api/parcel?do=check                     -> which services are switched on (no secrets)
     GET  /api/parcel?do=track&o=VG-1042&k=<key>   -> the order's progress (the private link in the customer's WhatsApp)
     POST /api/parcel {do:"track", ref, phone}     -> the same, with the order number + the mobile number on the order
     POST /api/parcel?do=news&from=courier         -> Shiprocket's updates (header x-api-key = PARCEL_HOOK_KEY)
     POST /api/parcel?do=news&from=rider&k=<key>   -> Borzo's updates (only a nudge: the order is read again from Borzo)
     POST /api/parcel {do:"quote"|"book"|"hand"|"step"|"refresh"|"refresh-all"|"cancel"|"pickups"|"pickup"|"claim"}
                                                    -> Admin only (the shop's sign-in)

   Settings in Vercel (Settings -> Environment Variables), all optional -- without them that way is simply off:
     SHIPROCKET_EMAIL, SHIPROCKET_PASSWORD   the API user made in Shiprocket -> Settings -> API (not your own login)
     BORZO_TOKEN                             Borzo -> API settings -> the secret token
     BORZO_TEST                              1 = use Borzo's test system (no real rider comes) -- remove it to go live
     PARCEL_HOOK_KEY                         any long password you make up; the same one goes into Shiprocket's webhook
                                             "token" and into Borzo's callback address
   NOTE: Shiprocket refuses a webhook address containing "shiprocket", "sr", "kr" or "kartrocket" -- so this file is
   called "parcel" and the address says from=courier. */
'use strict';
const crypto = require('crypto');
const L = require('./_lib.js');

const SITE = 'https://visiongallery.me';
const SR = 'https://apiv2.shiprocket.in/v1/external';
const BZ = () => L.env('BORZO_TEST') ? 'https://robotapitest-in.borzodelivery.com/api/business/1.8' : 'https://robot-in.borzodelivery.com/api/business/1.8';
const srReady = () => !!(L.env('SHIPROCKET_EMAIL') && L.env('SHIPROCKET_PASSWORD'));
const bzReady = () => !!L.env('BORZO_TOKEN');
const REF_RX = /^VG-(\d{4,6}|[A-Z0-9]{7})$/;

/* ---------- small helpers ---------- */
const plain = (v, n) => String(v == null ? '' : v).replace(/[\u0000-\u001f\u007f<>"`]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, n || 120);
const enc = encodeURIComponent;
const nowIso = () => new Date().toISOString();
function same(a, b) {
  const x = Buffer.from(String(a || '')), y = Buffer.from(String(b || ''));
  return x.length > 0 && x.length === y.length && crypto.timingSafeEqual(x, y);
}
function newKey() { return crypto.randomBytes(9).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); }
/* a courier's time: "2026-11-02 14:05:10" (India time), "02 11 2026 14:05:10", or a full ISO time */
function when(s) {
  s = String(s || '').trim(); if (!s) return '';
  let m = /^(\d{4})-(\d\d)-(\d\d)[ T](\d\d):(\d\d)(?::(\d\d))?$/.exec(s);
  if (m) { const d = new Date(m[1] + '-' + m[2] + '-' + m[3] + 'T' + m[4] + ':' + m[5] + ':' + (m[6] || '00') + '+05:30'); return isNaN(d) ? '' : d.toISOString(); }
  m = /^(\d\d)[ -/](\d\d)[ -/](\d{4})[ T](\d\d):(\d\d)(?::(\d\d))?$/.exec(s);
  if (m) { const d = new Date(m[3] + '-' + m[2] + '-' + m[1] + 'T' + m[4] + ':' + m[5] + ':' + (m[6] || '00') + '+05:30'); return isNaN(d) ? '' : d.toISOString(); }
  if (/^\d{4}-\d\d-\d\d$/.test(s)) { const d = new Date(s + 'T12:00:00+05:30'); return isNaN(d) ? '' : d.toISOString(); }
  const d = new Date(s); return isNaN(d) || !/\d{4}/.test(s) ? '' : d.toISOString();
}
/* "2026-11-03 10:00:00" -> "3 Nov" (India date) */
function dayName(v) {
  const t = when(v); if (!t) return '';
  const d = new Date(new Date(t).getTime() + 5.5 * 3600e3);
  return d.getUTCDate() + ' ' + ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][d.getUTCMonth()];
}
function indiaStamp(d) {          /* "2026-11-02 14:05" in India time, for Shiprocket's order_date */
  const t = new Date((d ? new Date(d) : new Date()).getTime() + 5.5 * 3600e3).toISOString();
  return t.slice(0, 10) + ' ' + t.slice(11, 16);
}
async function call(url, opts, ms) {
  opts = opts || {};
  try {
    const r = await Promise.race([fetch(url, opts), new Promise((_, j) => setTimeout(() => j(new Error('timeout')), ms || 15000))]);
    const text = await r.text().catch(() => '');
    let body = null; try { body = JSON.parse(text); } catch (e) {}
    return { ok: r.ok, status: r.status, body, text };
  } catch (e) { return { ok: false, status: 0, body: null, text: '', error: e.message }; }
}
const ip = req => String(req.headers['x-forwarded-for'] || '').split(',')[0].trim() || 'ip';

/* ---------- the order ---------- */
/* A parcel record is written only by this server, and carries its signature (made with the database's secret key, which
   only the server has). The public may add a new order -- with anything in it -- so a parcel record planted in a new
   order (a fake tracking number, a stranger's Borzo number) has no valid signature and is ignored everywhere here.
   (If the database's secret key is ever changed in Vercel, parcels still on their way lose their tracking: book them
   BY HAND with the same tracking number.) */
function shipSig(ref, s) {
  const k = crypto.createHash('sha256').update('vg-parcel|' + L.env('SUPABASE_SERVICE_KEY')).digest();
  return crypto.createHmac('sha256', k).update([ref, s.via, s.awb || '', s.bzOrderId || '', s.srOrderId || '', s.srShipmentId || ''].join('|')).digest('hex').slice(0, 32);
}
function shipOf(row) {
  const s = row && row.payload && typeof row.payload === 'object' ? row.payload.ship : null;
  return s && typeof s === 'object' && !Array.isArray(s) && typeof s.sig === 'string' && same(s.sig, shipSig(row.ref, s)) ? s : null;
}
async function readOrder(ref) {
  const r = await L.db('/rest/v1/orders?select=ref,name,phone,status,total,created_at,payload&ref=eq.' + enc(ref) + '&limit=2');
  if (!r.ok || !Array.isArray(r.body)) throw new Error('database');
  return r.body.length === 1 ? r.body[0] : (r.body.length > 1 ? { dup: true } : null);
}
/* "write only if it is still what I read". Two counters: the parcel record's rev (only this server writes it -- always a
   whole number) and payload.editRev (raised by every OTHER writer: Admin's own edits, the UPI confirmation, the prescription
   attach). ->> gives text; a missing record, a JSON null, a string or a number all give NULL there. */
function revFilter(stored, genuine) {
  if (!stored || typeof stored !== 'object' || Array.isArray(stored)) return '&payload->ship->>rev=is.null';
  const r = stored.rev;
  if (genuine) return Number.isSafeInteger(r) ? '&payload->ship->>rev=eq.' + r : '&payload->ship->>rev=is.null';
  /* a record planted in a stranger's order: matched by its own text (a planted number like 1.0 could never match) */
  if (typeof stored.sig === 'string' && /^[A-Za-z0-9_-]{1,64}$/.test(stored.sig)) return '&payload->ship->>sig=eq.' + stored.sig;
  if (r == null) return '&payload->ship->>rev=is.null';
  if (typeof r === 'string' && /^[A-Za-z0-9_-]{1,40}$/.test(r)) return '&payload->ship->>rev=eq.' + r;
  return '';
}
function editFilter(pay) {
  const e = pay && typeof pay === 'object' ? pay.editRev : undefined;
  if (e == null) return '&payload->>editRev=is.null';
  if (Number.isSafeInteger(e) && e >= 0 && e < 1e9) return '&payload->>editRev=eq.' + e;
  return '';
}
/* The parcel states. LIVE = on its way (checked with the courier); SHOWN = what the customer's page shows. Before that:
   "booking" (one phone is booking it right now), "created" (a Shiprocket order exists but no courier yet), "none". */
const LIVE = ['booked', 'picked', 'transit', 'out', 'failed', 'returning', 'problem'];
const SHOWN = LIVE.concat(['delivered', 'returned']);
const LOCK_MS = 150e3;                           /* a booking that died half way frees itself after 2.5 minutes */
/* Changes payload.ship (+ a few named fields) -- read fresh, changed, written only if nobody wrote the parcel in between,
   otherwise read again and tried again. fn(ship, row) returns { ship, status?, extra?, tell? }, null (no change) or
   { abort: 'why' }. */
async function saveShip(ref, fn) {
  for (let i = 0; i < 6; i++) {
    const row = await readOrder(ref);
    if (!row || row.dup) return { ok: false, why: row && row.dup ? 'dup' : 'not-found' };
    const pay = Object.assign({}, row.payload && typeof row.payload === 'object' ? row.payload : {});
    const stored = pay.ship;
    const old = shipOf(row);                                                   /* a planted record counts as none */
    const out = fn(old ? JSON.parse(JSON.stringify(old)) : null, row);
    if (!out) return { ok: true, row, ship: old, same: true, tell: [] };
    if (out.abort) return { ok: false, why: 'abort', msg: out.abort, ship: old };
    const ship = out.ship;
    const sr0 = old ? Number(old.rev) : 0;
    ship.rev = (Number.isSafeInteger(sr0) && sr0 > 0 ? sr0 : 0) + 1;
    ship.live = LIVE.indexOf(ship.step) >= 0 ? 1 : 0;
    ship.sig = shipSig(ref, ship);
    const np = Object.assign(pay, out.extra || {}, { ship });
    const body = { payload: np };
    if (out.status && out.status !== row.status) body.status = out.status;
    const w = await L.db('/rest/v1/orders?ref=eq.' + enc(ref) + revFilter(stored, !!old) + (i < 4 ? editFilter(row.payload) : '') + '&select=ref', { method: 'PATCH', headers: { Prefer: 'return=representation' }, body: JSON.stringify(body) });
    if (!w.ok) return { ok: false, why: 'database' };
    if (Array.isArray(w.body) && w.body.length === 1) return { ok: true, row: Object.assign({}, row, { payload: np, status: body.status || row.status }), ship, old, tell: out.tell || [] };
    /* someone else changed it at the same moment: read again */
  }
  return { ok: false, why: 'busy' };
}

/* ---------- where a parcel is ---------- */
const RANK = { booked: 1, picked: 2, transit: 3, out: 4, delivered: 5 };
const FINAL = ['delivered', 'returned', 'cancelled'];
function nextStep(cur, nw) {
  if (!nw || nw === cur) return cur || nw;
  if (!cur) return nw;
  if (FINAL.indexOf(cur) >= 0) return cur;                                  /* delivered / returned / cancelled stay */
  if (['delivered', 'cancelled', 'returned', 'returning', 'problem', 'failed'].indexOf(nw) >= 0) return cur === 'returning' && nw !== 'returned' && nw !== 'delivered' ? cur : nw;
  if (cur === 'returning') return cur;
  if (cur === 'failed' || cur === 'problem') return nw;                     /* back on its way */
  return (RANK[nw] || 0) > (RANK[cur] || 0) ? nw : cur;                       /* never backwards */
}
/* Shiprocket's status words -> our steps (by the words, so a new status number never confuses it) */
function srStep(text) {
  const t = String(text || '').toUpperCase().replace(/_/g, ' ').trim();
  if (!t) return '';
  if (/PICKUP (EXCEPTION|ERROR|FAIL|CANCEL|RESCHEDULED)|NOT PICKED/.test(t)) return 'booked';   /* still in the shop (the manager is told) */
  if (/RTO.*DELIVERED|RETURN.*DELIVERED|REACHED BACK|RETURNED TO (SELLER|ORIGIN)/.test(t)) return 'returned';
  if (/\bRTO\b|RETURN/.test(t)) return 'returning';
  if (/CANCEL.*REQUEST|REQUEST.*CANCEL/.test(t)) return '';                /* only asked for: nothing changes yet */
  if (/\bCANCELL?ED\b/.test(t)) return 'cancelled';
  if (/LOST|DAMAGE|DESTROY|UNTRACEABLE|DISPOSED/.test(t)) return 'problem';
  if (/UNDELIVERED|NOT DELIVERED|DELIVERY (ATTEMPT|FAILED)|\bNDR\b|FAILED ATTEMPT|ISSUE RELATED TO THE RECIPIENT/.test(t)) return 'failed';
  if (/OUT FOR DELIVERY|\bOFD\b/.test(t)) return 'out';
  if (/DELIVERED/.test(t)) return 'delivered';
  if (/PICKED UP|PICKUP DONE|SHIPMENT PICKED/.test(t)) return 'picked';
  if (/TRANSIT|SHIPPED|REACHED|HUB|IN FLIGHT|HANDOVER|MISROUTED|DELAYED|CONNECTION|DISPATCH/.test(t)) return 'transit';
  if (/PICKUP|MANIFEST|BOOKED|AWB ASSIGNED|READY TO SHIP|PACKED|^(NEW|PENDING|INVOICED)$/.test(t)) return 'booked';
  return '';
}
const WORDS = {                       /* what the customer reads, in plain words */
  booked: 'Booked with the courier — waiting for pickup from our shop',
  picked: 'Picked up from our shop',
  transit: 'On the way',
  out: 'Out for delivery today',
  delivered: 'Delivered',
  failed: 'The courier could not deliver it — they will try again',
  returning: 'Coming back to our shop',
  returned: 'Back at our shop',
  cancelled: 'Delivery cancelled',
  problem: 'Delayed — our team is checking with the courier'
};
const RIDER_WORDS = {
  booked: 'Looking for a rider', picked: 'Picked up — the rider is on the way to you', transit: 'Picked up — the rider is on the way to you',
  out: 'Picked up — the rider is on the way to you', delivered: 'Delivered', failed: 'The rider could not deliver it',
  returning: 'Coming back to our shop', returned: 'Back at our shop', cancelled: 'Delivery cancelled', problem: 'Delayed — our team is checking'
};
/* one courier report -> our parcel; returns the messages to send (each kind once per parcel) */
function applyNews(ship, n) {
  ship.told = ship.told && typeof ship.told === 'object' ? ship.told : {};
  const tell = [];
  ship.checkedAt = nowIso();
  /* the courier could not collect it from the shop: the manager hears at once (the parcel is still in the shop) */
  if (/PICKUP (EXCEPTION|ERROR|FAIL|CANCEL)|NOT PICKED/i.test(String(n.raw || '')) && !ship.told.mgr_pickup) { ship.told.mgr_pickup = n.at || nowIso(); tell.push('mgr:PICKUP PROBLEM'); }
  const at = n.at || nowIso();
  /* an older report arriving after a newer one changes nothing (not even the list of scans) */
  if (ship.lastAt && at < ship.lastAt && n.step !== 'delivered') return tell;
  if (!ship.lastAt || at > ship.lastAt) ship.lastAt = at;
  if (n.scans && n.scans.length) ship.scans = n.scans.slice(0, 15);
  if (n.eta) ship.eta = n.eta;
  if (n.trackUrl) ship.trackUrl = n.trackUrl;
  if (n.courier && !ship.courier) ship.courier = n.courier;
  if (n.rider) ship.rider = n.rider;
  if (n.raw) ship.raw = plain(n.raw, 80);
  const step = nextStep(ship.step, n.step);
  const text = plain(n.text || (ship.kind === 'rider' ? RIDER_WORDS : WORDS)[step] || '', 120);
  if (step !== ship.step || (text && text !== ship.text)) {
    const moved = step !== ship.step;
    ship.step = step; if (text) ship.text = text; ship.at = nowIso();
    ship.events = (Array.isArray(ship.events) ? ship.events : []).concat([{ at, step, text: ship.text }]).slice(-25);
    if (moved) {
      if ((step === 'out' || (ship.kind === 'rider' && (step === 'picked' || step === 'transit'))) && !ship.told.out) { ship.told.out = at; tell.push('out'); }
      if (step === 'delivered' && !ship.told.delivered) { ship.told.delivered = at; tell.push('delivered'); }
      if (step === 'failed' && !ship.told.failed) { ship.told.failed = at; tell.push('failed'); }
      if ((step === 'returning' || step === 'problem' || (step === 'cancelled' && !n.byShop) || step === 'failed') && !ship.told['mgr_' + step]) { ship.told['mgr_' + step] = at; tell.push('mgr'); }
    }
  }
  return tell;
}

/* ---------- Shiprocket ---------- */
let SRTOK = { t: '', at: 0 };
async function srToken(force) {
  if (!force && SRTOK.t && Date.now() - SRTOK.at < 20 * 3600e3) return SRTOK.t;
  const r = await call(SR + '/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: L.env('SHIPROCKET_EMAIL'), password: L.env('SHIPROCKET_PASSWORD') }) });
  const t = r.ok && r.body && r.body.token ? String(r.body.token) : '';
  if (!t) throw new Error('Shiprocket did not accept the API user (check SHIPROCKET_EMAIL and SHIPROCKET_PASSWORD in Vercel -- it must be the API user from Shiprocket -> Settings -> API)');
  SRTOK = { t, at: Date.now() };
  return t;
}
async function sr(path, opts, ms) {
  opts = opts || {};
  for (let i = 0; i < 2; i++) {
    const tok = await srToken(i > 0);
    const r = await call(SR + path, { method: opts.method || 'GET', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + tok }, body: opts.body ? JSON.stringify(opts.body) : undefined }, ms);
    if (r.status === 401 && i === 0) continue;                              /* the sign-in ran out: once more, signed in again */
    return r;
  }
}
function srWhy(r, fallback) {
  const b = (r && r.body) || {};
  const bits = [b.message, b.response && b.response.data && (b.response.data.awb_assign_error || b.response.data.message)];
  if (b.errors && typeof b.errors === 'object') Object.keys(b.errors).slice(0, 4).forEach(k => bits.push(k + ': ' + [].concat(b.errors[k]).join(', ')));
  const t = plain(bits.filter(x => typeof x === 'string' && x).join(' -- '), 220);
  return t || (r && r.status ? fallback + ' (Shiprocket answered ' + r.status + ')' : fallback + ' (Shiprocket did not answer)');
}
function srNews(td) {
  td = td || {};
  const st = Array.isArray(td.shipment_track) && td.shipment_track[0] ? td.shipment_track[0] : {};
  const acts = Array.isArray(td.shipment_track_activities) ? td.shipment_track_activities : [];
  const scans = acts.filter(a => a && typeof a === 'object').map(a => ({ at: when(a.date), text: plain(a.activity || a['sr-status-label'] || a.status, 100), place: plain(a.location, 60) }))
    .filter(s => s.text).sort((a, b) => (b.at || '').localeCompare(a.at || ''));
  const raw = String(st.current_status || (acts[0] && (acts[0]['sr-status-label'] || acts[0].activity)) || '');
  return { step: srStep(raw), raw, scans, at: (scans[0] && scans[0].at) || '', eta: when(td.etd || st.edd) || '', trackUrl: /^https:\/\//.test(String(td.track_url || '')) ? String(td.track_url) : '' };
}
async function srTrack(awb) {
  const r = await sr('/courier/track/awb/' + enc(awb), {}, 12000);
  if (!r || !r.ok || !r.body) return null;
  const td = r.body.tracking_data || (r.body[awb] && r.body[awb].tracking_data) || null;
  if (!td || typeof td !== 'object' || (Number(td.track_status) === 0 && !(td.shipment_track_activities || []).length)) return null;   /* nothing scanned yet */
  return srNews(td);
}
/* Shiprocket may have given a courier even when its answer never reached us (a timeout): ask before asking again */
async function srShow(id) {
  const r = await sr('/orders/show/' + enc(id), {}, 12000);
  const d = r && r.ok && r.body && r.body.data && typeof r.body.data === 'object' ? r.body.data : null;
  if (!d) return null;
  const sh = Array.isArray(d.shipments) ? d.shipments[0] : d.shipments;
  const awb = String((d.awb_data && d.awb_data.awb) || (sh && sh.awb) || '').trim();
  return awb ? { awb: plain(awb, 40), courier: plain((sh && (sh.courier || sh.courier_name)) || d.courier_name || '', 50) } : null;
}
async function srCancel(id) {
  const r = await sr('/orders/cancel', { method: 'POST', body: { ids: [Number(id) || id] } }, 15000);
  return r && r.ok ? { ok: true } : { ok: false, error: srWhy(r, 'Shiprocket did not cancel it') };
}

/* ---------- Borzo ---------- */
async function bz(path, opts, ms) {
  opts = opts || {};
  return call(BZ() + path, { method: opts.method || 'GET', headers: { 'Content-Type': 'application/json', 'X-DV-Auth-Token': L.env('BORZO_TOKEN') }, body: opts.body ? JSON.stringify(opts.body) : undefined }, ms);
}
const BZ_WORDS = {
  address_not_found: 'Borzo could not find this address on the map -- add the area, a landmark and the pincode',
  insufficient_balance: 'There is not enough money in your Borzo account -- top it up in the Borzo app',
  invalid_phone: 'Borzo did not accept a phone number -- check the customer\'s mobile and the shop\'s number in Settings -> Delivery',
  order_cannot_be_canceled: 'Borzo says this booking can no longer be cancelled (the rider has it) -- call Borzo support',
  unauthorized: 'Borzo did not accept the BORZO_TOKEN in Vercel (a test token works only with BORZO_TEST=1, a live token only without it)',
  invalid_api_version: 'Borzo did not accept the connection version'
};
function bzWhy(r, fallback) {
  const b = (r && r.body) || {};
  const codes = [].concat(b.errors || []).filter(x => typeof x === 'string');
  const walk = (o, path) => { if (!o) return; if (Array.isArray(o)) { o.forEach((x, i) => typeof x === 'string' ? codes.push(x + (path ? ' (' + path + ')' : '')) : walk(x, path ? path + '.' + i : String(i))); } else if (typeof o === 'object') Object.keys(o).forEach(k => walk(o[k], path ? path + '.' + k : k)); };
  walk(b.parameter_errors, '');
  const words = codes.map(c => { const k = String(c).split(' ')[0]; return BZ_WORDS[k] ? BZ_WORDS[k] + (/points\.0/.test(c) ? ' (the shop\'s address)' : /points\.1/.test(c) ? ' (the customer\'s address)' : '') : c; });
  const t = plain([...new Set(words)].join(' -- '), 240);
  if (r && r.status === 401) return BZ_WORDS.unauthorized;
  return t || (r && r.status ? fallback + ' (Borzo answered ' + r.status + ')' : fallback + ' (Borzo did not answer)');
}
function bzNews(order) {
  order = order && typeof order === 'object' ? order : {};
  const st = String(order.status || '').toLowerCase();
  const pts = Array.isArray(order.points) ? order.points.filter(x => x && typeof x === 'object') : [];
  const pick = pts[0] || {}, drop = pts[pts.length - 1] || {};
  const dst = String((drop.delivery && drop.delivery.status) || '').toLowerCase();
  const pickedUp = !!pick.courier_visit_datetime || ['parcel_picked_up', 'courier_arrived'].indexOf(dst) >= 0;
  const c = order.courier && typeof order.courier === 'object' ? order.courier : null;
  const rider = c ? { name: plain([c.name, c.surname].filter(Boolean).join(' '), 40), phone: String(c.phone || '').replace(/\D/g, '').slice(-12) } : null;
  let step = 'booked', text = 'Looking for a rider';
  /* a parcel coming back is checked BEFORE "completed" (an order can be completed by returning it to the shop) */
  if (st === 'canceled' || st === 'cancelled' || dst === 'canceled') { step = 'cancelled'; text = 'Delivery cancelled'; }
  else if (/^return/.test(dst)) { step = /finished|returned/.test(dst) ? 'returned' : 'returning'; text = step === 'returned' ? 'Back at our shop' : 'Coming back to our shop'; }
  else if (dst === 'failed') { step = 'failed'; text = 'The rider could not deliver it'; }
  else if (dst === 'finished' || (st === 'completed' && (!dst || dst === 'finished'))) { step = 'delivered'; text = 'Delivered'; }
  else if (pickedUp) { step = 'out'; text = dst === 'courier_arrived' ? 'The rider has reached your address' : 'Picked up — the rider is on the way to you'; }
  else if (st === 'active') { step = 'booked'; text = rider && rider.name ? 'Rider ' + rider.name.split(' ')[0] + ' is going to our shop to pick it up' : 'A rider is going to our shop to pick it up'; }
  const url = String(drop.tracking_url || '');
  return { step, text, raw: st + (dst ? '/' + dst : ''), rider, trackUrl: /^https:\/\//.test(url) ? url : '', price: Number(order.payment_amount) || 0 };
}
async function bzOrder(id) {
  const r = await bz('/orders?order_id=' + enc(id), {}, 12000);
  if (!r.ok || !r.body || r.body.is_successful === false) return null;
  /* only the order with exactly this number -- never "the first one in the list" */
  const list = Array.isArray(r.body.orders) ? r.body.orders : (r.body.order ? [r.body.order] : []);
  return list.find(x => x && String(x.order_id) === String(id)) || null;
}
async function bzCancel(id) {
  const r = await bz('/cancel-order', { method: 'POST', body: { order_id: Number(id) || id } }, 15000);
  return r.ok && r.body && r.body.is_successful !== false ? { ok: true } : { ok: false, error: bzWhy(r, 'Borzo did not cancel it') };
}

/* ---------- WhatsApp ---------- */
function trackLink(ref, key) { return SITE + '/track?o=' + enc(ref) + (key ? '&k=' + enc(key) : ''); }
function firstName(row) { return plain(String(row.name || (row.payload || {}).name || '').trim().split(/\s+/)[0], 30) || 'there'; }
async function tellCustomer(row, kind) {
  const p = row.payload || {}, s = p.ship || {}, ref = row.ref, link = trackLink(ref, p.trackKey);
  const hi = 'Hi ' + firstName(row) + ', ';
  let text = '';
  if (kind === 'booked') text = s.kind === 'rider'
    ? hi + 'your Vision Gallery order ' + ref + ' is being delivered today by a rider from our ' + (s.from || '') + ' shop.' + (s.trackUrl ? '\n\nFollow the rider live: ' + s.trackUrl : '') + '\n\nYour order page: ' + link
    : hi + 'your Vision Gallery order ' + ref + ' is on its way.' + (s.courier ? '\n\nCourier: ' + s.courier : '') + (s.awb ? '\nTracking no.: ' + s.awb : '') + '\n\nTrack it any time: ' + link;
  else if (kind === 'out') text = s.kind === 'rider'
    ? hi + 'the rider has picked up your glasses (order ' + ref + ') and is on the way to you.' + (s.trackUrl ? '\n\nFollow live: ' + s.trackUrl : '\n\nTrack: ' + link)
    : hi + 'your order ' + ref + ' is out for delivery today. Please keep your phone handy.\n\nTrack: ' + link;
  else if (kind === 'delivered') text = hi + 'your order ' + ref + ' has been delivered. We hope you love your new glasses!\n\nA quick review helps us a lot: ' + SITE + '/review?o=' + enc(ref) + '\n\nAnything not right? Just reply to this message.';
  else if (kind === 'failed') text = hi + 'the ' + (s.kind === 'rider' ? 'rider' : 'courier') + ' could not deliver your order ' + ref + ' just now. ' + (s.kind === 'rider' ? 'We will call you to fix a time.' : 'They will try again — or reply to this message and we will sort it out.') + '\n\nTrack: ' + link;
  if (!text) return { ok: false };
  /* a TEST booking (Borzo's test system): the message goes to the manager, marked, never to the customer */
  if (s.test) {
    const shop = await L.shopSettings(), mgr = shop.mgrWa || shop.wa;
    return mgr ? L.whatsapp(mgr, '[TEST -- this would go to the customer]\n\n' + text) : { ok: false };
  }
  return L.whatsapp(row.phone || p.phone, text);
}
async function tellManager(row, why) {
  try {
    const shop = await L.shopSettings(), mgr = shop.mgrWa || shop.wa; if (!mgr) return;
    const s = (row.payload || {}).ship || {};
    await L.whatsapp(mgr, (s.test ? '[TEST] ' : '') + 'DELIVERY ' + (why || 'PROBLEM') + ' -- ' + row.ref + '\n' + plain(row.name, 40) + '\n' + (s.text || '') + '\n' + [s.courier, s.awb].filter(Boolean).join(' · ') + '\n\nPlease check Admin -> Orders -> DELIVERY.');
  } catch (e) {}
}
async function afterSave(res) {
  if (!res || !res.ok || !res.tell || !res.tell.length) return;
  for (const k of res.tell) {
    try {
      if (/^mgr/.test(k)) await tellManager(res.row, k.split(':')[1] || (res.ship.step || '').toUpperCase());
      else await tellCustomer(res.row, k);
    } catch (e) {}
  }
}
/* a courier report saved onto the order (+ "Delivered" on the order itself when it arrives -- not for a TEST booking) */
async function applyToOrder(ref, news, touch) {
  const res = await saveShip(ref, ship => {
    if (!ship || SHOWN.indexOf(ship.step) < 0) return null;                  /* only a parcel on its way takes news */
    const checked0 = ship.checkedAt;
    const before = JSON.stringify([ship.step, ship.text, ship.eta, ship.trackUrl, (ship.scans || [])[0], ship.rider && ship.rider.name]);
    const tell = applyNews(ship, news);
    const after = JSON.stringify([ship.step, ship.text, ship.eta, ship.trackUrl, (ship.scans || [])[0], ship.rider && ship.rider.name]);
    if (before === after && !tell.length) {
      /* nothing new: a webhook writes nothing; a check asked by the website keeps its time (at most every 5 minutes) */
      if (touch && (!checked0 || Date.now() - new Date(checked0).getTime() > 5 * 60e3)) return { ship, tell: [] };
      return null;
    }
    return { ship, tell, status: ship.step === 'delivered' && !ship.test ? 'Delivered' : undefined };
  });
  await afterSave(res);
  return res;
}
/* ask the courier again (when nobody has told us anything for a while) */
async function refresh(row, force) {
  const s = shipOf(row);
  if (!s || !s.live) return { ok: true, ship: s };
  if (!force && s.checkedAt && Date.now() - new Date(s.checkedAt).getTime() < 10 * 60e3) return { ok: true, ship: s };
  let news = null;
  try {
    if (s.via === 'shiprocket' && s.awb && srReady()) news = await srTrack(s.awb);
    else if (s.via === 'borzo' && s.bzOrderId && bzReady()) { const o = await bzOrder(s.bzOrderId); if (o) news = bzNews(o); }
  } catch (e) { news = null; }
  if (!news) {                                     /* nothing new: only the time of the check is kept */
    if (s.via === 'hand') return { ok: true, ship: s };
    const r = await saveShip(row.ref, ship => ship && ship.live ? (ship.checkedAt = nowIso(), { ship, tell: [] }) : null);
    return { ok: true, ship: r.ship || s, row: r.row };
  }
  return applyToOrder(row.ref, news, true);
}

/* ---------- what the customer's page shows (never the address, the phone or the price) ---------- */
function stageOf(row) {
  const st = row.status || 'New', s0 = shipOf(row), s = s0 && SHOWN.indexOf(s0.step) >= 0 && !s0.test ? s0 : null;
  if (st === 'Delivered' || (s && s.step === 'delivered')) return 'delivered';
  if (s && ['returning', 'returned'].indexOf(s.step) >= 0) return 'back';
  if (s) return 'onway';
  if (st === 'Ready') return 'ready';
  if (st === 'At Lab' || st === 'At QC') return 'making';
  return 'received';
}
function view(row) {
  const p = row.payload || {}, s0 = shipOf(row), s = s0 && SHOWN.indexOf(s0.step) >= 0 && !s0.test ? s0 : null;
  const out = {
    ok: true, ref: row.ref, placed: row.created_at || p.placed || '', stage: stageOf(row),
    pickup: p.fulfil === 'pickup', store: p.fulfil === 'pickup' ? plain(p.store, 40) : '',
    frame: plain(p.frame, 80), waitingRx: (row.status || '') === 'Waiting for Prescription', eyeTest: ['hometest', 'shoptest'].indexOf(p.rxPath) >= 0 ? p.rxPath : '',
    express: !!p.express
  };
  if (s) out.ship = {
    kind: s.kind === 'rider' ? 'rider' : 'courier', courier: plain(s.courier, 40), awb: plain(s.awb, 40),
    trackUrl: /^https:\/\//.test(String(s.trackUrl || '')) ? String(s.trackUrl) : '', step: s.step || 'booked', text: plain(s.text, 120),
    eta: s.eta || '', at: s.at || s.bookedAt || '', rider: s.rider && s.rider.name ? plain(String(s.rider.name).split(' ')[0], 20) : '',
    events: (Array.isArray(s.events) ? s.events : []).slice(-12).reverse().map(e => ({ at: e && e.at, text: plain(e && e.text, 120) })),
    scans: (Array.isArray(s.scans) ? s.scans : []).slice(0, 10).map(e => ({ at: e && e.at, text: plain(e && e.text, 100), place: plain(e && e.place, 60) }))
  };
  return out;
}

/* ---------- Admin: booking ---------- */
function ten(v) { return L.phone10(v); }
function addressOf(row, to) {
  const p = row.payload || {};
  to = to && typeof to === 'object' ? to : {};
  const ad = p.addr && typeof p.addr === 'object' ? p.addr : null;           /* d17.205 orders: the address in parts */
  const pin = String(to.pin || (ad && ad.pin) || (/(\d{6})(?!.*\d{6})/.exec(String(p.address || '')) || [])[1] || '').replace(/\D/g, '').slice(0, 6);
  const line = plain(to.address || (ad ? [ad.line1, ad.line2].filter(Boolean).join(', ') : String(p.address || '').replace(/,?\s*\d{6}\s*$/, '')), 200);
  return { line, pin, landmark: plain(to.landmark != null ? to.landmark : ad && ad.landmark, 80), city: plain(to.city, 40), state: plain(to.state, 40) };
}
function boxOf(b) {
  b = b && typeof b === 'object' ? b : {};
  const n = (v, d, lo, hi) => { const x = Number(v); return x >= lo && x <= hi ? Math.round(x * 10) / 10 : d; };
  return { l: n(b.l, 20, 1, 100), b: n(b.b, 12, 1, 100), h: n(b.h, 8, 1, 100), kg: n(b.kg, 0.5, 0.05, 20) };
}
async function branchOf(name) {
  const shop = await L.shopSettings();
  const all = shop.branchAddr && typeof shop.branchAddr === 'object' ? shop.branchAddr : {};
  const b = all[name] && typeof all[name] === 'object' ? all[name] : {};
  return { name: plain(name, 40), address: plain(b.address, 300), pin: String(b.pin || '').replace(/\D/g, '').slice(0, 6), phone: ten(b.phone) || ten(shop.phone) || ten(shop.wa), shop };
}
async function srPickups() {
  const r = await sr('/settings/company/pickup', {}, 12000);
  const list = r && r.ok && r.body && r.body.data && Array.isArray(r.body.data.shipping_address) ? r.body.data.shipping_address : null;
  if (!list) return { ok: false, error: srWhy(r, 'Could not read your pickup addresses') };
  return { ok: true, list: list.filter(a => a && typeof a === 'object').map(a => ({ name: plain(a.pickup_location, 80), pin: String(a.pin_code || ''), city: plain(a.city, 40), primary: !!a.is_primary_location })) };
}

async function quote(row, b) {
  const to = addressOf(row, b.to), box = boxOf(b.box), out = {};
  const br = await branchOf(b.from);
  if (srReady()) {
    try {
      let pickPin = String(b.pickupPin || br.pin || '').replace(/\D/g, '');
      if (!/^\d{6}$/.test(pickPin)) { const pk = await srPickups(); const pr = pk.ok && (pk.list.find(x => x.name === b.pickup) || pk.list.find(x => x.primary) || pk.list[0]); pickPin = pr ? String(pr.pin) : ''; }
      if (!/^\d{6}$/.test(to.pin)) out.shiprocket = { ok: false, error: 'The customer\'s pincode is missing' };
      else if (!/^\d{6}$/.test(pickPin)) out.shiprocket = { ok: false, error: 'Type the shop\'s pincode in Settings -> Delivery' };
      else {
        const r = await sr('/courier/serviceability/?pickup_postcode=' + pickPin + '&delivery_postcode=' + to.pin + '&weight=' + box.kg + '&cod=0', {}, 12000);
        const list = r && r.ok && r.body && r.body.data && Array.isArray(r.body.data.available_courier_companies) ? r.body.data.available_courier_companies : null;
        if (!list) out.shiprocket = { ok: false, error: srWhy(r, 'No courier delivers to this pincode') };
        else out.shiprocket = { ok: true, recommended: r.body.data.shiprocket_recommended_courier_id || null, couriers: list.filter(c => c && typeof c === 'object').map(c => ({ id: c.courier_company_id, name: plain(c.courier_name, 50), rate: Number(c.rate || c.freight_charge) || 0, days: plain(c.estimated_delivery_days, 10), etd: plain(c.etd, 30) }))
          .filter(c => c.id).sort((a, x) => a.rate - x.rate).slice(0, 8) };
      }
    } catch (e) { out.shiprocket = { ok: false, error: plain(e.message, 200) }; }
  }
  if (bzReady()) {
    try {
      if (!br.address) out.borzo = { ok: false, error: 'Type the ' + (br.name || 'shop') + ' shop\'s address in Admin -> Settings -> Delivery first' };
      else {
        const r = await bz('/calculate-order', { method: 'POST', body: bzBody(row, to, br, b.note) }, 12000);
        if (r.ok && r.body && r.body.is_successful !== false && r.body.order) out.borzo = { ok: true, price: Number(r.body.order.payment_amount) || 0, test: !!L.env('BORZO_TEST') };
        else out.borzo = { ok: false, error: bzWhy(r, 'Borzo could not price this trip') };
      }
    } catch (e) { out.borzo = { ok: false, error: plain(e.message, 200) }; }
  }
  return out;
}
function bzBody(row, to, br, note) {
  const p = row.payload || {}, phone = ten(row.phone || p.phone);
  const body = {
    matter: 'Spectacles (glasses) in a box -- fragile, keep flat',
    total_weight_kg: 1,
    points: [
      { address: br.address + (br.pin && br.address.indexOf(br.pin) < 0 ? ', ' + br.pin : ''), contact_person: { phone: '91' + br.phone, name: 'Vision Gallery ' + br.name }, client_order_id: row.ref, note: plain('Order ' + row.ref + ' -- ask for it at the counter', 300) },
      { address: [to.line, to.city, to.pin].filter(Boolean).join(', '), contact_person: { phone: '91' + phone, name: plain(row.name || p.name, 60) || 'Customer' }, client_order_id: row.ref, note: plain([to.landmark && 'Landmark: ' + to.landmark, note].filter(Boolean).join(' -- '), 300) }
    ]
  };
  const shop = br.shop || {}, pay = shop.parcel && shop.parcel.borzoPay;
  if (pay === 'cash' || pay === 'non_cash') body.payment_method = pay;
  return body;
}
/* where a parcel record stands */
const isBusy = s => !!(s && s.lockAt && Date.now() - new Date(s.lockAt).getTime() < LOCK_MS);   /* a phone is working on it right now */
const isBooked = s => !!(s && (LIVE.indexOf(s.step) >= 0 || s.step === 'delivered'));   /* "returned" (back in the shop) can be sent again */
/* a Shiprocket order made without a courier yet (or one left by a booking that died half way) */
const srPending = s => !!(s && s.via === 'shiprocket' && s.srOrderId && !s.awb && (s.step === 'created' || (s.step === 'booking' && !isBusy(s))));
function histOf(s, why) {
  if (!s) return [];
  const h = Array.isArray(s.history) ? s.history.slice() : [];
  if (s.via && (s.awb || s.bzOrderId || s.srOrderId || s.via === 'hand')) h.push({ via: s.via, courier: s.courier || '', awb: s.awb || '', bzOrderId: s.bzOrderId || '', srOrderId: s.srOrderId || '', cancelledAt: s.cancelledAt || nowIso(), why: why || '' });
  return h.slice(-10);
}
const deep = o => JSON.parse(JSON.stringify(o));
/* The lock: one phone at a time works on an order's delivery. For a NEW booking the record becomes a bare "booking"
   (only who and when -- nothing of an earlier booking is carried); for a cancel the record keeps everything and only
   gets the lock fields. It frees itself after 2.5 minutes if a phone died half way. */
async function lockFor(ref, who, via, opt) {
  opt = opt || {};
  let prev = null;
  const lockAt = nowIso();
  const res = await saveShip(ref, s => {
    if (isBusy(s)) return { abort: 'Another phone is working on this order\'s delivery right now (' + (s.lockBy || 'staff') + ') -- wait a minute and look again' };
    if (!opt.booked && isBooked(s)) return { abort: 'This order is already booked (' + (s.courier || s.via) + '). Cancel that booking first to book again.' };
    if (!opt.keep && s && s.step === 'booking' && s.bzTry && !s.bzOrderId) return { abort: 'The last rider booking for this order may have gone through (the answer was lost). Look in the Borzo app: if a rider is booked, save it with BY HAND (Borzo + its number); if not, tap CLEAR and book again.' };
    prev = s ? deep(s) : null;
    if (opt.keep && s) return { ship: Object.assign(s, { lockAt, lockBy: plain(who, 40), lockVia: via }) };
    const lock = { step: 'booking', lockAt, lockBy: plain(who, 40), lockVia: via, history: Array.isArray(s && s.history) ? s.history.slice() : [], told: {}, events: [] };
    if (srPending(s)) Object.assign(lock, { via: 'shiprocket', srOrderId: s.srOrderId, srShipmentId: s.srShipmentId, fp: s.fp, pickup: s.pickup || '' });
    return { ship: lock };
  });
  return { res, prev, lockAt };
}
/* a write that must not be lost (money is already spent): tried again if the database stumbles */
async function saveHard(ref, fn) {
  let last = null;
  for (let i = 0; i < 3; i++) { try { last = await saveShip(ref, fn); if (last.ok || last.why === 'abort') return last; } catch (e) { last = { ok: false, why: 'database' }; } }
  return last || { ok: false };
}
/* give the lock back after a failure. What THIS try did decides what stays: a Shiprocket order it made (or carried on)
   stays as "created" (the next try uses it or cancels it); one it cancelled leaves "cancelled"; otherwise the record is
   exactly as it was before. */
async function unlock(ref, lockAt, prev, att) {
  att = att || {};
  await saveHard(ref, s => {
    if (!s || s.lockAt !== lockAt) return null;
    const hist = Array.isArray(att.history) ? att.history : (Array.isArray(s.history) ? s.history : []);
    if (att.newSr && !att.awb) return { ship: { via: 'shiprocket', kind: 'courier', step: 'created', srOrderId: att.newSr.srOrderId, srShipmentId: att.newSr.srShipmentId, fp: att.newSr.fp, pickup: att.newSr.pickup || '',
      text: 'Order made in Shiprocket (no courier yet)', note: plain(att.note, 220), history: hist, told: {}, events: [] } };
    if (att.cancelledPrev) return { ship: { step: 'cancelled', cancelledAt: nowIso(), history: hist, told: {}, events: [] } };
    if (prev) { const back = deep(prev); delete back.lockAt; delete back.lockBy; delete back.lockVia; return { ship: back }; }
    return { ship: { step: 'none', history: hist, told: {}, events: [] } };
  });
}
async function unlockKeep(ref, lockAt) {
  await saveHard(ref, s => {
    if (!s || s.lockAt !== lockAt) return null;
    delete s.lockAt; delete s.lockBy; delete s.lockVia;
    return { ship: s };
  });
}
function fpOf(to, box, pickup, phone) { return JSON.stringify([to.line, to.landmark, to.pin, to.city, to.state, pickup, box.l, box.b, box.h, box.kg, phone]); }

async function book(row, b, who) {
  const p = row.payload || {}, cur = shipOf(row);
  const via = b.via === 'borzo' ? 'borzo' : b.via === 'shiprocket' ? 'shiprocket' : '';
  if (!via) return { code: 400, body: { ok: false, error: 'Choose COURIER or RIDER' } };
  if (isBusy(cur)) return { code: 409, body: { ok: false, error: 'Another phone is working on this order\'s delivery right now -- wait a minute and look again' } };
  if (isBooked(cur)) return { code: 409, body: { ok: false, error: 'This order is already booked (' + (cur.courier || cur.via) + '). Cancel that booking first to book again.' } };
  /* the last try asked Borzo for a rider and lost the answer: a rider MAY be booked -- never book a second one blindly */
  if (cur && cur.step === 'booking' && cur.bzTry && !cur.bzOrderId) return { code: 409, body: { ok: false, error: 'The last rider booking for this order may have gone through (the answer was lost). Look in the Borzo app: if a rider is booked, save it with BY HAND (Borzo + its number); if not, tap CLEAR and book again.' } };
  if (via === 'shiprocket' && !srReady()) return { code: 501, body: { ok: false, error: 'Shiprocket is not connected yet (Vercel settings)' } };
  if (via === 'borzo' && !bzReady()) return { code: 501, body: { ok: false, error: 'Borzo is not connected yet (Vercel settings)' } };
  const phone = ten(row.phone || p.phone);
  if (!phone) return { code: 400, body: { ok: false, error: 'This order has no proper 10-digit mobile number -- the courier needs one' } };
  const to = addressOf(row, b.to), box = boxOf(b.box), br = await branchOf(b.from);
  if (to.line.length < 8) return { code: 400, body: { ok: false, error: 'Type the customer\'s full address (flat, building, street, area)' } };
  if (!/^[1-9]\d{5}$/.test(to.pin)) return { code: 400, body: { ok: false, error: 'Type the customer\'s 6-digit pincode' } };
  if (via === 'borzo' && !br.address) return { code: 400, body: { ok: false, error: 'Type the ' + (br.name || 'shop') + ' shop\'s address in Admin -> Settings -> Delivery first' } };
  if (via === 'borzo' && !br.phone) return { code: 400, body: { ok: false, error: 'Type the ' + (br.name || 'shop') + ' shop\'s phone number in Admin -> Settings -> Delivery first' } };
  let pickup = '';
  if (via === 'shiprocket') {
    if (!to.city || !to.state) return { code: 400, body: { ok: false, error: 'Type the customer\'s city and state' } };
    pickup = plain(b.pickup, 80);
    if (!pickup) {
      const all = await srPickups();
      if (!all.ok) return { code: 502, body: { ok: false, error: all.error } };
      const hit = all.list.find(x => br.pin && x.pin === br.pin) || all.list.find(x => x.primary) || all.list[0];
      if (!hit) return { code: 400, body: { ok: false, error: 'Add your shop\'s address in Shiprocket -> Settings -> Pickup addresses first' } };
      pickup = hit.name;
    }
  }
  const key = p.trackKey || newKey();
  /* 1. the lock -- one booking at a time (two phones tapping BOOK together book ONE rider) */
  const lk = await lockFor(row.ref, who, via);
  if (!lk.res.ok) return lk.res.why === 'abort' ? { code: 409, body: { ok: false, error: lk.res.msg } } : { code: 502, body: { ok: false, error: 'Could not start the booking -- try again' } };
  const prev = lk.prev, lockAt = lk.lockAt;
  const att = { history: prev && (prev.step === 'cancelled' || prev.step === 'returned') ? histOf(prev, prev.step) : (Array.isArray(prev && prev.history) ? prev.history.slice() : []) };
  try {
    return await bookLocked(row, b, who, { via, to, box, br, pickup, phone, key, prev, lockAt, att });
  } catch (e) {
    /* something broke half way: what was spent is said, and a booking already paid for is never left unlocked */
    const spent = att.bzOrderId ? ' -- the Borzo booking no. ' + att.bzOrderId + ' WAS made: in 3 minutes save it with BY HAND (Borzo, number ' + att.bzOrderId + '), or cancel it in the Borzo app'
      : att.awb ? ' -- the courier WAS booked (tracking no. ' + att.awb + '): wait 3 minutes, then tap BOOK again to finish'
      : att.cancelledPrev && prev && prev.srOrderId ? ' -- the earlier Shiprocket order (no. ' + prev.srOrderId + ') WAS cancelled: if the order later shows "no courier yet" for it, tap CLOSE (NO COURIER CALL) and book again' : '';
    if (!att.saved && !att.bzOrderId && !att.awb) { try { await unlock(row.ref, lockAt, prev, att); } catch (x) {} }
    return { code: 502, body: { ok: false, error: 'Something went wrong (' + plain(e && e.message, 100) + ')' + spent, bzOrderId: att.bzOrderId || undefined } };
  }
}
async function bookLocked(row, b, who, c) {
  const { via, to, box, br, pickup, phone, key, prev, lockAt, att } = c;
  const p = row.payload || {};
  const fail = async (code, error, extra) => { await unlock(row.ref, lockAt, prev, att); return { code, body: Object.assign({ ok: false, error }, extra || {}) }; };
  const base = { via, kind: via === 'borzo' ? 'rider' : 'courier', from: br.name, bookedAt: nowIso(), bookedBy: plain(who, 40), box, to: { pin: to.pin, city: to.city }, told: {}, events: [] };

  /* a Shiprocket order left without a courier: carried on when nothing changed, otherwise cancelled first */
  let carry = null;
  if (srPending(prev)) {
    if (via === 'shiprocket' && prev.fp === fpOf(to, box, pickup, phone)) { carry = prev; att.newSr = { srOrderId: prev.srOrderId, srShipmentId: prev.srShipmentId, fp: prev.fp, pickup: prev.pickup }; }
    else {
      const cc = await srCancel(prev.srOrderId);
      if (!cc.ok) return fail(502, 'The earlier Shiprocket order (no. ' + prev.srOrderId + ') could not be cancelled: ' + cc.error + ' -- cancel it in the Shiprocket panel, then tap CLOSE (NO COURIER CALL) here and book again');
      att.cancelledPrev = true; att.history = histOf(prev, 'replaced');
      const clr = await saveShip(row.ref, s => (s && s.lockAt === lockAt) ? { ship: Object.assign(s, { via: undefined, srOrderId: undefined, srShipmentId: undefined, fp: undefined, history: att.history }) } : { abort: 'lost' });
      if (!clr.ok) return fail(502, 'Could not continue the booking -- try again');
    }
  }

  if (via === 'borzo') {
    /* noted BEFORE asking Borzo: if the answer is lost, the next try knows a rider may exist */
    const mark = await saveShip(row.ref, s => (s && s.lockAt === lockAt) ? { ship: Object.assign(s, { bzTry: nowIso() }) } : { abort: 'The booking lock was lost -- tap BOOK again' });
    if (!mark.ok) return fail(502, mark.msg || 'Could not start the booking -- try again');
    const r = await bz('/create-order', { method: 'POST', body: bzBody(row, to, br, b.note) }, 20000);
    const o = r.ok && r.body && r.body.is_successful !== false && r.body.order && typeof r.body.order === 'object' ? r.body.order : null;
    if (!o || !o.order_id) {
      const refused = r.status >= 400 && r.status < 500 && r.body && r.body.is_successful === false;
      if (refused) return fail(502, bzWhy(r, 'Borzo did not take the booking'));
      /* no answer, a time-out, a server error or an answer that cannot be read: a rider MAY be booked. The record keeps
         the "asked Borzo" mark (the lock is let go): BOOK is refused until staff look in the Borzo app */
      await saveHard(row.ref, s => (s && s.lockAt === lockAt) ? { ship: Object.assign(s, { lockAt: null, lockBy: undefined, lockVia: undefined }) } : null);
      return { code: 502, body: { ok: false, error: 'Borzo did not answer clearly (' + (r.status ? 'it answered ' + r.status : 'no answer') + '). A rider MAY be booked: look in the Borzo app. If a rider is booked, save it here with BY HAND (Borzo + its number); if not, tap CLEAR and book again.' } };
    }
    att.bzOrderId = String(o.order_id);
    const n = bzNews(o);
    const ship = Object.assign(base, { history: att.history, courier: 'Borzo rider' + (L.env('BORZO_TEST') ? ' (TEST)' : ''), bzOrderId: att.bzOrderId, price: n.price, trackUrl: n.trackUrl, rider: n.rider, test: !!L.env('BORZO_TEST') });
    applyNews(ship, Object.assign({}, n, { step: n.step === 'cancelled' ? 'booked' : n.step }));
    if (SHOWN.indexOf(ship.step) < 0) ship.step = 'booked';
    ship.told = { booked: nowIso() };                                         /* a new parcel: nothing told yet */
    const res = await saveHard(row.ref, () => ({ ship: deep(ship), extra: { trackKey: key } }));   /* the rider IS booked: written whatever else */
    if (!res.ok) return { code: 502, body: { ok: false, error: 'Booked with Borzo (no. ' + att.bzOrderId + ') but it could not be written on the order -- in 3 minutes save it with BY HAND (Borzo, number ' + att.bzOrderId + '), or cancel it in the Borzo app', bzOrderId: att.bzOrderId } };
    att.saved = true;
    let sent = null; try { sent = await tellCustomer(res.row, 'booked'); } catch (e) {}
    return { code: 200, body: { ok: true, ship: res.ship, link: trackLink(row.ref, key), whatsapp: !!(sent && sent.ok), test: !!ship.test } };
  }

  /* Shiprocket: order -> courier (tracking no.) -> pickup -> label. Each part is written on the order the moment it is
     done, so a second tap carries on from where it stopped and never makes a second order or a second courier. */
  let srO = carry ? { srOrderId: carry.srOrderId, srShipmentId: carry.srShipmentId } : null;
  if (!srO) {
    /* the Shiprocket order number: VG-1042, then VG-1042-2, -3 ... (Shiprocket refuses a number twice) -- reserved on
       the order under the lock, so two tries never use the same one */
    let n = 0;
    const rsv = await saveShip(row.ref, (s, rw) => {
      if (!s || s.lockAt !== lockAt) return { abort: 'The booking lock was lost -- tap BOOK again' };
      n = Math.min(999, Math.max(0, Math.floor(Number((rw.payload || {}).srN) || 0))) + 1;
      return { ship: s, extra: { srN: n } };
    });
    if (!rsv.ok) return fail(502, rsv.msg || 'Could not start the booking -- try again');
    const nm = plain(row.name || p.name, 60).split(' ');
    const total = Math.max(1, Math.round(Number(p.total || row.total) || 0));
    const mail = /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(String(p.email || '')) ? String(p.email).trim() : (br.shop.email || 'visionviewoptic@gmail.com');
    const body = {
      order_id: n === 1 ? row.ref : row.ref + '-' + n, order_date: indiaStamp(row.created_at), pickup_location: pickup,
      billing_customer_name: nm[0] || 'Customer', billing_last_name: nm.slice(1).join(' '),
      billing_address: to.line, billing_address_2: to.landmark, billing_city: to.city, billing_pincode: to.pin, billing_state: to.state, billing_country: 'India',
      billing_email: mail, billing_phone: phone, shipping_is_billing: true,
      order_items: [{ name: plain('Spectacles' + (p.frame ? ' - ' + p.frame : ''), 100), sku: row.ref, units: 1, selling_price: total, discount: 0, tax: 0, hsn: 9004 }],
      payment_method: 'Prepaid', sub_total: total, length: box.l, breadth: box.b, height: box.h, weight: box.kg
    };
    const r = await sr('/orders/create/adhoc', { method: 'POST', body }, 20000);
    const made = r && r.ok && r.body && r.body.shipment_id && r.body.order_id ? r.body : null;
    if (!made) return fail(502, srWhy(r, 'Shiprocket did not take the order'));
    srO = { srOrderId: String(made.order_id), srShipmentId: String(made.shipment_id) };
    att.newSr = { srOrderId: srO.srOrderId, srShipmentId: srO.srShipmentId, fp: fpOf(to, box, pickup, phone), pickup };
    /* the new Shiprocket order goes on the record at once (a phone that dies now leaves it for the next try) */
    const w = await saveShip(row.ref, s => (s && s.lockAt === lockAt) ? { ship: Object.assign(s, { via: 'shiprocket', srOrderId: srO.srOrderId, srShipmentId: srO.srShipmentId, fp: att.newSr.fp, pickup }) } : { abort: 'lost' });
    if (!w.ok) return fail(502, 'Shiprocket order ' + made.order_id + ' was made, but the booking lock was lost -- tap BOOK again (that order is used)');
  }
  /* the courier: Shiprocket may already have given one (an answer that never reached us) */
  let awb = '', courier = '', courierId = '';
  if (carry) { const had = await srShow(srO.srOrderId); if (had) { awb = had.awb; courier = had.courier; } }
  if (!awb) {
    const a = await sr('/courier/assign/awb', { method: 'POST', body: Object.assign({ shipment_id: Number(srO.srShipmentId) || srO.srShipmentId }, b.courierId ? { courier_id: String(b.courierId) } : {}) }, 20000);
    const ad = a && a.ok && a.body && a.body.response && a.body.response.data && typeof a.body.response.data === 'object' ? a.body.response.data : null;
    if (!ad || !ad.awb_code || Number(a.body.awb_assign_status) === 0) {
      att.note = srWhy(a, 'Shiprocket did not give a courier');
      return fail(502, att.note + ' -- fix it and tap BOOK again (the same Shiprocket order is used, or cancelled and made again if you changed the address)', { partial: true });
    }
    awb = plain(ad.awb_code, 40); courier = plain(ad.courier_name, 50); courierId = ad.courier_company_id || '';
  }
  att.awb = awb;
  /* written at once: the courier is booked and paid for now (a new parcel: nothing told yet) */
  const now0 = nowIso();
  const ship = Object.assign(base, { history: att.history, step: 'booked', checkedAt: now0, at: now0, srOrderId: srO.srOrderId, srShipmentId: srO.srShipmentId, fp: fpOf(to, box, pickup, phone), pickup,
    awb, courier, srCourierId: courierId, trackUrl: 'https://shiprocket.co/tracking/' + enc(awb), text: 'Booked with ' + courier, told: { booked: now0 }, events: [{ at: now0, step: 'booked', text: 'Booked with ' + courier }] });
  const booked = await saveHard(row.ref, () => ({ ship: deep(ship), extra: { trackKey: key } }));
  if (!booked.ok) return { code: 502, body: { ok: false, error: 'Booked (tracking no. ' + awb + ') but it could not be written on the order -- wait 3 minutes, then tap BOOK again to finish' } };
  att.saved = true;
  /* the pickup and the label: a failure here is noted, the booking stands */
  let pickupAt = '', note = '', label = '';
  try {
    const pu = await sr('/courier/generate/pickup', { method: 'POST', body: { shipment_id: [Number(srO.srShipmentId) || srO.srShipmentId] } }, 15000);
    if (pu && pu.ok && pu.body && (Number(pu.body.pickup_status) === 1 || (pu.body.response && pu.body.response.pickup_scheduled_date))) pickupAt = plain(pu.body.response && pu.body.response.pickup_scheduled_date, 30) || 'booked';
    else note = 'Pickup not booked yet: ' + srWhy(pu, 'no answer') + ' -- tap BOOK PICKUP';
    const lb = await sr('/courier/generate/label', { method: 'POST', body: { shipment_id: [Number(srO.srShipmentId) || srO.srShipmentId] } }, 15000);
    if (lb && lb.ok && lb.body && /^https:\/\//.test(String(lb.body.label_url || ''))) label = String(lb.body.label_url);
  } catch (e) { note = note || 'Pickup / label not done yet -- tap BOOK PICKUP and GET LABEL'; }
  let fin = null;
  try {
    fin = await saveShip(row.ref, s => {
      if (!s || s.awb !== awb) return null;
      Object.assign(s, { pickupAt, note, label, text: 'Booked with ' + courier + (dayName(pickupAt) ? ' — pickup on ' + dayName(pickupAt) : '') });
      return { ship: s };
    });
  } catch (e) { fin = null; }
  const done = (fin && fin.ok && fin.ship) ? fin : booked;
  let sent = null; try { sent = await tellCustomer(done.row, 'booked'); } catch (e) {}
  return { code: 200, body: { ok: true, ship: done.ship, link: trackLink(row.ref, key), whatsapp: !!(sent && sent.ok) } };
}

async function hand(row, b, who) {
  const p = row.payload || {}, cur = shipOf(row);
  if (isBusy(cur)) return { code: 409, body: { ok: false, error: 'Another phone is working on this order\'s delivery right now -- wait a minute and look again' } };
  if (isBooked(cur) && cur.via !== 'hand') return { code: 409, body: { ok: false, error: 'This order is booked with ' + (cur.courier || cur.via) + ' -- cancel that first' } };
  const courier = plain(b.courier, 50), awb = plain(b.awb, 40), url = String(b.url || '').trim();
  if (!courier) return { code: 400, body: { ok: false, error: 'Type who is delivering it (courier name, app, or "Our staff")' } };
  if (url && !/^https:\/\/[^\s"'<>]{4,400}$/i.test(url)) return { code: 400, body: { ok: false, error: 'The tracking link must start with https://' } };
  const key = p.trackKey || newKey();
  const kind = b.kind === 'rider' ? 'rider' : 'courier';
  /* a Shiprocket order left without a courier is cancelled first -- under the lock (nobody else is booking it meanwhile) */
  let hist = null, mine = null;
  if (srPending(cur)) {
    const lk = await lockFor(row.ref, who, 'hand', { keep: true });
    if (!lk.res.ok) return lk.res.why === 'abort' ? { code: 409, body: { ok: false, error: lk.res.msg } } : { code: 502, body: { ok: false, error: 'Could not start -- try again' } };
    mine = lk.lockAt;
    if (srPending(lk.prev)) {
      let c; try { c = await srCancel(lk.prev.srOrderId); } catch (e) { c = { ok: false, error: plain(e && e.message, 160) }; }
      if (!c.ok) { await unlockKeep(row.ref, mine); return { code: 502, body: { ok: false, error: 'The earlier Shiprocket order (no. ' + lk.prev.srOrderId + ') could not be cancelled: ' + c.error + ' -- cancel it in the Shiprocket panel, then tap CLOSE (NO COURIER CALL) here' } }; }
      hist = histOf(lk.prev, 'replaced');
    }
  }
  let first = true;
  const res = await saveShip(row.ref, s => {
    if (isBusy(s) && !(mine && s.lockAt === mine)) return { abort: 'Another phone is working on this order\'s delivery right now -- wait a minute and look again' };
    if (isBooked(s) && s.via !== 'hand') return { abort: 'This order is booked with ' + (s.courier || s.via) + ' -- cancel that first' };
    const editing = !!(s && s.via === 'hand' && isBooked(s));
    first = !editing;
    const ship = editing ? s : { via: 'hand', kind, step: 'booked', bookedAt: nowIso(), bookedBy: plain(who, 40), from: plain(b.from, 40), told: {}, events: [],
      history: hist || (s && (s.step === 'cancelled' || s.step === 'returned') ? histOf(s, s.step) : (s && Array.isArray(s.history) ? s.history : [])) };
    delete ship.lockAt; delete ship.lockBy; delete ship.lockVia;
    Object.assign(ship, { courier, awb, trackUrl: url || autoLink(courier, awb), kind, checkedAt: nowIso() });
    const said = (kind === 'rider' ? 'Sent with ' : 'Sent by ') + courier;
    if (!editing) { ship.text = said; ship.at = nowIso(); ship.events = [{ at: nowIso(), step: 'booked', text: said }]; ship.told = { booked: nowIso() }; }
    else if (ship.step === 'booked') ship.text = said;                        /* a corrected name shows at once */
    return { ship, extra: { trackKey: key } };
  });
  if (!res.ok) { if (mine) await unlock(row.ref, mine, null, { cancelledPrev: true, history: hist }); return { code: res.why === 'abort' ? 409 : 502, body: { ok: false, error: res.msg || 'Could not save it on the order -- try again' } }; }
  let sent = null; if (first) { try { sent = await tellCustomer(res.row, 'booked'); } catch (e) {} }
  return { code: 200, body: { ok: true, ship: res.ship, link: trackLink(row.ref, key), whatsapp: !!(sent && sent.ok), test: false } };
}
/* a courier's own tracking page, when staff typed only the name and the number */
function autoLink(courier, awb) {
  if (!awb) return '';
  const k = String(courier || '').toLowerCase().replace(/[^a-z]/g, '');
  const base = /delhivery/.test(k) ? 'https://www.delhivery.com/track/package/' : /bluedart/.test(k) ? 'https://www.bluedart.com/tracking?trackingNo=' : /dtdc/.test(k) ? 'https://www.dtdc.in/tracking?trackingNo=' :
    /xpressbees|xpress/.test(k) ? 'https://www.xpressbees.com/shipment/tracking?awbNo=' : /indiapost|speedpost/.test(k) ? 'https://www.indiapost.gov.in/_layouts/15/DOP.Portal.Tracking/TrackConsignment.aspx?ID=' : /shiprocket/.test(k) ? 'https://shiprocket.co/tracking/' : '';
  return base ? base + enc(awb) : '';
}
async function handStep(row, b) {
  const s = shipOf(row);
  if (!s || s.via !== 'hand' || !isBooked(s)) return { code: 409, body: { ok: false, error: 'Only a delivery booked by hand is moved by hand -- the courier moves the others' } };
  const step = ['picked', 'out', 'delivered', 'failed'].indexOf(b.step) >= 0 ? b.step : '';
  if (!step) return { code: 400, body: { ok: false } };
  const res = await applyToOrder(row.ref, { step, at: nowIso(), text: (s.kind === 'rider' ? RIDER_WORDS : WORDS)[step] });
  if (!res.ok) return { code: 502, body: { ok: false, error: 'Could not save it -- try again' } };
  return { code: 200, body: { ok: true, ship: res.ship } };
}
/* CANCEL: the courier / rider is told, under the lock (nobody books or cancels it at the same moment) */
async function cancel(row, who) {
  const s = shipOf(row);
  if (isBusy(s)) return { code: 409, body: { ok: false, error: 'Another phone is working on this order\'s delivery right now -- wait a minute and look again' } };
  if (!s || !(isBooked(s) || srPending(s))) return { code: 409, body: { ok: false, error: 'Nothing is booked for this order' } };
  if (s.step === 'delivered') return { code: 409, body: { ok: false, error: 'It is already delivered -- if that is wrong, use CLOSE' } };
  const lk = await lockFor(row.ref, who, 'cancel', { keep: true, booked: true });
  if (!lk.res.ok) return lk.res.why === 'abort' ? { code: 409, body: { ok: false, error: lk.res.msg } } : { code: 502, body: { ok: false, error: 'Could not start -- try again' } };
  const prev = lk.prev, mine = lk.lockAt;
  let c = { ok: true };
  try {
    if (prev.via === 'shiprocket' && prev.srOrderId) c = await srCancel(prev.srOrderId);
    else if (prev.via === 'borzo' && prev.bzOrderId) c = await bzCancel(prev.bzOrderId);
  } catch (e) { c = { ok: false, error: plain(e && e.message, 120) }; }
  if (!c.ok) { await unlockKeep(row.ref, mine); return { code: 502, body: { ok: false, error: c.error + ' -- if the courier already has the parcel (lost, damaged, came back) or it is already cancelled in their app, use CLOSE (NO COURIER CALL) instead' } }; }
  const res = await saveHard(row.ref, x => {
    if (!x || x.lockAt !== mine) return null;
    delete x.lockAt; delete x.lockBy; delete x.lockVia;
    if (SHOWN.indexOf(x.step) >= 0) applyNews(x, { step: 'cancelled', text: 'Delivery cancelled by the shop', byShop: true });
    x.step = 'cancelled'; x.cancelledAt = nowIso();
    return { ship: x, tell: [] };
  });
  if (!res || !res.ok) return { code: 502, body: { ok: false, error: 'Cancelled with the courier, but not written on the order -- in 3 minutes tap CLOSE (NO COURIER CALL)' } };
  return { code: 200, body: { ok: true, ship: res.ship } };
}
/* CLOSE: the record is closed WITHOUT telling the courier -- for a parcel lost, damaged, back in the shop, or marked
   delivered by mistake (the courier can no longer cancel those). The order can then be sent again. */
async function closeShip(row) {
  /* (the order's own status is read fresh inside the write) */
  const s = shipOf(row);
  if (isBusy(s)) return { code: 409, body: { ok: false, error: 'Another phone is working on this order\'s delivery right now -- wait a minute and look again' } };
  if (!s || ['none', 'cancelled'].indexOf(s.step) >= 0) return { code: 409, body: { ok: false, error: 'Nothing to close' } };
  const res = await saveHard(row.ref, (x, rw) => {
    if (!x || isBusy(x) || ['none', 'cancelled'].indexOf(x.step) >= 0) return null;
    const wasDelivered = x.step === 'delivered' && !x.test;
    x.history = histOf(x, 'closed by the shop');
    return { ship: { step: 'cancelled', cancelledAt: nowIso(), closed: true, text: 'Closed by the shop (no courier call)', history: x.history, told: {}, events: [] }, status: wasDelivered && rw && rw.status === 'Delivered' ? 'Ready' : undefined };
  });
  if (!res || !res.ok || res.same) return { code: 502, body: { ok: false, error: 'Could not close it -- try again' } };
  return { code: 200, body: { ok: true, ship: res.ship, orderStatus: res.row && res.row.status } };
}

/* "Delivered" bill message: whichever Admin phone asks first sends it -- once. Written only while nobody has claimed it AND
   the parcel and the order are as they were read (a courier update or a staff edit at the same moment is never written
   over). For a parcel, only when the website's own parcel record says delivered (a record planted in a stranger's order
   does not count). Returns null when the database could not be reached (the phone asks again later). */
async function claim(ref, who, mode) {
  try {
    for (let i = 0; i < 6; i++) {
      const row = await readOrder(ref);
      if (!row || row.dup) return false;
      const pay = Object.assign({}, row.payload || {});
      if (pay.doneSent) return false;
      const g = shipOf(row);
      if (mode !== 'manual' && (!g || g.step !== 'delivered' || g.test)) return false;
      pay.doneSent = { at: nowIso(), by: plain(who, 40), how: mode === 'manual' ? 'manual' : 'parcel' };
      const er = row.payload && row.payload.editRev; pay.editRev = (Number.isSafeInteger(er) && er >= 0 && er < 1e9 ? er : 0) + 1;
      const w = await L.db('/rest/v1/orders?ref=eq.' + enc(ref) + '&payload->>doneSent=is.null' + revFilter(row.payload && row.payload.ship, !!g) + (i < 4 ? editFilter(row.payload) : '') + '&select=ref', { method: 'PATCH', headers: { Prefer: 'return=representation' }, body: JSON.stringify({ payload: pay }) });
      if (!w.ok) return null;
      if (Array.isArray(w.body) && w.body.length === 1) return true;
    }
    return false;
  } catch (e) { return null; }
}

/* ---------- the courier's news ---------- */
async function news(req, res, q) {
  const from = q.get('from');
  const key = L.env('PARCEL_HOOK_KEY');
  if (!key) return L.send(res, 501, { ok: false, configured: false });
  if (L.tooMany('n:' + ip(req), 600, 3600e3)) return L.send(res, 429, { ok: false });
  const b = await L.body(req) || {};
  if (from === 'courier') {
    if (!same(req.headers['x-api-key'], key)) return L.send(res, 401, { ok: false });
    const awb = plain(b.awb, 40);
    if (!awb) return L.send(res, 200, { ok: true, note: 'no awb' });                                  /* Shiprocket's test message */
    const r = await L.db('/rest/v1/orders?select=ref,ship:payload->ship&payload->ship->>awb=eq.' + enc(awb) + '&limit=100');
    const rows = (r.ok && Array.isArray(r.body) ? r.body : []).map(x => ({ ref: x.ref, payload: { ship: x.ship } })).filter(x => shipOf(x));
    if (rows.length !== 1) return L.send(res, 200, { ok: true, note: rows.length ? 'two orders' : 'not ours' });
    const scans = (Array.isArray(b.scans) ? b.scans : []).filter(a => a && typeof a === 'object').map(a => ({ at: when(a.date), text: plain(a.activity || a['sr-status-label'] || a.status, 100), place: plain(a.location, 60) }))
      .filter(s => s.text).sort((x, y) => (y.at || '').localeCompare(x.at || ''));
    const raw = String(b.current_status || b.shipment_status || '');
    const nw = { step: srStep(raw), raw, scans, at: when(b.current_timestamp) || (scans[0] && scans[0].at) || '', eta: when(b.etd) || '', courier: plain(b.courier_name, 50) };
    await applyToOrder(rows[0].ref, nw);
    return L.send(res, 200, { ok: true });
  }
  if (from === 'rider') {
    if (!same(q.get('k'), key)) return L.send(res, 401, { ok: false });
    if (!bzReady()) return L.send(res, 200, { ok: true });
    /* never taken at its word: the order is read again from Borzo with the shop's own token */
    const id = String((b.order && b.order.order_id) || (b.delivery && b.delivery.order_id) || b.order_id || '').replace(/\D/g, '').slice(0, 20);
    if (!id) return L.send(res, 200, { ok: true, note: 'no order' });
    const r = await L.db('/rest/v1/orders?select=ref,ship:payload->ship&payload->ship->>bzOrderId=eq.' + enc(id) + '&limit=100');
    const rows = (r.ok && Array.isArray(r.body) ? r.body : []).map(x => ({ ref: x.ref, payload: { ship: x.ship } })).filter(x => shipOf(x));
    if (rows.length !== 1) return L.send(res, 200, { ok: true, note: 'not ours' });
    const o = await bzOrder(id);
    if (o) await applyToOrder(rows[0].ref, bzNews(o));
    return L.send(res, 200, { ok: true });
  }
  return L.send(res, 400, { ok: false });
}

/* a wrong mobile number for an order: counted per order, so nobody can guess at one order's mobile for long. (A private
   link's key is far too long to guess, and a stranger sending wrong keys must never block the customer's own link.) */
const FAILS = new Map();
function failCount(ref) { const now = Date.now(); const l = (FAILS.get(ref) || []).filter(t => now - t < 3600e3); FAILS.set(ref, l); return l.length; }
function failed(ref) { const l = (FAILS.get(ref) || []); l.push(Date.now()); FAILS.set(ref, l); if (FAILS.size > 5000) FAILS.clear(); }

/* ---------- the door ---------- */
module.exports = async function (req, res) {
  const q = L.query(req), method = req.method;
  if (method === 'GET' && q.get('do') === 'check')
    return L.send(res, 200, { shiprocket: srReady(), borzo: bzReady(), borzoTest: bzReady() && !!L.env('BORZO_TEST'), news: !!L.env('PARCEL_HOOK_KEY'), whatsapp: L.senderReady() });
  if (!L.env('SUPABASE_SERVICE_KEY')) return L.send(res, 501, { ok: false, configured: false });
  try {
    if (method === 'POST' && q.get('do') === 'news') return await news(req, res, q);

    /* the customer's page */
    const b0 = method === 'POST' ? (await L.body(req) || {}) : {};
    if ((method === 'GET' && q.get('do') === 'track') || (method === 'POST' && b0.do === 'track')) {
      const ref = String((method === 'GET' ? q.get('o') : b0.ref) || '').trim().toUpperCase();
      const k = method === 'GET' ? String(q.get('k') || '') : '', phone = method === 'POST' ? ten(b0.phone) : '';
      if (L.tooMany('t:' + ip(req), 150, 3600e3)) return L.send(res, 429, { ok: false, error: 'Please wait a little and try again.' });
      if (!REF_RX.test(ref) || (!k && !phone)) return L.send(res, 404, { ok: false, reason: 'not-found' });
      if (phone && failCount(ref) >= 20) return L.send(res, 429, { ok: false, error: 'Please wait a little and try again.' });
      let row = await readOrder(ref);
      /* the same answer for "no such order", "wrong mobile number" and "wrong link" */
      if (!row || row.dup) { if (phone) failed(ref); return L.send(res, 404, { ok: false, reason: 'not-found' }); }
      const p = row.payload || {};
      const yes = k ? same(k, p.trackKey) : (phone && ten(row.phone) === phone);
      if (!yes) { if (phone) failed(ref); return L.send(res, 404, { ok: false, reason: 'not-found' }); }
      const s = shipOf(row);
      if (s && s.live) {                                          /* old news: ask the courier (at most every 10 minutes) */
        const r = await refresh(row, false);
        if (r && r.row) row = r.row;
      }
      const out = view(row);
      const tk = (row.payload || {}).trackKey;
      if (phone && tk) out.link = trackLink(ref, tk);
      return L.send(res, 200, out);
    }

    /* Admin */
    if (method !== 'POST') return L.send(res, 405, { ok: false });
    const user = await L.staffUser(req);
    if (!user) return L.send(res, 401, { ok: false, error: 'Please sign in to Admin again' });
    const b = b0, who = String((b.by || user.email || 'staff')).slice(0, 40);
    if (b.do === 'pickups') { if (!srReady()) return L.send(res, 501, { ok: false, error: 'Shiprocket is not connected yet' }); return L.send(res, 200, await srPickups()); }
    /* Admin asks which parcel records on its phone are really the website's (a record in an order a stranger made up is
       not): { ref: record or null } -- only the parcel part is read */
    if (b.do === 'verify') {
      const refs = [...new Set((Array.isArray(b.refs) ? b.refs : []).map(x => String(x || '').trim().toUpperCase()).filter(x => REF_RX.test(x)))].slice(0, 60);
      if (!refs.length) return L.send(res, 200, { ok: true, ships: {} });
      const r = await L.db('/rest/v1/orders?select=ref,ship:payload->ship&ref=in.(' + refs.join(',') + ')&limit=' + (refs.length * 2 + 2));
      if (!r.ok || !Array.isArray(r.body)) return L.send(res, 502, { ok: false, error: 'Could not read the orders' });
      const count = {}; r.body.forEach(x => { count[x.ref] = (count[x.ref] || 0) + 1; });
      const ships = {}; refs.forEach(x => { ships[x] = null; });
      r.body.forEach(x => { if (count[x.ref] === 1) ships[x.ref] = shipOf({ ref: x.ref, payload: { ship: x.ship } }) || null; });
      return L.send(res, 200, { ok: true, ships });
    }
    if (b.do === 'refresh-all') {
      const r = await L.db('/rest/v1/orders?select=ref,ship:payload->ship&payload->ship->>live=eq.1&order=created_at.desc&limit=300');
      const rows = (r.ok && Array.isArray(r.body) ? r.body : []).map(x => ({ ref: x.ref, payload: { ship: x.ship } })).filter(x => shipOf(x));
      const old = rows.filter(x => { const s = shipOf(x); return s.via !== 'hand' && (!s.checkedAt || Date.now() - new Date(s.checkedAt).getTime() > 20 * 60e3); }).slice(0, 8);
      /* side by side (each courier question has its own time limit), so the whole check stays well inside a minute */
      const done = await Promise.all(old.map(x => refresh(x, true).then(z => ({ ref: x.ref, ship: z && z.ship })).catch(() => null)));
      const out = done.filter(Boolean);
      return L.send(res, 200, { ok: true, checked: out.length, ships: out });
    }
    const ref = String(b.ref || '').trim().toUpperCase();
    if (!REF_RX.test(ref)) return L.send(res, 400, { ok: false, error: 'No order number' });
    const row = await readOrder(ref);
    if (!row) return L.send(res, 404, { ok: false, error: 'This order is not in your account yet (only website orders, and orders saved to the account, can be sent this way)' });
    if (row.dup) return L.send(res, 409, { ok: false, error: 'Two orders have this number -- sort that out first' });
    let out;
    if (b.do === 'get') out = { code: 200, body: { ok: true, ship: shipOf(row) || null, trackKey: (row.payload || {}).trackKey || '' } };
    else if (b.do === 'quote') out = { code: 200, body: Object.assign({ ok: true }, await quote(row, b)) };
    else if (b.do === 'book') out = await book(row, b, who);
    else if (b.do === 'hand') out = await hand(row, b, who);
    else if (b.do === 'step') out = await handStep(row, b);
    else if (b.do === 'cancel') out = await cancel(row, who);
    else if (b.do === 'close') out = await closeShip(row);
    else if (b.do === 'label') {
      const s = shipOf(row);
      if (!s || s.via !== 'shiprocket' || !s.srShipmentId || !s.awb || !s.live) out = { code: 409, body: { ok: false, error: 'No courier label for this order' } };
      else {
        const lb = await sr('/courier/generate/label', { method: 'POST', body: { shipment_id: [Number(s.srShipmentId) || s.srShipmentId] } }, 15000);
        const url = lb && lb.ok && lb.body && /^https:\/\//.test(String(lb.body.label_url || '')) ? String(lb.body.label_url) : '';
        const res2 = url ? await saveShip(ref, x => x && x.awb === s.awb ? (x.label = url, { ship: x }) : null) : null;
        out = url ? { code: 200, body: { ok: true, ship: (res2 && res2.ship) || s } } : { code: 502, body: { ok: false, error: srWhy(lb, 'Shiprocket did not give the label') } };
      }
    }
    else if (b.do === 'refresh') { const z = await refresh(row, true); out = { code: 200, body: { ok: true, ship: (z && z.ship) || shipOf(row) || null } }; }
    else if (b.do === 'pickup') {
      const s = shipOf(row);
      if (!s || s.via !== 'shiprocket' || !s.srShipmentId || !s.awb || !s.live) out = { code: 409, body: { ok: false, error: 'Nothing to book a pickup for' } };
      else {
        const pu = await sr('/courier/generate/pickup', { method: 'POST', body: { shipment_id: [Number(s.srShipmentId) || s.srShipmentId] } }, 15000);
        const okp = !!(pu && pu.ok && pu.body && (Number(pu.body.pickup_status) === 1 || (pu.body.response && pu.body.response.pickup_scheduled_date)));
        const res2 = await saveShip(ref, x => x ? (x.pickupAt = okp ? plain(pu.body.response && pu.body.response.pickup_scheduled_date, 30) || 'booked' : x.pickupAt, x.note = okp ? '' : 'Pickup not booked yet: ' + srWhy(pu, 'no answer'), { ship: x, tell: [] }) : null);
        out = { code: okp ? 200 : 502, body: { ok: okp, ship: res2.ship, error: okp ? '' : srWhy(pu, 'Shiprocket did not book the pickup') } };
      }
    }
    else if (b.do === 'claim') { const c = await claim(ref, who, b.mode === 'manual' ? 'manual' : 'parcel'); out = c === null ? { code: 502, body: { ok: false, error: 'Could not reach the database -- asked again later' } } : { code: 200, body: { ok: true, claimed: c } }; }
    else out = { code: 400, body: { ok: false } };
    return L.send(res, out.code, out.body);
  } catch (e) {
    return L.send(res, 502, { ok: false, error: plain(e && e.message, 200) || 'Something went wrong -- try again' });
  }
};
module.exports._t = { shipSig, shipOf, revFilter, editFilter, srStep, nextStep, applyNews, when, bzNews, srNews, view, addressOf, autoLink, indiaStamp, LIVE, SHOWN };

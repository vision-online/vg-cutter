TRY-ON FRAME CUTOUTS
=====================
For the TRY ON button to appear under a product photo, put a matching
transparent PNG in the folder for that category, using the SAME number.

Example:
  images/frames/3.jpg          -> the product photo customers see
  images/tryon/frames/3.png    -> transparent cutout used for try-on

Folders:
  images/tryon/frames/       1.png, 2.png, 3.png ...
  images/tryon/sunglasses/   1.png, 2.png, 3.png ...
  images/tryon/kids/         1.png, 2.png, 3.png ...

The PNG must have the background REMOVED (only the frame visible),
photographed straight on. Use a background remover such as remove.bg.

If a cutout is missing, the product still shows normally - it just
won't have a TRY ON button.

The loose 1.png, 2.png files directly in images/tryon/ still work as the
general frame picker inside the try-on section.

/* =====================================================================
   Vision Gallery — cloud sign in

   WHY THIS EXISTS

   Until now the admin panel kept everything in the browser it was
   opened in. Your frames, prices and settings lived on your phone and
   nowhere else. Open admin on a laptop and it was empty. Clear the
   browser data and the catalogue was gone.

   Worse, the orders table was readable by anyone holding the
   publishable key -- and that key is visible in the page source of
   your own website. Customer names, phone numbers and prescriptions
   were, in principle, open to anyone who looked.

   Signing in fixes both. Supabase issues a real token for your
   account, that token is sent with every request, and the database
   rules can then say: the public may read products, but only a
   signed-in account may add or change them, or read an order.

   HOW IT WORKS

   No library. Supabase's auth endpoints are ordinary HTTPS, so this
   is a few fetch calls:

     sign in   POST /auth/v1/token?grant_type=password
     refresh   POST /auth/v1/token?grant_type=refresh_token
     sign out  POST /auth/v1/logout

   The session is kept in localStorage so you stay signed in when you
   come back tomorrow. The access token expires roughly hourly and is
   refreshed automatically and silently.

   NOT stored anywhere: your password. It is sent once, exchanged for
   a token, and never written to disk.
   ===================================================================== */

(function (global) {
  'use strict';

  const KEY = 'vg_session';

  /* Credentials come from the same place VGSync uses -- a key saved in
     admin Settings wins, old static config is the fallback. Kept identical on
     purpose: two different ideas of "which project am I talking to"
     is exactly the split-brain bug that wasted so much time before. */
  function saved(){
    try {
      const s = JSON.parse(localStorage.getItem('vg_sync') || 'null');
      if (s && s.url && s.key) return s;
    } catch(e){}
    return null;
  }
  /* The project this site belongs to.

     These used to live in old static config, which is no longer shipped --
     and that quietly broke the shop. Admin kept working, because
     pressing SAVE in Settings writes the same values into the
     browser. A customer opening the shop had neither, so the page
     could not reach the database at all: it showed nothing and said
     nothing. Built in here, there is no file left to forget.

     The publishable key is meant to be public -- it sits in the page
     source of every Supabase site. What protects the data is the
     database rules: the public may read products and place an order,
     and nothing else. Reading a customer's order, or changing a
     price, needs a signed-in account. */
  const DEFAULTS = {
    url: 'https://oscpunukbyosckrmopeh.supabase.co',
    key: 'sb_publishable_WWAPQTu0lo-X51T4kDlgng_LR39PPkU'
  };

  const CFG = () => saved() || (global.VG_CONFIG && global.VG_CONFIG.sync) || DEFAULTS;
  const configured = () => { const c = CFG(); return !!(c.url && c.key); };

  /* ---- session storage ------------------------------------------ */

  function load(){
    try { return JSON.parse(localStorage.getItem(KEY) || 'null'); }
    catch(e){ return null; }
  }
  function store(s){
    try {
      if (s) localStorage.setItem(KEY, JSON.stringify(s));
      else   localStorage.removeItem(KEY);
    } catch(e){}
  }

  /* Supabase returns expires_in (seconds). Turn it into a wall-clock
     moment so a browser that was closed for two days knows the token
     is stale rather than trusting a countdown that never ran. */
  function shape(body){
    if (!body || !body.access_token) return null;
    return {
      access_token:  body.access_token,
      refresh_token: body.refresh_token || '',
      expires_at:    Date.now() + ((Number(body.expires_in) || 3600) * 1000),
      email:        (body.user && body.user.email) || '',
      user_id:      (body.user && body.user.id) || ''
    };
  }

  /* Read the real reason out of the response. Supabase is specific --
     "Invalid login credentials", "Email not confirmed" -- and hiding
     that behind a status code is what turned the last round of
     debugging into guesswork. */
  async function reason(res){
    let msg = '';
    try {
      const b = await res.json();
      msg = b.error_description || b.msg || b.message || b.error || '';
    } catch(e){
      try { msg = (await res.text()).slice(0, 200); } catch(e2){}
    }
    return msg || ('HTTP ' + res.status);
  }

  /* ---- sign in / out -------------------------------------------- */

  async function signIn(email, password){
    if (!configured()) return { ok:false, error:'Supabase is not set up on this browser yet. Add the project URL and publishable key under Settings first.' };
    const c = CFG();
    let res;
    try {
      res = await fetch(c.url + '/auth/v1/token?grant_type=password', {
        method: 'POST',
        headers: { 'apikey': c.key, 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: String(email || '').trim(), password: String(password || '') })
      });
    } catch (err){
      return { ok:false, error:'Could not reach Supabase. Check the internet connection.' };
    }
    if (!res.ok) return { ok:false, error: await reason(res) };

    let body;
    try { body = await res.json(); } catch(e){ return { ok:false, error:'Supabase sent back something unreadable.' }; }
    const s = shape(body);
    if (!s) return { ok:false, error:'Signed in but no token came back.' };
    store(s);
    return { ok:true, email:s.email };
  }

  async function signOut(){
    const s = load();
    const c = CFG();
    store(null);
    if (s && c.url){
      /* Best effort. If it fails the local session is gone anyway,
         which is what the person pressing "sign out" wanted. */
      try {
        await fetch(c.url + '/auth/v1/logout', {
          method: 'POST',
          headers: { 'apikey': c.key, 'Authorization': 'Bearer ' + s.access_token }
        });
      } catch(e){}
    }
  }

  /* ---- signing in with a code instead ---------------------------

     A password is one more thing to remember, and to forget at the
     counter with a customer waiting. Supabase can email a six digit
     code instead: ask for one, type it in, you are in.

     create_user is false on purpose. Left true, anybody who typed any
     email address into the login box would be sent a code and let
     straight into your admin panel. With it false, only the accounts
     you created in Supabase can ask for one at all.                */

  async function sendCode(email){
    if (!configured()) return { ok:false, error:'Supabase is not set up on this browser yet. Add the project URL and publishable key under Settings first.' };
    const c = CFG();
    const addr = String(email || '').trim();
    if (!addr) return { ok:false, error:'Enter your email address first.' };
    let res;
    try {
      res = await fetch(c.url + '/auth/v1/otp', {
        method: 'POST',
        headers: { 'apikey': c.key, 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: addr, create_user: false })
      });
    } catch (err){
      return { ok:false, error:'Could not reach Supabase. Check the internet connection.' };
    }
    if (!res.ok){
      const why = await reason(res);
      /* Supabase is deliberately vague here so strangers cannot use
         the login box to find out which emails have accounts. That
         same vagueness is unhelpful when it is your own shop, so say
         what it usually means. */
      if (/rate|limit|too many/i.test(why))
        return { ok:false, error:'Too many codes requested. Supabase only sends a few per hour on the free email service. Wait a while, or sign in with your password.' };
      if (/signup|not allowed|disabled/i.test(why))
        return { ok:false, error:'No account for that email. Create it in Supabase under Authentication, Users.' };
      return { ok:false, error: why };
    }
    return { ok:true };
  }

  async function verifyCode(email, code){
    if (!configured()) return { ok:false, error:'Supabase is not set up on this browser yet.' };
    const c = CFG();
    /* People read the code off their phone and type it with the
       spaces the email put in. Strip anything that is not a digit
       rather than rejecting it. */
    const token = String(code || '').replace(/\D/g, '');
    if (!token) return { ok:false, error:'Enter the code from your email.' };
    let res;
    try {
      res = await fetch(c.url + '/auth/v1/verify', {
        method: 'POST',
        headers: { 'apikey': c.key, 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: String(email || '').trim(), token: token, type: 'email' })
      });
    } catch (err){
      return { ok:false, error:'Could not reach Supabase. Check the internet connection.' };
    }
    if (!res.ok){
      const why = await reason(res);
      if (/expired/i.test(why))  return { ok:false, error:'That code has expired. Ask for a new one.' };
      if (/invalid/i.test(why))  return { ok:false, error:'That code is not right. Check it and try again.' };
      return { ok:false, error: why };
    }
    let body;
    try { body = await res.json(); } catch(e){ return { ok:false, error:'Supabase sent back something unreadable.' }; }
    const sess = shape(body);
    if (!sess) return { ok:false, error:'Code accepted but no token came back.' };
    store(sess);
    return { ok:true, email: sess.email };
  }

  /* ---- keeping the session alive -------------------------------- */

  let refreshing = null;

  async function refresh(){
    const s = load();
    if (!s || !s.refresh_token) return null;
    const c = CFG();
    if (!c.url) return null;
    try {
      const res = await fetch(c.url + '/auth/v1/token?grant_type=refresh_token', {
        method: 'POST',
        headers: { 'apikey': c.key, 'Content-Type': 'application/json' },
        body: JSON.stringify({ refresh_token: s.refresh_token })
      });
      if (!res.ok){
        /* A refused refresh means the session is genuinely dead --
           password changed, or signed out elsewhere. Clear it so the
           login screen appears instead of failing silently forever. */
        if (res.status === 400 || res.status === 401) store(null);
        return null;
      }
      const next = shape(await res.json());
      if (next){
        /* Supabase may omit the refresh token on rotation; keep the
           old one rather than losing the ability to refresh again. */
        if (!next.refresh_token) next.refresh_token = s.refresh_token;
        store(next);
        return next;
      }
    } catch(e){}
    return null;
  }

  /* Returns a usable access token, refreshing first if it is close to
     expiry. Everything that talks to Supabase goes through here, so
     one slow refresh should not fire ten times at once -- hence the
     shared promise. */
  async function token(){
    let s = load();
    if (!s) return null;
    if (Date.now() < s.expires_at - 60000) return s.access_token;
    if (!refreshing) refreshing = refresh().finally(() => { refreshing = null; });
    const next = await refreshing;
    return next ? next.access_token : null;
  }

  /* Synchronous, for code that just needs to know whether to show the
     login screen. Does not prove the token still works. */
  function signedIn(){ return !!load(); }
  function email(){ const s = load(); return s ? s.email : ''; }

  global.VGAuth = { configured, signIn, sendCode, verifyCode, signOut, token, refresh, signedIn, email };

})(window);

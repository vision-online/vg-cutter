/* =====================================================================
   Vision Gallery — basket

   WHY IT IS SHAPED THIS WAY

   An optical order is not a normal shopping cart. A frame on its own
   means nothing: it needs lenses, and the lenses need a prescription.
   So a basket that just totals up frame prices would quote a number
   that is never what the customer pays.

   What actually happens at the counter is this. Someone picks two or
   three frames. It is one person, so it is one prescription. Usually
   they want the same lenses in each pair, and when they do not, they
   say so.

   So: the basket holds frames. The prescription is entered once. The
   lens choice is made once and applied to every pair, and the order
   says so in plain words, with a line inviting them to tell us if one
   pair needs something different. That matches the conversation a
   shop actually has, and it does not pretend to price something it
   cannot price without talking to them.
   ===================================================================== */

(function (global) {
  'use strict';

  const KEY = 'vg_basket';
  const MAX = 12;          // beyond this it is a wholesale enquiry, not a basket

  function read(){
    try {
      const v = JSON.parse(localStorage.getItem(KEY) || '[]');
      return Array.isArray(v) ? v : [];
    } catch (e){ return []; }
  }

  function write(list){
    try { localStorage.setItem(KEY, JSON.stringify(list)); } catch(e){}
    announce();
  }

  /* Anything watching -- the header count, an open basket panel -- gets
     told, so two views of the basket can never disagree. */
  function announce(){
    try { global.dispatchEvent(new CustomEvent('vg:basket', { detail: read() })); } catch(e){}
  }

  function items(){ return read(); }
  function count(){ return read().reduce((n, i) => n + (Number(i.qty) || 1), 0); }
  function has(id){ return read().some(i => i.id === id); }

  /* Frames only carry a price when the shop has set one. A frame with
     no price still belongs in the basket -- the customer wants it, and
     we will quote when we see the prescription -- but it must not be
     silently counted as zero in a total. */
  function subtotal(){
    return read().reduce((n, i) => n + ((Number(i.price) || 0) * (Number(i.qty) || 1)), 0);
  }
  function anyUnpriced(){
    return read().some(i => !(Number(i.price) > 0));
  }

  function add(p){
    if (!p || !p.id) return { ok:false, reason:'no-product' };
    const list = read();
    const found = list.find(i => i.id === p.id);
    if (found){
      /* Two of the same frame is a real order -- a spare pair, or one
         for each parent -- so allow it rather than refusing. */
      found.qty = (Number(found.qty) || 1) + 1;
      write(list);
      return { ok:true, added:false, qty:found.qty };
    }
    if (list.length >= MAX) return { ok:false, reason:'full', max:MAX };
    list.push({
      id: p.id,
      name: p.name || '',
      url: p.url || '',
      originalUrl: p.originalUrl || '',
      price: Number(p.price) || 0,
      cat: p.cat || '',
      brand: p.brand || '',
      model: p.model || p.modelNo || '',
      colour: p.colour || p.color || '',
      material: p.material || '',
      shape: p.shape || '',
      size: p.size || null,
      description: p.description || p.desc || '',
      /* Carried so the order page can work out the buy-1-get-1 without
         going back to the catalogue for every line. */
      bogo: !!p.bogo,
      offerCode: p.offerCode || '',
      offerPrice: Number(p.offerPrice) || 0,
      qty: 1
    });
    write(list);
    return { ok:true, added:true };
  }

  function remove(id){
    write(read().filter(i => i.id !== id));
  }

  function setQty(id, qty){
    const list = read();
    const it = list.find(i => i.id === id);
    if (!it) return;
    const n = Math.max(0, Math.min(9, Number(qty) || 0));
    if (!n) return remove(id);
    it.qty = n;
    write(list);
  }

  function clear(){ write([]); }

  /* Lines for the WhatsApp message and the saved order. Kept as plain
     text here so the order page and the shop cannot word it
     differently. */
  function lines(money){
    const fmt = money || (n => '\u20b9' + Number(n || 0).toLocaleString('en-IN'));
    return read().map(i => {
      const qty = Number(i.qty) || 1;
      const name = i.name || 'Frame';
      const price = Number(i.price) > 0
        ? fmt(Number(i.price) * qty)
        : 'price on quote';
      return (qty > 1 ? qty + ' x ' : '') + name + ' \u2014 ' + price;
    });
  }

  global.VGBasket = {
    items, count, has, add, remove, setQty, clear,
    subtotal, anyUnpriced, lines, MAX
  };

})(window);

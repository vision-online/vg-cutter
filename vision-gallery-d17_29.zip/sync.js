/* =====================================================================
   Vision Gallery — order sync

   Until now an order only existed on the customer's phone, and reached
   you only if they remembered to press send in WhatsApp. If they did
   not, you never knew the order happened at all.

   This saves every order to a small database the moment it is placed —
   BEFORE WhatsApp opens — so it is in your admin panel whether or not
   the customer completes the message. You see it while you are on the
   shop floor, without touching anything.

   Supabase is used because it needs no server to run or maintain, the
   free tier is far more than an optical shop will use, and a static
   site can talk to it directly.

   If it is not configured, or the network is down, everything falls
   back to the old behaviour rather than losing the order.
   ===================================================================== */

(function (global) {
  'use strict';

  /* Where the credentials come from.

     This used to read old static config ONLY. The admin Settings box, though,
     saves to localStorage. So pressing SAVE in admin changed nothing
     until the whole site was rebuilt and re-uploaded — and if the two
     ever disagreed, the panel reported on one key while actually
     using the other. That is why fixing the key appeared to do
     nothing. A key saved in admin now takes effect immediately;
     old static config remains the fallback and is what customers' phones use. */
  function saved(){
    try {
      const s = JSON.parse(localStorage.getItem('vg_sync') || 'null');
      if (s && s.url && s.key) return s;
    } catch(e){}
    return null;
  }
  /* The project this site belongs to.

     These used to live in old static config, which is no longer shipped --
     and that quietly broke the shop. Admin kept working, because
     pressing SAVE in Settings writes the same values into the
     browser. A customer opening the shop had neither, so the page
     could not reach the database at all: it showed nothing and said
     nothing. Built in here, there is no file left to forget.

     The publishable key is meant to be public -- it sits in the page
     source of every Supabase site. What protects the data is the
     database rules: the public may read products and place an order,
     and nothing else. Reading a customer's order, or changing a
     price, needs a signed-in account. */
  const DEFAULTS = {
    url: 'https://oscpunukbyosckrmopeh.supabase.co',
    key: 'sb_publishable_WWAPQTu0lo-X51T4kDlgng_LR39PPkU'
  };

  const CFG = () => saved() || DEFAULTS;
  const ready = () => { const c = CFG(); return !!(c.url && c.key); };

  /* A legacy anon key is a JWT and looks like eyJ... . The newer
     sb_publishable_... keys are NOT JWTs, and Supabase rejects them
     when they arrive in Authorization: Bearer — even when the value
     matches the apikey header exactly. Sending Bearer unconditionally
     made every request come back 401, which the admin then reported
     as "the key was rejected" although the key was perfectly good.
     So: apikey always, Bearer only when the key really is a JWT. */
  function isJwt(k){ return typeof k === 'string' && /^ey[A-Za-z0-9_-]+\./.test(k); }

  /* Which token goes in Authorization.

     Three cases, and getting them confused is what caused the 401s:

     1. Signed in  -> the account's access token. This is what makes
        the database rules treat you as staff rather than as a
        stranger, so it must win over everything else.
     2. Legacy anon key (eyJ...) -> itself. It IS a JWT, so Supabase
        accepts it there.
     3. New sb_publishable_... key -> nothing at all. It is not a JWT
        and Supabase rejects it in Authorization even when it matches
        the apikey header exactly. */
  async function headers(extra){
    const c = CFG();
    const h = {
      'apikey': c.key,
      'Content-Type': 'application/json',
      'Prefer': 'return=representation'
    };
    let tok = null;
    try { tok = global.VGAuth ? await global.VGAuth.token() : null; } catch(e){}
    if (tok)                h['Authorization'] = 'Bearer ' + tok;
    else if (isJwt(c.key))  h['Authorization'] = 'Bearer ' + c.key;
    if (extra) Object.assign(h, extra);
    return h;
  }

  /* Supabase says exactly what is wrong in the body -- "permission
     denied for table orders", "Invalid API key", and so on. Throwing
     that away and showing only a status code turned every failure
     into a guess. Carry it through. */
  async function fail(res){
    let detail = '', code = '';
    try {
      const b = await res.json();
      detail = b.message || b.error_description || b.error || b.hint || '';
      code = b.code ? ' [' + b.code + ']' : '';
    } catch(e){
      try { detail = (await res.text()).slice(0,200); } catch(e2){}
    }
    const err = new Error('HTTP ' + res.status + (detail ? ' \u2014 ' + detail + code : ''));
    err.status = res.status; err.detail = detail; err.code = code;
    return err;
  }

  /* ---- customer side: save the order ---------------------------- */

  async function saveOrder(order){
    if (!ready()) return { ok:false, reason:'not-configured' };
    const c = CFG();
    try {
      const res = await fetch(c.url + '/rest/v1/orders', {
        method: 'POST',
        headers: await headers(),
        body: JSON.stringify([{
          ref: order.ref,
          name: order.name || '',
          phone: order.phone || '',
          total: Number(order.total) || 0,
          status: order.status || 'New',
          channel: 'website',
          payload: order,
          created_at: new Date().toISOString()
        }])
      });
      if (!res.ok) throw new Error('HTTP ' + res.status);
      return { ok:true };
    } catch (err){
      console.warn('order sync failed', err);
      // Keep it locally so nothing is lost; admin can pull it later.
      try {
        const q = JSON.parse(localStorage.getItem('vg_pending') || '[]');
        q.push(order);
        localStorage.setItem('vg_pending', JSON.stringify(q));
      } catch(e){}
      return { ok:false, reason:'network' };
    }
  }

  /* Retry anything that failed to send earlier. */
  async function flushPending(){
    if (!ready()) return 0;
    let q = [];
    try { q = JSON.parse(localStorage.getItem('vg_pending') || '[]'); } catch(e){ return 0; }
    if (!q.length) return 0;
    const left = [];
    for (const o of q){
      const r = await saveOrder(o);
      if (!r.ok) left.push(o);
    }
    localStorage.setItem('vg_pending', JSON.stringify(left));
    return q.length - left.length;
  }

  /* ---- the next order number ------------------------------------

     Orders used to be stamped VG-K3M9F42 -- a random string that is
     painful to read over the phone and impossible to file in order.
     The shop wants VG-1001, VG-1002.

     There is no counter table, so the next number is worked out from
     the newest orders already saved. Two hundred is plenty: they come
     back newest first, so the highest number is always among them.

     If this cannot be reached for any reason, it returns null and the
     order page falls back to the old random reference. An order must
     never be blocked by a numbering problem. */
  async function nextRef(){
    if (!ready()) return null;
    const c = CFG();
    try {
      const res = await fetch(c.url + '/rest/v1/orders?select=ref&order=created_at.desc&limit=200',
                              { headers: await headers() });
      if (!res.ok) return null;
      const rows = await res.json();
      let max = 1000;                       // so the first order is VG-1001
      (rows || []).forEach(r => {
        const m = /^VG-(\d{3,})$/.exec(String(r.ref || ''));
        if (m){ const n = Number(m[1]); if (n > max) max = n; }
      });
      return 'VG-' + (max + 1);
    } catch (err){
      return null;
    }
  }

  /* ---- customer side: read/update one order safely ----------------
     Used by the post-payment prescription page. The customer must know
     both the order reference and the mobile number saved on the order.
     If Supabase RLS blocks customer reads/updates, the caller gets a
     normal error and can fall back to store support; nothing is exposed
     by reference number alone. */
  async function fetchOrder(ref, phone){
    if (!ready()) return null;
    const c = CFG();
    const q = '/rest/v1/orders?select=ref,name,phone,status,payload&ref=eq.' + encodeURIComponent(ref) +
              '&phone=eq.' + encodeURIComponent(phone) + '&limit=1';
    const res = await fetch(c.url + q, { headers: await headers() });
    if (!res.ok) throw await fail(res);
    const rows = await res.json();
    return rows && rows[0] ? rows[0] : null;
  }

  async function updateOrderPayload(ref, phone, patch, status){
    if (!ready()) return {ok:false, reason:'not-configured'};
    const row = await fetchOrder(ref, phone);
    if (!row) return {ok:false, reason:'not-found'};
    const payload = Object.assign({}, row.payload || {}, patch || {});
    const body = { payload:payload };
    if (status) body.status = status;
    const c = CFG();
    const q = '/rest/v1/orders?ref=eq.' + encodeURIComponent(ref) + '&phone=eq.' + encodeURIComponent(phone);
    const res = await fetch(c.url + q, { method:'PATCH', headers:await headers({'Prefer':'return=minimal'}), body:JSON.stringify(body) });
    if (!res.ok) throw await fail(res);
    return {ok:true, payload:payload};
  }


  /* ---- shop side: read orders ----------------------------------- */

  async function fetchOrders(sinceISO){
    if (!ready()) return null;
    const c = CFG();
    let url = c.url + '/rest/v1/orders?select=*&order=created_at.desc&limit=200';
    if (sinceISO) url += '&created_at=gt.' + encodeURIComponent(sinceISO);
    const res = await fetch(url, { headers: await headers() });
    if (!res.ok) throw await fail(res);
    return await res.json();
  }

  async function updateStatus(ref, status){
    if (!ready()) return false;
    const c = CFG();
    const res = await fetch(c.url + '/rest/v1/orders?ref=eq.' + encodeURIComponent(ref), {
      method: 'PATCH',
      headers: await headers(),
      body: JSON.stringify({ status: status })
    });
    return res.ok;
  }


  /* ---- the catalogue -------------------------------------------- */

  /* Products are stored one row per frame:

       id          text     the same id the admin panel already uses
       data        jsonb    the whole product object, untouched
       updated_at  timestamp

     The whole object goes into one jsonb column deliberately. Mapping
     twenty-odd fields into twenty-odd columns means a mapping bug
     every time a field is added, and silently dropped data when one
     is missed. This way anything the admin panel invents tomorrow
     survives the round trip without a migration. */

  async function fetchProducts(){
    if (!ready()) return null;
    const c = CFG();
    /* Whole-catalogue fetch. Kept for admin's backup and migration,
       and for a small shop where downloading everything is cheaper
       than paging. The shop pages use searchProducts instead -- this
       one has a ceiling, and above it the answer is quietly
       incomplete, which is the worst kind of wrong. */
    const res = await fetch(c.url + '/rest/v1/products?select=id,data&order=id.asc&limit=' + WHOLE_CATALOGUE_CAP,
                            { headers: await headers() });
    if (!res.ok) throw await fail(res);
    const rows = await res.json();
    if ((rows || []).length >= WHOLE_CATALOGUE_CAP){
      console.warn('Catalogue is at or above ' + WHOLE_CATALOGUE_CAP +
        ' rows; this whole-catalogue read is truncated. Use searchProducts.');
    }
    return rows
      /* Rows whose id starts with __ are settings, not stock. Sharing
         the table means no second table and no extra SQL for the shop
         owner to run -- but they must never reach a shelf. */
      .filter(r => !String(r.id).startsWith('__'))
      .filter(r => !(r.data && r.data.deleted))
      .map(r => {
      /* Trust the row id over anything inside the blob -- the id is
         the primary key and the blob is just cargo. */
      const o = (r.data && typeof r.data === 'object') ? r.data : {};
      o.id = r.id;
      return o;
    });
  }

  /* Save the catalogue as the admin panel currently has it.

     Upsert every frame, then delete rows that are no longer in the
     list. Done in that order on purpose: if the delete fails you are
     left with an extra frame, which you can see and remove. If it ran
     first and the upsert failed, you would be left with nothing. */
  async function saveProducts(list){
    if (!ready()) return { ok:false, reason:'not-configured' };
    if (!Array.isArray(list)) return { ok:false, reason:'bad-input' };
    const c = CFG();

    const rows = list
      .filter(p => p && p.id)
      .map(p => ({ id: String(p.id), data: p, updated_at: new Date().toISOString() }));

    try {
      if (rows.length){
        const res = await fetch(c.url + '/rest/v1/products?on_conflict=id', {
          method: 'POST',
          headers: await headers({ 'Prefer': 'resolution=merge-duplicates,return=minimal' }),
          body: JSON.stringify(rows)
        });
        if (!res.ok) throw await fail(res);
      }

      /* Remove anything deleted in admin. "not in this list" is
         expressed as id=not.in.(...) -- and with an empty catalogue
         that would delete everything, so guard it. */
      /* Prune only real products. Without the like filter this delete
         would take the settings rows with it every time a frame was
         saved, and the home page pictures would vanish. */
      const keep = rows.map(r => '"' + String(r.id).replace(/"/g, '') + '"').join(',');
      const url = c.url + '/rest/v1/products?id=not.like.__*'
                + (keep ? '&id=not.in.(' + encodeURIComponent(keep) + ')' : '');
      const del = await fetch(url, { method:'DELETE', headers: await headers({ 'Prefer':'return=minimal' }) });
      if (!del.ok) throw await fail(del);

      return { ok:true, count: rows.length };
    } catch (err){
      return { ok:false, reason:'error', error: err, message: err.message || String(err) };
    }
  }


  /* ---- keeping the shop pages up to date ------------------------

     The customer-facing pages used to read products from old static config
     only. That meant every price change or new frame needed the file
     downloaded from admin and re-uploaded to the host by hand, and
     until that happened the shop showed the old list. In practice
     that step gets skipped, and the website quietly goes stale.

     So: the page still renders from old static config immediately -- fast,
     and it still works if the database is unreachable -- and then
     quietly replaces the catalogue with the live one and re-draws.
     A missed download can no longer leave the shop wrong.        */

  /* Is this frame allowed on the website? Yes only when its try-on
     picture exists -- cut by the robot, or supplied ready-made. */
  function shopReady(p){
    if (!p) return false;
    if (p.tryOnFails === undefined || p.tryOnFails === null) return true;   /* saved before the robot existed: unchanged */
    return !!(p.tryOnLocked || (p.tryOnReady && p.tryOnUrl));
  }

  async function refreshCatalogue(onUpdate){
    if (!ready()) return false;
    let rows;
    try { rows = await fetchProducts(); }
    catch (err){
      console.warn('catalogue refresh failed', err.message || err);
      return false;             // keep whatever old static config had
    }
    if (!rows) return false;
    rows = rows.filter(shopReady);   /* d16.62: no cut-out, not on the website */

    /* An empty table almost always means "not set up yet" rather than
       "the shop has no frames". Wiping a working old static config list on
       that basis would empty the website for a customer who is
       looking at it right now. */
    const current = (global.VG_CONFIG && global.VG_CONFIG.products) || [];
    if (!rows.length && current.length) return false;

    if (!global.VG_CONFIG) global.VG_CONFIG = {};
    global.VG_CONFIG.products = rows;
    try { if (typeof onUpdate === 'function') onUpdate(rows); } catch(e){ console.warn(e); }
    try {
      global.dispatchEvent(new CustomEvent('vg:catalogue', { detail: rows }));
    } catch(e){}
    return true;
  }


  /* ---- shop settings that customers must be able to read ---------

     Things like the home page pictures. They live as reserved rows in
     the same table, so they arrive on every device the same way the
     catalogue does and need no extra setup. */

  async function fetchSetting(key){
    if (!ready()) return null;
    const c = CFG();
    const id = '__' + key;
    const res = await fetch(c.url + '/rest/v1/products?select=id,data&id=eq.' + encodeURIComponent(id),
                            { headers: await headers() });
    if (!res.ok) throw await fail(res);
    const rows = await res.json();
    return (rows && rows[0] && rows[0].data) || null;
  }

  async function saveSetting(key, value){
    if (!ready()) return { ok:false, reason:'not-configured' };
    const c = CFG();
    try {
      const res = await fetch(c.url + '/rest/v1/products?on_conflict=id', {
        method: 'POST',
        headers: await headers({ 'Prefer': 'resolution=merge-duplicates,return=minimal' }),
        body: JSON.stringify([{ id: '__' + key, data: value, updated_at: new Date().toISOString() }])
      });
      if (!res.ok) throw await fail(res);
      return { ok:true };
    } catch (err){
      return { ok:false, error:err, message: err.message || String(err) };
    }
  }


  /* ---- searching in the database, not the browser ----------------

     The old fetchProducts pulled the whole catalogue down and let the
     page filter it. That is the right shape for a few hundred frames
     and the wrong one for forty thousand: eleven megabytes before the
     home page draws, and a browser storage limit that gives out around
     seventeen thousand.

     This asks the database for one page of already-filtered results.
     The work happens where the indexes are, and the phone receives
     twenty-four frames instead of forty thousand. */

  const PAGE = 24;

  /* Raised from 2000. Anything at or above this is being truncated, so
     the caller is told rather than left with a short list it believes
     is complete. */
  const WHOLE_CATALOGUE_CAP = 10000;

  function esc(v){ return encodeURIComponent(String(v == null ? '' : v)); }

  async function searchProducts(opts){
    if (!ready()) return null;
    opts = opts || {};
    const c = CFG();
    const page = Math.max(0, Number(opts.page) || 0);
    const size = Math.max(1, Math.min(60, Number(opts.pageSize) || PAGE));

    const qs = ['select=id,data'];

    /* Only what a customer could actually buy. Computed in the
       database, so a hidden frame never crosses the wire. */
    if (opts.includeHidden !== true) qs.push('p_visible=is.true');
    /* A frame is on the website only once its try-on picture exists
       (d16.62). The robot writes tryOnReady when it has cut the photo;
       a ready-made PNG from the shop sets it at save time. Until then
       the frame is invisible to customers -- never half-working.
       Frames saved before the robot existed carry no tryOnFails field
       and are left exactly as they were. */
    if (opts.includeHidden !== true) qs.push('or=(data->>tryOnReady.eq.true,data->>tryOnFails.is.null)');

    if (opts.cat)    qs.push('p_cat=eq.'    + esc(opts.cat));
    if (opts.shape)  qs.push('p_shape=eq.'  + esc(String(opts.shape).toLowerCase()));
    if (opts.colour) qs.push('p_colour=eq.' + esc(String(opts.colour).toLowerCase()));
    if (opts.maxPrice) qs.push('p_price=lte.' + esc(opts.maxPrice));

    /* These filters are stored in the product JSON. Querying the JSON
       directly means Metal / Plastic / Supra / Rimless / 1+1 work on
       the live Supabase catalogue without another migration. */
    if (opts.material) qs.push('data->>material=eq.' + esc(opts.material));
    if (opts.rim)      qs.push('data->>rim=eq.' + esc(opts.rim));
    if (opts.offer)    qs.push('data->>offerCode=eq.' + esc(opts.offer));
    if (opts.size){
      const z=String(opts.size).toLowerCase();
      if (z==='extra narrow'){qs.push('p_width=gte.126');qs.push('p_width=lte.129');}
      else if (z==='narrow'){qs.push('p_width=gte.130');qs.push('p_width=lte.133');}
      else if (z==='medium'){qs.push('p_width=gte.134');qs.push('p_width=lte.137');}
      else if (z==='wide'){qs.push('p_width=gte.138');qs.push('p_width=lte.141');}
      else if (z==='extra wide')qs.push('p_width=gte.142');
    }

    /* An untagged frame is unisex, so "Men" must also return the ones
       with no wearer set -- otherwise filtering hides most of the
       shop. Kids is different and is handled by category. */
    if (opts.wearer){
      const w = String(opts.wearer).toLowerCase();
      /* Kids must be tagged, or on the kids shelf. Untagged adult
         stock falling into a children's search is how a parent ends
         up buying a frame that cannot fit their child. Every other
         heading treats untagged as unisex, which it is. */
      if (w === 'kids') qs.push('or=(p_wearer.eq.kids,p_cat.eq.kids)');
      else qs.push('or=(p_wearer.eq.' + esc(w) + ',p_wearer.is.null,p_wearer.eq.)');
    }

    /* Contact-lens kind: Clear, Colour, Solution.

       These used to be a plain word search, so a clear lens named
       "Bausch & Lomb Monthly" matched nothing and the tile looked
       broken. Now the kind set in admin is what counts -- and the old
       name match is kept alongside it, so lenses added before the
       field existed still turn up. */
    if (opts.sub){
      const s = String(opts.sub).toLowerCase().replace(/[^a-z]/g, '');
      if (s) qs.push('or=(data->>sub.eq.' + esc(s) + ',p_name.ilike.*' + esc(s) + '*)');
    }

    if (opts.q){
      /* Every word must appear somewhere, so more words narrow the
         result rather than widening it. */
      const terms = String(opts.q).trim().toLowerCase()
        .split(/\s+/).filter(Boolean).map(w => w.replace(/[^a-z0-9]/g, ''))
        .filter(Boolean).join(' & ');
      if (terms) qs.push('p_search=fts(simple).' + esc(terms));
    }

    const order = opts.sort === 'low'  ? 'p_price.asc.nullslast'
                : opts.sort === 'high' ? 'p_price.desc.nullslast'
                : opts.sort === 'name' ? 'p_name.asc'
                : 'updated_at.desc';
    qs.push('order=' + order);

    const from = page * size, to = from + size - 1;
    const h = await headers({
      'Range-Unit': 'items',
      'Range': from + '-' + to,
      /* Planned rather than exact: an exact count rescans the table on
         every search. "About 1,200" instantly beats "1,207" slowly. */
      'Prefer': 'count=planned'
    });

    const res = await fetch(c.url + '/rest/v1/products?' + qs.join('&'), { headers: h });
    if (!res.ok && res.status !== 206) throw await fail(res);

    const rows = await res.json();
    /* Content-Range comes back as "0-23/1200". */
    let total = null;
    const cr = res.headers && res.headers.get ? res.headers.get('content-range') : null;
    if (cr){
      const m = /\/(\d+|\*)$/.exec(cr);
      if (m && m[1] !== '*') total = Number(m[1]);
    }

    return {
      rows: (rows || []).filter(r => !(r.data && (r.data.deleted || r.data.draft || r.data.awaitingCheck))).map(r => {
        const o = (r.data && typeof r.data === 'object') ? r.data : {};
        o.id = r.id;
        return o;
      }),
      total: total,
      page: page,
      pageSize: size,
      more: (rows || []).length === size
    };
  }

  async function fetchProduct(id){
    if(!ready()||!id)return null;const c=CFG();
    const res=await fetch(c.url+'/rest/v1/products?select=id,data&id=eq.'+esc(id)+'&limit=1',{headers:await headers()});
    if(!res.ok)throw await fail(res);const rows=await res.json();if(!rows||!rows[0])return null;
    if (rows[0].data && (rows[0].data.deleted || rows[0].data.draft || rows[0].data.awaitingCheck)) return null;   /* a draft, or a frame not yet checked, is never shown to a customer */
    const o=(rows[0].data&&typeof rows[0].data==='object')?rows[0].data:{};o.id=rows[0].id;return o;
  }
  async function fetchVariants(p){
    if(!ready()||!p)return [];const group=String(p.modelGroup||p.model||'').trim();if(!group)return [p];const c=CFG();
    const q='select=id,data&or=(data->>modelGroup.eq.'+esc(group)+',data->>model.eq.'+esc(group)+')&limit=30';
    const res=await fetch(c.url+'/rest/v1/products?'+q,{headers:await headers()});if(!res.ok)throw await fail(res);
    return (await res.json()).map(r=>{const o=(r.data&&typeof r.data==='object')?r.data:{};o.id=r.id;return o}).filter(o=>!o.draft&&!o.deleted&&!o.awaitingCheck);
  }

  /* ---- saving one frame, not all of them ----

     saveProducts sends the entire catalogue. At forty thousand rows
     that is minutes of upload to change one price, and it would run on
     every keystroke. */
  async function saveProduct(p){
    if (!ready()) return { ok:false, reason:'not-configured' };
    if (!p || !p.id) return { ok:false, reason:'no-id' };
    const c = CFG();
    try {
      const res = await fetch(c.url + '/rest/v1/products?on_conflict=id', {
        method: 'POST',
        headers: await headers({ 'Prefer':'resolution=merge-duplicates,return=minimal' }),
        body: JSON.stringify([{ id:String(p.id), data:p, updated_at:new Date().toISOString() }])
      });
      if (!res.ok) throw await fail(res);
      return { ok:true };
    } catch (err){
      return { ok:false, error:err, message: err.message || String(err) };
    }
  }

  async function deleteProduct(ids){
    if (!ready()) return { ok:false, reason:'not-configured' };
    const list = Array.isArray(ids) ? ids : [ids];
    if (!list.length) return { ok:true, count:0 };
    const c = CFG();
    try {
      const inList = list.map(i => '"' + String(i).replace(/"/g,'') + '"').join(',');
      /* return=representation, NOT return=minimal.

         With row-level security switched on and no DELETE policy on the
         table, PostgREST answers 204 and removes nothing. Asking only
         "did the request succeed?" gets a yes, the frame disappears from
         the admin screen, and it is still live on the website. That is
         exactly the silent failure that let deleted frames keep showing.

         Asking for the deleted rows back turns the lie into a number we
         can check. */
      const res = await fetch(c.url + '/rest/v1/products?id=in.(' + encodeURIComponent(inList) + ')', {
        method:'DELETE', headers: await headers({ 'Prefer':'return=representation' })
      });
      if (!res.ok) throw await fail(res);

      let rows = [];
      try { rows = await res.json(); } catch (e){ rows = null; }

      /* A server that genuinely cannot report back is not proof of
         failure, so only treat a real, readable count as evidence. */
      if (Array.isArray(rows)){
        /* DELETED MEANS GONE. (d16.21)

           With no DELETE policy on the table the request removes
           nothing. Until now that came back as a red warning and the
           frame stayed on the website. UPDATE is allowed, so the rows
           that would not delete are overwritten with a tombstone --
           deleted:true, qty:0, no photo -- and every reader of the
           catalogue skips tombstones. The frame leaves the website
           either way. delete-policy.sql still makes the real delete
           work; this makes the shop not depend on it. */
        const gone = new Set(rows.map(r => String(r.id)));
        const left = list.filter(i => !gone.has(String(i)));
        if (left.length){
          const stamp = new Date().toISOString();
          const tomb = left.map(i => ({ id:String(i), data:{ id:String(i), deleted:true, deletedAt:stamp, qty:0, url:'', name:'(deleted)' }, updated_at:stamp }));
          const up = await fetch(c.url + '/rest/v1/products?on_conflict=id', {
            method:'POST',
            headers: await headers({ 'Prefer':'resolution=merge-duplicates,return=minimal' }),
            body: JSON.stringify(tomb)
          });
          if (!up.ok) throw await fail(up);
          return { ok:true, count:list.length, soft:left.length,
                   message: left.length + ' removed by marking as deleted (no DELETE policy on the table \u2014 run delete-policy.sql once to delete for real).' };
        }
        return { ok:true, count:rows.length };
      }
      return { ok:true, count:list.length, verified:false };
    } catch (err){
      return { ok:false, error:err, message: err.message || String(err) };
    }
  }

  /* Upload in batches. One request carrying forty thousand rows is
     refused by the server; five hundred at a time is not. */
  async function saveProductsChunked(list, onProgress){
    if (!ready()) return { ok:false, reason:'not-configured' };
    const rows = (list || []).filter(p => p && p.id);
    const SIZE = 500;
    const c = CFG();
    let done = 0;
    for (let i = 0; i < rows.length; i += SIZE){
      const chunk = rows.slice(i, i + SIZE).map(p => ({
        id:String(p.id), data:p, updated_at:new Date().toISOString()
      }));
      try {
        const res = await fetch(c.url + '/rest/v1/products?on_conflict=id', {
          method:'POST',
          headers: await headers({ 'Prefer':'resolution=merge-duplicates,return=minimal' }),
          body: JSON.stringify(chunk)
        });
        if (!res.ok) throw await fail(res);
      } catch (err){
        /* Report how far it got. Half an upload is recoverable; a bare
           failure with no position is not. */
        return { ok:false, done, total:rows.length, error:err, message: err.message || String(err) };
      }
      done += chunk.length;
      if (typeof onProgress === 'function') onProgress(done, rows.length);
    }
    return { ok:true, count:done };
  }

  global.VGSync = { ready, saveOrder, nextRef, flushPending, fetchOrder, updateOrderPayload, fetchOrders, updateStatus,
                    fetchProducts, saveProducts, refreshCatalogue, shopReady,
                    fetchSetting, saveSetting,
                    searchProducts, fetchProduct, fetchVariants, saveProduct, deleteProduct, saveProductsChunked, PAGE };

})(window);

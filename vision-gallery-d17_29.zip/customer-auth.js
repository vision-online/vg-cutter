/* Vision Gallery — customer mobile OTP session.
   Separate from staff/admin auth on purpose. */
(function(global){
  'use strict';
  const KEY='vg_customer_session';
  const DEFAULTS={
    url:'https://oscpunukbyosckrmopeh.supabase.co',
    key:'sb_publishable_WWAPQTu0lo-X51T4kDlgng_LR39PPkU'
  };
  function cfg(){
    try{ const s=JSON.parse(localStorage.getItem('vg_sync')||'null'); if(s&&s.url&&s.key) return s; }catch(e){}
    return DEFAULTS;
  }
  function load(){ try{return JSON.parse(localStorage.getItem(KEY)||'null');}catch(e){return null;} }
  function save(s){ try{s?localStorage.setItem(KEY,JSON.stringify(s)):localStorage.removeItem(KEY);}catch(e){} }
  function normalizePhone(v){
    let d=String(v||'').replace(/\D/g,'');
    if(d.length===12 && d.startsWith('91')) d=d.slice(2);
    if(d.length!==10) return null;
    return {local:d,e164:'+91'+d};
  }
  async function reason(res){
    try{ const b=await res.json(); return b.msg||b.message||b.error_description||b.error||('HTTP '+res.status); }
    catch(e){ return 'HTTP '+res.status; }
  }
  function shape(body, phone){
    if(!body||!body.access_token) return null;
    return {
      access_token:body.access_token,
      refresh_token:body.refresh_token||'',
      expires_at:Date.now()+((Number(body.expires_in)||3600)*1000),
      phone:(body.user&&body.user.phone)||phone||'',
      user_id:(body.user&&body.user.id)||''
    };
  }
  async function sendOtp(input){
    const p=normalizePhone(input); if(!p) return {ok:false,error:'Enter a valid 10-digit mobile number.'};
    const c=cfg();
    try{
      const res=await fetch(c.url+'/auth/v1/otp',{method:'POST',headers:{apikey:c.key,'Content-Type':'application/json'},body:JSON.stringify({phone:p.e164,create_user:true})});
      if(!res.ok){ const why=await reason(res); return {ok:false,error:why}; }
      return {ok:true,phone:p.local,e164:p.e164};
    }catch(e){ return {ok:false,error:'Could not reach the secure login service. Check your internet connection.'}; }
  }
  async function verifyOtp(input, code){
    const p=normalizePhone(input); if(!p) return {ok:false,error:'Enter a valid mobile number.'};
    const token=String(code||'').replace(/\D/g,''); if(!token) return {ok:false,error:'Enter the OTP sent to your mobile.'};
    const c=cfg();
    try{
      const res=await fetch(c.url+'/auth/v1/verify',{method:'POST',headers:{apikey:c.key,'Content-Type':'application/json'},body:JSON.stringify({phone:p.e164,token,type:'sms'})});
      if(!res.ok){ const why=await reason(res); return {ok:false,error:why}; }
      const body=await res.json(), s=shape(body,p.e164); if(!s) return {ok:false,error:'OTP was accepted but no secure session was returned.'};
      save(s); return {ok:true,session:s,phone:p.local};
    }catch(e){ return {ok:false,error:'Could not verify the OTP. Check your internet connection.'}; }
  }
  async function refresh(){
    const s=load(); if(!s||!s.refresh_token) return null;
    const c=cfg();
    try{
      const res=await fetch(c.url+'/auth/v1/token?grant_type=refresh_token',{method:'POST',headers:{apikey:c.key,'Content-Type':'application/json'},body:JSON.stringify({refresh_token:s.refresh_token})});
      if(!res.ok){save(null);return null;}
      const n=shape(await res.json(),s.phone); if(!n){save(null);return null;} save(n); return n;
    }catch(e){return null;}
  }
  async function session(){
    let s=load(); if(!s) return null;
    if((s.expires_at||0)<Date.now()+60000) s=await refresh();
    return s;
  }
  async function signOut(){save(null);}
  async function fetchOrders(){
    const s=await session(); if(!s) return {ok:false,error:'not-signed-in',orders:[]};
    const p=normalizePhone(s.phone); if(!p) return {ok:false,error:'phone-missing',orders:[]};
    const c=cfg();
    const url=c.url+'/rest/v1/orders?select=ref,name,phone,total,status,created_at,payload&phone=eq.'+encodeURIComponent(p.local)+'&order=created_at.desc&limit=100';
    try{
      const res=await fetch(url,{headers:{apikey:c.key,Authorization:'Bearer '+s.access_token}});
      if(!res.ok) return {ok:false,error:await reason(res),orders:[]};
      return {ok:true,orders:await res.json(),phone:p.local};
    }catch(e){return {ok:false,error:'Could not load your records. Check your internet connection.',orders:[]};}
  }
  global.VGCustomerAuth={sendOtp,verifyOtp,session,signOut,fetchOrders,normalizePhone};
})(window);

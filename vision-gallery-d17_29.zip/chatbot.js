/* =====================================================================
   VISION GALLERY — CHAT ASSISTANT
   Drop <script src="chatbot.js"></script> before </body> on any page.

   The assistant answers from a knowledge base you control in
   Admin -> Chatbot. Unknown questions get a neutral support response.
   ===================================================================== */
(function () {
  'use strict';

  const CFG   = window.VG_CONFIG || {};
  const SHOP  = CFG.shop || {};
  const NAME  = SHOP.shopName || 'Vision Gallery';

  /* ---------- Knowledge base ----------
     Priority: what you taught in Admin  ->  old static config  ->  these defaults */
  const DEFAULT_KB = [
    { q: 'timing hours open close when shop working', 
      a: 'All our stores are open daily from 10am to 9pm, including Sundays.' },
    { q: 'eye test checkup free appointment optometrist',
      a: 'Eye tests are completely free at every branch and you don\'t need an appointment. We\'re in JB Nagar, Chakala, Poonam Nagar, Marol, Santacruz / Kalina and Goregaon (near the station), open daily 10am to 9pm. A qualified optometrist checks your vision in a few minutes — no obligation to buy.' },
    { q: 'how long time ready delivery days make lens',
      a: 'Most single-vision glasses are ready the same day. Progressive and high-index lenses usually take 2 to 3 days.' },
    { q: 'offer discount buy one get free bogo deal',
      a: 'Right now: buy 1 get 1 free on over 1000 frames, and progressive glasses at ₹2,800 with buy 1 get 1 free. You also get a free home trial of up to 3 frames.' },
    { q: 'warranty guarantee broken repair',
      a: 'Every purchased pair carries a 1-year warranty, and the free pair from a buy-one-get-one offer carries 6 months. It covers manufacturing defects and coating problems.' },
    { q: 'return refund exchange policy',
      a: 'You can return within 7 days. Custom-cut prescription lenses can only be returned if there\'s a fault or an error in the power.' },
    { q: 'store location branch where address near find',
      a: 'We have 6 stores across Mumbai: JB Nagar, Chakala, Poonam Nagar, Marol, Santacruz/Kalina and Goregaon (near the station). We also deliver to your home.' },
    { q: 'payment pay upi card cash cod online netbanking',
      a: 'You can pay by UPI or QR, card at the store, an online payment link, or cash on delivery. You\'ll see all the available options at checkout.' },
    { q: 'price cost how much rate frame cheap budget',
      a: 'Frames start around ₹900 and lenses from ₹500, so a complete pair often works out under ₹2,000. Build your glasses on our order page to see the exact price as you choose.' },
    { q: 'progressive bifocal multifocal difference',
      a: 'Bifocals have a visible line separating distance and reading. Progressives blend distance, middle and reading with no line at all — they look like ordinary glasses. Ours are ₹2,800 with buy 1 get 1 free.' },
    { q: 'blue light filter screen computer eye strain',
      a: 'A blue light filter cuts the blue light from phones, laptops and TVs, which helps if you spend long hours on screens. It\'s ₹900 added to any lens.' },
    { q: 'photochromatic transition sunlight dark change',
      a: 'Photochromatic lenses stay clear indoors and darken automatically in sunlight — ₹2,200. Branded Transitions® lenses darken and clear faster, at ₹3,600.' },
    { q: 'high index thin thick lens power strong',
      a: 'Higher index means a thinner, lighter lens. We stock 1.50, 1.56, 1.61, 1.67 and 1.74. The stronger your power, the higher the index we\'d suggest — our order page recommends one based on your prescription.' },
    { q: 'anti glare antiglare reflection ar coating',
      a: 'Anti-glare coating is included free on every pair we make. It cuts reflections from screens and headlights, and makes your eyes more visible to others.' },
    { q: 'contact lens lenses daily monthly coloured',
      a: 'We stock daily, monthly and coloured contact lenses from all major brands, with fitting support from our optometrists.' },
    { q: 'try on virtual camera face see',
      a: 'Yes — tap Try On on any frame and you can see it live on your face using your camera. Nothing is recorded; it all stays on your device.' },
    { q: 'prescription power send upload how give rx',
      a: 'You can type your power into our order page, or upload a photo of your paper prescription. If you don\'t know your power, come in for a free eye test.' },
    { q: 'pd pupillary distance what mean measure',
      a: 'PD is the distance between the centres of your pupils, in millimetres. It centres the lens in front of your eye. Most adults are between 54 and 74. If you only know the total, our form works out each eye for you.' },
    { q: 'kids children child frame school',
      a: 'We stock flexible, impact-resistant kids frames built for daily school use, starting around ₹900.' },
    { q: 'home trial try at home 3 frames',
      a: 'We offer a free home trial — we send up to 3 frames to your home so you can try them before deciding.' },
    { q: 'delivery ship courier home deliver mumbai charge fee free shipping',
      a: 'We deliver across Mumbai. Delivery is free on orders above ₹1,500, and ₹99 below that. If you would rather collect, you can choose a store at checkout — that is always free.' }
  ];

  function loadKB() {
    let kb = [];
    try {
      const saved = JSON.parse(localStorage.getItem('vg_chatbot') || 'null');
      if (Array.isArray(saved) && saved.length) kb = saved;
    } catch (e) {}
    if (!kb.length && CFG.chatbot && Array.isArray(CFG.chatbot) && CFG.chatbot.length) kb = CFG.chatbot;
    if (!kb.length) kb = DEFAULT_KB;
    return kb;
  }

  const STOP = new Set(['the','a','an','is','are','do','does','i','you','we','my','me','to','of',
    'in','on','for','and','or','can','it','what','how','when','where','with','have','has','be','at','your']);

  /* ---------- What is actually in the shop ----------

     The knowledge base is written by hand and goes stale the moment a
     price changes. The catalogue does not: it comes from the shop's
     account and is the same list the customer is looking at. So for
     anything about frames, prices or stock, read the catalogue rather
     than a sentence somebody typed months ago.

     This is the difference between "frames start around 900" and
     "the cheapest right now is the VG-300 at 900". */

  function catalogue(){
    const list = (window.VG_CONFIG && window.VG_CONFIG.products) || [];
    return list.filter(p => p && p.url && p.stock !== false &&
      !(p.qty !== '' && p.qty !== undefined && p.qty !== null && Number(p.qty) <= 0));
  }

  const CAT_WORDS = {
    'sunglass': 'sunglasses', 'sunglasses': 'sunglasses', 'shades': 'sunglasses',
    'goggle': 'sunglasses', 'goggles': 'sunglasses',
    'frame': 'frames', 'frames': 'frames', 'spectacle': 'frames', 'specs': 'frames',
    'eyeglass': 'frames', 'eyeglasses': 'frames',
    'kid': 'kids', 'kids': 'kids', 'child': 'kids', 'children': 'kids',
    'contact': 'contact-lenses', 'lens': 'contact-lenses', 'lenses': 'contact-lenses',
    'branded': 'branded', 'brand': 'branded',
    'progressive': 'progressive', 'photochromatic': 'photochromatic'
  };

  function money(n){ return '\u20b9' + Number(n || 0).toLocaleString('en-IN'); }

  /* Pull a budget out of plain speech: "under 2000", "below 1500",
     "2k budget", "around 3000". */
  function budgetFrom(q){
    let m = q.match(/(?:under|below|less than|upto|up to|within|max|budget of|around|about)\s*(?:rs\.?|inr|\u20b9)?\s*([0-9][0-9,]*)\s*(k)?/i);
    if (!m) m = q.match(/(?:rs\.?|inr|\u20b9)\s*([0-9][0-9,]*)\s*(k)?/i);
    if (!m) return null;
    let n = Number(String(m[1]).replace(/,/g, ''));
    if (m[2]) n *= 1000;
    return n > 0 ? n : null;
  }

  function frameLine(p){
    const name = (p.name || 'Frame').replace(/</g, '&lt;');
    const price = Number(p.price) > 0 ? money(p.price) : 'price on request';
    const bits = [p.colour, p.shape].filter(Boolean).join(', ');
    return '<a href="product.html?id=' + encodeURIComponent(p.id || '') + '">' + name + '</a> \u2014 ' +
           price + (bits ? ' (' + bits.replace(/</g, '&lt;') + ')' : '');
  }

  /* Answer from stock where the question is about stock. Returns null
     when it is not, so the written knowledge base still handles
     timings, warranty, eye tests and the rest. */
  function fromCatalogue(q){
    const list = catalogue();
    if (!list.length) return null;

    const lower = ' ' + q.toLowerCase().replace(/[^a-z0-9\s\u20b9]/g, ' ') + ' ';
    const words = lower.split(/\s+/).filter(Boolean);

    let cat = null;
    words.forEach(w => { if (CAT_WORDS[w] && !cat) cat = CAT_WORDS[w]; });

    const budget = budgetFrom(q);
    const wantsCheap  = /\b(cheap|cheapest|lowest|budget|affordable|starting|start)\b/.test(lower);
    const wantsCount  = /\b(how many|how much stock|available|in stock)\b/.test(lower);
    const wantsSugges = /\b(suggest|recommend|show|which|options?|looking for|want|need)\b/.test(lower);

    /* Colour and shape, matched against what the shop actually has, so
       a made-up colour does not produce a confident empty answer. */
    const colours = [...new Set(list.map(p => (p.colour || '').toLowerCase()).filter(Boolean))];
    const shapes  = [...new Set(list.map(p => (p.shape  || '').toLowerCase()).filter(Boolean))];
    const colour = colours.find(c => lower.indexOf(' ' + c + ' ') !== -1) || null;
    const shape  = shapes.find(sh => lower.indexOf(' ' + sh + ' ') !== -1) || null;

    /* If they named a colour or shape we simply do not carry, say so.

       Without this, asking for purple sunglasses returned the black
       and the gold ones with no mention of purple -- which reads as
       "here is your purple" and wastes the customer's time when the
       box arrives. Silence about the thing they actually asked for is
       a form of overselling. */
    const KNOWN_COLOURS = ['black','brown','blue','gold','silver','grey','gray','green','red',
      'pink','purple','white','tortoise','tortoiseshell','rose','beige','maroon','orange',
      'yellow','transparent','clear','gunmetal','bronze','navy','olive','tan'];
    const KNOWN_SHAPES = ['round','square','rectangle','rectangular','oval','aviator','pilot',
      'cat eye','cateye','wayfarer','geometric','hexagonal','butterfly','wraparound'];

    const askedColour = KNOWN_COLOURS.find(c => lower.indexOf(' ' + c + ' ') !== -1) || null;
    const askedShape  = KNOWN_SHAPES.find(sh => lower.indexOf(' ' + sh + ' ') !== -1) || null;

    if (askedColour && !colour){
      return 'I do not have anything in ' + askedColour + ' listed online at the moment. ' +
        'We carry a lot more in the shops than we can put on the site \u2014 worth asking, ' +
        'or tell me a colour and I will check what is listed.';
    }
    if (askedShape && !shape){
      return 'Nothing in ' + askedShape + ' is listed online just now. ' +
        'There is more in the shops than we list here, so it is worth asking.';
    }

    if (!cat && !budget && !wantsCheap && !colour && !shape && !wantsCount) return null;

    let hits = list.slice();
    if (cat)    hits = hits.filter(p => p.cat === cat);
    if (colour) hits = hits.filter(p => (p.colour || '').toLowerCase() === colour);
    if (shape)  hits = hits.filter(p => (p.shape  || '').toLowerCase() === shape);
    if (budget) hits = hits.filter(p => Number(p.price) > 0 && Number(p.price) <= budget);

    const what = [colour, shape, cat ? cat.replace('-', ' ') : 'frames'].filter(Boolean).join(' ');

    if (!hits.length){
      /* Say what is missing and offer the nearest thing, rather than a
         flat no. A flat no ends the conversation; a near miss keeps it
         going. */
      let near = list.slice();
      if (cat) near = near.filter(p => p.cat === cat);
      near = near.filter(p => Number(p.price) > 0).sort((a,b) => a.price - b.price);
      if (budget && near.length){
        return 'I could not find ' + what + ' under ' + money(budget) +
          ' right now. The closest is ' + frameLine(near[0]) +
          '.<br><br>We carry far more in the shops than we list online \u2014 worth asking.';
      }
      return 'I do not have ' + what + ' listed online at the moment. ' +
        'We carry a lot more in the shops than we can put on the site, so it is worth asking.';
    }

    if (wantsCount && !wantsSugges){
      return 'We have ' + hits.length + ' ' + what + ' listed online right now' +
        (budget ? ' under ' + money(budget) : '') + '. There is more in the shops.';
    }

    const priced = hits.filter(p => Number(p.price) > 0).sort((a,b) => a.price - b.price);
    const show = (wantsCheap ? priced : hits).slice(0, 3);

    let head;
    if (wantsCheap && priced.length){
      head = 'The cheapest ' + what + ' we have online is ' + money(priced[0].price) + '.';
    } else if (budget){
      head = hits.length + ' ' + what + ' under ' + money(budget) + ':';
    } else {
      head = 'Here is what we have in ' + what + ':';
    }

    return head + '<br><br>' + show.map(p => '\u2022 ' + frameLine(p)).join('<br>') +
      (hits.length > show.length
        ? '<br><br>Plus ' + (hits.length - show.length) + ' more \u2014 use the search on the shop page to see them all.'
        : '');
  }

  function score(query, entry) {
    const words = query.toLowerCase().replace(/[^a-z0-9\s]/g, ' ').split(/\s+/)
      .filter(w => w.length > 2 && !STOP.has(w));
    if (!words.length) return 0;
    const keys = entry.q.toLowerCase().split(/\s+/);
    let hits = 0;
    words.forEach(w => {
      if (keys.some(k => k === w || k.startsWith(w) || w.startsWith(k))) hits += 2;
      else if (entry.a.toLowerCase().includes(w)) hits += 1;
    });
    return hits;
  }

  function answer(query) {
    const kb = loadKB();
    let best = null, bestScore = 0;
    kb.forEach(e => {
      const s = score(query, e);
      if (s > bestScore) { bestScore = s; best = e; }
    });
    return bestScore >= 2 ? best.a : null;
  }

  /* ---------- Styles ---------- */
  const css = `
  .vgc-btn{position:fixed;right:20px;bottom:20px;z-index:400;width:58px;height:58px;border-radius:50%;
    background:#0A0A0A;border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;
    box-shadow:0 6px 24px rgba(10,10,10,.3);transition:transform .2s ease,background .2s ease;}
  .vgc-btn:hover{transform:scale(1.06);background:#C9962C;}
  .vgc-btn svg{width:27px;height:27px;color:#fff;}
  .vgc-btn:hover svg{color:#0A0A0A;}
  .vgc-btn .vgc-dot{position:absolute;top:2px;right:2px;width:13px;height:13px;border-radius:50%;
    background:#C9962C;border:2px solid #fff;}
  .vgc-btn.open .vgc-dot{display:none;}

  .vgc-panel{position:fixed;right:20px;bottom:88px;z-index:400;width:370px;max-width:calc(100vw - 32px);
    height:520px;max-height:calc(100vh - 130px);background:#fff;border:1px solid #E0D9CA;
    box-shadow:0 16px 50px rgba(10,10,10,.22);display:none;flex-direction:column;overflow:hidden;}
  .vgc-panel.on{display:flex;}

  .vgc-head{background:#0A0A0A;color:#fff;padding:15px 18px;display:flex;align-items:center;gap:11px;flex-shrink:0;}
  .vgc-head .vgc-av{width:34px;height:34px;border-radius:50%;background:#C9962C;display:flex;
    align-items:center;justify-content:center;flex-shrink:0;}
  .vgc-head .vgc-av svg{width:19px;height:19px;color:#0A0A0A;}
  .vgc-head b{font-family:Marcellus,Georgia,serif;font-size:.94rem;font-weight:400;letter-spacing:.04em;display:block;}
  .vgc-head small{font-size:.71rem;color:#8ED9A8;display:flex;align-items:center;gap:5px;}
  .vgc-head small::before{content:"";width:6px;height:6px;border-radius:50%;background:#25D366;}
  .vgc-head .vgc-x{margin-left:auto;background:none;border:none;color:#B5B0A5;cursor:pointer;
    font-size:1.4rem;line-height:1;padding:0 2px;}
  .vgc-head .vgc-x:hover{color:#fff;}

  .vgc-body{flex:1;overflow-y:auto;padding:18px;background:#FAF7F0;}
  .vgc-msg{margin-bottom:13px;display:flex;}
  .vgc-msg.bot{justify-content:flex-start;}
  .vgc-msg.you{justify-content:flex-end;}
  .vgc-bub{max-width:83%;padding:11px 14px;font-size:.87rem;line-height:1.6;}
  .vgc-msg.bot .vgc-bub{background:#fff;border:1px solid #E0D9CA;color:#1A1A1A;}
  .vgc-msg.you .vgc-bub{background:#0A0A0A;color:#fff;}
  .vgc-bub a{color:#C9962C;text-decoration:underline;}

  .vgc-chips{display:flex;flex-wrap:wrap;gap:7px;padding:0 18px 14px;background:#FAF7F0;}
  .vgc-chip{background:#fff;border:1px solid #E0D9CA;padding:7px 12px;font-size:.76rem;cursor:pointer;
    font-family:inherit;color:#1A1A1A;transition:border-color .2s ease,background .2s ease;}
  .vgc-chip:hover{border-color:#C9962C;background:#FFFDF8;}

  .vgc-foot{border-top:1px solid #E0D9CA;padding:11px;display:flex;gap:8px;background:#fff;flex-shrink:0;}
  .vgc-foot input{flex:1;padding:11px 13px;border:1px solid #E0D9CA;font-family:inherit;font-size:.86rem;
    color:#1A1A1A;}
  .vgc-foot input:focus{outline:none;border-color:#C9962C;}
  .vgc-send{background:#C9962C;border:none;width:42px;cursor:pointer;display:flex;align-items:center;
    justify-content:center;flex-shrink:0;}
  .vgc-send:hover{background:#E3BC6B;}
  .vgc-send svg{width:19px;height:19px;color:#0A0A0A;}

  .vgc-typing{display:flex;gap:4px;padding:13px 15px;}
  .vgc-typing i{width:6px;height:6px;border-radius:50%;background:#C9C4B8;animation:vgcBounce 1.2s infinite;}
  .vgc-typing i:nth-child(2){animation-delay:.15s;}
  .vgc-typing i:nth-child(3){animation-delay:.3s;}
  @keyframes vgcBounce{0%,60%,100%{transform:translateY(0);opacity:.5;}30%{transform:translateY(-5px);opacity:1;}}

  @media (max-width:480px){
    .vgc-panel{right:12px;left:12px;width:auto;bottom:82px;height:calc(100vh - 120px);}
    .vgc-btn{right:14px;bottom:14px;}
  }
  @media (prefers-reduced-motion:reduce){.vgc-typing i{animation:none;}}
  `;
  const style = document.createElement('style');
  style.textContent = css;
  document.head.appendChild(style);

  /* ---------- Markup ---------- */
  const btn = document.createElement('button');
  btn.className = 'vgc-btn';
  btn.setAttribute('aria-label', 'Chat with us');
  btn.innerHTML = `<span class="vgc-dot"></span>
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7">
      <path d="M21 11.5a8.4 8.4 0 01-9 8.4 9.3 9.3 0 01-2.9-.4L3 21l1.6-4.6A8.2 8.2 0 013 11.5 8.4 8.4 0 0112 3a8.4 8.4 0 019 8.5z"/>
      <path d="M8.5 11h.01M12 11h.01M15.5 11h.01"/></svg>`;

  const panel = document.createElement('div');
  panel.className = 'vgc-panel';
  panel.innerHTML = `
    <div class="vgc-head">
      <div class="vgc-av"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <rect x="2" y="9" width="8" height="6.5" rx="3"/><rect x="14" y="9" width="8" height="6.5" rx="3"/><path d="M10 12h4"/></svg></div>
      <div><b>${NAME} Assistant</b><small>Usually replies instantly</small></div>
      <button class="vgc-x" aria-label="Close chat">&times;</button>
    </div>
    <div class="vgc-body" id="vgcBody"></div>
    <div class="vgc-chips" id="vgcChips"></div>
    <div class="vgc-foot">
      <input type="text" id="vgcInput" placeholder="Ask us anything…" aria-label="Your message">
      <button class="vgc-send" id="vgcSend" aria-label="Send"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 12l16-8-6 8 6 8-16-8z"/></svg></button>
    </div>`;

  document.body.appendChild(btn);
  document.body.appendChild(panel);

  const body   = panel.querySelector('#vgcBody');
  const chips  = panel.querySelector('#vgcChips');
  const input  = panel.querySelector('#vgcInput');

  const CHIPS = ['Store timings', 'Book an eye test', 'Current offers', 'How long does it take?', 'Payment options'];

  function bubble(text, who) {
    const m = document.createElement('div');
    m.className = 'vgc-msg ' + who;
    m.innerHTML = `<div class="vgc-bub">${text}</div>`;
    body.appendChild(m);
    body.scrollTop = body.scrollHeight;
    return m;
  }

  function typing() {
    const m = document.createElement('div');
    m.className = 'vgc-msg bot';
    m.innerHTML = `<div class="vgc-bub vgc-typing"><i></i><i></i><i></i></div>`;
    body.appendChild(m);
    body.scrollTop = body.scrollHeight;
    return m;
  }

  function reply(q) {
    const t = typing();
    setTimeout(() => {
      t.remove();
      /* Stock questions first: a live answer beats a written one that
         may be months out of date. */
      let found = null;
      try { found = fromCatalogue(q); } catch (err){ found = null; }
      if (!found) found = answer(q);
      if (found) {
        bubble(found, 'bot');
      } else {
        bubble(`I don't have that answer yet. You can continue shopping, use the checkout notes box for order-specific instructions, or visit the Stores section for in-store help.`, 'bot');
      }
    }, 420 + Math.random() * 300);
  }

  function send(text) {
    const q = (text || input.value).trim();
    if (!q) return;
    bubble(q.replace(/</g, '&lt;'), 'you');
    input.value = '';
    chips.innerHTML = '';
    reply(q);
  }

  panel.querySelector('#vgcSend').addEventListener('click', () => send());
  input.addEventListener('keydown', e => { if (e.key === 'Enter') send(); });

  chips.addEventListener('click', e => {
    const c = e.target.closest('.vgc-chip');
    if (c) send(c.textContent);
  });

  let started = false;
  function openChat() {
    panel.classList.add('on');
    btn.classList.add('open');
    if (!started) {
      started = true;
      bubble(`Hello! 👋 I'm the ${NAME} assistant. How can I help you today?`, 'bot');
      chips.innerHTML = CHIPS.map(c => `<button class="vgc-chip">${c}</button>`).join('');
    }
    setTimeout(() => input.focus(), 120);
  }
  function closeChat() {
    panel.classList.remove('on');
    btn.classList.remove('open');
  }

  btn.addEventListener('click', () => panel.classList.contains('on') ? closeChat() : openChat());
  panel.querySelector('.vgc-x').addEventListener('click', closeChat);
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeChat(); });

  // let other code open it: window.VGChat.open()
  window.VGChat = { open: openChat, close: closeChat };
})();

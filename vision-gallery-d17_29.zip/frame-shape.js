/* =====================================================================
   Vision Gallery — reading a frame's shape from its photograph

   WHY

   Shape is the field the whole "what suits your face" feature runs on,
   and it is the field most likely to be left blank, because setting it
   on two thousand frames by hand is two thousand judgement calls.

   HOW

   Not machine learning, and not a guess dressed up as one. The frame
   is photographed on white, so the lens opening is a white island
   surrounded by frame. Find that island and measure it:

     how much wider than tall it is       -- rectangle vs round
     how much of its bounding box it fills -- square corners vs curves
     whether the top is wider than the bottom -- cat eye, aviator

   Those three numbers separate the shapes an optician names. It is
   geometry, and it can be checked.

   WHAT IT MUST NOT DO

   Fill the field silently. The shop is shown what it found and how
   sure it is, and confirms. A wrong shape sends a customer a frame
   that does not suit them, and they blame the shop, not the software.
   ===================================================================== */

(function (global) {
  'use strict';

  const SIZE = 320;          // working resolution; plenty for outline shape

  function load(url){
    return new Promise((res, rej) => {
      const img = new Image();
      /* Cloudinary serves CORS headers, so the canvas stays readable.
         Without this the pixels come back blank and every frame would
         be reported as unreadable. */
      img.crossOrigin = 'anonymous';
      img.onload = () => res(img);
      img.onerror = () => rej(new Error('could not load the photo'));
      img.src = url;
    });
  }

  /* A mask of "this pixel is background", i.e. near-white and flat.
     The photo is padded onto white, so the surround and the lens
     openings are both background; the frame itself is not. */
  function backgroundMask(img){
    const c = document.createElement('canvas');
    c.width = c.height = SIZE;
    const x = c.getContext('2d', { willReadFrequently: true });
    x.fillStyle = '#fff';
    x.fillRect(0, 0, SIZE, SIZE);

    const s = Math.min(SIZE / img.width, SIZE / img.height);
    const w = Math.round(img.width * s), h = Math.round(img.height * s);
    x.drawImage(img, (SIZE - w) / 2, (SIZE - h) / 2, w, h);

    const d = x.getImageData(0, 0, SIZE, SIZE).data;
    const bg = new Uint8Array(SIZE * SIZE);
    for (let i = 0, p = 0; i < d.length; i += 4, p++){
      const r = d[i], g = d[i+1], b = d[i+2];
      const max = Math.max(r, g, b), min = Math.min(r, g, b);
      /* Bright and unsaturated. A pale gold frame is bright but
         saturated, so it is not mistaken for background. */
      bg[p] = (max > 205 && (max - min) < 34) ? 1 : 0;
    }
    return bg;
  }

  /* Flood fill from the border marks everything connected to the
     outside. Whatever is left of the background is enclosed -- the
     lens openings. */
  function enclosedRegions(bg){
    const seen = new Uint8Array(SIZE * SIZE);
    const stack = [];
    for (let i = 0; i < SIZE; i++){
      stack.push(i, (SIZE - 1) * SIZE + i, i * SIZE, i * SIZE + SIZE - 1);
    }
    while (stack.length){
      const p = stack.pop();
      if (p < 0 || p >= bg.length || seen[p] || !bg[p]) continue;
      seen[p] = 1;
      const x = p % SIZE, y = (p / SIZE) | 0;
      if (x > 0)        stack.push(p - 1);
      if (x < SIZE - 1) stack.push(p + 1);
      if (y > 0)        stack.push(p - SIZE);
      if (y < SIZE - 1) stack.push(p + SIZE);
    }

    /* Collect what is background but not reachable from outside. */
    const regions = [];
    const done = new Uint8Array(SIZE * SIZE);
    for (let p = 0; p < bg.length; p++){
      if (!bg[p] || seen[p] || done[p]) continue;
      const cells = [];
      const st = [p];
      done[p] = 1;
      while (st.length){
        const q = st.pop();
        cells.push(q);
        const x = q % SIZE, y = (q / SIZE) | 0;
        const push = r => { if (r >= 0 && r < bg.length && bg[r] && !seen[r] && !done[r]){ done[r] = 1; st.push(r); } };
        if (x > 0)        push(q - 1);
        if (x < SIZE - 1) push(q + 1);
        if (y > 0)        push(q - SIZE);
        if (y < SIZE - 1) push(q + SIZE);
      }
      if (cells.length > 250) regions.push(cells);   // ignore specks
    }
    return regions;
  }

  function measure(cells){
    let x0 = SIZE, x1 = 0, y0 = SIZE, y1 = 0;
    cells.forEach(p => {
      const x = p % SIZE, y = (p / SIZE) | 0;
      if (x < x0) x0 = x; if (x > x1) x1 = x;
      if (y < y0) y0 = y; if (y > y1) y1 = y;
    });
    const w = x1 - x0 + 1, h = y1 - y0 + 1;

    /* How wide the opening is across its top third and bottom third.
       A cat eye is wider at the top; an aviator narrows to a point at
       the bottom. */
    const band = (a, b) => {
      let min = SIZE, max = 0;
      cells.forEach(p => {
        const x = p % SIZE, y = (p / SIZE) | 0;
        const f = (y - y0) / h;
        if (f >= a && f < b){ if (x < min) min = x; if (x > max) max = x; }
      });
      return max >= min ? (max - min + 1) : 0;
    };

    /* Where the highest part of the opening sits, left to right.

       This is what actually separates a cat eye from an aviator, and
       comparing top and bottom widths does not: both are wider at the
       top. On a cat eye the outer corner sweeps UP, so the highest
       point sits away from the centre. On an aviator and on every
       round or square frame the highest point is near the middle.

       Returned as 0 (centred) to 1 (hard against one edge). */
    let topY = SIZE, topMin = SIZE, topMax = 0;
    cells.forEach(p => { const y = (p / SIZE) | 0; if (y < topY) topY = y; });
    cells.forEach(p => {
      const x = p % SIZE, y = (p / SIZE) | 0;
      if (y <= topY + Math.max(2, h * 0.08)){
        if (x < topMin) topMin = x;
        if (x > topMax) topMax = x;
      }
    });
    const topCentre = (topMin + topMax) / 2;
    const skew = w > 1 ? Math.abs(topCentre - (x0 + w / 2)) / (w / 2) : 0;

    return {
      x0, y0, w, h,
      aspect: w / h,
      fill: cells.length / (w * h),      // 1.0 = a perfect rectangle
      top: band(0.05, 0.35) / w,
      bottom: band(0.65, 0.95) / w,
      skew: skew
    };
  }

  const NAMES = ['Rectangle','Square','Round','Oval','Cat eye','Aviator','Geometric'];

  function classify(m){
    const { aspect, fill, top, bottom } = m;

    /* Aviator before cat eye.

       Both are wider at the top, so whichever is tested first wins --
       and testing cat eye first called every aviator a cat eye. What
       separates them is the bottom: an aviator closes to a rounded
       point, a cat eye keeps a full-width lens underneath. */
    /* Cat eye first, and identified by where its high point is rather
       than by width alone. Comparing top and bottom widths cannot tell
       these two apart -- both are wider at the top -- which is why the
       first version called every aviator a cat eye. */
    if ((m.skew || 0) > 0.34 && aspect > 1.1)
      return { shape:'Cat eye', why:'the outer corner sweeps upward' };

    if (top > bottom + 0.10 && bottom < 0.80 && fill < 0.86)
      return { shape:'Aviator', why:'narrowing towards the bottom' };

    /* How squarely the opening fills its own bounding box.

       A rectangle fills all of it. A perfect ellipse fills pi/4, which
       is 0.785 -- and the first version put the curved boundary at
       0.80, close enough that a real oval landed on the wrong side and
       came back "Geometric". The two boundaries now sit well clear of
       0.785 and of a rounded rectangle at roughly 0.92. */
    if (fill > 0.88){
      return aspect >= 1.35
        ? { shape:'Rectangle', why:'square corners, clearly wider than tall' }
        : { shape:'Square',    why:'square corners, roughly as wide as tall' };
    }
    if (fill < 0.84){
      return aspect < 1.18
        ? { shape:'Round', why:'curved all round, as wide as tall' }
        : { shape:'Oval',  why:'curved, wider than tall' };
    }
    return { shape:'Geometric', why:'part straight, part curved' };
  }

  /* How near the measurements sit to a boundary. Close to one means
     the frame is between two shapes and the shop should look. */
  function confidence(m){
    const edges = [
      Math.abs(m.fill - 0.88), Math.abs(m.fill - 0.84),
      Math.abs(m.aspect - 1.18), Math.abs(m.aspect - 1.35)
    ];
    return Math.min.apply(null, edges) > 0.06 ? 'clear' : 'close';
  }

  /* Returns { shape, why, sure } or null. Null means unreadable, and
     unreadable must stay unreadable rather than becoming a guess. */
  async function readShape(url){
    let img;
    try { img = await load(url); }
    catch (e){ return null; }

    let bg, regions;
    try {
      bg = backgroundMask(img);
      regions = enclosedRegions(bg);
    } catch (e){
      /* A tainted canvas throws here. Better to say nothing than to
         report a shape measured from pixels we could not read. */
      return null;
    }

    if (!regions.length) return null;

    /* Two lens openings of similar size is the expected picture. Take
       the largest; if the two differ wildly, the photo is at an angle
       and the measurement is not trustworthy. */
    regions.sort((a, b) => b.length - a.length);
    if (regions.length >= 2){
      const ratio = regions[1].length / regions[0].length;
      if (ratio < 0.45) return null;        // one lens hidden or angled away
    }

    const m = measure(regions[0]);

    /* Sanity. A lens opening is a sensible fraction of the picture and
       wider than it is tall in almost every real frame. Anything else
       means we found something that is not a lens. */
    if (m.w < SIZE * 0.12 || m.w > SIZE * 0.62) return null;
    if (m.aspect < 0.7 || m.aspect > 3.2) return null;

    const c = classify(m);
    return { shape: c.shape, why: c.why, sure: confidence(m), measured: m };
  }


  /* ---- what colour is this frame? -------------------------------

     Colour is what customers filter by more than any other field, and
     it is tedious to set by hand on two thousand frames. The frame
     pixels are already identified -- everything that is not background
     -- so the dominant colour is there to be measured.

     Named in the words a customer would use, not hex codes. "Gunmetal"
     is a colour an optician says; "#4A5058" is not. */

  const PALETTE = [
    ['Black',      18,  18,  20],
    ['Grey',      128, 128, 132],
    ['Gunmetal',   74,  80,  88],
    ['Silver',    196, 200, 206],
    ['White',     242, 242, 244],
    ['Brown',     104,  68,  42],
    ['Tortoise',  138,  92,  44],
    ['Beige',     206, 178, 140],
    ['Gold',      198, 158,  70],
    ['Rose gold', 198, 140, 120],
    ['Blue',       44,  84, 160],
    ['Navy',       28,  42,  84],
    ['Green',      52, 110,  70],
    ['Red',       164,  44,  44],
    ['Maroon',    108,  36,  48],
    ['Pink',      212, 130, 156],
    ['Purple',    108,  62, 148],
    ['Transparent',224, 226, 228]
  ];

  function nearestName(r, g, b){
    let best = null, bestD = Infinity;
    PALETTE.forEach(([name, pr, pg, pb]) => {
      /* Weighted to how the eye judges difference -- green counts for
         more than blue. A plain sum treats navy and black as further
         apart than they look. */
      const d = 2*(r-pr)*(r-pr) + 4*(g-pg)*(g-pg) + 3*(b-pb)*(b-pb);
      if (d < bestD){ bestD = d; best = name; }
    });
    return { name: best, distance: Math.sqrt(bestD / 9) };
  }

  async function readColour(url){
    let img;
    try { img = await load(url); } catch (e){ return null; }

    const c = document.createElement('canvas');
    c.width = c.height = SIZE;
    const x = c.getContext('2d', { willReadFrequently: true });
    x.fillStyle = '#fff';
    x.fillRect(0, 0, SIZE, SIZE);
    const s = Math.min(SIZE / img.width, SIZE / img.height);
    const w = Math.round(img.width * s), h = Math.round(img.height * s);
    x.drawImage(img, (SIZE - w) / 2, (SIZE - h) / 2, w, h);

    let d;
    try { d = x.getImageData(0, 0, SIZE, SIZE).data; }
    catch (e){ return null; }

    /* Average only the frame itself. Including the white surround
       would drag every answer towards white and report a black frame
       as grey. */
    let n = 0, R = 0, G = 0, B = 0;
    for (let i = 0; i < d.length; i += 4){
      const r = d[i], g = d[i+1], b = d[i+2];
      const max = Math.max(r,g,b), min = Math.min(r,g,b);
      if (max > 205 && (max - min) < 34) continue;      // background
      R += r; G += g; B += b; n++;
    }
    if (n < 400) return null;                            // too little frame to judge
    R = Math.round(R/n); G = Math.round(G/n); B = Math.round(B/n);

    const hit = nearestName(R, G, B);
    return {
      colour: hit.name,
      rgb: [R, G, B],
      /* A frame sitting between two named colours should be checked,
         not accepted silently. */
      sure: hit.distance < 46 ? 'clear' : 'close'
    };
  }

  global.VGShape = { readShape, classify, measure, readColour, nearestName, NAMES, PALETTE };

})(window);

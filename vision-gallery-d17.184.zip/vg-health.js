/* =====================================================================
   Vision Gallery — problem reporter (d17.153)

   WHY THIS EXISTS
   When something breaks on a customer's phone -- a page error, a frame
   picture that will not load, an order that cannot be saved, a try-on
   that cannot start -- the customer simply leaves. Nobody at the shop
   ever hears about it.

   This file sits first on every customer page and, when something goes
   wrong, quietly writes ONE short note to the database: which page,
   what failed, when, and the kind of phone. Admin -> HEALTH shows these
   notes, grouped by page, in plain words.

   WHAT IT NEVER RECORDS
   No name, no phone number, no email, no prescription. Long numbers and
   email addresses inside error messages are blanked out before sending.
   Only the frame id is kept from the page address.

   LIMITS, so it can never slow a phone down or flood the database
   - at most 6 notes per page visit, the same problem only once
   - at most 40 notes per phone per day
   - if the reports table is not set up yet, it stops trying for 12 hours
   - inside the HEALTH test it records but sends nothing
   ===================================================================== */
(function (g) {
  'use strict';
  if (g.VGHealth) return;

  var BUILD = 'd17.184';
  var DEF = { url: 'https://oscpunukbyosckrmopeh.supabase.co', key: 'sb_publishable_WWAPQTu0lo-X51T4kDlgng_LR39PPkU' };
  function cfg() {
    try { var s = JSON.parse(localStorage.getItem('vg_sync') || 'null'); if (s && s.url && s.key) return s; } catch (e) {}
    return DEF;
  }

  function pageOf(p) {
    var f = String(p || '').toLowerCase().split('?')[0].split('/').pop().replace(/\.html$/, '');
    var map = { '': 'home', 'index': 'home', 'product': 'frame', 'order': 'checkout', 'prescription': 'prescription',
                'account': 'myorders', 'pd-guide': 'pd', 'admin': 'admin', 'check': 'check', '404': 'notfound' };
    return map.hasOwnProperty(f) ? map[f] : (f || 'home');
  }
  /* a page can name itself (the 404 page is served at any missing address) */
  var PAGE = (function () { try { var m = document.querySelector('meta[name="vg-page"]'); if (m && m.content) return m.content; } catch (e) {} return pageOf(g.location && g.location.pathname); })();

  /* inside the Admin HEALTH test (or with ?vgtest=1): record, never send */
  var TEST = (function () {
    try { if (/[?&]vgtest=1\b/.test(g.location.search)) return true; } catch (e) {}
    try { return g.top !== g && !!g.top.__VG_HEALTH_RUNNER; } catch (e) { return false; }
  })();

  var LOG = g.__vgHealthLog = [];
  var seen = {}, sentThisVisit = 0, MAX_VISIT = 6, MAX_DAY = 40, OFF_KEY = 'vg_health_off', DAY_KEY = 'vg_health_day';
  var origFetch = g.fetch ? g.fetch.bind(g) : null;

  function scrub(s) {
    return String(s == null ? '' : s)
      .replace(/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g, '•••@•••')
      .replace(/\+?\d[\d\s-]{8,}\d/g, function (x) { return x.replace(/\D/g, '').length >= 10 ? '•••' : x; })   /* phone-like only */
      .slice(0, 300);
  }
  function shortUrl(u) {
    u = String(u || '');
    try {
      var x = new URL(u, g.location.href);
      if (x.origin === g.location.origin) return x.pathname.split('/').pop() || '/';
      return x.host + x.pathname.slice(0, 80);
    } catch (e) { return u.slice(0, 100); }
  }
  function where() {
    var m = /[?&](?:id|frame)=([^&#]+)/.exec(g.location.search || '');
    var id = '';
    try { id = m ? decodeURIComponent(m[1]).slice(0, 40) : ''; } catch (e) {}
    return (g.location.pathname || '/') + (id ? '?id=' + id : '');
  }
  function device() {
    var u = navigator.userAgent || '', m;
    var os = /iPhone|iPod/.test(u) ? 'iPhone' : /iPad/.test(u) ? 'iPad' : /Android/.test(u) ? 'Android' : /Windows/.test(u) ? 'Windows'
           : /Mac OS X/.test(u) ? 'Mac' : /Linux/.test(u) ? 'Linux' : 'Other';
    var br = /FBAN|FBAV|FB_IAB/.test(u) ? 'Facebook app' : /Instagram/.test(u) ? 'Instagram app' : /WhatsApp/.test(u) ? 'WhatsApp'
           : (m = /SamsungBrowser\/(\d+)/.exec(u)) ? 'Samsung Internet ' + m[1]
           : (m = /EdgA?\/(\d+)/.exec(u)) ? 'Edge ' + m[1]
           : (m = /CriOS\/(\d+)/.exec(u)) ? 'Chrome ' + m[1]
           : /FxiOS|Firefox\//.test(u) ? 'Firefox'
           : (m = /Chrome\/(\d+)/.exec(u)) ? 'Chrome ' + m[1]
           : (m = /Version\/(\d+)[^ ]* (Mobile\/\S+ )?Safari/.exec(u)) ? 'Safari ' + m[1] : 'Browser';
    return os + ' · ' + br;
  }

  function off() { try { return Number(localStorage.getItem(OFF_KEY) || 0) > Date.now(); } catch (e) { return false; } }
  function setOff(hours) { try { localStorage.setItem(OFF_KEY, String(Date.now() + hours * 3600000)); } catch (e) {} }
  function dayOk() {
    try {
      var d = new Date().toISOString().slice(0, 10), r = JSON.parse(localStorage.getItem(DAY_KEY) || 'null') || {};
      if (r.d !== d) r = { d: d, n: 0 };
      if (r.n >= MAX_DAY) return false;
      r.n++; localStorage.setItem(DAY_KEY, JSON.stringify(r)); return true;
    } catch (e) { return true; }
  }

  /* d17.166: search-engine robots (Google, Bing, Facebook link previews ...) open old addresses all day -- never reported */
  var ROBOT = /googlebot|bingbot|adsbot|applebot|duckduckbot|yandex|baiduspider|petalbot|bytespider|gptbot|ahrefs|semrush|mj12bot|crawl|spider|slurp|lighthouse|inspectiontool|facebookexternalhit|bingpreview|pagespeed|[a-z]bot\/\d|\bbot\//i.test((g.navigator && navigator.userAgent) || '');
  function send(row) {
    if (!origFetch || ROBOT) return;
    var c = cfg();
    var h = { 'apikey': c.key, 'Content-Type': 'application/json', 'Prefer': 'return=minimal' };
    if (/^ey[A-Za-z0-9_-]+\./.test(c.key)) h.Authorization = 'Bearer ' + c.key;
    try {
      origFetch(c.url + '/rest/v1/site_health', { method: 'POST', headers: h, body: JSON.stringify([row]), keepalive: true })
        .then(function (res) {
          /* no table yet (404), or not allowed (401/403): stop for 12 hours -- Admin -> HEALTH explains the one-time setup */
          if (res.status === 404 || res.status === 401 || res.status === 403) setOff(12);
        }, function () {});
    } catch (e) {}
  }

  /* level: 'problem' (something on the site is wrong) or 'info' (the customer's side: no camera, slow internet ...) */
  function report(kind, message, extra, level) {
    try {
      var msg = scrub(message);
      var key = (kind === 'order' || kind === 'prescription') ? kind : kind + '|' + msg;   /* one failed save = one note */
      if (!msg || seen[key]) return;
      seen[key] = 1;
      var detail = { level: level === 'info' ? 'info' : 'problem', where: where(), device: device(),
                     w: Math.round((g.screen && g.screen.width) || g.innerWidth || 0), build: BUILD,
                     t: Math.round((g.performance && performance.now && performance.now()) || 0) };
      if (extra && typeof extra === 'object') for (var k in extra) if (extra.hasOwnProperty(k)) detail[k] = typeof extra[k] === 'string' ? scrub(extra[k]).slice(0, 160) : extra[k];
      var row = { page: PAGE, kind: String(kind).slice(0, 40), message: msg, detail: detail };
      LOG.push(row);
      if (TEST) return;
      if (sentThisVisit >= MAX_VISIT || off() || !dayOk()) return;
      sentThisVisit++;
      send(row);
    } catch (e) {}
  }

  /* ---- 1. code errors, and files / pictures that do not load ---- */
  g.addEventListener('error', function (e) {
    var t = e && e.target;
    if (t && t !== g && t.tagName) {
      var tag = String(t.tagName).toLowerCase();
      var src = t.currentSrc || t.src || t.href || '';
      if (!src || /^(data|blob|about):/.test(src) || src === g.location.href) return;
      if (tag === 'img') {
        /* many pictures have a back-up (onerror swaps the address): only a picture that is STILL broken is a problem */
        setTimeout(function () {
          if (!t.isConnected) return;
          if (t.complete && t.naturalWidth > 0) return;
          if ((t.currentSrc || t.src) !== src) return;
          /* a picture the page hides when it fails (a tile that falls back to a drawing) is not a customer problem */
          var box = t.getBoundingClientRect ? t.getBoundingClientRect() : { width: 1, height: 1 };
          if (!(box.width > 0 && box.height > 0)) return;
          report('photo', 'A picture did not load: ' + shortUrl(src), { src: shortUrl(src) });
        }, 2000);
        return;
      }
      /* a web font that does not arrive only changes the letters' look: noted, not a problem */
      if (tag === 'script' || tag === 'link') report('file', 'A ' + (tag === 'script' ? 'program' : 'style') + ' file did not load: ' + shortUrl(src), { src: shortUrl(src) }, /fonts\.(googleapis|gstatic)\.com/.test(src) ? 'info' : 'problem');
      return;
    }
    var m = (e && e.message) || '';
    var f = (e && e.filename) || '';
    if (!m || /^Script error\.?$/i.test(m) || /ResizeObserver loop/i.test(m)) return;
    if (/^(chrome|moz|safari|safari-web)-extension:/.test(f)) return;
    report('script', m, { src: shortUrl(f), line: (e && e.lineno) || 0, col: (e && e.colno) || 0 });
  }, true);

  g.addEventListener('unhandledrejection', function (e) {
    var r = e && e.reason;
    var name = (r && r.name) || '';
    var m = (r && (r.message || r.name)) || (typeof r === 'string' ? r : '');
    if (!m || /AbortError|NotAllowedError|NotSupportedError/.test(name + ' ' + m)) return;
    var st = (r && r.stack) ? String(r.stack).split('\n').slice(0, 2).join(' | ') : '';
    report('script', m, { src: shortUrl(st.replace(/^.*?(https?:\/\/[^\s)]+).*$/, '$1')) });
  });

  /* ---- 2. the database: frames that cannot load, OTP that cannot be sent, a database that is down ---- */
  function dbFail(url, method, status, res) {
    if (status === 0 && navigator.onLine === false) return;                 /* the phone itself is offline */
    var what = (/\/rest\/v1\/([a-z_]+)/.exec(url) || [])[1] || (/\/auth\/v1\/([a-z]+)/.exec(url) || [])[1] || 'database';
    var isAuth = /\/auth\/v1\//.test(url);
    var kind = null, text = '', level = 'problem';
    if (status === 0) { kind = 'database'; text = 'Could not reach the database (' + what + ')'; level = 'info'; }
    else if (status >= 500) { kind = 'database'; text = 'The database answered with an error ' + status + ' (' + what + ')'; }
    else if (what === 'products' && method === 'GET') { kind = 'database'; text = 'Frames could not be loaded from the database (error ' + status + ')'; }
    else if (what === 'orders' && method === 'PATCH') { kind = 'prescription'; text = 'A prescription could not be attached to its order (error ' + status + ')'; }
    else if (isAuth && what === 'otp') { kind = 'otp'; text = 'My Orders: the OTP could not be sent (error ' + status + ')'; }
    if (!kind) return;
    if (res && res.clone && status > 0) {
      res.clone().json().then(function (b) {
        var why = b && (b.msg || b.message || b.error_description || b.error || '');
        report(kind, text + (why ? ': ' + why : ''), { status: status, what: what }, level);
      }, function () { report(kind, text, { status: status, what: what }, level); });
    } else report(kind, text, { status: status, what: what }, level);
  }
  if (origFetch) {
    g.fetch = function (input, init) {
      var p = origFetch(input, init);
      try {
        var url = typeof input === 'string' ? input : (input && input.url) || String(input || '');
        /* d17.166: the website's own server (/api/...) failing -- e.g. 500 / 502 / 504 -- is a problem the shop must hear about.
           501 = "not set up yet" and 429 = "too many, wait" are expected answers, not failures. */
        var own = null; try { own = new URL(url, g.location.href); } catch (e) {}
        if (own && own.origin === g.location.origin && /^\/api\//.test(own.pathname)) {
          var api = (/^\/api\/([a-z-]+)/.exec(own.pathname) || [])[1] || 'api';
          /* the chat's helper being busy (502) is not urgent: the chat already offers WhatsApp / Call instead */
          var lvl = api === 'chat' ? 'info' : 'problem';
          p.then(function (res) { if (res && res.status >= 500 && res.status !== 501) report('server', 'The website server answered with an error ' + res.status + ' (' + api + ')', { status: res.status, api: api }, lvl); },
                 function (err) { if (!(err && err.name === 'AbortError') && navigator.onLine !== false) report('server', 'The website server did not answer (' + api + ')', { api: api }, 'info'); });
        }
        if (/supabase\.co\//.test(url) && !/\/site_health/.test(url)) {
          var method = String((init && init.method) || (input && input.method) || 'GET').toUpperCase();
          p.then(function (res) { if (res && !res.ok) dbFail(url, method, res.status, res); },
                 function (err) { if (!(err && err.name === 'AbortError')) dbFail(url, method, 0, null); });
        }
      } catch (e) {}
      return p;
    };
  }

  /* ---- 3. a page that takes too long to open ---- */
  g.addEventListener('load', function () {
    setTimeout(function () {
      try {
        var nav = performance.getEntriesByType && performance.getEntriesByType('navigation')[0];
        var ms = nav ? nav.loadEventStart : 0;
        if (ms > 8000) report('slow', 'The page took ' + (ms / 1000).toFixed(1) + ' seconds to open', { ms: Math.round(ms) }, 'info');
      } catch (e) {}
    }, 0);
  });

  g.VGHealth = { report: report, page: PAGE, build: BUILD, test: TEST, log: LOG, pageOf: pageOf };
})(window);

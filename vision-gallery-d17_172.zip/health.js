/* =====================================================================
   Vision Gallery — SITE HEALTH (Admin -> HEALTH) — d17.153

   One question, answered at a glance: "Is any page of my website having
   a problem right now, and what exactly is it?"

   1. WEBSITE PAGES   Every customer page is opened here, inside Admin,
                      exactly as a customer's phone opens it (you see it
                      in the small preview while it runs). Each page is
                      checked for what a customer needs: frames showing,
                      photos loading, prices right, the try-on button,
                      lens prices matching Settings, the forms working.
                      Nothing is bought, sent or saved.
   2. CUSTOMERS' PHONES  Problems that really happened on customers'
                      phones (vg-health.js writes them), grouped by page.
   3. SERVICES        Database, the cut-out robot, the WhatsApp sender,
                      the OTP login, which build is live.
   4. SHOP DATA       The older technical check (check.html), read and
                      shown here in the same colours.

   Green = working. Amber = needs a look. Red = a customer is affected.
   Every red or amber line says what to do, in plain words.
   ===================================================================== */
(function (g) {
  'use strict';
  var VERSION = '2026-10-22 d17.172';
  g.__VG_HEALTH_RUNNER = true;            /* pages opened by this test record problems but send nothing */

  var DEF = { url: 'https://oscpunukbyosckrmopeh.supabase.co', key: 'sb_publishable_WWAPQTu0lo-X51T4kDlgng_LR39PPkU' };
  function cfg() { try { var s = JSON.parse(localStorage.getItem('vg_sync') || 'null'); if (s && s.url && s.key) return s; } catch (e) {} return DEF; }
  function isJwt(k) { return typeof k === 'string' && /^ey[A-Za-z0-9_-]+\./.test(k); }
  function projectRef() { var m = /https:\/\/([a-z0-9]+)\.supabase\.co/.exec(cfg().url); return m ? m[1] : ''; }

  var SQL = [
    '-- Vision Gallery: problem reports from customers\' phones (Admin -> HEALTH). Run once.',
    'create table if not exists public.site_health (',
    '  id uuid primary key default gen_random_uuid(),',
    '  created_at timestamptz not null default now(),',
    '  page text not null default \'\',',
    '  kind text not null default \'\',',
    '  message text not null default \'\',',
    '  detail jsonb not null default \'{}\'::jsonb',
    ');',
    'create index if not exists site_health_created_at on public.site_health (created_at desc);',
    'alter table public.site_health enable row level security;',
    'grant insert on public.site_health to anon, authenticated;',
    'grant select, delete on public.site_health to authenticated;',
    'grant select, insert, update, delete on public.site_health to service_role;',
    'drop policy if exists site_health_report on public.site_health;',
    'create policy site_health_report on public.site_health for insert to anon, authenticated',
    '  with check (char_length(page) <= 40 and char_length(kind) <= 40 and char_length(message) <= 400 and pg_column_size(detail) <= 4000);',
    'drop policy if exists site_health_staff_read on public.site_health;',
    'create policy site_health_staff_read on public.site_health for select to authenticated',
    '  using (coalesce(auth.jwt() ->> \'email\', \'\') <> \'\');',
    'drop policy if exists site_health_staff_clear on public.site_health;',
    'create policy site_health_staff_clear on public.site_health for delete to authenticated',
    '  using (coalesce(auth.jwt() ->> \'email\', \'\') <> \'\');',
    '',
    '-- d17.155: private shop settings (staff passcodes, roles, WhatsApp key) -- only signed-in staff can read them.',
    'create table if not exists public.shop_private (',
    '  id text primary key,',
    '  data jsonb not null default \'{}\'::jsonb,',
    '  updated_at timestamptz not null default now()',
    ');',
    'alter table public.shop_private enable row level security;',
    'revoke all on public.shop_private from anon;',
    'grant select, insert, update, delete on public.shop_private to authenticated;',
    'grant select, insert, update, delete on public.shop_private to service_role;',
    'drop policy if exists shop_private_staff on public.shop_private;',
    'create policy shop_private_staff on public.shop_private for all to authenticated',
    '  using (coalesce(auth.jwt() ->> \'email\', \'\') <> \'\') with check (coalesce(auth.jwt() ->> \'email\', \'\') <> \'\');',
    '',
    '-- d17.158: the chat assistant\'s answers -- customers read only APPROVED ones; signed-in staff approve, edit, reject.',
    'create table if not exists public.chat_learned (',
    '  id uuid primary key default gen_random_uuid(),',
    '  created_at timestamptz not null default now(),',
    '  updated_at timestamptz not null default now(),',
    '  qkey text not null unique,',
    '  q text not null default \'\',',
    '  a text not null default \'\',',
    '  status text not null default \'pending\',',
    '  asks integer not null default 1,',
    '  by text not null default \'\'',
    ');',
    'alter table public.chat_learned enable row level security;',
    'grant select on public.chat_learned to anon, authenticated;',
    'grant insert, update, delete on public.chat_learned to authenticated;',
    'grant select, insert, update, delete on public.chat_learned to service_role;   -- d17.160: Supabase stops giving new tables access by itself from 30 Oct 2026',
    'drop policy if exists chat_learned_read_approved on public.chat_learned;',
    'create policy chat_learned_read_approved on public.chat_learned for select to anon, authenticated using (status = \'approved\');',
    'drop policy if exists chat_learned_staff on public.chat_learned;',
    'create policy chat_learned_staff on public.chat_learned for all to authenticated',
    '  using (coalesce(auth.jwt() ->> \'email\', \'\') <> \'\') with check (coalesce(auth.jwt() ->> \'email\', \'\') <> \'\');'
  ].join('\n');


  /* ---------------- look ---------------- */
  var CSS = [
    '#panel-health{--hp-ok:#17834F;--hp-warn:#B86E00;--hp-bad:#C2352A;--hp-off:#7C879B;--hp-ink:#0F1E3D;--hp-sub:#56627A;--hp-line:#E1E7F0;--hp-bg:#F3F6FB}',
    '.hp{max-width:760px;margin:0 auto;padding:4px 0 36px;color:var(--hp-ink)}',
    '.hp-hero{border-radius:20px;padding:18px 16px 14px;color:#fff;background:linear-gradient(135deg,#102A5C,#1F4FB0);box-shadow:0 10px 30px rgba(16,42,92,.22);margin-bottom:14px}',
    '.hp-hero.ok{background:linear-gradient(135deg,#0D5B39,#1C9A5E)}.hp-hero.warn{background:linear-gradient(135deg,#7A4600,#C47F0A)}.hp-hero.bad{background:linear-gradient(135deg,#7D1A13,#CF3D2F)}',
    '.hp-hero-top{display:flex;gap:14px;align-items:flex-start}',
    '.hp-big{flex:none;width:52px;height:52px;border-radius:50%;background:rgba(255,255,255,.18);border:2px solid rgba(255,255,255,.55);display:flex;align-items:center;justify-content:center;font-size:1.6rem;font-weight:800;line-height:1}',
    '.hp-big .hp-ic{width:28px;height:28px}',
    '.hp-hero h2{margin:2px 0 4px;font-size:1.42rem;line-height:1.2;font-weight:800;letter-spacing:-.01em;font-family:Inter,system-ui,sans-serif}',
    '.hp-hero p{margin:0;font-size:.9rem;line-height:1.45;opacity:.93}',
    '.hp-bar{height:6px;border-radius:6px;background:rgba(255,255,255,.22);margin:14px 0 2px;overflow:hidden}.hp-bar i{display:block;height:100%;background:#fff;border-radius:6px;transition:width .4s}',
    '.hp-hero-foot{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-top:14px;flex-wrap:wrap}',
    '.hp-hero-foot small{font-size:.78rem;opacity:.85}',
    '.hp-run{border:0;border-radius:12px;background:#fff;color:#0F1E3D;font:800 .82rem Inter,system-ui,sans-serif;letter-spacing:.06em;padding:0 18px;min-height:46px;cursor:pointer;box-shadow:0 4px 14px rgba(0,0,0,.18)}',
    '.hp-run:disabled{opacity:.7;cursor:default}',
    '.hp-spin{width:24px;height:24px;border-radius:50%;border:3px solid rgba(255,255,255,.35);border-top-color:#fff;animation:hpspin .8s linear infinite}',
    '@keyframes hpspin{to{transform:rotate(360deg)}}',
    '.hp-prev{display:flex;gap:14px;align-items:center;background:#fff;border:1px solid var(--hp-line);border-radius:16px;padding:12px;margin-bottom:14px}',
    '.hp-prev[hidden]{display:none}',
    '.hp-prev-l{flex:1;min-width:0}.hp-prev-l b{display:block;font-size:.7rem;letter-spacing:.12em;color:var(--hp-sub);text-transform:uppercase}.hp-prev-l span{display:block;font-size:1.05rem;font-weight:700;margin:2px 0 6px}.hp-prev-l small{display:block;font-size:.78rem;color:var(--hp-sub);line-height:1.4}',
    '.hp-prev-ph{flex:none;width:136px;height:262px;border-radius:18px;overflow:hidden;border:5px solid #0F1E3D;background:#fff;position:relative}',
    '.hp-prev-fr{position:absolute;left:0;top:0;width:390px;height:752px;border:0;transform:scale(.323);transform-origin:0 0;pointer-events:none;background:#fff}',
    '.hp-hidden{position:fixed;left:0;bottom:0;width:1px;height:1px;overflow:hidden;opacity:0;pointer-events:none;z-index:-1}',
    '.hp-hidden-fr{width:360px;height:640px;border:0}',
    '.hp-sec-h{display:flex;align-items:baseline;justify-content:space-between;gap:10px;margin:22px 2px 10px}',
    '.hp-sec-h h3{margin:0;font:800 .74rem Inter,system-ui,sans-serif;letter-spacing:.14em;text-transform:uppercase;color:var(--hp-sub)}',
    '.hp-legend{font-size:.72rem;color:var(--hp-sub);display:flex;align-items:center;gap:4px;white-space:nowrap}.hp-legend i{width:8px;height:8px;border-radius:50%;display:inline-block;margin-left:6px}',
    '.hp-legend i.ok{background:var(--hp-ok)}.hp-legend i.warn{background:var(--hp-warn)}.hp-legend i.bad{background:var(--hp-bad)}',
    '.hp-link{font-size:.78rem;font-weight:700;color:#1F55C8;text-decoration:none}',
    '.hp-card,.hp-rep{background:#fff;border:1px solid var(--hp-line);border-radius:16px;margin-bottom:9px;overflow:hidden;box-shadow:0 1px 2px rgba(15,30,61,.04)}',
    '.hp-card.bad,.hp-rep.bad{border-color:#F0C3BE}.hp-card.warn,.hp-rep.warn{border-color:#F1D9AE}',
    '.hp-head,.hp-rep-h{all:unset;box-sizing:border-box;display:flex;align-items:center;gap:12px;width:100%;padding:12px 12px 12px 12px;cursor:pointer;min-height:62px}',
    '.hp-head:focus-visible,.hp-rep-h:focus-visible{outline:2px solid #1F55C8;outline-offset:-2px;border-radius:16px}',
    '.hp-ring{flex:none;width:40px;height:40px;border-radius:12px;display:flex;align-items:center;justify-content:center;background:#EEF2F8;color:var(--hp-off)}',
    '.hp-ring.ok{background:#E3F4EB;color:var(--hp-ok)}.hp-ring.warn{background:#FCF0DB;color:var(--hp-warn)}.hp-ring.bad{background:#FBE5E2;color:var(--hp-bad)}.hp-ring.run{background:#E6EDFB;color:#1F55C8}',
    '.hp-ic{width:22px;height:22px}',
    '.hp-ttl{flex:1;min-width:0}.hp-ttl b{display:block;font-size:.98rem;font-weight:700;color:var(--hp-ink);line-height:1.25}.hp-ttl small{display:block;font-size:.8rem;color:var(--hp-sub);line-height:1.35;margin-top:2px;overflow:hidden;text-overflow:ellipsis}',
    '.hp-ttl em{font-style:normal;color:var(--hp-bad);font-weight:600}',
    '.hp-pill{flex:none;font:800 .62rem Inter,system-ui,sans-serif;letter-spacing:.08em;padding:5px 8px;border-radius:999px;background:#EEF2F8;color:var(--hp-off);white-space:nowrap}',
    '.hp-pill.ok{background:#E3F4EB;color:var(--hp-ok)}.hp-pill.warn{background:#FCF0DB;color:var(--hp-warn)}.hp-pill.bad{background:var(--hp-bad);color:#fff}.hp-pill.run{background:#E6EDFB;color:#1F55C8}',
    '.hp-chev{flex:none;width:18px;height:18px;color:#9AA5B8;transition:transform .2s}.open>.hp-head .hp-chev,.open>.hp-rep-h .hp-chev{transform:rotate(180deg)}',
    '.hp-body{padding:0 14px 14px;border-top:1px solid var(--hp-line)}',
    '.hp-checks{list-style:none;margin:10px 0 0;padding:0}',
    '.hp-checks li{display:flex;gap:10px;align-items:flex-start;padding:6px 0;font-size:.88rem;line-height:1.4;color:var(--hp-ink)}',
    '.hp-checks li i{flex:none;width:20px;height:20px;border-radius:50%;display:flex;align-items:center;justify-content:center;font:800 .7rem Inter,sans-serif;font-style:normal;background:#EEF2F8;color:var(--hp-off);margin-top:1px}',
    '.hp-checks li.ok i{background:var(--hp-ok);color:#fff}.hp-checks li.warn i{background:var(--hp-warn);color:#fff}.hp-checks li.bad i{background:var(--hp-bad);color:#fff}.hp-checks li.info{color:var(--hp-sub)}',
    '.hp-fix{margin-top:10px;border-radius:12px;padding:10px 12px;background:#FFF6E6;border:1px solid #F1D9AE;font-size:.86rem;line-height:1.45}',
    '.hp-fix.bad{background:#FDEDEB;border-color:#F0C3BE}.hp-fix.off{background:#F3F6FB;border-color:var(--hp-line)}',
    '.hp-fix b{display:block;font-size:.7rem;letter-spacing:.12em;text-transform:uppercase;margin-bottom:4px}.hp-fix ol{margin:0;padding-left:18px}.hp-fix li{margin:2px 0}',
    '.hp-acts{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px}',
    '.hp-btn{display:inline-flex;align-items:center;justify-content:center;min-height:42px;padding:0 14px;border-radius:10px;border:1px solid #1F55C8;background:#1F55C8;color:#fff;font:800 .74rem Inter,system-ui,sans-serif;letter-spacing:.06em;text-decoration:none;cursor:pointer}',
    '.hp-btn.hp-line{background:#fff;color:#1F55C8}.hp-btn.hp-danger{border-color:#C2352A;color:#C2352A}',
    '.hp-muted{color:var(--hp-sub);font-size:.84rem;line-height:1.45;margin:10px 0 0}.hp-pad{padding:0 2px}',
    '.hp-chips{display:flex;gap:8px;margin:0 0 10px;flex-wrap:wrap}',
    '.hp-chip{border:1px solid var(--hp-line);background:#fff;border-radius:999px;padding:0 14px;min-height:36px;font:700 .8rem Inter,system-ui,sans-serif;color:var(--hp-sub);cursor:pointer}.hp-chip.on{background:#0F1E3D;border-color:#0F1E3D;color:#fff}',
    '.hp-n{flex:none;min-width:40px;height:40px;border-radius:12px;display:flex;align-items:center;justify-content:center;font:800 .9rem Inter,sans-serif;background:#FCF0DB;color:var(--hp-warn)}',
    '.hp-rep.bad .hp-n{background:#FBE5E2;color:var(--hp-bad)}.hp-rep.info .hp-n{background:#EEF2F8;color:var(--hp-off)}',
    '.hp-msg{margin:10px 0 0;font:500 .82rem ui-monospace,Menlo,Consolas,monospace;background:#F3F6FB;border-radius:10px;padding:8px 10px;word-break:break-word;color:var(--hp-ink)}',
    '.hp-empty{display:flex;flex-direction:column;align-items:center;gap:4px;text-align:center;background:#fff;border:1px dashed #C9D3E3;border-radius:16px;padding:18px 14px;color:var(--hp-sub);font-size:.86rem}',
    '.hp-empty .hp-ic{width:30px;height:30px;color:var(--hp-ok)}.hp-empty b{color:var(--hp-ink);font-size:.95rem}',
    '.hp-setup{background:#fff;border:1px solid #BFD0F2;border-radius:16px;padding:14px;font-size:.88rem;line-height:1.5}',
    '.hp-setup>b{display:block;font-size:1rem;margin-bottom:4px}.hp-setup p{margin:0 0 6px;color:var(--hp-sub)}.hp-setup ol{margin:6px 0 0;padding-left:20px}.hp-setup li{margin:4px 0}',
    '.hp-setup details{margin-top:12px}.hp-setup summary{cursor:pointer;font-weight:700;color:#1F55C8;font-size:.84rem}',
    '.hp-sql{white-space:pre-wrap;word-break:break-word;font:500 .72rem ui-monospace,Menlo,Consolas,monospace;background:#0F1E3D;color:#D9E4FF;border-radius:10px;padding:10px;margin:8px 0 0;max-height:240px;overflow:auto}',
    '.hp-data{background:#fff;border:1px solid var(--hp-line);border-radius:14px;padding:11px 12px;margin-bottom:8px}',
    '.hp-data.bad{border-color:#F0C3BE}.hp-data.warn{border-color:#F1D9AE}',
    '.hp-data>b{display:flex;gap:9px;align-items:center;font-size:.92rem}.hp-data>b i{flex:none;width:20px;height:20px;border-radius:50%;display:flex;align-items:center;justify-content:center;font:800 .7rem Inter,sans-serif;font-style:normal;background:#EEF2F8;color:var(--hp-off)}',
    '.hp-data.ok>b i{background:var(--hp-ok);color:#fff}.hp-data.warn>b i{background:var(--hp-warn);color:#fff}.hp-data.bad>b i{background:var(--hp-bad);color:#fff}',
    '.hp-data p{margin:6px 0 0 29px;font-size:.83rem;line-height:1.5;color:var(--hp-sub);word-break:break-word}.hp-data code{background:#EEF2F8;border-radius:4px;padding:0 4px;font-size:.92em}',
    '.hp-fine{all:unset;box-sizing:border-box;display:block;width:100%;text-align:center;padding:12px;border-radius:14px;border:1px dashed #C9D3E3;color:var(--hp-ok);font:700 .85rem Inter,system-ui,sans-serif;cursor:pointer;margin-bottom:8px;background:#fff}',
    '.hp-quick{display:flex;gap:8px;flex-wrap:wrap;padding:0 12px 12px 64px;margin-top:-4px}.hp-quick .hp-btn{min-height:38px;font-size:.7rem}',
    '.hp-copyall{display:block;width:100%;margin-top:12px;min-height:48px;border-radius:12px;border:2px solid #fff;background:rgba(255,255,255,.12);color:#fff;font:800 .82rem Inter,system-ui,sans-serif;letter-spacing:.06em;cursor:pointer}',
    '.hp-copyhint{display:block;font-size:.76rem;opacity:.85;margin-top:6px;text-align:center}',
    '.hp-wide{width:100%;min-height:50px}',
    '.hp-wa{margin-top:14px;border-top:1px dashed var(--hp-line);padding-top:12px}.hp-wa>b{display:block;font-size:.95rem}.hp-wa label{display:block;font-size:.78rem;font-weight:700;color:var(--hp-sub);margin:10px 0 4px}',
    '.hp-wa-row{display:flex;gap:8px}.hp-wa-row input{flex:1;min-width:0;min-height:44px;border:1px solid #C9D3E3;border-radius:10px;padding:0 12px;font:600 1rem Inter,system-ui,sans-serif;color:var(--hp-ink)}',
    '.hp-wa a{color:#1F55C8;word-break:break-all}.hp-fix.ok{background:#E3F4EB;border-color:#BFE3CF}',
    '.hp-foot{font-size:.76rem;color:var(--hp-sub);text-align:center;margin:20px 8px 0;line-height:1.5}',
    '@media (max-width:360px){.hp-pill{display:none}.hp-prev-ph{width:112px;height:216px}.hp-prev-fr{transform:scale(.262)}.hp-hero h2{font-size:1.25rem}}'
  ].join('\n');
  (function addCss() { if (document.getElementById('hpCss')) return; var st = document.createElement('style'); st.id = 'hpCss'; st.textContent = CSS; (document.head || document.documentElement).appendChild(st); })();

  /* ---------------- small helpers ---------------- */
  var $ = function (id) { return document.getElementById(id); };
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  function secs(ms) { return (ms / 1000).toFixed(1) + ' s'; }
  function rupees(n) { return '₹' + Number(n || 0).toLocaleString('en-IN'); }
  function ago(iso) {
    var m = Math.round((Date.now() - new Date(iso).getTime()) / 60000);
    if (!(m >= 0)) return '';
    if (m < 1) return 'just now'; if (m < 60) return m + ' min ago';
    var h = Math.round(m / 60); if (h < 24) return h + ' h ago';
    var d = Math.round(h / 24); return d + (d === 1 ? ' day ago' : ' days ago');
  }
  function clock(d) { try { return new Date(d).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' }); } catch (e) { return ''; } }
  function worst(a, b) { var o = { bad: 4, warn: 3, ok: 2, off: 1, skip: 0 }; return (o[a] || 0) >= (o[b] || 0) ? a : b; }
  function withTimeout(p, ms, what) { return Promise.race([p, new Promise(function (_, j) { setTimeout(function () { j(new Error((what || 'It') + ' did not answer within ' + Math.round(ms / 1000) + ' seconds')); }, ms); })]); }
  async function token() { try { return g.VGAuth ? await g.VGAuth.token() : null; } catch (e) { return null; } }
  async function sb(path, opts) {
    opts = opts || {}; var c = cfg();
    var h = { apikey: c.key, 'Content-Type': 'application/json' };
    var t = opts.anon ? null : await token();
    if (t) h.Authorization = 'Bearer ' + t; else if (isJwt(c.key)) h.Authorization = 'Bearer ' + c.key;
    if (opts.headers) for (var k in opts.headers) h[k] = opts.headers[k];
    var t0 = performance.now();
    var res = await withTimeout(fetch(c.url + path, { method: opts.method || 'GET', headers: h, body: opts.body, cache: 'no-store' }), opts.timeout || 15000, 'The database');
    var body = null; try { body = await res.json(); } catch (e) {}
    return { ok: res.ok, status: res.status, body: body, ms: Math.round(performance.now() - t0) };
  }
  function why(r) { var b = r && r.body; return (b && (b.message || b.msg || b.error_description || b.error || b.hint)) || ('error ' + (r && r.status)); }
  function pageProto() { return g.__VG_PAGE_PROTO || location.protocol; }   /* tests run on http://localhost and say https here */
  function adminSet() { try { return typeof SET !== 'undefined' ? SET : {}; } catch (e) { return {}; } }
  function canDo(p) { try { return typeof can === 'function' ? can(p) : true; } catch (e) { return true; } }
  function copy(text, btn) {
    var done = function () { if (btn) { var t = btn.textContent; btn.textContent = 'COPIED ✓'; setTimeout(function () { btn.textContent = t; }, 1800); } };
    try { if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(text).then(done, fallback); return; } } catch (e) {}
    fallback();
    function fallback() { var ta = document.createElement('textarea'); ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0'; document.body.appendChild(ta); ta.select(); try { document.execCommand('copy'); } catch (e) {} ta.remove(); done(); }
  }
  /* the old check page is our own, but what it shows can include product names -- keep only simple formatting */
  function clean(html) {
    var d = new DOMParser().parseFromString('<div>' + String(html || '') + '</div>', 'text/html').body.firstChild;
    var OK = { B: 1, STRONG: 1, CODE: 1, BR: 1, SMALL: 1, I: 1, EM: 1, A: 1 };
    (function walk(n) {
      [].slice.call(n.childNodes).forEach(function (c) {
        if (c.nodeType === 1) {
          if (!OK[c.tagName]) { walk(c); while (c.firstChild) c.parentNode.insertBefore(c.firstChild, c); c.remove(); return; }
          [].slice.call(c.attributes).forEach(function (a) { if (!(c.tagName === 'A' && a.name === 'href' && /^(https?:|[a-z0-9_-]+\.html)/i.test(a.value))) c.removeAttribute(a.name); });
          if (c.tagName === 'A') { c.setAttribute('target', '_blank'); c.setAttribute('rel', 'noopener'); }
          walk(c);
        } else if (c.nodeType !== 3) c.remove();
      });
    })(d);
    return d.innerHTML;
  }

  /* ---------------- what each kind of customer problem means ---------------- */
  var KIND = {
    'script':       { t: 'The page hit a program error', fix: 'This needs a fix in the website code. Tap COPY and send it for fixing.', sev: 'warn' },
    'file':         { t: 'A program file did not load', fix: 'Usually an incomplete upload. Upload the latest build again. If it keeps happening, tap COPY and send it for fixing.', sev: 'warn' },
    'photo':        { t: 'A picture did not load', fix: 'Open that frame in PRODUCTS → EDIT and upload the photo again. If many photos fail at the same time, the photo storage (Cloudinary) may be down.', sev: 'warn' },
    'database':     { t: 'Frames or settings could not be loaded from the database', fix: 'If it is one or two customers, it is their internet. If many: open supabase.com and check your project is running (a paused project shows a RESTORE button).', sev: 'warn' },
    'order':        { t: 'An order could not be saved', fix: 'The order stays on the customer’s phone and is sent again when they next open the site. If you see this more than once, tap COPY and send it for fixing.', sev: 'bad' },
    'prescription': { t: 'A prescription could not be saved to its order', fix: 'Ask the customer to send the prescription photo on WhatsApp. Tap COPY and send it for fixing so the cause can be fixed.', sev: 'bad' },
    'otp':          { t: 'My Orders: the OTP could not be sent', fix: 'Open supabase.com → Authentication → Sign In / Providers → Phone: the SMS provider must be switched on and have credit.', sev: 'bad' },
    'tryon-net':    { t: 'Try-on could not start (the face finder did not load)', fix: 'One customer: slow internet. Many customers: the face-finder service may be down — tap COPY and send it for fixing.', sev: 'bad' },
    'tryon-stuck':  { t: 'Try-on camera opened but showed no picture', fix: 'Usually that phone’s camera. If many customers: tap COPY and send it for fixing.', sev: 'warn' },
    'tryon-frame':  { t: 'A frame’s try-on picture did not load', fix: 'Open that frame in PRODUCTS or TO CHECK and cut / upload its try-on picture again.', sev: 'bad' },
    'tryon-busy':   { t: 'Camera busy (the customer was on a call)', fix: 'Nothing to do — the customer’s side.', info: true },
    'tryon-nocam':  { t: 'No live camera — the customer used the photo try-on', fix: 'Nothing to do — the customer did not allow the camera, or their app has none.', info: true },
    'server':       { t: 'The website server answered with an error', fix: 'Usually a short hiccup at Vercel. If it repeats, open Vercel \u2192 your project \u2192 Logs, or tap COPY and send it for fixing.', sev: 'bad' },
    'notfound':     { t: 'A customer opened a page that does not exist (404)', fix: 'Check where that link was shared (an old WhatsApp message or ad?) and share the right one: Admin \u2192 VISITORS \u2192 MAKE A LINK.', sev: 'warn' },
    'login':        { t: 'Admin sign-in failed', fix: 'One or two: a typing mistake. Many in a row: someone may be guessing \u2014 change the passcodes in Staff & Roles.', sev: 'warn' },
    'slow':         { t: 'A page was slow to open', fix: 'One or two: the customer’s internet. If this is frequent, tap COPY and send it for fixing.', info: true }
  };
  function kindOf(r) {
    var k = KIND[r.kind] || (/^tryon-/.test(r.kind) ? KIND['tryon-stuck'] : KIND.script);
    var info = (r.detail && r.detail.level === 'info') || k.info;
    var t = k.t; if (r.kind === 'database' && info) t = 'A customer could not reach the database (usually their internet)';
    return { t: t, fix: k.fix, sev: info ? 'info' : k.sev, info: !!info };
  }
  function cardOf(r) {
    var k = r.kind || '';
    if (/^tryon/.test(k)) return 'tryon';
    if (k === 'otp') return 'myorders';
    if (k === 'order') return 'checkout';
    if (k === 'prescription') return r.page === 'myorders' ? 'myorders' : 'prescription';
    if (k === 'login') return 'admin';
    return { home: 'home', frame: 'frame', checkout: 'checkout', prescription: 'prescription', myorders: 'myorders', pd: 'tryon', admin: 'admin' }[r.page] || 'other';
  }
  var PAGE_NAME = { home: 'Home page', frame: 'Frame page', tryon: 'Try-on', checkout: 'Checkout', prescription: 'Prescription', myorders: 'My Orders', admin: 'Admin', other: 'Other pages', pd: 'PD guide', check: 'Check page' };

  /* ---------------- icons ---------------- */
  var I = {
    home: '<path d="M3 11l9-7 9 7"/><path d="M5 10v10h14V10"/><path d="M10 20v-6h4v6"/>',
    frame: '<circle cx="6.5" cy="14" r="3.5"/><circle cx="17.5" cy="14" r="3.5"/><path d="M10 14h4M3 13l1.5-5M21 13l-1.5-5"/>',
    tryon: '<path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>',
    checkout: '<path d="M3 4h2l2.4 11h11L21 7H6.2"/><circle cx="9" cy="19.5" r="1.4"/><circle cx="17" cy="19.5" r="1.4"/>',
    prescription: '<path d="M6 3h9l4 4v14H6z"/><path d="M14 3v5h5M9 12h7M9 16h7"/>',
    myorders: '<circle cx="12" cy="8" r="4"/><path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"/>',
    admin: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1"/>',
    database: '<ellipse cx="12" cy="5.5" rx="7.5" ry="2.8"/><path d="M4.5 5.5v13c0 1.5 3.4 2.8 7.5 2.8s7.5-1.3 7.5-2.8v-13M4.5 12c0 1.5 3.4 2.8 7.5 2.8s7.5-1.3 7.5-2.8"/>',
    reports: '<path d="M12 3l8 3v6c0 4.5-3.4 8-8 9-4.6-1-8-4.5-8-9V6z"/><path d="M12 8v5M12 16v.5"/>',
    robot: '<rect x="5" y="8" width="14" height="11" rx="2"/><path d="M12 4v4M9 13h.01M15 13h.01M9.5 16.5h5"/>',
    whatsapp: '<path d="M4 20l1.3-4A8 8 0 1 1 8 19z"/><path d="M9 9.5c.3 2.5 2.5 4.7 5 5l1.3-1.3-2-1-1 .8a5 5 0 0 1-2-2l.8-1-1-2z"/>',
    otp: '<rect x="7" y="2.5" width="10" height="19" rx="2"/><path d="M10 6h4M11 18h2"/>',
    version: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 2.7 3.8 5.7 3.8 9s-1.3 6.3-3.8 9c-2.5-2.7-3.8-5.7-3.8-9S9.5 5.7 12 3z"/>',
    data: '<path d="M4 6h16M4 12h16M4 18h10"/>',
    chev: '<path d="M8 10l4 4 4-4"/>'
  };
  function icon(n, cls) { return '<svg class="' + (cls || 'hp-ic') + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (I[n] || I.data) + '</svg>'; }
  var PILL = { ok: 'WORKING', warn: 'NEEDS A LOOK', bad: 'PROBLEM', off: 'NOT SET UP', skip: 'NOT TESTED', run: 'TESTING…', wait: 'WAITING' };
  var MARK = { ok: '✓', warn: '!', bad: '✕', off: '–', skip: '–', info: 'i' };

  /* ---------------- the result ---------------- */
  var ITEMS = [
    ['home', 'pages', 'Home page', 'home'], ['frame', 'pages', 'Frame page', 'frame'], ['tryon', 'pages', 'Try-on', 'tryon'],
    ['checkout', 'pages', 'Checkout', 'checkout'], ['prescription', 'pages', 'Prescription', 'prescription'], ['myorders', 'pages', 'My Orders', 'myorders'],
    ['admin', 'pages', 'Admin', 'admin'],
    ['database', 'services', 'Database', 'database'], ['privacy', 'services', 'Private details (passcodes, keys)', 'reports'],
    ['reports', 'services', 'Problem reports from customers’ phones', 'reports'],
    ['robot', 'services', 'Cut-out robot', 'robot'], ['whatsapp', 'services', 'WhatsApp sender', 'whatsapp'], ['server', 'services', 'WhatsApp computer (space)', 'database'], ['watch', 'services', 'Watchman (automatic alerts)', 'version'],
    ['upi', 'services', 'Automatic UPI confirmation', 'otp'], ['chat', 'services', 'Chat assistant', 'whatsapp'], ['analytics', 'services', 'Visitor analytics (PostHog)', 'data'],
    ['version', 'services', 'Website version', 'version']
  ];
  var R = null;
  function fresh() {
    var o = { at: null, ms: 0, running: false, step: '', done: 0, total: 0, items: {}, data: [], dataState: 'skip', reports: null, reportsWhy: '', period: 24, open: {} };
    ITEMS.forEach(function (x) { o.items[x[0]] = { id: x[0], group: x[1], name: x[2], icon: x[3], state: 'wait', line: 'Waiting…', checks: [], fix: [], link: '', tech: '' }; });
    return o;
  }
  function item(id) { return R.items[id]; }
  function check(it, s, text, fix) { it.checks.push({ s: s, t: text }); if (fix && (s === 'bad' || s === 'warn') && it.fix.indexOf(fix) < 0) it.fix.push(fix); }
  function settle(it, line) { var s = 'ok'; it.checks.forEach(function (c) { if (c.s !== 'info') s = worst(s, c.s); }); if (!it.checks.length) s = 'skip'; it.state = s; if (line) it.line = line; }

  /* ---------------- open a page as a customer's phone does ---------------- */
  function openPage(url, ready, timeout, hidden) {
    return new Promise(function (resolve) {
      var host = hidden ? $('hpHidden') : $('hpPrevBox');
      if (!host) { resolve({ why: 'gone' }); return; }
      host.innerHTML = '';
      var fr = document.createElement('iframe');
      fr.title = 'Page under test'; fr.setAttribute('aria-hidden', 'true'); fr.tabIndex = -1;
      fr.className = hidden ? 'hp-hidden-fr' : 'hp-prev-fr';
      host.appendChild(fr);
      var t0 = performance.now(), loaded = false, done = false;
      fr.addEventListener('load', function () { loaded = true; });
      function finish(w) {
        if (done) return; done = true; clearInterval(iv); clearTimeout(to);
        var win = null, doc = null; try { win = fr.contentWindow; doc = fr.contentDocument; } catch (e) {}
        resolve({ fr: fr, win: win, doc: doc, why: w, ms: Math.round(performance.now() - t0), loaded: loaded });
      }
      var iv = setInterval(function () {
        var doc = null, win = null;
        try { doc = fr.contentDocument; win = fr.contentWindow; } catch (e) { finish('blocked'); return; }
        if (loaded && !doc) { finish('blocked'); return; }
        if (!doc || !win || doc.URL === 'about:blank') return;
        try { if (ready(win, doc)) finish('ready'); } catch (e) {}
      }, 200);
      var to = setTimeout(function () { finish('timeout'); }, timeout);
      fr.src = url + (url.indexOf('?') >= 0 ? '&' : '?') + 'vgtest=1';
    });
  }
  function logOf(r) { try { return (r.win && r.win.__vgHealthLog) ? r.win.__vgHealthLog.slice() : []; } catch (e) { return []; } }
  function visible(doc, sel) { var e = doc.querySelector(sel); if (!e) return false; var cs = doc.defaultView.getComputedStyle(e); var b = e.getBoundingClientRect(); return cs.display !== 'none' && cs.visibility !== 'hidden' && b.width > 0 && b.height > 0; }
  function brokenIn(doc, sel) { return [].slice.call(doc.querySelectorAll(sel)).filter(function (i) { return i.complete && i.naturalWidth === 0 && (i.currentSrc || i.src) && !/^data:/.test(i.src); }); }
  /* common to every page: could it open, how long, any program error while it opened */
  function basics(it, r, readyLabel) {
    if (r.why === 'blocked' || !r.doc) {
      check(it, 'bad', 'The page could not be opened', 'Upload the latest build again. If this stays red, the website’s security setting is blocking the test — tap COPY and send it for fixing.');
      return false;
    }
    var errs = logOf(r).filter(function (x) { return (x.kind === 'script' || x.kind === 'file') && !(x.detail && x.detail.level === 'info'); });
    errs.slice(0, 3).forEach(function (x) { check(it, 'warn', 'Program error while the page opened: ' + x.message + (x.detail && x.detail.src ? ' (' + x.detail.src + (x.detail.line ? ':' + x.detail.line : '') + ')' : ''), KIND.script.fix); });
    if (errs.length) it.tech += errs.map(function (x) { return x.kind + ': ' + x.message + ' @ ' + (x.detail && x.detail.src) + ':' + (x.detail && x.detail.line); }).join('\n') + '\n';
    if (r.why === 'timeout') check(it, 'bad', readyLabel + ' — not ready after ' + secs(r.ms), null);
    else if (r.ms > 6000) check(it, 'warn', 'Slow: took ' + secs(r.ms) + ' to be ready', 'Check on mobile data too. If it is always slow, tap COPY and send it for fixing.');
    else check(it, 'ok', 'Ready in ' + secs(r.ms), null);
    return true;
  }

  var CTX = { frameId: '', frameName: '', framePage: null };

  async function testHome() {
    var it = item('home'); it.link = 'index.html';
    var r = await openPage('index.html', function (w, d) { return d.readyState === 'complete' && d.querySelectorAll('.gal-item').length > 0; }, 20000);
    if (r.why === 'ready') await sleep(900);
    if (!basics(it, r, 'Frames did not appear')) return settle(it, 'Could not open');
    var d = r.doc, cards = [].slice.call(d.querySelectorAll('.gal-item'));
    /* d17.155: a frame can sit on several shelves -- count each frame once */
    var ids = {}; cards.forEach(function (c, i) { var b = c.querySelector('[data-add]'), a = c.querySelector('a[href*="id="]');
      var id = (b && b.getAttribute('data-add')) || (a && (/[?&]id=([^&]+)/.exec(a.getAttribute('href')) || [])[1]) || ('card' + i); ids[id] = 1; });
    var nFrames = Object.keys(ids).length;
    if (cards.length) check(it, 'ok', nFrames + ' frame' + (nFrames === 1 ? '' : 's') + ' showing' + (cards.length > nFrames ? ' (' + cards.length + ' cards across the shelves)' : ''), null);
    else check(it, 'bad', 'No frames are showing on the home page', 'See SHOP DATA below: a frame shows only when it is ticked “Show on the website” and approved in TO CHECK. If the Database line is red, fix that first.');
    if (cards.length) {
      var priced = cards.filter(function (c) { return /₹\s?[\d,]+/.test(c.textContent); }).length;
      if (priced >= Math.ceil(cards.length * 0.8)) check(it, 'ok', 'Prices showing on the frame cards', null);
      else check(it, 'warn', (cards.length - priced) + ' frame cards show no price', 'Open those frames in PRODUCTS → EDIT and type a price.');
      var broken = brokenIn(d, '.gal-item img');
      if (!broken.length) check(it, 'ok', 'Frame photos load', null);
      else check(it, 'warn', broken.length + ' frame photo' + (broken.length > 1 ? 's do' : ' does') + ' not load: ' + broken.slice(0, 4).map(function (i) { var c = i.closest('.gal-item'); return c ? (c.querySelector('h3,b,.gal-name') || c).textContent.trim().slice(0, 30) : ''; }).join(', '), KIND.photo.fix);
    }
    var offer = d.querySelector('.hero-offer');
    if (offer) { if (/₹\s?[\d,]+/.test(offer.textContent)) check(it, 'ok', '1+1 offer box shows prices', null); else check(it, 'warn', 'The 1+1 offer box shows no price', 'Open Settings → 1+1 offer, check the prices and SAVE.'); }
    /* a frame to test the next pages with: the first one a customer sees */
    var add = d.querySelector('[data-add]'), a = d.querySelector('a[href*="product.html?id="]');
    CTX.frameId = (add && add.getAttribute('data-add')) || (a && (/id=([^&]+)/.exec(a.getAttribute('href')) || [])[1]) || '';
    try { CTX.frameId = decodeURIComponent(CTX.frameId); } catch (e) {}
    settle(it, cards.length ? nFrames + ' frame' + (nFrames === 1 ? '' : 's') + ' · ready in ' + secs(r.ms) : 'No frames showing');
  }

  async function findFrame() {
    if (CTX.frameId) return CTX.frameId;
    try { var s = await withTimeout(g.VGSync.searchProducts({ pageSize: 1 }), 12000, 'The database'); if (s && s.rows && s.rows[0]) CTX.frameId = s.rows[0].id; } catch (e) {}
    return CTX.frameId;
  }

  async function testFrame() {
    var it = item('frame'), id = await findFrame();
    if (!id) { check(it, 'warn', 'No frame on the website to test with', 'Add a frame and approve it in TO CHECK, then run the check again.'); return settle(it, 'No frame to test'); }
    it.link = 'product.html?id=' + encodeURIComponent(id);
    var r = await openPage('product.html?id=' + encodeURIComponent(id), function (w, d) { var n = d.getElementById('pName'), im = d.getElementById('mainImg'); return d.readyState === 'complete' && n && n.textContent.trim() && n.textContent.trim() !== 'Frame' && im && im.complete && (im.currentSrc || im.src); }, 20000);
    if (r.why === 'ready') await sleep(500);
    if (!basics(it, r, 'The frame did not appear')) return settle(it, 'Could not open');
    var d = r.doc, nm = (d.getElementById('pName') || {}).textContent || '';
    CTX.frameName = nm.trim();
    if (nm.trim() && nm.trim() !== 'Frame') check(it, 'ok', 'Frame shows: ' + nm.trim().slice(0, 40), null); else check(it, 'bad', 'The frame’s details did not appear', 'Check the Database line. If it is green, tap COPY and send it for fixing.');
    var im = d.getElementById('mainImg');
    if (im && im.complete && im.naturalWidth > 0) check(it, 'ok', 'Main photo loads', null); else check(it, 'bad', 'The main photo does not load', KIND.photo.fix);
    var pr = (d.getElementById('pPrice') || {}).textContent || '';
    if (/\d/.test(pr)) check(it, 'ok', 'Price shows: ' + pr.trim().slice(0, 30), null); else check(it, 'bad', 'No price on the frame page', 'Open the frame in PRODUCTS → EDIT and type a price.');
    if (visible(d, '#actTry')) check(it, 'ok', '“See it on me” try-on button is there', null); else check(it, 'warn', 'The try-on button is missing', 'The frame needs its try-on picture (TO CHECK). If it has one, tap COPY and send it for fixing.');
    if (visible(d, '#ctaBuild') || visible(d, '#ctaAdd')) check(it, 'ok', 'Buy buttons are there', null); else check(it, 'bad', 'No button to buy the frame', 'Tap COPY and send it for fixing.');
    CTX.framePage = { tryBtn: visible(d, '#actTry'), engine: !!(r.win && r.win.VGLive && r.win.VGOnFace) };
    settle(it, (nm.trim() || id) + ' · ready in ' + secs(r.ms));
  }

  function pick(doc, win, fn) {
    var inputs = [].slice.call(doc.querySelectorAll('#lensTypes input'));
    var i = inputs.find(fn); if (!i) return false;
    i.checked = true; i.dispatchEvent(new win.Event('change', { bubbles: true })); return true;
  }
  async function testCheckout() {
    var it = item('checkout'), id = await findFrame();
    if (!id) { check(it, 'warn', 'No frame on the website to test with', 'Add a frame and approve it in TO CHECK.'); return settle(it, 'No frame to test'); }
    it.link = 'order.html?id=' + encodeURIComponent(id);
    var r = await openPage('order.html?id=' + encodeURIComponent(id), function (w, d) { return d.readyState === 'complete' && d.querySelectorAll('#lensTypes input').length > 0; }, 20000);
    if (r.why === 'ready') await sleep(1200);
    if (!basics(it, r, 'The lens choices did not appear')) return settle(it, 'Could not open');
    var d = r.doc, w = r.win;
    var fr = ''; try { fr = String(new w.Function('return typeof O !== "undefined" && O ? O.frame : ""')() || '').trim(); } catch (e) {}   /* O is the checkout\'s own order (a const, so not on window) */
    if (fr && !/^(Selected frame|Own frame)$/.test(fr)) check(it, 'ok', 'The frame is in the checkout: ' + fr.slice(0, 40), null);
    else check(it, 'warn', 'The chosen frame did not reach the checkout', 'Tap COPY and send it for fixing.');
    var types = d.querySelectorAll('#lensTypes input').length;
    if (types) check(it, 'ok', types + ' power types to choose from', null); else check(it, 'bad', 'No power types to choose from', 'Tap COPY and send it for fixing.');
    var T = null; try { if (typeof offerTiers === 'function') T = offerTiers(); } catch (e) {}
    var lines = [];
    async function level(label, fn, kind) {
      if (!pick(d, w, fn)) { check(it, 'warn', label + ': not offered', null); return; }
      await sleep(500);
      var cards = [].slice.call(d.querySelectorAll('#lensPackages .lens-card'));
      var pk = []; try { pk = w.packageData ? w.packageData() : []; } catch (e) {}
      if (!cards.length) { check(it, 'bad', label + ': no lenses to choose from', 'Open LENSES & BRANDS and Settings → 1+1 offer, check the lenses and prices, and SAVE.'); return; }
      var priced = cards.filter(function (c) { return /₹\s?[1-9][\d,]*|Included/.test(c.textContent); }).length;
      if (priced === cards.length) check(it, 'ok', label + ': ' + cards.length + ' lens choices, all priced', null);
      else check(it, 'bad', label + ': ' + (cards.length - priced) + ' lens choice(s) show no price', 'Open Settings → 1+1 offer (or LENSES & BRANDS), type the missing prices and SAVE.');
      /* the prices a customer sees must be the ones in Settings */
      if (T && T[kind]) {
        var wrong = [];
        T[kind].forEach(function (t, i) {
          if (!t.on) return;
          var p = pk.find(function (x) { return x.id === 'tier-' + kind + '-' + i; });
          if (p && Number(p.offerPrice) !== Number(t.price)) wrong.push(t.name + ': customers see ' + rupees(p.offerPrice) + ', Settings says ' + rupees(t.price));
          if (p) lines.push(t.name + ' ' + rupees(p.offerPrice));
        });
        if (wrong.length) check(it, 'bad', label + ': prices differ from Settings — ' + wrong.join('; '), 'Open Settings → 1+1 offer and tap SAVE so the website gets your prices. If it stays red, tap COPY and send it for fixing.');
        else if (pk.some(function (x) { return /^tier-/.test(x.id); })) check(it, 'ok', label + ': prices match your Settings', null);
      }
    }
    await level('Single vision', function (i) { return i.value === 'powered'; }, 'sv');
    await level('Progressive', function (i) { return i.value === 'progressive'; }, 'prog');
    it.tech += 'prices seen: ' + lines.join(', ') + '\n';
    check(it, 'info', 'Nothing was ordered — the test stops before payment', null);
    settle(it, types + ' power types · lens prices ' + (it.checks.some(function (c) { return /differ/.test(c.t); }) ? 'DIFFER' : 'checked'));
  }

  async function testPrescription() {
    var it = item('prescription'); it.link = 'prescription.html';
    var r = await openPage('prescription.html', function (w, d) { return d.readyState === 'complete' && d.getElementById('submitBtn') && d.getElementById('odSph'); }, 15000);
    if (!basics(it, r, 'The form did not appear')) return settle(it, 'Could not open');
    var d = r.doc;
    if (d.getElementById('odSph') && d.getElementById('osSph')) check(it, 'ok', 'Power boxes for both eyes are there', null); else check(it, 'bad', 'The power boxes are missing', 'Tap COPY and send it for fixing.');
    if (d.getElementById('rxFile')) check(it, 'ok', 'Prescription photo upload is there', null); else check(it, 'warn', 'The photo upload is missing', 'Tap COPY and send it for fixing.');
    var st = d.querySelectorAll('#cStore option').length;
    if (st > 1) check(it, 'ok', st + ' shop choices in the list', null); else check(it, 'warn', 'The list of shops is empty', 'Open Settings, check the shop list and SAVE.');
    settle(it, 'Form ready in ' + secs(r.ms));
  }

  async function testMyOrders() {
    var it = item('myorders'); it.link = 'account.html';
    var r = await openPage('account.html', function (w, d) { return d.readyState === 'complete' && d.getElementById('waBtn'); }, 15000);
    if (!basics(it, r, 'The page did not appear')) return settle(it, 'Could not open');
    var d = r.doc;
    if (d.getElementById('phone') && d.getElementById('waBtn') && d.getElementById('callBtn')) check(it, 'ok', 'Mobile number box, WhatsApp and Call buttons are there (no OTP)', null);
    else check(it, 'bad', 'The My Orders buttons are missing', 'Tap COPY and send it for fixing.');
    var cap = null; try { var res = await withTimeout(fetch('/api/order-details?check=1', { cache: 'no-store' }), 10000, 'The website'); if (res.ok) cap = await res.json(); } catch (e) {}
    if (cap && cap.whatsapp) check(it, 'ok', 'Order details are sent automatically on WhatsApp', null);
    else check(it, 'warn', 'Order details are not sent automatically yet — the WhatsApp button opens a chat with the shop instead', 'Add the website settings in Vercel (the setup guide): SUPABASE_SERVICE_KEY, SENDER_URL, SENDER_KEY. Then deploy again.');
    if (cap && cap.email) check(it, 'ok', 'Order details by e-mail are switched on', null);
    else check(it, 'info', 'E-mail option is hidden until e-mail is set up (RESEND_KEY, MAIL_FROM)', null);
    check(it, 'info', 'Nothing was sent by this test', null);
    settle(it, 'Ready in ' + secs(r.ms));
  }

  async function testAdmin() {
    var it = item('admin');
    var signed = !!(g.VGAuth && g.VGAuth.signedIn && g.VGAuth.signedIn());
    if (signed) check(it, 'ok', 'Signed in to your shop account', null);
    else check(it, 'bad', 'Not signed in to your shop account — changes stay on this phone only', 'Tap SIGN OUT at the top, then sign in with your shop email.');
    if (signed && g.VGSync && g.VGSync.saveSetting) {
      try {
        var who = (typeof ME !== 'undefined' && ME) ? ME.name : '';
        var s = await withTimeout(g.VGSync.saveSetting('health_ping', { at: new Date().toISOString(), by: who }), 15000, 'The database');
        if (s && s.ok) check(it, 'ok', 'Admin can save to the database', null);
        else check(it, 'bad', 'Admin cannot save: ' + ((s && s.message) || 'refused'), 'Sign out and sign in again. If it stays red, tap COPY and send it for fixing.');
      } catch (e) { check(it, 'bad', 'Admin cannot save: ' + e.message, 'Check your internet, then run the check again.'); }
    }
    try {
      var own = (typeof STAFF !== 'undefined' ? STAFF : []).find(function (x) { return x.id === 'owner'; });
      if (own && own.pass === 'vg2026') check(it, 'warn', 'The Owner passcode is still the starting one (vg2026)', 'Open STAFF & ROLES and change the Owner passcode, so nobody else can open Admin.');
      else if (own) check(it, 'ok', 'The Owner passcode has been changed', null);
    } catch (e) {}
    var chk = $('chkBadge'), rej = $('rejBadge');
    var nChk = chk && !chk.hidden ? Number(chk.textContent) || 0 : 0, nRej = rej && !rej.hidden ? Number(rej.textContent) || 0 : 0;
    if (nChk) check(it, 'info', nChk + ' frame' + (nChk > 1 ? 's' : '') + ' waiting for you in TO CHECK (not on the website yet)', null);
    if (nRej) check(it, 'info', nRej + ' frame' + (nRej > 1 ? 's' : '') + ' in REJECTED need a new photo', null);
    settle(it, signed ? 'Signed in' : 'Not signed in');
  }

  /* ---------------- services ---------------- */
  async function svcDatabase() {
    var it = item('database');
    try {
      var r = await sb('/rest/v1/products?select=id&p_visible=is.true&limit=1', { anon: true });
      if (r.ok) {
        check(it, 'ok', 'Customers can see the frames (answered in ' + r.ms + ' ms)', null);
        if (r.ms > 3000) check(it, 'warn', 'The database is slow (' + secs(r.ms) + ')', 'Run the check again in a few minutes. If it stays slow, open supabase.com and look at your project.');
      } else if (r.status === 401 || r.status === 403) check(it, 'bad', 'Customers are NOT allowed to see the frames: ' + why(r), 'The database permission for the public was removed. Tap COPY and send it for fixing.');
      else check(it, 'bad', 'The database answered with an error: ' + why(r), 'Open supabase.com and check the project is running (a paused project shows RESTORE).');
      var s = await sb('/rest/v1/products?select=id&id=eq.__shop', { anon: true });
      if (s.ok && Array.isArray(s.body) && s.body.length) check(it, 'ok', 'Customers can read your shop settings (lens prices, offers)', null);
      else if (s.ok) check(it, 'warn', 'Your shop settings are not saved to the account yet', 'Open Settings and tap SAVE once.');
      else check(it, 'bad', 'Customers cannot read your shop settings: ' + why(s), 'Tap COPY and send it for fixing.');
      settle(it, r.ok ? 'Answering in ' + r.ms + ' ms' : 'Not answering properly');
    } catch (e) {
      check(it, 'bad', 'The database did not answer: ' + e.message, 'Check this phone’s internet. Then open supabase.com and check the project is running (a paused project shows RESTORE).');
      settle(it, 'Not answering');
    }
  }

  async function svcReports() {
    var it = item('reports');
    var since = new Date(Date.now() - 7 * 86400000).toISOString();
    try {
      var r = await sb('/rest/v1/site_health?select=*&created_at=gte.' + encodeURIComponent(since) + '&order=created_at.desc&limit=500');
      if (r.ok && Array.isArray(r.body)) {
        R.reports = r.body;
        check(it, 'ok', 'Switched on — customers’ phones report problems here', null);
        settle(it, r.body.length ? r.body.length + ' report' + (r.body.length > 1 ? 's' : '') + ' in 7 days' : 'Switched on · no problems reported');
        return;
      }
      var code = (r.body && r.body.code) || '';
      if (r.status === 404 || code === 'PGRST205' || code === '42P01') {
        R.reportsWhy = 'setup';
        it.state = 'off'; it.line = 'Not set up yet — one-time, 2 minutes';
        it.checks = [{ s: 'warn', t: 'The reports table is not in your database yet, so problems on customers’ phones cannot be recorded.' }];
        it.fix = ['Do the one-time setup in the box “Switch on problem reports” below.'];
        return;
      }
      R.reportsWhy = 'denied';
      check(it, 'warn', 'Admin cannot read the reports: ' + why(r), (g.VGAuth && g.VGAuth.signedIn && !g.VGAuth.signedIn()) ? 'Sign in to your shop account first.' : 'Run the one-time setup again (it is safe to run twice).');
      settle(it, 'Cannot read the reports');
    } catch (e) {
      R.reportsWhy = 'error';
      check(it, 'warn', 'Could not read the reports: ' + e.message, 'Run the check again.');
      settle(it, 'Could not read the reports');
    }
  }

  async function svcRobot() {
    var it = item('robot');
    try {
      var r = await withTimeout(g.VGSync.fetchSetting('robot'), 15000, 'The database');
      if (!r) { check(it, 'warn', 'The robot has never reported in', 'Open github.com/vision-online/vg-cutter/actions and look for red runs. Check the SUPABASE_KEY secret.'); return settle(it, 'No note from the robot'); }
      var mins = r.lastLook ? Math.round((Date.now() - new Date(r.lastLook).getTime()) / 60000) : null;
      if (mins !== null && mins <= 45) check(it, 'ok', 'Running — last look ' + mins + ' min ago', null);
      else check(it, 'bad', 'Not running — last look ' + (mins === null ? 'never' : (mins >= 120 ? Math.round(mins / 60) + ' hours' : mins + ' min') + ' ago') + ' (it should look every 10 minutes)', 'Open github.com/vision-online/vg-cutter/actions. A red run means a failure (usually the Supabase key or Cloudinary secret); no runs at all means GitHub switched the schedule off — tap ENABLE WORKFLOW.');
      if (r.waiting != null) check(it, 'info', r.waiting + ' frame(s) waiting to be cut', null);
      if (r.error) check(it, 'warn', 'Last error: ' + String(r.error).slice(0, 160), 'This is a database problem, not a cutting problem — tap COPY and send it for fixing.');
      settle(it, mins !== null && mins <= 45 ? 'Running' : 'Not running');
    } catch (e) { check(it, 'warn', 'Could not read the robot’s note: ' + e.message, null); settle(it, 'Could not read'); }
  }

  async function relayOn() { try { var r = await withTimeout(fetch('/api/wa?check=1', { cache: 'no-store' }), 8000, 'The website'); return !!(r.ok && (await r.json()).configured); } catch (e) { return false; } }
  /* d17.158 (shop, 20 Oct: "if WhatsApp blocks a number we must replace it instantly") */
  function blockTip(it) {
    check(it, 'info', 'If WhatsApp ever blocks the SENDING number: put the new SIM in a phone, open WhatsApp → Settings → Linked devices → Link a device, and scan the QR on the sender page (Settings → OPEN THE QR PAGE). Nothing else changes. The numbers customers see are in Settings → Contact numbers.', null);
  }
  /* d17.164 (shop, 22 Oct: "how do we know how much space we are using?"): the Google Cloud computer that runs the
     3 WhatsApp programs -- disk, memory, and each program -- read from the sender's /stats through the website */
  function gb(b) { b = Number(b) || 0; return b >= 1e9 ? (b / 1073741824).toFixed(1) + ' GB' : Math.round(b / 1048576) + ' MB'; }
  async function svcServer() {
    var it = item('server');
    if (!(await relayOn())) { it.state = 'off'; it.line = 'Not switched on'; it.checks = [{ s: 'off', t: 'Shows once WhatsApp sending through the website is set up (SENDER_URL / SENDER_KEY in Vercel).' }]; return; }
    var d = null, why = '';
    try {
      var t = await token();
      var r = await withTimeout(fetch('/api/wa?stats=1', { cache: 'no-store', headers: { Authorization: 'Bearer ' + (t || '') } }), 15000, 'The website');
      d = await r.json().catch(function () { return null; });
      if (!r.ok || !d || !d.ok) { why = (d && d.error) || ('error ' + r.status); d = null; }
    } catch (e) { why = e.message; }
    if (!d) { check(it, 'warn', 'Could not read the computer\u2019s space: ' + why, 'The sender needs its usage report (added 22 Oct). If the sender itself is not answering, see WhatsApp sender above.'); return settle(it, 'Not reported'); }
    var dp = d.disk.total ? Math.round(d.disk.used / d.disk.total * 100) : 0;
    check(it, dp >= 95 ? 'bad' : dp >= 85 ? 'warn' : 'ok', 'Disk: ' + gb(d.disk.used) + ' used, ' + gb(d.disk.free) + ' free of ' + gb(d.disk.total) + ' (' + dp + '% used)',
      dp >= 85 ? 'The disk is nearly full \u2014 tap COPY and send it for fixing (old logs can be cleared).' : null);
    var rf = d.ram.free || 0;
    check(it, rf < 50 * 1048576 ? 'bad' : rf < 100 * 1048576 ? 'warn' : 'ok', 'Memory: ' + gb(rf) + ' free of ' + gb(d.ram.total) + (d.swap && d.swap.total ? ' (backup memory ' + gb(d.swap.used) + ' of ' + gb(d.swap.total) + ' in use)' : ''),
      rf < 100 * 1048576 ? 'Memory is running low \u2014 tap COPY and send it for fixing.' : null);
    var NAMES = { 'vg-sender': 'WhatsApp sender (website, orders)', 'vg-eyetest': 'Eye-test WhatsApp bridge', 'vg-staff-relay': 'Staff app WhatsApp relay' };
    (d.services || []).forEach(function (sv) {
      check(it, sv.active ? 'ok' : 'bad', (NAMES[sv.name] || sv.name) + (sv.active ? ': running' + (sv.mem ? ', using ' + gb(sv.mem) : '') : ': NOT running'),
        sv.active ? null : 'On the Google Cloud computer: sudo systemctl restart ' + sv.name + ' \u2014 or tap COPY and send it for fixing.');
    });
    settle(it, gb(d.disk.free) + ' disk free \u00b7 ' + gb(rf) + ' memory free');
  }

  /* d17.166 (shop, 22 Oct: "a customer gets a 404 / 504 and we never come to know"): the 5-minute watchman */
  var WATCH_LINE = 'bash <(curl -s https://visiongallery.me/watch-setup.sh)';
  async function svcWatch() {
    var it = item('watch'), S = adminSet(), d = null;
    try { d = await withTimeout(g.VGSync.fetchSetting('watch'), 10000, 'The database'); } catch (e) {}
    if (!d || !d.lastRun) {
      it.state = 'off'; it.line = 'Not switched on';
      it.checks = [{ s: 'off', t: 'Nobody is told automatically when a page stops opening or customers hit errors.' }];
      it.fix = ['Add SUPABASE_SERVICE_KEY in Vercel (it lets the watchman read the reports), publish the latest zip, then in the Google Cloud window (vg-whatsapp \u2192 SSH) paste this one line and press Enter: ' + WATCH_LINE];
      return;
    }
    var age = Date.now() - Number(d.lastRun);
    if (age > 15 * 60e3) check(it, 'warn', 'The watchman last looked ' + ago(new Date(Number(d.lastRun)).toISOString()) + ' \u2014 it should look every 5 minutes', 'The Google Cloud computer may be off, or its line was removed. Start the computer, then paste again: ' + WATCH_LINE);
    else check(it, 'ok', 'Looking every 5 minutes \u2014 last look ' + ago(new Date(Number(d.lastRun)).toISOString()), null);
    var down = (d.pages || []).filter(function (p) { return !p.ok; });
    if (down.length) down.forEach(function (p) { check(it, 'bad', p.name + ' was NOT opening at the last look' + (p.status ? ' (error ' + p.status + ')' : ''), 'You have been told on WhatsApp. If it does not come back by itself in 10 minutes, tap COPY and send it for fixing.'); });
    else if ((d.pages || []).length) check(it, 'ok', 'All ' + d.pages.length + ' pages and server parts were opening at the last look', null);
    if (d.lastFail && d.lastFail.at && Date.now() - Number(d.lastFail.at) < 20 * 60e3) check(it, 'bad', 'An alert could NOT be sent on WhatsApp: ' + d.lastFail.why, 'Check WhatsApp sender above, and Settings \u2192 Contact numbers \u2192 Website problem alerts. It is tried again every 5 minutes.');
    if (d.lastAlert && d.lastAlert.at) check(it, 'info', 'Last WhatsApp alert: ' + clock(new Date(Number(d.lastAlert.at)).toISOString()), null);
    var to = String(S.alertWa || '').replace(/\D/g, '');
    if (to) check(it, 'ok', 'Alerts go to \u2022\u2022\u2022' + to.slice(-4), null);
    else check(it, 'info', 'Alerts go to the manager\u2019s number \u2014 set your own in Settings \u2192 Contact numbers \u2192 Website problem alerts', null);
    settle(it, down.length ? down.length + ' page' + (down.length === 1 ? '' : 's') + ' down' : 'Watching');
  }

  async function svcWhatsapp() {
    var it = item('whatsapp'), S = adminSet();
    /* d17.155: through the website's relay (works with the sender's http address) */
    if (await relayOn()) {
      try {
        var t = await token();
        var hr = await withTimeout(fetch('/api/wa?health=1', { cache: 'no-store', headers: { Authorization: 'Bearer ' + (t || '') } }), 15000, 'The website');
        var hd = await hr.json().catch(function () { return {}; });
        if (hr.ok && hd.ready) check(it, 'ok', 'Linked' + (hd.me ? ' as ' + hd.me : '') + ' — messages go out through the website', null);
        else if (hr.ok) check(it, 'bad', 'Running but NOT linked to WhatsApp', 'Open the sender’s link page and scan again with the sending phone (WhatsApp → Linked devices).');
        else check(it, 'bad', hd.error || ('The website could not reach the sender (error ' + hr.status + ')'), 'Check the vg-whatsapp computer is running on Google Cloud, and SENDER_URL / SENDER_KEY in Vercel.');
      } catch (e) { check(it, 'bad', 'The website could not reach the sender: ' + e.message, 'Check the vg-whatsapp computer is running on Google Cloud.'); }
      blockTip(it);
      return settle(it, it.checks.some(function (c) { return c.s === 'ok'; }) ? 'Linked' : 'Not working');
    }
    var base = String(($('setWaSend') && $('setWaSend').value) || S.waSend || '').trim().replace(/\/send\s*$/, '').replace(/\/+$/, '');
    if (!base) { it.state = 'off'; it.line = 'Not switched on'; it.checks = [{ s: 'off', t: 'Automatic WhatsApp messages from Admin are not set up yet.' }]; it.fix = ['Add SENDER_URL and SENDER_KEY in Vercel (the setup guide), then deploy again.']; return; }
    if (pageProto() === 'https:' && /^http:\/\//i.test(base)) {
      check(it, 'bad', 'The sender address starts with http:// — a secure website cannot talk to it directly, so no message goes out', 'Add SENDER_URL and SENDER_KEY in Vercel (the setup guide): the website then passes messages on for you.');
      return settle(it, 'Address not secure');
    }
    var host = ''; try { host = new URL(base).host; } catch (e) {}
    var csp = null, onCsp = function (e) { if (host && String(e.blockedURI || '').indexOf(host) >= 0) csp = e; };
    document.addEventListener('securitypolicyviolation', onCsp);
    try {
      var res = await withTimeout(fetch(base + '/health', { cache: 'no-store' }), 10000, 'The sender');
      var d = await res.json().catch(function () { return {}; });
      if (d.ready) check(it, 'ok', 'Linked' + (d.me ? ' as ' + d.me : '') + ' — order messages will go out', null);
      else check(it, 'bad', 'Running but NOT linked to WhatsApp' + (d.error ? ' (' + d.error + ')' : ''), 'Settings → WhatsApp sending → open the QR page and scan it again with the shop’s WhatsApp (Linked devices).');
      blockTip(it);
      settle(it, d.ready ? 'Linked' : 'Not linked');
    } catch (e) {
      await sleep(80);
      if (csp) check(it, 'bad', 'The website’s security list blocks the sender address (' + host + ')', 'The sender address must be added to the website’s allowed list — tap COPY and send it for fixing.');
      else check(it, 'bad', 'The sender did not answer', 'Start the vg-whatsapp computer on Google Cloud (VM instances → START). If it is running, open its QR page to see why.');
      settle(it, csp ? 'Blocked by the website' : 'Not answering');
    } finally { document.removeEventListener('securitypolicyviolation', onCsp); }
  }

  /* d17.155: the public settings row must not hold staff passcodes, roles or the WhatsApp key */
  async function svcPrivacy() {
    var it = item('privacy');
    var leaks = [];
    try {
      var r = await sb('/rest/v1/products?select=data&id=eq.__shop', { anon: true });
      var bag = r.ok && Array.isArray(r.body) && r.body[0] ? r.body[0].data || {} : {};
      if (bag.staff) leaks.push('staff names and passcodes'); if (bag.roles) leaks.push('roles');
      var sh = bag.shop || {}; if (sh.waKey) leaks.push('the WhatsApp sender key'); if (sh.mgrWa || sh.labWa) leaks.push('manager / lab numbers');
    } catch (e) { check(it, 'warn', 'Could not read the public settings: ' + e.message, null); return settle(it, 'Could not check'); }
    var pv = null; try { pv = g.VGSync && g.VGSync.fetchPrivate ? await g.VGSync.fetchPrivate('shop') : null; } catch (e) {}
    R.privMissing = !!(pv && pv.missing);
    if (leaks.length) check(it, 'bad', 'Anyone on the internet can read: ' + leaks.join(', '), R.privMissing ? 'Do the one-time database setup (the box under “Problems on customers’ phones”), then close Admin and open it again — they move to the private place by themselves.' : 'Close Admin and open it again — they move to the private place by themselves.');
    else check(it, 'ok', 'Staff passcodes and keys are not in the public settings', null);
    if (R.privMissing) check(it, 'warn', 'The private settings table is not set up yet', 'Do the one-time database setup (the box under “Problems on customers’ phones”).');
    settle(it, leaks.length ? 'Readable by anyone' : (R.privMissing ? 'Setup needed' : 'Private'));
  }

  async function svcUpi() {
    var it = item('upi');
    var cfg = null; try { var r = await withTimeout(fetch('/api/upi-sms?check=1', { cache: 'no-store' }), 10000, 'The website'); if (r.ok) cfg = await r.json(); } catch (e) {}
    if (!cfg || !cfg.configured) { it.state = 'off'; it.line = 'Not switched on'; it.checks = [{ s: 'off', t: 'Payments are not confirmed automatically yet.' }]; it.fix = ['Add the website settings in Vercel and the SMS-forwarding app on your phone (the setup guide).']; return; }
    var last = null; try { last = await withTimeout(g.VGSync.fetchSetting('upi'), 10000, 'The database'); } catch (e) {}
    check(it, 'ok', 'Switched on — Kotak “Received” SMS confirm orders by themselves', null);
    if (!cfg.whatsapp) check(it, 'warn', 'The customer WhatsApp message is not set up on the website', 'Add SENDER_URL and SENDER_KEY in Vercel, then deploy again.');
    if (last && last.lastSms) check(it, 'info', 'Last payment SMS: ' + clock(last.lastSms) + ' (' + (last.lastResult || '') + ')', null);
    else check(it, 'info', 'No payment SMS has arrived yet — pay ₹1 to your QR to test it', null);
    settle(it, last && last.lastSms ? 'Last SMS ' + ago(last.lastSms) : 'Waiting for the first SMS');
  }

  /* d17.158: the chat -- its own answers always work; smart answers need GEMINI_KEY; learned answers need the table */
  async function svcChat() {
    var it = item('chat');
    var t = await sb('/rest/v1/chat_learned?select=status&status=eq.pending&limit=300').catch(function () { return null; });
    R.chatMissing = !!(t && (t.status === 404 || (t.body && t.body.code === 'PGRST205')));
    var cfg = null; try { var r = await withTimeout(fetch('/api/chat?check=1', { cache: 'no-store' }), 10000, 'The website'); if (r.ok) cfg = await r.json(); } catch (e) {}
    check(it, 'ok', 'Answers from your own list: offers and prices from Settings, branches, timings, warranty, returns, Try On, My Orders', null);
    if (cfg && cfg.configured) check(it, 'ok', 'Smart answers are on for other questions', null);
    else check(it, 'off', 'Smart answers are off — other questions get your WhatsApp / Call buttons', 'Vercel → Settings → Environment Variables: add GEMINI_KEY (free key from aistudio.google.com), then deploy again.');
    if (R.chatMissing) check(it, 'warn', 'The approval list is not set up yet, so new answers cannot wait for approval', 'Do the one-time database setup (the box under “Problems on customers’ phones”).');
    else if (t && t.ok && Array.isArray(t.body)) check(it, t.body.length ? 'warn' : 'ok', t.body.length ? t.body.length + ' answer' + (t.body.length === 1 ? '' : 's') + ' waiting for approval' : 'Nothing waiting for approval', t.body.length ? 'CHATBOT → To approve: check each answer and tap APPROVE or REJECT.' : null);
    settle(it, R.chatMissing ? 'Setup needed' : (cfg && cfg.configured ? 'Smart answers on' : 'Own answers only'));
  }

  async function svcAnalytics() {
    var it = item('analytics'), S = adminSet();
    if (!S.posthogKey) { it.state = 'off'; it.line = 'Not switched on'; it.checks = [{ s: 'off', t: 'Visits are not counted yet.' }]; it.fix = ['Settings → Visitor analytics: paste your PostHog project key (phc_…) and SAVE.']; return; }
    if (!/^phc_/.test(S.posthogKey)) check(it, 'warn', 'The PostHog key does not look right (it should start with phc_)', 'Settings → Visitor analytics: copy the Project API key from PostHog again.');
    else check(it, 'ok', 'Counting visits (' + (S.posthogHost === 'eu' ? 'Europe' : 'US') + ' region) — typed details are never recorded', null);
    settle(it, 'Counting visits');
  }

  function buildNo(s) { var m = /d(\d+)\.(\d+)/.exec(String(s || '')); return m ? Number(m[1]) * 1000 + Number(m[2]) : 0; }
  async function svcVersion() {
    var it = item('version');
    try {
      var res = await withTimeout(fetch('check.html?ts=' + Date.now(), { cache: 'no-store' }), 12000, 'The website');
      var txt = await res.text(), m = /const BUILD = '([^'(]+)/.exec(txt);
      var live = m ? m[1].trim() : '';
      if (!live) { check(it, 'warn', 'Could not read which build is live', null); return settle(it, 'Unknown'); }
      var a = buildNo(live), b = buildNo(VERSION);
      if (a === b) check(it, 'ok', 'Live build: ' + live + ' — the same as this Admin', null);
      else if (a > b) check(it, 'warn', 'The website has a newer build (' + live + ') than this Admin (' + VERSION + ')', 'Close Admin and open it again (or pull down to refresh) to load the new build.');
      else check(it, 'warn', 'The website still runs an older build (' + live + ')', 'Your last upload has not gone live yet. Upload the zip again and wait for the deploy to finish.');
      settle(it, live);
    } catch (e) { check(it, 'warn', 'Could not read the live build: ' + e.message, null); settle(it, 'Unknown'); }
  }

  async function harvestCheck() {
    R.dataState = 'run'; render();
    var r = await openPage('check.html', function (w, d) { return [].slice.call(d.querySelectorAll('button')).some(function (b) { return /COPY REPORT/.test(b.textContent); }); }, 90000, true);
    var rows = [];
    try {
      [].slice.call(r.doc.querySelectorAll('#rows .row')).forEach(function (row) {
        var dot = row.querySelector('.dot'), h = row.querySelector('h2'), p = row.querySelector('p');
        var st = dot ? (/\bbad\b/.test(dot.className) ? 'bad' : /\bwarn\b/.test(dot.className) ? 'warn' : /\bok\b/.test(dot.className) ? 'ok' : 'skip') : 'skip';
        rows.push({ s: st, t: h ? h.textContent.trim() : '', html: clean(p ? p.innerHTML : '') });
      });
    } catch (e) {}
    R.data = rows.filter(function (x) { return x.t && !/^This page$/.test(x.t); });
    R.dataState = r.why === 'ready' ? 'done' : (rows.length ? 'partial' : 'fail');
    var h = $('hpHidden'); if (h) h.innerHTML = '';
  }

  /* try-on: the frame page's button and engine, the face finder service, the engine tests of the technical check, and customers */
  async function composeTryon() {
    var it = item('tryon'); it.link = CTX.frameId ? 'product.html?id=' + encodeURIComponent(CTX.frameId) : '';
    if (CTX.framePage) {
      check(it, CTX.framePage.tryBtn ? 'ok' : 'warn', CTX.framePage.tryBtn ? 'Try-on button on the frame page' : 'No try-on button on the frame page', 'The frame needs its try-on picture (TO CHECK).');
      check(it, CTX.framePage.engine ? 'ok' : 'bad', CTX.framePage.engine ? 'Try-on program loaded on the frame page' : 'The try-on program did not load on the frame page', 'Upload the latest build again. If it stays red, tap COPY and send it for fixing.');
    }
    var cdn = [['cdn.jsdelivr.net', 'https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh@0.4/face_mesh.js'], ['unpkg.com (back-up)', 'https://unpkg.com/@mediapipe/face_mesh@0.4/face_mesh.js']];
    var up = [];
    for (var i = 0; i < cdn.length; i++) {
      try { var res = await withTimeout(fetch(cdn[i][1], { method: 'HEAD', cache: 'no-store' }), 10000, 'The face finder'); up.push(res.ok); } catch (e) { up.push(false); }
    }
    if (up[0]) check(it, 'ok', 'Face finder service is reachable', null);
    else if (up[1]) check(it, 'warn', 'The main face-finder service is down; the back-up works', 'Nothing to do now — customers still get the try-on, a little slower.');
    else check(it, 'bad', 'The face-finder service cannot be reached — the try-on cannot start', 'Check this phone’s internet. If the internet is fine, the service is down — tap COPY and send it for fixing.');
    settle(it, up[0] || up[1] ? 'Face finder reachable' : 'Face finder unreachable');
  }
  function addTryonData() {
    var it = item('tryon');
    R.data.filter(function (x) { return /try-on|face library|seating|same size|30°|engine/i.test(x.t); }).forEach(function (x) {
      var txt = document.createElement('div'); txt.innerHTML = x.html;
      check(it, x.s === 'skip' ? 'info' : x.s, x.t + ': ' + txt.textContent.replace(/\s+/g, ' ').slice(0, 140), 'See the full line under SHOP DATA below.');
    });
  }

  /* ---------------- customers' phones ---------------- */
  function groups(period) {
    var since = Date.now() - period * 3600000, map = {};
    (R.reports || []).forEach(function (r) {
      if (new Date(r.created_at).getTime() < since) return;
      var key = cardOf(r) + '|' + r.kind + '|' + r.message;
      var gq = map[key] || (map[key] = { card: cardOf(r), kind: r.kind, page: r.page, message: r.message, n: 0, last: r.created_at, first: r.created_at, dev: {}, rows: [] });
      gq.n++; gq.rows.push(r);
      if (r.created_at > gq.last) gq.last = r.created_at; if (r.created_at < gq.first) gq.first = r.created_at;
      var dv = (r.detail && r.detail.device) || 'unknown phone'; gq.dev[dv] = (gq.dev[dv] || 0) + 1;
    });
    return Object.keys(map).map(function (k) { var x = map[k]; x.k = kindOf(x.rows[0]); return x; })
      .sort(function (a, b) { var o = { bad: 3, warn: 2, info: 1 }; return (o[b.k.sev] - o[a.k.sev]) || (b.last > a.last ? 1 : -1); });
  }
  function applyReports() {
    if (!R.reports) return;
    var day = groups(24);
    ['home', 'frame', 'tryon', 'checkout', 'prescription', 'myorders'].forEach(function (id) {
      var it = item(id), mine = day.filter(function (x) { return x.card === id; });
      var probs = mine.filter(function (x) { return !x.k.info; }), n = probs.reduce(function (s, x) { return s + x.n; }, 0);
      var infoDb = mine.filter(function (x) { return x.kind === 'database' && x.k.info; }).reduce(function (s, x) { return s + x.n; }, 0);
      if (!n && !infoDb) { if (it.checks.length) check(it, 'ok', 'No problems from customers’ phones in the last 24 hours', null); }
      probs.forEach(function (x) {
        var s = x.k.sev === 'bad' ? 'bad' : (x.n >= 5 ? 'bad' : 'warn');
        check(it, s, 'Customers: ' + x.k.t + ' — ' + x.n + '×, last ' + ago(x.last), x.k.fix);
      });
      if (infoDb >= 8) check(it, 'warn', 'Customers: ' + infoDb + ' could not reach the database in 24 hours', KIND.database.fix);
      it.cust = n;
      if (it.checks.length) settle(it);
    });
  }

  /* ---------------- local data the test pages might touch: put it back ---------------- */
  var KEEP_LS = /^(vg_session|vg_customer_session|vg_pending|vg_health_|vg_sync)/;
  function snap() { var o = { ls: {}, ss: {} }; try { for (var i = 0; i < localStorage.length; i++) { var k = localStorage.key(i); o.ls[k] = localStorage.getItem(k); } } catch (e) {} try { for (var j = 0; j < sessionStorage.length; j++) { var q = sessionStorage.key(j); o.ss[q] = sessionStorage.getItem(q); } } catch (e) {} return o; }
  function restore(o) {
    function put(st, saved, skip) {
      try {
        var now = []; for (var i = 0; i < st.length; i++) now.push(st.key(i));
        now.forEach(function (k) { if (skip.test(k)) return; if (!(k in saved)) st.removeItem(k); else if (st.getItem(k) !== saved[k]) st.setItem(k, saved[k]); });
        Object.keys(saved).forEach(function (k) { if (!skip.test(k) && st.getItem(k) === null) st.setItem(k, saved[k]); });
      } catch (e) {}
    }
    put(localStorage, o.ls, KEEP_LS); put(sessionStorage, o.ss, /^vg_me$/);
  }

  /* ---------------- run ---------------- */
  async function run() {
    if (R && R.running) return;
    var keepOpen = R ? R.open : {}, keepPeriod = R ? R.period : 24;
    R = fresh(); R.open = keepOpen; R.period = keepPeriod; R.running = true;
    var t0 = performance.now(), saved = snap();
    CTX = { frameId: '', frameName: '', framePage: null };
    var steps = [
      ['Database, services and customers’ reports', function () { return Promise.all([svcDatabase(), svcPrivacy(), svcReports(), svcRobot(), svcWhatsapp(), svcServer(), svcWatch(), svcUpi(), svcChat(), svcAnalytics(), svcVersion()]); }],
      ['Home page', testHome], ['Frame page', testFrame], ['Checkout', testCheckout],
      ['Prescription', testPrescription], ['My Orders', testMyOrders], ['Admin', testAdmin], ['Try-on', composeTryon],
      ['Shop data and settings (technical check)', harvestCheck]
    ];
    R.total = steps.length;
    try {
      for (var i = 0; i < steps.length; i++) {
        R.step = steps[i][0]; R.done = i;
        var id = { 'Home page': 'home', 'Frame page': 'frame', 'Checkout': 'checkout', 'Prescription': 'prescription', 'My Orders': 'myorders', 'Admin': 'admin', 'Try-on': 'tryon' }[R.step];
        if (id) item(id).state = 'run';
        render();
        try { await steps[i][1](); } catch (e) { if (id) { check(item(id), 'warn', 'The test itself failed: ' + (e && e.message || e), 'Run the check again. If it repeats, tap COPY and send it for fixing.'); settle(item(id)); } }
      }
      addTryonData();
      { var ti = item('tryon'), nb = ti.checks.filter(function (c) { return c.s === 'bad'; }).length, nw = ti.checks.filter(function (c) { return c.s === 'warn'; }).length;
        settle(ti, nb ? nb + ' problem' + (nb > 1 ? 's' : '') + ' found' : nw ? nw + ' thing' + (nw > 1 ? 's' : '') + ' to look at' : 'Button, program, face finder and engine all working'); }
      applyReports();
    } finally {
      restore(saved);
      R.running = false; R.at = new Date(); R.ms = Math.round(performance.now() - t0); R.done = R.total;
      var v = verdict();
      try { localStorage.setItem('vg_health_last', JSON.stringify({ at: R.at.toISOString(), bad: v.bad.length, warn: v.warn.length })); } catch (e) {}
      setBadge(v.bad.length);
      render();
    }
  }

  function verdict() {
    var bad = [], warn = [];
    ITEMS.forEach(function (x) { var it = item(x[0]); if (it.state === 'bad') bad.push(it.name); else if (it.state === 'warn') warn.push(it.name); });
    R.data.forEach(function (x) { if (/try-on|face library|seating|same size|30°|engine/i.test(x.t)) return; if (x.s === 'bad') bad.push(x.t); else if (x.s === 'warn') warn.push(x.t); });
    return { bad: bad, warn: warn };
  }

  /* ---------------- drawing ---------------- */
  function pill(s) { return '<span class="hp-pill ' + s + '">' + (PILL[s] || s) + '</span>'; }
  function cardHtml(it) {
    var open = !!R.open[it.id];
    var body = '';
    if (open) {
      body += '<ul class="hp-checks">' + it.checks.map(function (c) { return '<li class="' + c.s + '"><i>' + (MARK[c.s] || '•') + '</i><span>' + esc(c.t) + '</span></li>'; }).join('') + '</ul>';
      if (!it.checks.length) body += '<p class="hp-muted">' + (it.state === 'run' ? 'Testing now…' : 'Not tested yet.') + '</p>';
      if (it.fix.length && (it.state === 'bad' || it.state === 'warn' || it.state === 'off')) body += '<div class="hp-fix ' + it.state + '"><b>What to do</b><ol>' + it.fix.map(function (f) { return '<li>' + esc(f) + '</li>'; }).join('') + '</ol></div>';
      var acts = '';
      if (it.link) acts += '<a class="hp-btn hp-line" href="' + esc(it.link) + '" target="_blank" rel="noopener">OPEN THIS PAGE</a>';
      if (it.state === 'bad' || it.state === 'warn') acts += '<button type="button" class="hp-btn hp-line" data-hpcopy="' + it.id + '">COPY</button>';
      if (it.cust) acts += '<button type="button" class="hp-btn hp-line" data-hpgo="cust">SEE CUSTOMER PROBLEMS</button>';
      if (acts) body += '<div class="hp-acts">' + acts + '</div>';
      if (it.id === 'whatsapp') body += waBox();
      if (it.id === 'watch') body += watchTestBox();
    }
    var quick = '';
    if (!open && !R.running && (it.state === 'bad' || it.state === 'warn')) quick = '<div class="hp-quick"><button type="button" class="hp-btn hp-line" data-hpcopy="' + it.id + '">COPY</button><button type="button" class="hp-btn hp-line" data-hptoggle="' + it.id + '">WHAT TO DO</button></div>';
    if (!open && !R.running && it.id === 'whatsapp' && it.state !== 'wait') quick = '<div class="hp-quick">' + (it.state === 'bad' || it.state === 'warn' ? '<button type="button" class="hp-btn hp-line" data-hpcopy="whatsapp">COPY</button>' : '') + '<button type="button" class="hp-btn" data-hptoggle="whatsapp">SEND A TEST MESSAGE</button></div>';
    if (!open && !R.running && it.id === 'watch' && it.state !== 'wait') quick = '<div class="hp-quick">' + (it.state === 'bad' || it.state === 'warn' ? '<button type="button" class="hp-btn hp-line" data-hpcopy="watch">COPY</button>' : '') + '<button type="button" class="hp-btn" data-hptoggle="watch">SEND TEST ALERT</button></div>';
    return '<div class="hp-card ' + it.state + (open ? ' open' : '') + '" data-hpid="' + it.id + '">' +
      '<button type="button" class="hp-head" data-hptoggle="' + it.id + '" aria-expanded="' + open + '">' +
        '<span class="hp-ring ' + it.state + '">' + icon(it.icon) + '</span>' +
        '<span class="hp-ttl"><b>' + esc(it.name) + '</b><small>' + esc(it.line || '') + (it.cust ? ' · <em>' + it.cust + ' from customers today</em>' : '') + '</small></span>' +
        pill(it.state) + icon('chev', 'hp-chev') +
      '</button>' + quick + (open ? '<div class="hp-body">' + body + '</div>' : '') + '</div>';
  }
  /* ---------------- WhatsApp: a real test message (shop, 18 Oct: "keep one option for a trial message") ---------------- */
  function waCfg() {
    var S = adminSet();
    var url = String(($('setWaSend') && $('setWaSend').value) || S.waSend || '').trim();
    var key = String(($('setWaKey') && $('setWaKey').value) || S.waKey || '').trim();
    var base = url.replace(/\/send\s*$/, '').replace(/\/+$/, '');
    return { url: base ? base + '/send' : '', base: base, key: key, to: String(S.mgrWa || S.wa || '').replace(/\D/g, '') };
  }
  function waBox() {
    var c = waCfg(), t = R.waTest || {};
    var num = t.num != null ? t.num : c.to;
    return '<div class="hp-wa"><b>Send a test message</b><p class="hp-muted">Sends one short WhatsApp message through your sender, so you can see on the phone that it really arrives.</p>' +
      '<label for="hpWaNum">Send it to this WhatsApp number</label><div class="hp-wa-row"><input id="hpWaNum" type="tel" inputmode="numeric" placeholder="919876543210" value="' + esc(num) + '">' +
      '<button type="button" class="hp-btn" data-hpwatest="1"' + (t.busy ? ' disabled' : '') + '>' + (t.busy ? 'SENDING…' : 'SEND TEST') + '</button></div>' +
      (t.msg ? '<div class="hp-fix ' + (t.ok ? 'ok' : 'bad') + '"><b>' + (t.ok ? 'Sent' : 'Not sent') + '</b>' + esc(t.msg) + '</div>' : '') +
      (c.base ? '<p class="hp-muted">Sender\u2019s own status page (opens in Chrome): <a href="' + esc(c.base) + '/" target="_blank" rel="noopener">' + esc(c.base) + '/</a></p>' : '') + '</div>';
  }
  /* d17.167 (shop, 22 Oct): a real test alert to the alert number, through the website -- proves the whole chain */
  function watchTestBox() {
    var t = R.watchTest || {};
    return '<div class="hp-wa"><b>Send a test alert</b><p class="hp-muted">Sends one WhatsApp to the number real website alerts go to (Settings \u2192 Contact numbers \u2192 Website problem alerts), so you know they really arrive.</p>' +
      '<div class="hp-wa-row"><button type="button" class="hp-btn" data-hpwatchtest="1"' + (t.busy ? ' disabled' : '') + '>' + (t.busy ? 'SENDING\u2026' : 'SEND TEST ALERT') + '</button></div>' +
      (t.msg ? '<div class="hp-fix ' + (t.ok ? 'ok' : 'bad') + '"><b>' + (t.ok ? 'Sent' : 'Not sent') + '</b>' + esc(t.msg) + '</div>' : '') + '</div>';
  }
  async function watchTest() {
    try {
      var tk = await token();
      if (!tk) return { ok: false, msg: 'Sign in to your shop account first (Settings \u2192 Your account) \u2014 the website only sends for signed-in staff.' };
      var r = await withTimeout(fetch('/api/watch?test=1', { cache: 'no-store', headers: { Authorization: 'Bearer ' + tk } }), 30000, 'The website');
      var d = await r.json().catch(function () { return {}; });
      if (r.status === 404) return { ok: false, msg: 'The website does not have the watchman yet \u2014 upload the latest zip.' };
      if (r.ok && d.ok) return { ok: true, msg: 'Sent to ' + d.to + '. Look at WhatsApp \u2014 \u201cwatchman test\u201d should arrive within a minute. If it does not, the sending phone has lost its link (see WhatsApp sender above).' };
      return { ok: false, msg: d.error || ('The website answered ' + r.status) };
    } catch (e) { return { ok: false, msg: 'The website did not answer (' + e.message + ').' }; }
  }
  async function waTest(num) {
    var c = waCfg();
    num = String(num || '').replace(/\D/g, ''); if (num.length === 10) num = '91' + num;
    var text0 = 'Vision Gallery — test message from Admin → Health (' + new Date().toLocaleString('en-IN') + '). If you can read this, automatic WhatsApp messages work.';
    if (await relayOn()) {
      if (num.length < 11) return { ok: false, msg: 'Type the full number with 91 in front, e.g. 919876543210.' };
      try {
        var t = await token();
        var rr = await withTimeout(fetch('/api/wa', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + (t || '') }, body: JSON.stringify({ phone: num, text: text0 }) }), 25000, 'The website');
        var dd = await rr.json().catch(function () { return {}; });
        if (rr.ok && dd.ok !== false) return { ok: true, msg: 'The sender accepted it (through the website). Look at WhatsApp on +' + num + ' — it should arrive within a minute. If it does not, the sending phone has lost its link: open the link page and scan again.' };
        if (rr.status === 401) return { ok: false, msg: 'Sign in to your shop account first (the website only sends for signed-in staff).' };
        return { ok: false, msg: 'Not sent: ' + (dd.error || ('error ' + rr.status)) + '. If it says not linked, open the sender’s link page and scan again.' };
      } catch (e) { return { ok: false, msg: 'The website did not answer (' + e.message + ').' }; }
    }
    if (!c.url) return { ok: false, msg: 'There is no sender address in Settings \u2192 WhatsApp sending.' };
    if (!c.key) return { ok: false, msg: 'There is no sender key in Settings \u2192 WhatsApp sending (the SEND_KEY box).' };
    if (num.length < 11) return { ok: false, msg: 'Type the full number with 91 in front, e.g. 919876543210.' };
    if (pageProto() === 'https:' && /^http:\/\//i.test(c.url)) return { ok: false, msg: 'Your sender\u2019s address starts with http:// (' + c.base + '). Your website is secure (https://), and phones block a secure page from talking to an http:// address \u2014 so Admin can never reach it. The sender needs an https:// address. Meanwhile, open ' + c.base + '/ in Chrome: it shows whether the sender itself is linked.' };
    var host = ''; try { host = new URL(c.url).host; } catch (e) {}
    var csp = null, onCsp = function (e) { if (host && String(e.blockedURI || '').indexOf(host) >= 0) csp = e; };
    document.addEventListener('securitypolicyviolation', onCsp);
    try {
      var text = 'Vision Gallery \u2014 test message from Admin \u2192 Health (' + new Date().toLocaleString('en-IN') + '). If you can read this, automatic WhatsApp messages work.';
      var res = await withTimeout(fetch(c.url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Send-Key': c.key }, body: JSON.stringify({ phone: num, number: num, text: text, message: text }) }), 20000, 'The sender');
      var d = await res.json().catch(function () { return {}; });
      if (res.ok && d.ok !== false) return { ok: true, msg: 'The sender accepted it. Look at WhatsApp on +' + num + ' \u2014 it should arrive within a minute. If it does not, the sender\u2019s phone has lost its link: open the QR page and scan again.' };
      if (res.status === 401 || res.status === 403) return { ok: false, msg: 'The sender refused the key. The SEND_KEY in Settings must be the same as the key on the sender.' };
      return { ok: false, msg: 'The sender answered with an error' + (d.error ? ': ' + d.error : ' (' + res.status + ')') + '. If it says not linked, open the QR page and scan again.' };
    } catch (e) {
      await sleep(80);
      if (csp) return { ok: false, msg: 'The website\u2019s security list blocks the sender address (' + host + '). It must be added to the allowed list \u2014 tap COPY and send it for fixing.' };
      return { ok: false, msg: 'The sender did not answer (' + e.message + '). Check the vg-whatsapp computer is running on Google Cloud.' };
    } finally { document.removeEventListener('securitypolicyviolation', onCsp); }
  }
  function custHtml() {
    var head = '<div class="hp-sec-h" id="hpCust"><h3>Problems on customers’ phones</h3></div>';
    if (R.reportsWhy === 'setup' || R.privMissing || R.chatMissing) {
      var box = '<div class="hp-setup"><b>One-time database setup (about 2 minutes)</b>' +
        '<p>It switches on problem reports from customers’ phones, a private place for staff passcodes and the WhatsApp key (only your signed-in Admin can read it), and the chat’s list of answers waiting for approval. Everything else on this page already works.</p>' +
        '<ol><li>Tap <b>COPY THE SETUP</b>.</li><li>Tap <b>OPEN SUPABASE</b> and sign in. It opens a new SQL query for your project.</li>' +
        '<li>Paste into the big box, then tap <b>RUN</b> (bottom right). It should say “Success. No rows returned”.</li><li>Come back here and tap <b>RUN CHECK AGAIN</b>.</li></ol>' +
        '<div class="hp-acts"><button type="button" class="hp-btn" data-hpsql="1">COPY THE SETUP</button>' +
        '<a class="hp-btn hp-line" href="https://supabase.com/dashboard/project/' + esc(projectRef()) + '/sql/new" target="_blank" rel="noopener">OPEN SUPABASE</a></div>' +
        '<details><summary>See what it does</summary><p class="hp-muted">It adds two small tables. <code>site_health</code>: anyone’s phone may ADD a short note to it (no name, no number); only your signed-in Admin can READ or CLEAR the notes. <code>shop_private</code>: only your signed-in Admin can read or change it. <code>chat_learned</code>: the chat’s answers; customers can read only the APPROVED ones, only your signed-in Admin can approve. Safe to run twice.</p><pre class="hp-sql">' + esc(SQL) + '</pre></details></div>';
      if (R.reportsWhy === 'setup') return head + box;
      head += box;
    }
    if (!R.reports) return head + '<p class="hp-muted hp-pad">' + (R.running ? 'Reading…' : (R.reportsWhy ? 'Could not read the reports — see “Problem reports” under SERVICES.' : 'Run the check to see them.')) + '</p>';
    var list = groups(R.period), n24 = groups(24).reduce(function (s, x) { return s + (x.k.info ? 0 : x.n); }, 0), n7 = groups(168).reduce(function (s, x) { return s + (x.k.info ? 0 : x.n); }, 0);
    var h = head + '<div class="hp-chips"><button type="button" class="hp-chip' + (R.period === 24 ? ' on' : '') + '" data-hpperiod="24">Last 24 hours · ' + n24 + '</button>' +
      '<button type="button" class="hp-chip' + (R.period === 168 ? ' on' : '') + '" data-hpperiod="168">Last 7 days · ' + n7 + '</button></div>';
    if (!list.length) return h + '<div class="hp-empty">' + icon('reports') + '<b>No problems reported</b><span>Nothing went wrong on a customer’s phone in this period.</span></div>';
    h += list.map(function (x, i) {
      var devs = Object.keys(x.dev).sort(function (a, b) { return x.dev[b] - x.dev[a]; }).slice(0, 3).map(function (d) { return d + (x.dev[d] > 1 ? ' (' + x.dev[d] + ')' : ''); }).join(', ');
      var key = 'c' + i, open = !!R.open[key];
      return '<div class="hp-rep ' + x.k.sev + (open ? ' open' : '') + '"><button type="button" class="hp-rep-h" data-hptoggle="' + key + '">' +
        '<span class="hp-n">' + x.n + '×</span><span class="hp-ttl"><b>' + esc(x.k.t) + '</b><small>' + esc(PAGE_NAME[x.card] || x.card) + ' · last ' + esc(ago(x.last)) + (x.k.info ? ' · customer’s side' : '') + '</small></span>' + icon('chev', 'hp-chev') + '</button>' +
        (open ? '<div class="hp-body"><p class="hp-msg">' + esc(x.message) + '</p><p class="hp-muted">Phones: ' + esc(devs) + '<br>First ' + esc(clock(x.first)) + ' · last ' + esc(clock(x.last)) + (x.rows[0].detail && x.rows[0].detail.where ? '<br>Where: ' + esc(x.rows[0].detail.where) : '') + '</p>' +
          '<div class="hp-fix ' + (x.k.info ? 'off' : x.k.sev) + '"><b>What to do</b><ol><li>' + esc(x.k.fix) + '</li></ol></div>' +
          (x.k.info ? '' : '<div class="hp-acts"><button type="button" class="hp-btn hp-line" data-hpcopyrep="' + i + '">COPY</button></div>') + '</div>' : '') + '</div>';
    }).join('');
    if (canDo('health.edit')) h += '<div class="hp-acts hp-pad"><button type="button" class="hp-btn hp-line hp-danger" data-hpclear="1">CLEAR REPORTS OLDER THAN 7 DAYS</button></div>';
    return h;
  }
  function dataHtml() {
    var head = '<div class="hp-sec-h"><h3>Shop data &amp; settings</h3><a href="check.html" target="_blank" rel="noopener" class="hp-link">Full technical check ↗</a></div>';
    if (R.dataState === 'skip') return head + '<p class="hp-muted hp-pad">Run the check to see it.</p>';
    if (R.dataState === 'run' || (R.running && !R.data.length)) return head + '<p class="hp-muted hp-pad">' + (R.dataState === 'run' ? 'Reading the technical check… (up to a minute)' : 'Waiting for the page tests…') + '</p>';
    var rows = R.data.filter(function (x) { return !/try-on|face library|seating|same size|30°|engine/i.test(x.t); });
    var probs = rows.filter(function (x) { return x.s === 'bad' || x.s === 'warn'; }), fine = rows.filter(function (x) { return x.s !== 'bad' && x.s !== 'warn'; });
    var h = head;
    if (R.dataState === 'fail') h += '<p class="hp-muted hp-pad">The technical check did not open. Tap “Full technical check” to open it by itself.</p>';
    else if (R.dataState === 'partial') h += '<p class="hp-muted hp-pad">The technical check did not finish in time — these are the lines it got to.</p>';
    h += probs.map(function (x) { return '<div class="hp-data ' + x.s + '"><b><i>' + MARK[x.s] + '</i>' + esc(x.t) + '</b><p>' + x.html + '</p></div>'; }).join('');
    if (fine.length) {
      var open = !!R.open.fine;
      h += '<button type="button" class="hp-fine" data-hptoggle="fine">' + fine.length + ' checks working ' + (open ? '▴' : '▾') + '</button>';
      if (open) h += fine.map(function (x) { return '<div class="hp-data ' + x.s + '"><b><i>' + (MARK[x.s] || '–') + '</i>' + esc(x.t) + '</b><p>' + x.html + '</p></div>'; }).join('');
    }
    return h;
  }
  function render() {
    var root = $('healthRoot'); if (!root || !R) return;
    var v = verdict(), st = v.bad.length ? 'bad' : v.warn.length ? 'warn' : 'ok';
    var title, sub;
    if (R.running) { st = 'run'; title = 'Checking your website…'; sub = 'Step ' + Math.min(R.done + 1, R.total) + ' of ' + R.total + ': ' + R.step; }
    else if (!R.at) { st = 'idle'; title = 'Site health'; sub = 'Tap RUN CHECK to test every page the way a customer’s phone opens it.'; }
    else if (st === 'ok') { title = 'All good'; sub = 'Every page opened and worked like a customer’s phone. No problems from customers in the last 24 hours.'; }
    else if (st === 'bad') { title = v.bad.length + (v.bad.length === 1 ? ' problem found' : ' problems found'); sub = v.bad.slice(0, 4).join(' · ') + (v.warn.length ? ' — and ' + v.warn.length + ' to look at' : ''); }
    else { title = v.warn.length + (v.warn.length === 1 ? ' thing needs a look' : ' things need a look'); sub = v.warn.slice(0, 4).join(' · '); }
    var heroIc = st === 'ok' ? '✓' : st === 'bad' ? '✕' : st === 'warn' ? '!' : st === 'run' ? '<span class="hp-spin"></span>' : icon('reports');
    var pct = R.running ? Math.round(100 * R.done / R.total) : 100;
    var hero = '<div class="hp-hero ' + st + '"><div class="hp-hero-top"><span class="hp-big">' + heroIc + '</span><div><h2>' + esc(title) + '</h2><p>' + esc(sub) + '</p></div></div>' +
      (R.running ? '<div class="hp-bar"><i style="width:' + pct + '%"></i></div>' : '') +
      '<div class="hp-hero-foot"><small>' + (R.at ? 'Checked ' + esc(clock(R.at)) + ' · took ' + Math.round(R.ms / 1000) + ' s' : (R.running ? 'Nothing is bought, sent or saved' : '')) + '</small>' +
      '<button type="button" class="hp-run" data-hprun="1"' + (R.running ? ' disabled' : '') + '>' + (R.running ? 'CHECKING…' : (R.at ? 'RUN CHECK AGAIN' : 'RUN CHECK')) + '</button></div>' +
      (R.at && !R.running && st !== 'ok' ? '<button type="button" class="hp-copyall" data-hpcopyall="1">COPY ALL PROBLEMS</button><small class="hp-copyhint">Tap it, then paste it wherever you need it — it has every detail of what is wrong.</small>' : '') + '</div>';
    var main = '<div class="hp-sec-h"><h3>Website pages</h3><span class="hp-legend"><i class="ok"></i>working <i class="warn"></i>look <i class="bad"></i>problem</span></div>' +
      ITEMS.filter(function (x) { return x[1] === 'pages'; }).map(function (x) { return cardHtml(item(x[0])); }).join('') +
      custHtml() +
      '<div class="hp-sec-h"><h3>Services</h3></div>' +
      ITEMS.filter(function (x) { return x[1] === 'services'; }).map(function (x) { return cardHtml(item(x[0])); }).join('') +
      dataHtml() +
      (R.at && !R.running ? '<div class="hp-acts hp-pad"><button type="button" class="hp-btn hp-wide" data-hpcopyall="1">COPY THE FULL REPORT</button></div>' : '') +
      '<p class="hp-foot">Green = working · Amber = needs a look · Red = a customer is affected. Tap any line to see what was checked and what to do. Build ' + esc(VERSION) + '.</p>';
    /* the page under test lives in a box that is never redrawn -- moving an iframe reloads it */
    if (!$('hpHero')) root.innerHTML = '<div class="hp"><div id="hpHero"></div>' +
      '<div class="hp-prev" id="hpPrev" hidden><div class="hp-prev-l"><b>Now testing</b><span id="hpPrevStep"></span><small>This is what a customer’s phone sees. Nothing is bought, sent or saved.</small></div><div class="hp-prev-ph" id="hpPrevBox"></div></div>' +
      '<div id="hpMain"></div></div><div id="hpHidden" class="hp-hidden"></div>';
    $('hpHero').innerHTML = hero; $('hpMain').innerHTML = main;
    var showPrev = R.running && /page|Checkout|Prescription|My Orders/.test(R.step);
    $('hpPrev').hidden = !showPrev; $('hpPrevStep').textContent = R.step;
    if (!R.running) { $('hpPrevBox').innerHTML = ''; $('hpHidden').innerHTML = ''; }
  }

  function copyItem(id) {
    var it = item(id);
    return ['VISION GALLERY SITE HEALTH — ' + it.name + ' (' + (PILL[it.state] || it.state) + ')', 'Build: ' + VERSION + ' · checked ' + (R.at ? R.at.toString() : ''), 'Admin browser: ' + navigator.userAgent, '']
      .concat(it.checks.map(function (c) { return '[' + c.s.toUpperCase() + '] ' + c.t; }))
      .concat(it.fix.length ? ['', 'What the page says to do:'].concat(it.fix.map(function (f) { return '- ' + f; })) : [])
      .concat(it.tech ? ['', 'Technical:', it.tech.trim()] : [])
      .concat(it.id === 'whatsapp' && R.waTest && R.waTest.msg ? ['', 'Test message: ' + (R.waTest.ok ? 'SENT' : 'NOT SENT') + ' — ' + R.waTest.msg] : []).join('\n');
  }
  function copyAll() {
    var v = verdict(), L = ['VISION GALLERY SITE HEALTH \u2014 FULL REPORT', 'Admin build: ' + VERSION + ' \u00b7 checked ' + (R.at ? R.at.toString() : '') + ' \u00b7 took ' + Math.round(R.ms / 1000) + ' s',
      'Page: ' + location.href.split('?')[0], 'Browser: ' + navigator.userAgent, 'Signed in: ' + !!(g.VGAuth && g.VGAuth.signedIn && g.VGAuth.signedIn()) + (typeof ME !== 'undefined' && ME ? ' \u00b7 ' + ME.role : ''),
      'Frame used for the tests: ' + (CTX.frameId || 'none'), '', 'SUMMARY: ' + v.bad.length + ' red, ' + v.warn.length + ' amber', v.bad.length ? 'RED: ' + v.bad.join(' | ') : '', v.warn.length ? 'AMBER: ' + v.warn.join(' | ') : ''];
    ITEMS.forEach(function (x) {
      var it = item(x[0]); L.push('', '== ' + it.name + ' [' + (PILL[it.state] || it.state) + '] ' + (it.line || ''));
      it.checks.forEach(function (c) { L.push('  [' + c.s.toUpperCase() + '] ' + c.t); });
      if (it.tech) L.push('  technical: ' + it.tech.trim().replace(/\n/g, '\n  technical: '));
    });
    L.push('', '== Problems on customers\u2019 phones (7 days)');
    if (R.reportsWhy) L.push('  not readable: ' + R.reportsWhy);
    else groups(168).forEach(function (x) { L.push('  ' + x.n + '\u00d7 [' + x.k.sev + '] ' + x.kind + ' on ' + x.page + ': ' + x.message + ' \u00b7 last ' + x.last + ' \u00b7 ' + Object.keys(x.dev).join(', ') + (x.rows[0].detail && x.rows[0].detail.where ? ' \u00b7 ' + x.rows[0].detail.where : '')); });
    L.push('', '== Shop data & settings (technical check: ' + R.dataState + ')');
    R.data.forEach(function (x) { var d = document.createElement('div'); d.innerHTML = x.html; L.push('  [' + x.s.toUpperCase() + '] ' + x.t + ': ' + d.textContent.replace(/\s+/g, ' ').trim().slice(0, 400)); });
    if (R.waTest && R.waTest.msg) L.push('', '== WhatsApp test message: ' + (R.waTest.ok ? 'SENT' : 'NOT SENT') + ' \u2014 ' + R.waTest.msg);
    return L.filter(function (l, i) { return l !== '' || L[i - 1] !== ''; }).join('\n');
  }
  function copyRep(i) {
    var x = groups(R.period)[i]; if (!x) return '';
    return ['VISION GALLERY — problem on customers’ phones', 'Build of this Admin: ' + VERSION, 'What: ' + x.k.t + ' (' + x.kind + ', page ' + x.page + ')', 'Times: ' + x.n + ' · first ' + x.first + ' · last ' + x.last,
      'Message: ' + x.message, 'Phones: ' + Object.keys(x.dev).join(', '), 'Detail of the last one: ' + JSON.stringify(x.rows[0].detail)].join('\n');
  }
  async function clearOld(btn) {
    if (typeof need === 'function' && !need('health.edit')) return;
    if (!confirm('Delete the problem reports that are older than 7 days?\n\nReports from the last 7 days stay.')) return;
    btn.disabled = true; btn.textContent = 'CLEARING…';
    try {
      var before = new Date(Date.now() - 7 * 86400000).toISOString();
      var r = await sb('/rest/v1/site_health?created_at=lt.' + encodeURIComponent(before), { method: 'DELETE', headers: { Prefer: 'return=representation' } });
      btn.textContent = r.ok ? 'CLEARED ' + ((r.body && r.body.length) || 0) + ' OLD REPORTS' : 'COULD NOT CLEAR: ' + why(r);
    } catch (e) { btn.textContent = 'COULD NOT CLEAR: ' + e.message; }
  }

  document.addEventListener('click', function (e) {
    var t = e.target && e.target.closest ? e.target.closest('[data-hprun],[data-hptoggle],[data-hpcopy],[data-hpcopyrep],[data-hpsql],[data-hpperiod],[data-hpclear],[data-hpgo],[data-hpcopyall],[data-hpwatest],[data-hpwatchtest]') : null;
    if (!t || !$('healthRoot') || !$('healthRoot').contains(t)) return;
    if (t.dataset.hprun) { run(); return; }
    if (t.dataset.hptoggle) { R.open[t.dataset.hptoggle] = !R.open[t.dataset.hptoggle]; render(); return; }
    if (t.dataset.hpcopy) { copy(copyItem(t.dataset.hpcopy), t); return; }
    if (t.dataset.hpcopyall) { copy(copyAll(), t); return; }
    if (t.dataset.hpwatest) {
      var n = ($('hpWaNum') || {}).value || '';
      R.waTest = { num: n, busy: true }; render();
      waTest(n).then(function (r) { R.waTest = { num: n, ok: r.ok, msg: r.msg }; render(); });
      return;
    }
    if (t.dataset.hpwatchtest) {
      R.watchTest = { busy: true }; render();
      watchTest().then(function (r) { R.watchTest = { ok: r.ok, msg: r.msg }; render(); });
      return;
    }
    if (t.dataset.hpcopyrep) { copy(copyRep(Number(t.dataset.hpcopyrep)), t); return; }
    if (t.dataset.hpsql) { copy(SQL, t); return; }
    if (t.dataset.hpperiod) { R.period = Number(t.dataset.hpperiod); render(); return; }
    if (t.dataset.hpclear) { clearOld(t); return; }
    if (t.dataset.hpgo) { var c = $('hpCust'); if (c) c.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
  });

  /* ---------------- the HEALTH tab badge: red problems from customers in the last 24 hours ---------------- */
  function setBadge(n) { var b = $('healthBadge'); if (!b) return; b.textContent = n; b.hidden = !(n > 0); }
  async function badgeFromReports() {
    try {
      if (!canDo('health.view') || !(g.VGAuth && g.VGAuth.signedIn && g.VGAuth.signedIn())) return;
      var since = new Date(Date.now() - 86400000).toISOString();
      var r = await sb('/rest/v1/site_health?select=kind,detail&created_at=gte.' + encodeURIComponent(since) + '&limit=200');
      if (!r.ok || !Array.isArray(r.body)) return;
      var n = r.body.filter(function (x) { return !kindOf(x).info; }).length;
      if (!R || !R.at) setBadge(n);
    } catch (e) {}
  }
  (function waitForLogin(tries) {
    if (typeof ME !== 'undefined' && ME) { setTimeout(badgeFromReports, 2500); return; }
    if (tries > 0) setTimeout(function () { waitForLogin(tries - 1); }, 2000);
  })(90);

  g.VGHealthPage = {
    open: function () { if (!R) { R = fresh(); render(); run(); } else render(); },
    run: run, render: render, waTest: waTest, state: function () { return R; }, SQL: SQL, VERSION: VERSION, groups: function (p) { return groups(p); }, kindOf: kindOf, cardOf: cardOf
  };
})(window);

/* side45.js -- THE CUSTOMER'S 45-DEGREE STEP (d17.23, 1 Oct 2026)

   A layer over the try-on. The customer has already taken the front photo. Here she turns her head
   about halfway, a still photo is taken (by itself when the turn is right, or by TAKE PHOTO at any
   time -- the shutter is never locked), and the frame's own 45-degree cut-out is put on it.

   Rules it keeps
     - OFF unless Settings has try45On (the shop switches it on after trying it on her own face).
     - Only frames whose 45 views are approved (not hidden, not pending) and have fit points.
     - The photo never leaves the phone (kept in this browser, next to the front photo).
     - The front try-on is not touched: this file only reads vg_selfie and adds its own layer.
     - If the face or the ear cannot be judged, it says what to do and asks for a retake.
     - The frame's own 45 picture sits beside the customer's, and the two switch together.

   Public: VGSide45.open(product), .eligible(product), .enabled(), .viewsOf(product), .clearTurned() */
(function (g) {
  'use strict';
  var LS = 'vg_selfie45';
  var HOLD_MS = 900;             /* the turn must stay right this long before the photo is taken by itself */
  var LIVE_MS = 130;             /* live detection rhythm */

  var $ = function (id) { return document.getElementById(id); };
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }

  /* ---------- the rules ---------- */
  /* d17.39 SHOP TEST MODE: open the shop with ?try45=1 and the side view works for that visit only (this tab), even
     while it is switched off in Settings -- the shop tries it on its own face before customers ever see it. */
  try { if (/[?&]try45=1\b/.test(g.location.search)) g.sessionStorage.setItem('vg_try45', '1'); if (/[?&]try45=0\b/.test(g.location.search)) g.sessionStorage.removeItem('vg_try45'); } catch (e) {}
  function testMode() { try { return g.sessionStorage.getItem('vg_try45') === '1'; } catch (e) { return false; } }
  /* d17.67 (shop, 6 Oct): the side look is part of the try-on now -- on unless Settings turns it off (try45On === false) */
  function enabled() { var s = (g.VG_CONFIG && g.VG_CONFIG.shop) || {}; return s.try45On !== false || testMode(); }
  function frontSelfie() { try { return JSON.parse(localStorage.getItem('vg_selfie') || 'null'); } catch (e) { return null; } }
  function frontKey(s) { return s && s.data ? 'p' + s.data.length + '_' + s.data.slice(-24).replace(/[^a-zA-Z0-9]/g, '') : null; }   /* the same rule the shop uses for SELFIE.id */

  function viewsOf(p, tryNoFit) {
    if (!p) return [];
    var hid = [].concat(Array.isArray(p.hideViews) ? p.hideViews : [], Array.isArray(p.pendingViews) ? p.pendingViews : []);
    var out = [];
    function add(key, url, fit) {
      if (!url || hid.indexOf(key) >= 0) return;
      if (fit === null) { if (tryNoFit) out.push({ key: key, url: url, robotFit: undefined, pageOnly: true }); return; }   /* robot found no lens openings: d17.72 the page may still find them (thin rims) */
      if (fit && !fit.bridge && !fit.robotClean) return;   /* d17.82: {robotClean} alone = hand-fixed robot picture: the page finds the points */
      out.push({ key: key, url: url, robotFit: fit });
    }
    add('angle', p.tryOnAngleUrl, p.tryOnAngleFit);
    add('angleR', p.tryOnAngleRUrl, p.tryOnAngleRFit);
    return out;
  }
  function eligible(p) {
    if (!enabled() || !p || !p.tryOnUrl) return false;
    if (p.awaitingCheck || p.draft || p.deleted) return false;
    return viewsOf(p).length > 0;
  }

  /* ---------- the turned photos kept on this phone ---------- */
  function readTurned() {
    var s = frontSelfie(), k = frontKey(s), o = null;
    try { o = JSON.parse(localStorage.getItem(LS) || 'null'); } catch (e) { o = null; }
    if (!o || !k || o.fk !== k) return { fk: k, L: null, R: null };      /* a new front photo makes the old turned ones stale */
    return { fk: k, L: o.L || null, R: o.R || null };
  }
  function writeTurned(o) {
    try { localStorage.setItem(LS, JSON.stringify(o)); return true; }
    catch (e) {
      try { var s = { fk: o.fk, L: o.L, R: o.R }; if (s.L && s.R) { localStorage.removeItem(LS); s.R = null; localStorage.setItem(LS, JSON.stringify(s)); } } catch (e2) {}
      return false;
    }
  }
  function clearTurned() { try { localStorage.removeItem(LS); } catch (e) {} }

  /* ---------- small helpers ---------- */
  function loadImg(src, cors) { return new Promise(function (res, rej) { var i = new Image(); if (cors) i.crossOrigin = 'anonymous'; i.onload = function () { res(i); }; i.onerror = function () { rej(new Error('picture did not load')); }; i.src = src; }); }
  function shrink(canvas, maxSide, q) {
    var k = Math.min(1, maxSide / Math.max(canvas.width, canvas.height)), c = canvas;
    if (k < 1) { c = document.createElement('canvas'); c.width = Math.round(canvas.width * k); c.height = Math.round(canvas.height * k); c.getContext('2d').drawImage(canvas, 0, 0, c.width, c.height); }
    return { data: c.toDataURL('image/jpeg', q || 0.86), k: k, w: c.width, h: c.height };
  }
  function scaleFace(f, k) {                                  /* a face measured on a bigger picture, expressed on the shrunk one */
    if (!f || k === 1) return f;
    var o = JSON.parse(JSON.stringify(f));
    ['pupilR', 'pupilL', 'bridge', 'noseSeat', 'eyeOutR', 'eyeOutL', 'browR', 'browL', 'noseTip', 'chin', 'brow', 'templeR', 'templeL', 'cheekR', 'cheekL'].forEach(function (n) { if (o[n]) { o[n].x *= k; o[n].y *= k; } });
    ['pd', 'irisPx', 'faceL', 'faceW', 'jawW', 'browW', 'noseAxisX', 'w', 'h'].forEach(function (n) { if (typeof o[n] === 'number') o[n] *= k; });
    return o;
  }
  function slotOfYaw(y) { return y > 0 ? 'L' : 'R'; }          /* nose toward the left of the (mirrored) picture = turned to her own left */
  var SLOT_NAME = { L: 'SIDE LOOK \u00b7 LEFT', R: 'SIDE LOOK \u00b7 RIGHT' };
  var SLOT_SAY = { L: 'Turn your head a little to your LEFT (about 30\u00b0).', R: 'Turn your head a little to your RIGHT (about 30\u00b0).' };

  /* ---------- the layer ---------- */
  var CSS = '#s45{position:fixed;inset:0;z-index:2147483000;background:rgba(10,14,22,.94);color:#fff;display:none;flex-direction:column;font:15px/1.4 system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;}' +
    '#s45.on{display:flex}' +
    '#s45 .s45-top{display:flex;align-items:center;justify-content:space-between;padding:calc(10px + env(safe-area-inset-top)) 14px 8px}' +
    '#s45 .s45-top b{font-size:1rem;letter-spacing:.04em}#s45 .s45-top small{display:block;font-size:.72rem;opacity:.7}' +
    '#s45 .s45-x{background:none;border:0;color:#fff;font-size:2rem;line-height:1;padding:0 6px;cursor:pointer}' +
    '#s45 .s45-body{flex:1;overflow:auto;padding:0 14px 18px;-webkit-overflow-scrolling:touch}' +
    '#s45 .s45-msg{font-size:1.02rem;font-weight:700;text-align:center;margin:8px 0}' +
    '#s45 .s45-msg.ok{color:#7ee2a7}#s45 .s45-msg.warn{color:#ffd27a}#s45 .s45-msg.bad{color:#ff9d9d}' +
    '#s45 .s45-sub{font-size:.8rem;opacity:.8;text-align:center;margin:0 0 8px}' +
    '#s45 .s45-cam{position:relative;border-radius:14px;overflow:hidden;background:#000;max-width:520px;margin:0 auto}' +
    '#s45 .s45-cam video{width:100%;display:block;transform:scaleX(-1);max-height:62vh;object-fit:cover}' +
    '#s45 .s45-bar{height:7px;border-radius:4px;background:rgba(255,255,255,.18);margin:8px auto 0;max-width:520px;overflow:hidden}' +
    '#s45 .s45-bar i{display:block;height:100%;width:0;background:#7ee2a7;transition:width .12s}' +
    '#s45 .s45-btns{display:flex;gap:8px;flex-wrap:wrap;max-width:520px;margin:12px auto 0}' +
    '#s45 .s45-btns button,#s45 .s45-btns label{flex:1 1 140px;min-height:48px;border-radius:10px;border:1px solid rgba(255,255,255,.35);background:transparent;color:#fff;font-weight:700;font-size:.85rem;letter-spacing:.04em;cursor:pointer;display:flex;align-items:center;justify-content:center;text-align:center;padding:6px 10px}' +
    '#s45 .s45-btns .gold{background:#c9a24b;border-color:#c9a24b;color:#111}' +
    '#s45 .s45-tabs{display:flex;gap:8px;max-width:520px;margin:6px auto 10px}' +
    '#s45 .s45-tabs button{flex:1;min-height:44px;border-radius:10px;border:1px solid rgba(255,255,255,.35);background:transparent;color:#fff;font-weight:700;font-size:.85rem;cursor:pointer}' +
    '#s45 .s45-tabs button.on{background:#fff;color:#111;border-color:#fff}' +
    '#s45 .s45-pair{display:flex;gap:8px;max-width:620px;margin:0 auto}' +
    '#s45 .s45-pair figure{flex:1 1 0;min-width:0;margin:0;text-align:center}' +
    '#s45 .s45-pair img{width:100%;border-radius:10px;display:block;background:#fff;object-fit:contain;aspect-ratio:4/5}' +
    '#s45 .s45-pair figure.you img{background:#222}' +
    '#s45 .s45-pair figcaption{font-size:.72rem;opacity:.8;margin-top:4px}' +
    '#s45 .s45-note{font-size:.72rem;opacity:.65;text-align:center;max-width:520px;margin:12px auto 0}';

  var ST = null;     /* the open session */

  function build() {
    if ($('s45')) return;
    var st = document.createElement('style'); st.id = 's45css'; st.textContent = CSS; document.head.appendChild(st);
    var d = document.createElement('div'); d.id = 's45'; d.setAttribute('role', 'dialog'); d.setAttribute('aria-modal', 'true'); d.setAttribute('aria-label', 'Side view, 45 degrees');
    d.innerHTML = '<div class="s45-top"><div><b>MY SIDE LOOK</b><small id="s45Name"></small></div><button type="button" class="s45-x" id="s45X" aria-label="Close">&times;</button></div><div class="s45-body" id="s45Body"></div>';
    document.body.appendChild(d);
    $('s45X').addEventListener('click', close);
  }

  function setBody(html) { $('s45Body').innerHTML = html; }

  /* ---------- opening ---------- */
  async function open(p, opts) {
    build();
    if (!enabled()) return false;
    var sf = frontSelfie();
    ST = { p: p, sf: sf, slot: null, tab: null, stream: null, mesh: null, live: null, ring: [], holdSince: 0, alive: true, shots: readTurned(), views: null, ref: null, busy: false, loopTimer: 0, temple: undefined,
           onDone: (opts && typeof opts.onDone === 'function') ? opts.onDone : null, onCancel: (opts && typeof opts.onCancel === 'function') ? opts.onCancel : null };   /* d17.70: opened from the SIDE 30\u00b0 tab -- photo only, the try-on shows the result */
    $('s45').classList.add('on'); document.documentElement.style.overflow = 'hidden';
    $('s45Name').textContent = (p && p.name) || '';
    if (!sf || !sf.face || !sf.data) { setBody('<p class="s45-msg warn">Take your front try-on photo first.</p><div class="s45-btns"><button type="button" id="s45Done" class="gold">OK</button></div>'); $('s45Done').onclick = close; return true; }
    setBody('<p class="s45-msg">Getting the frame ready\u2026</p>');
    try { await prepare(); } catch (e) {
      if (!ST || !ST.alive) return true;
      var nofit = e && e.message === 'nofit';
      setBody('<p class="s45-msg bad">' + (nofit ? 'This frame\u2019s side pictures cannot be placed on a face yet.' : 'The frame\u2019s side picture could not be loaded.') + '</p><p class="s45-sub">' + (nofit ? 'Try another frame.' : 'Check your connection and try again.') + '</p><div class="s45-btns"><button type="button" id="s45Done" class="gold">CLOSE</button></div>'); $('s45Done').onclick = close; return true;
    }
    if (!ST || !ST.alive) return true;
    if (ST.onDone) return startCapture(opts.slot === 'R' ? 'R' : 'L');
    if (!ST.shots.L && !ST.shots.R) return startCapture('L'); else return showResult(ST.shots.L ? 'L' : 'R');
  }

  async function prepare() {
    var p = ST.p, V = viewsOf(p, true), loaded = [];
    var front = await loadImg(p.tryOnUrl, true).catch(function () { return null; });
    for (var i = 0; i < V.length; i++) {
      var img = await loadImg(V[i].url, true);
      var fit = VG45.fitFor(img, V[i].robotFit);
      if (fit) loaded.push({ key: V[i].key, url: V[i].url, img: img, fit: fit });
    }
    if (!loaded.length) throw new Error('nofit');
    ST.views = loaded;
    ST.ref = VG45.frontReference(front, p.size || {}, ST.sf.face, undefined);
  }

  /* ---------- capture ---------- */
  async function startCapture(slot) {
    if (!ST) return true;
    ST.slot = slot; ST.ring = []; ST.holdSince = 0;
    setBody('<p class="s45-msg" id="s45Msg">Starting the camera\u2026</p><p class="s45-sub" id="s45Sub">' + esc(SLOT_SAY[slot]) + '</p>' +
      '<div class="s45-cam"><video id="s45Vid" autoplay playsinline muted></video></div><div class="s45-bar"><i id="s45Bar"></i></div>' +
      '<div class="s45-btns"><button type="button" id="s45Shoot" class="gold">TAKE PHOTO</button>' +
      '<label>USE A PHOTO<input type="file" id="s45File" accept="image/*" hidden></label>' +
      (ST.onDone ? '<button type="button" id="s45Cancel">CANCEL</button>' : (ST.shots.L || ST.shots.R ? '<button type="button" id="s45Back">BACK TO RESULT</button>' : '')) + '</div>' +
      '<p class="s45-note">Phone at eye level, shoulders still \u2014 turn only your head. The photo is taken by itself when the turn is right, or tap TAKE PHOTO any time. It stays on your phone.</p>');
    $('s45Shoot').onclick = function () { shoot(false); };
    $('s45File').onchange = function (e) { var f = e.target.files && e.target.files[0]; if (f) fromFile(f); };
    if ($('s45Back')) $('s45Back').onclick = function () { stopCam(); showResult(ST.shots.L ? 'L' : 'R'); };
    if ($('s45Cancel')) $('s45Cancel').onclick = close;
    var vid = $('s45Vid');
    try {
      ST.stream = await openCamera();
      if (!ST || !ST.alive) { stopStream(ST && ST.stream); return true; }
      vid.srcObject = ST.stream; await vid.play().catch(function () {});
    } catch (e) {
      if ($('s45Msg')) { $('s45Msg').className = 's45-msg bad'; $('s45Msg').textContent = 'The camera did not open.'; }
      if ($('s45Sub')) $('s45Sub').textContent = 'Allow the camera for this site, or tap USE A PHOTO and choose a photo with your head turned halfway.';
      return true;
    }
    say('Looking for your face\u2026', '');
    try { await g.loadFaceMesh(); } catch (e) { say('The face finder could not load. Tap TAKE PHOTO and I will try on the photo.', 'warn'); return true; }
    if (!ST || !ST.alive) return true;
    try {
      ST.mesh = new g.FaceMesh({ locateFile: function (f) { return (g.FACEMESH_BASE || 'https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh@0.4/') + f; } });
      ST.mesh.setOptions({ maxNumFaces: 1, refineLandmarks: true, minDetectionConfidence: 0.3, minTrackingConfidence: 0.3 });
      ST.mesh.onResults(onLive);
    } catch (e) { say('The face finder could not start. Tap TAKE PHOTO.', 'warn'); return true; }
    loop();
    return true;
  }

  function say(t, cls, sticky) { var m = $('s45Msg'); if (!m) return; m.textContent = t; m.className = 's45-msg ' + (cls || ''); if (sticky && ST) ST.stickyUntil = Date.now() + 3500; }
  /* the live guide must not wipe out the advice about the photo that was just taken */
  function sayLive(t, cls) { if (ST && Date.now() < (ST.stickyUntil || 0)) return; say(t, cls); }
  async function openCamera() {
    var tries = [{ video: { facingMode: { exact: 'user' }, width: { ideal: 1280 }, height: { ideal: 960 } }, audio: false }, { video: { facingMode: 'user' }, audio: false }, { video: true, audio: false }], last = null;
    for (var i = 0; i < tries.length; i++) { try { return await navigator.mediaDevices.getUserMedia(tries[i]); } catch (e) { last = e; } }
    throw last || new Error('no camera');
  }
  function stopStream(s) { try { if (s) s.getTracks().forEach(function (t) { t.stop(); }); } catch (e) {} }
  function stopCam() {
    if (!ST) return;
    ST.alive2 = false; clearTimeout(ST.loopTimer);
    stopStream(ST.stream); ST.stream = null;
    try { if (ST.mesh && ST.mesh.close) ST.mesh.close(); } catch (e) {}
    ST.mesh = null;
  }

  var sending = false;
  function loop() {
    if (!ST || !ST.alive || !ST.mesh) return;
    ST.alive2 = true;
    var vid = $('s45Vid');
    (async function tick() {
      if (!ST || !ST.alive || !ST.alive2 || !ST.mesh || !vid) return;
      if (vid.videoWidth && !sending) {
        sending = true;
        try { await ST.mesh.send({ image: vid }); } catch (e) {}
        sending = false;
      }
      if (ST && ST.alive && ST.alive2) ST.loopTimer = setTimeout(tick, LIVE_MS);
    })();
  }

  function onLive(res) {
    if (!ST || !ST.alive || !ST.alive2) return;
    var vid = $('s45Vid'); if (!vid) return;
    var lm = res && res.multiFaceLandmarks && res.multiFaceLandmarks[0];
    var now = Date.now();
    if (!lm) { ST.live = null; ST.holdSince = 0; ST.lastSeen = ST.lastSeen || 0; if (now - (ST.lastSeen || 0) > 1500) sayLive('I cannot see your face. Hold the phone at eye level.', 'warn'); setBar(0); return; }
    ST.lastSeen = now;
    var face = null;
    try { face = VGOnFace.faceFromLandmarks(lm, vid.videoWidth, vid.videoHeight, true); } catch (e) {}
    if (!face) return;
    ST.live = face;
    ST.ring.push({ at: now, lm: lm.map(function (q) { return { x: q.x, y: q.y, z: q.z || 0 }; }) });
    while (ST.ring.length && now - ST.ring[0].at > 1500) ST.ring.shift();
    var turn = VG45.headTurn(face), yaw = turn.yaw || 0, want = ST.slot, rightWay = turn.state === 'ok' && slotOfYaw(yaw) === want;
    if (turn.state === 'ok' && !rightWay) { sayLive('Other way \u2014 ' + SLOT_SAY[want], 'warn'); ST.holdSince = 0; setBar(0); return; }
    if (turn.state === 'turn-more') sayLive(SLOT_SAY[want].replace('(about 30\u00b0).', '\u2014 a little more.'), 'warn');
    else if (turn.state === 'turn-less') sayLive(turn.text, 'warn');
    else sayLive('Good \u2014 hold it there.', 'ok');
    if (rightWay) {
      if (!ST.holdSince) ST.holdSince = now;
      setBar(Math.min(1, (now - ST.holdSince) / HOLD_MS));
      if (now - ST.holdSince >= HOLD_MS && !ST.busy) shoot(true);
    } else { ST.holdSince = 0; setBar(0); }
  }
  function setBar(v) { var b = $('s45Bar'); if (b) b.style.width = Math.round(v * 100) + '%'; }

  function medianLM() {
    var r = ST.ring.filter(function (x) { return Date.now() - x.at < 1500 && x.lm && x.lm.length; });
    if (r.length >= 3 && r.every(function (x) { return x.lm.length === r[0].lm.length; })) {
      return r[0].lm.map(function (_, i) {
        var xs = r.map(function (x) { return x.lm[i].x; }).sort(function (a, b) { return a - b; }), ys = r.map(function (x) { return x.lm[i].y; }).sort(function (a, b) { return a - b; }), m = r.length >> 1;
        return { x: xs[m], y: ys[m], z: 0 };
      });
    }
    return r.length ? r[r.length - 1].lm : null;
  }

  async function shoot(auto) {
    if (!ST || ST.busy) return;
    var vid = $('s45Vid');
    if (!ST.stream && vid && !vid.videoWidth) { startCapture(ST.slot); return; }          /* the camera had paused: start it again */
    if (!vid || !vid.videoWidth) { say('The camera is still starting \u2014 try once more.', 'warn'); return; }
    ST.busy = true;
    try {
      var c = document.createElement('canvas'); c.width = vid.videoWidth; c.height = vid.videoHeight;
      var x = c.getContext('2d'); x.translate(c.width, 0); x.scale(-1, 1); x.drawImage(vid, 0, 0);
      var lm = medianLM(), face = null;
      if (lm) { try { face = VGOnFace.faceFromLandmarks(lm, vid.videoWidth, vid.videoHeight, true); } catch (e) {} }
      var small = shrink(c, 1100, 0.86);
      if (!face) {
        var im = await loadImg(small.data);
        face = await VGOnFace.findFace(im, { runs: 1 });
        if (face) { await keepShot(small.data, face, auto); return; }
        say('I could not find your face in that photo. Take it again at eye level.', 'bad', true); ST.busy = false; return;
      }
      await keepShot(small.data, scaleFace(face, small.k), auto);
    } catch (e) { say('That photo did not work. Try again.', 'bad', true); if (ST) ST.busy = false; }
  }

  async function fromFile(f) {
    if (!ST) return;
    ST.busy = true; say('Reading your photo\u2026', '');
    try {
      var url = URL.createObjectURL(f), img = await loadImg(url);
      var cv = document.createElement('canvas'); cv.width = img.naturalWidth; cv.height = img.naturalHeight; cv.getContext('2d').drawImage(img, 0, 0);
      var small = shrink(cv, 1100, 0.86), im = await loadImg(small.data);
      await g.loadFaceMesh().catch(function () {});
      var face = await VGOnFace.findFace(im, { runs: 1 });
      if (!face) { say('I could not find a face in that photo. Choose one where your face is clear and your head is turned halfway.', 'bad', true); ST.busy = false; return; }
      await keepShot(small.data, face, false);
    } catch (e) { say('That photo could not be read.', 'bad', true); if (ST) ST.busy = false; }
  }

  /* judge the turn BEFORE keeping the photo: a photo that cannot be used is not saved */
  async function keepShot(data, face, auto) {
    var turn = VG45.headTurn(face);
    if (turn.state === 'no-face') { say(VG45.ADVICE['no-face'], 'bad', true); ST.busy = false; return; }
    if (turn.state === 'turn-more') { say(VG45.ADVICE['turn-more'], 'bad', true); ST.busy = false; return; }
    if (turn.state === 'turn-less') { say(VG45.ADVICE['turn-less'], 'bad', true); ST.busy = false; return; }
    var slot = slotOfYaw(turn.yaw);
    var o = readTurned(); o.fk = frontKey(ST.sf);
    o[slot] = { data: data, face: face, at: Date.now() };
    var saved = writeTurned(o);
    ST.shots = readTurned();
    if (!ST.shots[slot]) ST.shots[slot] = o[slot];            /* storage was full: keep it for this visit only */
    stopCam(); ST.busy = false;
    if (ST.onDone) { var cb = ST.onDone; ST.onCancel = null; close(); try { cb(slot); } catch (e) {} return; }   /* d17.70: back to the try-on, which shows the side */
    await showResult(slot, !saved);
  }

  /* ---------- the result ---------- */
  async function showResult(tab, notSaved) {
    if (!ST) return true;
    ST.tab = tab; stopCam();
    var other = tab === 'L' ? 'R' : 'L', shot = ST.shots[tab];
    var tabs = '<div class="s45-tabs"><button type="button" data-tab="L" class="' + (tab === 'L' ? 'on' : '') + '">' + SLOT_NAME.L + '</button><button type="button" data-tab="R" class="' + (tab === 'R' ? 'on' : '') + '">' + SLOT_NAME.R + '</button></div>';
    if (!shot) {
      setBody(tabs + '<p class="s45-msg">No ' + SLOT_NAME[tab] + ' photo yet.</p><div class="s45-btns"><button type="button" id="s45Take" class="gold">TAKE ' + SLOT_NAME[tab] + ' PHOTO</button><button type="button" id="s45Done">CLOSE</button></div>');
      wireTabs(); $('s45Take').onclick = function () { startCapture(tab); }; $('s45Done').onclick = close; return true;
    }
    var faceImg = await loadImg(shot.data).catch(function () { return null; });
    var view = faceImg ? VG45.pickView(shot.face, ST.views) : null;
    var html = tabs, advice = '', composite = null, report = null;
    if (!faceImg) { advice = 'This photo could not be read. Take it again.'; }
    else if (!view) { advice = 'This frame has no side picture for this side yet.'; }
    else {
      if (ST.temple === undefined) { ST.temple = []; try { ST.temple = await VG45.loadTemples(ST.p, function (u) { return loadImg(u, true); }); } catch (e) {} }   /* d17.69: both 90 photos (logo the right way round); read with CORS so the strip can be measured */
      var r = VG45.fit45({ faceImg: faceImg, face: shot.face, cutImg: view.img, fit: view.fit, frontRef: ST.ref, sizes: ST.p.size || {}, temple: ST.temple });
      if (r.error) advice = r.advice || 'This photo could not be used. Take it again.';
      else { composite = r.canvas.toDataURL('image/jpeg', 0.9); report = r.report; }
    }
    if (composite) {
      html += '<p class="s45-msg ok">' + SLOT_NAME[tab] + ' \u2014 ' + esc((ST.p && ST.p.name) || 'your frame') + '</p>' +
        '<div class="s45-pair"><figure class="you"><img id="s45You" alt="The frame on you, side view" src="' + composite + '"><figcaption>On you</figcaption></figure>' +
        '<figure><img id="s45Frame" alt="The frame, side view" src="' + esc(view.url) + '"><figcaption>The frame, same side</figcaption></figure></div>';
    } else html += '<p class="s45-msg warn">' + esc(advice) + '</p>';
    if (notSaved) html += '<p class="s45-sub">This phone is short of space, so this photo is kept only until you close this.</p>';
    html += '<div class="s45-btns"><button type="button" id="s45Retake" class="gold">' + (composite ? 'RETAKE ' + SLOT_NAME[tab] : 'TAKE IT AGAIN') + '</button>' +
      (ST.shots[other] ? '' : '<button type="button" id="s45Other">ADD ' + SLOT_NAME[other] + ' PHOTO</button>') + '<button type="button" id="s45Done">CLOSE</button></div>' +
      '<p class="s45-note">A visual estimate from your photo and the frame\u2019s measurements. Your photos stay on this phone.</p>';
    setBody(html); wireTabs();
    $('s45Retake').onclick = function () { startCapture(tab); };
    if ($('s45Other')) $('s45Other').onclick = function () { startCapture(other); };
    $('s45Done').onclick = close;
    ST.lastReport = report;
    return true;
  }
  function wireTabs() { document.querySelectorAll('#s45 [data-tab]').forEach(function (b) { b.onclick = function () { showResult(b.getAttribute('data-tab')); }; }); }

  function close() {
    var cancelled = ST && ST.onCancel;
    if (ST) { ST.alive = false; ST.alive2 = false; stopCam(); }
    var d = $('s45'); if (d) d.classList.remove('on');
    document.documentElement.style.overflow = ''; ST = null;
    if (cancelled) try { cancelled(); } catch (e) {}          /* d17.70: closed without a photo -- the try-on goes back to FRONT */
  }
  document.addEventListener('visibilitychange', function () { if (document.hidden && ST && ST.stream) { stopCam(); if ($('s45Msg')) say('The camera paused. Tap TAKE PHOTO to start it again.', 'warn'); } });

  /* d17.70 THE SIDE 30° TAB in the try-on (shop, 7 Oct: "first click for the front, second click for the side"):
     the side picture for one frame from the customer's saved turned photo, without opening the layer.
     Returns { src, report } or { need: 'front' | 'photo' } or { error, advice }. Frames are prepared once per visit. */
  var FRAMES = {};
  async function prepFrame(p, sf) {
    var key = p.id + '|' + frontKey(sf);
    if (FRAMES[key]) return FRAMES[key];
    var job = (async function () {
      var V = viewsOf(p, true), views = [];
      var front = await loadImg(p.tryOnUrl, true).catch(function () { return null; });
      for (var i = 0; i < V.length; i++) {
        try { var img = await loadImg(V[i].url, true); var fit = VG45.fitFor(img, V[i].robotFit); if (fit) views.push({ key: V[i].key, url: V[i].url, img: img, fit: fit }); } catch (e) {}
      }
      if (!views.length) return { error: 'nofit' };
      var temples = []; try { temples = await VG45.loadTemples(p, function (u) { return loadImg(u, true); }); } catch (e) {}
      return { views: views, ref: VG45.frontReference(front, p.size || {}, sf.face, undefined), temples: temples };
    })();
    FRAMES[key] = job;
    var r = await job; if (r.error) delete FRAMES[key];
    return r;
  }
  async function sideImage(p, slot) {
    if (!p || !g.VG45) return { error: 'failed', advice: 'The side view could not be made.' };
    var sf = frontSelfie(); if (!sf || !sf.face || !sf.data) return { need: 'front' };
    var shot = readTurned()[slot === 'R' ? 'R' : 'L']; if (!shot) return { need: 'photo' };
    var F = await prepFrame(p, sf);
    if (F.error) return { error: 'nofit', advice: 'This frame’s side pictures cannot be placed on a face yet.' };
    var faceImg = await loadImg(shot.data).catch(function () { return null; });
    if (!faceImg) return { error: 'photo', advice: 'Your side photo could not be read. Tap RETAKE.' };
    var view = VG45.pickView(shot.face, F.views);
    if (!view) return { error: 'no-view', advice: 'This frame has no side picture for this side yet.' };
    var r = VG45.fit45({ faceImg: faceImg, face: shot.face, cutImg: view.img, fit: view.fit, frontRef: F.ref, sizes: p.size || {}, temple: F.temples });
    if (r.error) return { error: r.error, advice: r.advice || 'This photo could not be used. Tap RETAKE.' };
    return { src: r.canvas.toDataURL('image/jpeg', 0.9), report: r.report };
  }
  /* d17.72: a frame whose 30° pictures the robot could not read (thin metal rims) is checked by the page itself, once */
  function maybe(p) { return !!(p && !eligible(p) && viewsOf(p, true).length && enabled() && p.tryOnUrl && !p.awaitingCheck && !p.draft && !p.deleted); }
  var CHECKED = {};
  function checkSide(p) {
    if (!p) return Promise.resolve(false);
    if (eligible(p)) return Promise.resolve(true);
    if (!maybe(p)) return Promise.resolve(false);
    if (CHECKED[p.id]) return CHECKED[p.id];
    CHECKED[p.id] = (async function () {
      var V = viewsOf(p, true);
      for (var i = 0; i < V.length; i++) { try { var img = await loadImg(V[i].url, true); if (VG45.fitFor(img, V[i].robotFit)) return true; } catch (e) {} }
      return false;
    })();
    return CHECKED[p.id];
  }
  function hasShot(slot) { return !!readTurned()[slot === 'R' ? 'R' : 'L']; }
  function shootSide(p, slot, onDone, onCancel) { return open(p, { slot: slot, onDone: onDone, onCancel: onCancel }); }

  /* d17.71 (shop, 7 Oct: "we already took the photos, why does it say coming soon?"): the exact reason a frame has no
     side view yet, in plain words, for admin and the check page. '' = the side view is ready. */
  function whyNot(p) {
    if (!p) return 'no frame';
    if (!enabled()) return 'the side view is switched off in Settings';
    if (p.deleted) return 'deleted';
    if (p.draft) return 'still a draft — fill the details and tap SAVE & PUT LIVE';
    if (!p.tryOnUrl) return 'the robot has not cut the front photo yet';
    if (p.awaitingCheck) return 'waiting in TO CHECK — tap APPROVE';
    if (viewsOf(p).length) return '';
    var hid = Array.isArray(p.hideViews) ? p.hideViews : [], pend = Array.isArray(p.pendingViews) ? p.pendingViews : [];
    var prob = (p.viewProblems && typeof p.viewProblems === 'object') ? p.viewProblems : {};
    var gal = Array.isArray(p.gallery) ? p.gallery : [], ap = (p.anglePhotos && typeof p.anglePhotos === 'object') ? p.anglePhotos : {};
    var hasPhoto = { angle: !!(p.rawAngleUrl || ap.angle || gal.some(function (x) { return x && x.view === 'angle'; })),
                     angleR: !!(p.rawAngleRUrl || ap.angleR || gal.some(function (x) { return x && x.view === 'angle-right'; })) };
    var out = [];
    [['angle', 'tryOnAngleUrl', 'tryOnAngleFit', '30° LEFT'], ['angleR', 'tryOnAngleRUrl', 'tryOnAngleRFit', '30° RIGHT']].forEach(function (v) {
      var k = v[0], url = p[v[1]], fit = p[v[2]], lbl = v[3];
      if (!url) {
        if (prob[k]) out.push(lbl + ': the robot could not cut it (' + prob[k] + ') — take that photo again');
        else if (!hasPhoto[k]) out.push(lbl + ': no photo on this frame — add it in EDIT (photos 2 and 3)');
        else if (Number(p.tryOnViewsV || 0) < 2) out.push(lbl + ': photo is there but not cut yet — older frame: run the robot with views:' + ((String(p.name || '').match(/VG-?\d+/i) || [p.name || p.id])[0]));
        else out.push(lbl + ': photo is there but not cut yet — wait 10 minutes for the robot');
      }
      else if (pend.indexOf(k) >= 0) out.push(lbl + ': waiting in TO CHECK — tap APPROVE');
      else if (hid.indexOf(k) >= 0) out.push(lbl + ': HIDDEN in TO CHECK — tap SHOW');
      else if (fit === null) out.push(lbl + ': the robot found no lens openings (thin rim?) — the try-on looks for them itself; if SIDE VIEW stays grey, retake it turned only 30° so both lenses show');
      else if (fit && !fit.bridge && !fit.robotClean) out.push(lbl + ': fit points incomplete — retake it');
    });
    return out.join(' · ') || 'no usable 30° picture';
  }

  g.VGSide45 = { maybe: maybe, checkSide: checkSide, whyNot: whyNot, sideImage: sideImage, shootSide: shootSide, hasShot: hasShot, open: open, close: close, eligible: eligible, enabled: enabled, viewsOf: viewsOf, clearTurned: clearTurned, readTurned: readTurned, _state: function () { return ST; } };
})(window);

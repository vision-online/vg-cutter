/* Vision Gallery Admin -- DELIVERY (d17.205, shop 2 Nov).
   Orders -> DELIVERY on any order: send it by COURIER (Shiprocket), by a same-day RIDER (Borzo), or BY HAND (any other
   courier or app). After that the same button shows where the parcel is. Settings -> Delivery holds each branch's
   address and phone (the rider collects from there) and the parcel size.
   The website's server does the booking (api/parcel.js); this file is only the buttons.
   d17.206 (shop, 2 Nov): COURIER (Shiprocket) is the first choice for every order, Mumbai too; the rider is second.
   CASH ON DELIVERY: "Collect on delivery Rs X" (the balance: total - paid) -- the courier collects it and pays it into the
   bank. When the parcel is delivered the order is marked paid here, and "Rs X to come" shows until staff tap MONEY
   RECEIVED IN BANK. Orders shows how many cash parcels were sent, delivered and came back.
   d17.207 (shop, 3 Nov): SEE PRICES shows the courier AND the same-day rider side by side (choose per order); an EXPRESS
   order opens on the rider. A parcel the courier brings back: RECEIVED BACK AT SHOP, then SEND AGAIN or CANCEL ORDER; a
   mobile that refused cash on delivery before is pointed out. RETURN / EXCHANGE on a delivered order -- for the shop
   only, nothing of it shows on the customer's page: the reason, how the glasses come back (the customer brings them,
   a Shiprocket courier pickup, a Borzo rider, by hand), RECEIVED AT SHOP, then what was done (remake, exchange, refund,
   repair). The customer gets one WhatsApp: when a pickup is booked. */
(function () {
  'use strict';
  const SITE = 'https://visiongallery.me';
  const H = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const $id = id => document.getElementById(id);
  const inr = n => '₹' + (Math.round(Number(n) * 100) / 100).toLocaleString('en-IN');
  let CHECK = null, OPEN = null, BUSY = false, QUOTE = null, PICKUPS = null, MODE = '', PANEL = 'dlv', RMODE = '', RQUOTE = null;

  /* ---------- styles ---------- */
  const css = document.createElement('style');
  css.textContent = `
  .dlv-chip{display:inline-flex;align-items:center;gap:4px;font-size:.68rem;font-weight:800;letter-spacing:.06em;padding:3px 8px;border-radius:999px;background:#E7EEFF;color:#1741B3;white-space:nowrap}
  .dlv-chip.ok{background:#DDF3E6;color:#17834F}.dlv-chip.bad{background:#FFE6E2;color:#B3261E}.dlv-chip.out{background:#C8FF1A;color:#06143E}.dlv-chip.due{background:#FFF3DF;color:#8A5300}
  #dlv .codbox{background:#F6F8FD;border:1.5px solid #CDD8EC;border-radius:12px;padding:2px 12px 10px;margin:10px 0}
  #dlv .codbox input{font-weight:800;font-size:18px}
  .dlvCodLine{display:flex;flex-wrap:wrap;gap:6px 14px;align-items:center;margin:0 0 12px;padding:10px 12px;border-radius:12px;background:#FFF8EA;color:#5C3A00;font-size:.84rem;font-weight:700}
  .dlvCodLine b{color:#06143E}
  #dlv{position:fixed;inset:0;z-index:400;background:rgba(6,20,62,.55);display:flex;align-items:flex-end;justify-content:center}
  #dlv[hidden]{display:none}
  #dlv .dv{background:#fff;color:#0F1E3D;width:100%;max-width:640px;max-height:94vh;overflow:auto;border-radius:20px 20px 0 0;padding:16px 16px 28px;font-size:15px;line-height:1.5;box-shadow:0 -8px 40px rgba(0,0,0,.25)}
  @media(min-width:700px){#dlv{align-items:center}#dlv .dv{border-radius:20px}}
  #dlv .dv-top{display:flex;justify-content:space-between;align-items:center;gap:10px;position:sticky;top:-16px;background:#fff;padding:4px 0 10px;margin-top:-4px;z-index:2;border-bottom:1px solid #E3E9F4}
  #dlv h3{margin:0;font-size:1.02rem;letter-spacing:.04em}
  #dlv .x{border:0;background:#EEF2FA;border-radius:50%;width:38px;height:38px;font-size:1.3rem;cursor:pointer;color:#06143E}
  #dlv .who{margin:12px 0 4px;font-size:.92rem}
  #dlv .warn{background:#FFF3DF;color:#5C3A00;border-radius:12px;padding:10px 12px;margin:10px 0;font-size:.88rem;font-weight:600}
  #dlv .info{background:#EEF3FF;color:#1B2F66;border-radius:12px;padding:10px 12px;margin:10px 0;font-size:.86rem}
  #dlv .err{background:#FFE6E2;color:#8C1D14;border-radius:12px;padding:10px 12px;margin:10px 0;font-size:.88rem;font-weight:700}
  #dlv .good{background:#DDF3E6;color:#0E5A35;border-radius:12px;padding:10px 12px;margin:10px 0;font-size:.88rem;font-weight:700}
  #dlv label{display:block;font-weight:800;font-size:.8rem;margin:10px 0 4px;color:#06143E}
  #dlv input,#dlv textarea,#dlv select{width:100%;box-sizing:border-box;font:inherit;font-size:16px;border:1.5px solid #CDD8EC;border-radius:10px;padding:10px;background:#fff;color:#0F1E3D}
  #dlv textarea{min-height:64px;resize:vertical}
  #dlv .g2{display:grid;grid-template-columns:1fr 1fr;gap:8px}
  #dlv .g4{display:grid;grid-template-columns:repeat(4,1fr);gap:6px}
  #dlv .ways{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin:14px 0 4px}
  #dlv .ways button{border:1.5px solid #CDD8EC;background:#fff;border-radius:12px;padding:10px 6px;font:800 .78rem/1.25 inherit;letter-spacing:.03em;cursor:pointer;color:#06143E;min-height:58px}
  #dlv .ways button small{display:block;font-weight:600;color:#5A6987;font-size:.7rem;letter-spacing:0;margin-top:2px}
  #dlv .ways button.on{border-color:#06143E;background:#06143E;color:#fff}#dlv .ways button.on small{color:#C8FF1A}
  #dlv .ways button:disabled{opacity:.45}
  #dlv .act{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}
  #dlv .act button,#dlv .act a{flex:1 1 auto;min-height:46px;border-radius:12px;border:1.5px solid #06143E;background:#fff;color:#06143E;font:800 .8rem inherit;letter-spacing:.05em;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;text-decoration:none;padding:0 12px}
  #dlv .act .main{background:#06143E;color:#fff}
  #dlv .act .lime{background:#C8FF1A;border-color:#C8FF1A;color:#06143E;flex-direction:column}
  #dlv .act .red{border-color:#C2352A;color:#C2352A}
  #dlv .act button:disabled{opacity:.5;cursor:default}
  #dlv .rates{margin:10px 0 0;border:1.5px solid #CDD8EC;border-radius:12px;overflow:hidden}
  #dlv .rates label{display:flex;align-items:center;gap:10px;margin:0;padding:10px 12px;border-bottom:1px solid #E3E9F4;font-weight:700;font-size:.9rem;cursor:pointer}
  #dlv .rates label:last-child{border-bottom:0}
  #dlv .rates input{width:auto}
  #dlv .rates .r{margin-left:auto;font-weight:800}
  #dlv .rates small{display:block;font-weight:600;color:#5A6987;font-size:.76rem}
  #dlv .now{font-size:1.05rem;font-weight:800;margin:12px 0 2px;color:#06143E}
  #dlv dl{display:grid;grid-template-columns:auto 1fr;gap:4px 12px;margin:10px 0;font-size:.9rem}
  #dlv dt{color:#5A6987;font-weight:700}#dlv dd{margin:0;font-weight:700;word-break:break-word}
  #dlv ul.ev{list-style:none;margin:8px 0 0;padding:0;border-top:1px solid #E3E9F4}
  #dlv ul.ev li{padding:7px 0;border-bottom:1px solid #E3E9F4;font-size:.84rem}
  #dlv ul.ev span{color:#5A6987;font-size:.76rem;display:block}
  #dlv .muted{color:#5A6987;font-size:.8rem}
  #dlv .sbs{display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap}
  #dlv .sbs .use{border:1.5px solid #06143E;background:#fff;color:#06143E;border-radius:10px;padding:8px 12px;font:800 .74rem inherit;letter-spacing:.05em;cursor:pointer}
  #dlv select.rsel{margin-bottom:2px}
  #dlv .ways.r4{grid-template-columns:repeat(4,1fr)}
  #dlv .outs label{display:flex;align-items:center;gap:10px;margin:0;padding:9px 12px;border-bottom:1px solid #E3E9F4;font-weight:700;font-size:.9rem;cursor:pointer}
  #dlv .outs{border:1.5px solid #CDD8EC;border-radius:12px;overflow:hidden;margin-top:6px}
  #dlv .outs label:last-child{border-bottom:0}
  #dlv .outs input{width:auto}
  #dlvCard .bt{width:100%;border-collapse:collapse;font-size:.86rem}
  #dlvCard .bt td,#dlvCard .bt th{padding:6px 4px;border-bottom:1px solid rgba(127,140,170,.3);vertical-align:top;text-align:left}
  #dlvCard .bt input{width:100%;box-sizing:border-box}
  #dlvCard code{word-break:break-all;font-size:.78rem}
  @media(max-width:640px){#dlvCard .bt thead{display:none}#dlvCard .bt tr{display:block;padding:8px 0;border-bottom:1px solid rgba(127,140,170,.4)}#dlvCard .bt td{display:block;border:0;padding:3px 0}}
  `;
  document.head.appendChild(css);

  /* ---------- talking to the server ---------- */
  async function api(body) {
    let tok = null; try { tok = window.VGAuth ? await VGAuth.token() : null; } catch (e) {}
    try {
      const r = await fetch('/api/parcel', { method: 'POST', cache: 'no-store', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + (tok || '') },
        body: JSON.stringify(Object.assign({ by: (window.ME && ME.name) || (typeof ME !== 'undefined' && ME && ME.name) || '' }, body)) });
      let d = {}; try { d = await r.json(); } catch (e) {}
      if (r.status === 404 && !d.error) d.error = 'The delivery part of the website is not uploaded yet';
      if (r.status === 401) d.error = d.error || 'Please sign in to Admin again';
      return Object.assign({ status: r.status }, d, { ok: r.ok && d.ok !== false });
    } catch (e) { return { ok: false, status: 0, error: 'Could not reach the website -- check the internet' }; }
  }
  async function check(force) {
    if (CHECK && !force) return CHECK;
    try { const r = await fetch('/api/parcel?do=check', { cache: 'no-store' }); CHECK = r.ok ? await r.json() : { shiprocket: false, borzo: false, news: false, missing: r.status === 404 }; }
    catch (e) { CHECK = { shiprocket: false, borzo: false, news: false, offline: true }; }
    return CHECK;
  }

  /* ---------- the chip on each order ---------- */
  const CHIP = { booking: ['BOOKING…', ''], created: ['NOT BOOKED YET', 'bad'], none: ['', ''], booked: ['BOOKED', ''], picked: ['PICKED UP', ''], transit: ['ON THE WAY', ''], out: ['OUT FOR DELIVERY', 'out'], delivered: ['DELIVERED', 'ok'],
    failed: ['NOT DELIVERED', 'bad'], returning: ['COMING BACK', 'bad'], returned: ['RETURNED', 'bad'], problem: ['DELAYED', 'bad'], cancelled: ['', ''] };
  /* which parcel records on this phone the website has confirmed as its own (ref -> "rev|sig"): a record in an order a
     stranger made up is never shown as booked or delivered */
  const VERIFIED = {};
  const vkey = s => (s && typeof s === 'object') ? String(s.rev) + '|' + String(s.sig) : '';
  const trusted = o => !!(o && o.ship && VERIFIED[o.ref] && VERIFIED[o.ref] === vkey(o.ship));
  const fresh = s => !!(s && s.lockAt && Date.now() - new Date(s.lockAt).getTime() < 150e3);
  window.dlvChip = function (o) { return trusted(o) ? mainChip(o) + histDueChip(o) + retChip(o) : ''; };
  /* cash on delivery of an earlier parcel (the glasses came back and a new pair was / will be sent) still to reach the bank */
  const histDue = s => (s && Array.isArray(s.history) ? s.history : []).filter(e => e && Number(e.cod) > 0 && e.codAt && !e.codVoid && !e.test && !e.codBank);
  function histDueChip(o) { const l = histDue(o.ship); if (!l.length) return ''; const sum = r2(l.reduce((m, e) => m + Number(e.cod), 0)); return ' <span class="dlv-chip due">' + inr(sum) + ' TO COME</span>'; }
  function histDueHtml(s) {
    const l = histDue(s);
    if (!l.length) {
      /* the last earlier-parcel cash marked received in the last day can be undone */
      const done = (s && Array.isArray(s.history) ? s.history : []).filter(e => e && Number(e.cod) > 0 && e.codBank && !e.codVoid && !e.test && Date.now() - new Date(e.codBank).getTime() < 86400e3).pop();
      return done && canPay() ? '<div class="act"><button type="button" data-d="codunbankh" data-key="' + H(done.bookedAt || done.awb || done.bzOrderId || '') + '">NOT RECEIVED YET (UNDO, EARLIER PARCEL ' + inr(Number(done.cod)) + ')</button></div>' : '';
    }
    const e = l[l.length - 1], sum = r2(l.reduce((m, x) => m + Number(x.cod), 0));
    return '<div class="warn">Cash on delivery <b>' + inr(sum) + '</b> from the earlier parcel' + (e.courier || e.awb ? ' (' + H([e.courier, e.awb].filter(Boolean).join(' ')) + ')' : '') + ' is still to come from ' + H(e.via === 'shiprocket' ? 'Shiprocket' : e.via === 'borzo' ? 'Borzo' : (e.courier || 'the courier')) + '.' +
      (canPay() ? '<div class="act"><button type="button" class="main" data-d="codbankh" data-key="' + H(e.bookedAt || e.awb || e.bzOrderId || '') + '" data-amt="' + H(Number(e.cod)) + '">MONEY RECEIVED' + (e.via === 'hand' ? '' : ' IN BANK') + ' (' + inr(Number(e.cod)) + ')</button></div>' : '') + '</div>';
  }
  function mainChip(o) {
    const s = o.ship;
    if (s.step === 'booking' && !fresh(s) && s.bzTry && !s.bzOrderId) return '<span class="dlv-chip bad">\u{1F6F5} CHECK BORZO APP</span>';
    if (s.step === 'created' || (s.step === 'booking' && !fresh(s) && s.srOrderId && !s.awb)) return '<span class="dlv-chip bad">\u{1F69A} NOT BOOKED YET</span>';
    if (!s.step || s.step === 'cancelled' || s.step === 'none' || s.step === 'booking' && !fresh(s)) return '';
    const c = CHIP[s.step] || ['ON THE WAY', ''];
    if (!c[0]) return '';
    /* cash on delivery: "COD Rs X" while on its way, "Rs X TO COME" once collected until it is in the bank */
    const ca = codAmt(s);
    const cod = !(ca > 0) ? '' : s.cod.collectedAt ? (s.cod.settledAt ? '' : ' <span class="dlv-chip due">' + inr(ca) + ' TO COME</span>')
      : (LIVE_STEPS.indexOf(s.step) >= 0 ? ' <span class="dlv-chip">COD ' + inr(ca) + '</span>' : '');
    return '<span class="dlv-chip ' + c[1] + '">' + (s.kind === 'rider' ? '\u{1F6F5} ' : '\u{1F69A} ') + H(c[0]) + '</span>' + cod;
  }
  const LIVE_STEPS = ['booked', 'picked', 'transit', 'out', 'failed', 'problem'];
  const SENT_STEPS = ['booked', 'picked', 'transit', 'out', 'failed', 'returning', 'problem', 'delivered'];
  window.dlvButton = function (o) {
    const s = o && o.ship, on = !!(trusted(o) && SENT_STEPS.indexOf(s.step) >= 0);
    return '<button class="btn ' + (on ? 'btn-line' : 'btn-dark') + ' btn-sm dlvBtn" data-ref="' + H(o.ref) + '">' + (on ? 'DELIVERY STATUS' : 'DELIVERY') + '</button>';
  };

  /* ---------- the panel ---------- */
  function order(ref) { try { return (typeof getOrders === 'function' ? getOrders() : []).find(x => x.ref === ref) || null; } catch (e) { return null; } }
  function branches() { const st = (window.SET && SET.stores) || (typeof SET !== 'undefined' && SET.stores) || []; return st.filter(s => s && !/deliver/i.test(s)); }
  function shopSet() { return typeof SET !== 'undefined' ? SET : (window.SET || {}); }
  function cityState(pin) {
    pin = String(pin || '');
    if (/^4006\d\d$/.test(pin)) return ['Thane', 'Maharashtra'];
    if (/^400\d{3}$/.test(pin)) return ['Mumbai', 'Maharashtra'];
    if (/^403\d{3}$/.test(pin)) return ['', 'Goa'];
    if (/^4[0-4]\d{4}$/.test(pin)) return ['', 'Maharashtra'];
    return ['', ''];
  }
  function addrOf(o) {
    const a = o.addr && typeof o.addr === 'object' ? o.addr : null;
    const pin = String((a && a.pin) || (/(\d{6})(?!.*\d{6})/.exec(String(o.address || '')) || [])[1] || '');
    const line = a ? [a.line1, a.line2].filter(Boolean).join(', ') : String(o.address || '').replace(/,?\s*near [^,]*/i, '').replace(/,?\s*\d{6}\s*$/, '');
    const landmark = a ? (a.landmark || '') : ((/near ([^,]*)/i.exec(String(o.address || '')) || [])[1] || '');
    const cs = cityState(pin);
    return { line, pin, landmark, city: cs[0], state: cs[1] };
  }
  const remember = (k, v) => { try { localStorage.setItem('vg_dlv_' + k, v); } catch (e) {} };
  const recall = k => { try { return localStorage.getItem('vg_dlv_' + k) || ''; } catch (e) { return ''; } };
  function wrap() {
    let w = $id('dlv');
    if (!w) { w = document.createElement('div'); w.id = 'dlv'; w.hidden = true; w.innerHTML = '<div class="dv" role="dialog" aria-modal="true" aria-label="Delivery"></div>'; document.body.appendChild(w);
      w.addEventListener('click', e => { if (e.target === w) close(); }); }
    return w;
  }
  function close() { const w = $id('dlv'); if (w) w.hidden = true; OPEN = null; QUOTE = null; CODPRE = null; RQUOTE = null; }
  window.dlvOpen = async function (ref) {
    const o = order(ref); if (!o) return;
    OPEN = ref; QUOTE = null; MODE = ''; CODPRE = null; PANEL = 'dlv'; RQUOTE = null;
    const w = wrap(); w.hidden = false;
    paint('<p class="muted">Loading&hellip;</p>');
    await check(true);
    const g = await api({ do: 'get', ref });
    if (OPEN !== ref) return;
    if (g.ok) keep(ref, { ship: g.ship || null, trackKey: g.trackKey }, true);
    draw();
    if (!g.ok && g.status !== 404) msg('err', 'Could not check with the website: ' + (g.error || 'no answer') + ' -- close and open again.');
  };
  function paint(inner) {
    const o = order(OPEN) || {};
    wrap().querySelector('.dv').innerHTML = '<div class="dv-top"><h3>' + (PANEL === 'ret' ? 'RETURN' : 'DELIVERY') + ' &mdash; ' + H(o.ref || '') + '</h3><button type="button" class="x" data-d="close" aria-label="Close">&times;</button></div>' + inner;
  }
  function msg(kind, text) { const m = $id('dvMsg'); if (m) { m.className = kind; m.textContent = text; m.hidden = !text; } }
  function canEdit() { try { return typeof can === 'function' ? can('orders.edit') : true; } catch (e) { return true; } }
  function canPay() { try { return typeof can === 'function' ? can('orders.payments') : true; } catch (e) { return true; } }

  function draw() {
    if (PANEL === 'ret') return drawRet();
    const o = order(OPEN); if (!o) return close();
    /* only a record the website confirmed counts (anything else on this phone is shown as not booked) */
    const s = trusted(o) && typeof o.ship === 'object' ? o.ship : null;
    if (s && fresh(s)) return drawBusy(o, s);
    if (s && SENT_STEPS.indexOf(s.step) >= 0) return drawBooked(o, s);
    drawNew(o, s);
  }
  function drawBusy(o, s) {
    paint('<div class="now">' + (s.lockVia === 'cancel' ? 'Being cancelled right now' : 'Being booked right now') + '</div><div class="info">' + H(s.lockBy || 'Another phone') + ' started this a moment ago. Wait a minute, then tap CHECK AGAIN.</div>' +
      '<div class="act"><button type="button" data-d="reopen">CHECK AGAIN</button></div><div id="dvMsg" hidden></div>');
  }
  function waysHtml(c) {
    const b = (k, t, sm) => '<button type="button" data-way="' + k + '" class="' + (MODE === k ? 'on' : '') + '">' + t + '<small>' + sm + '</small></button>';
    /* the shop's order of choice: Shiprocket first (Mumbai too), the Borzo rider second, by hand last */
    return '<div class="ways">' + b('shiprocket', 'COURIER', c.shiprocket ? 'Shiprocket' : 'not connected') + b('borzo', 'SAME-DAY RIDER', c.borzo ? 'Borzo' + (c.borzoTest ? ' (TEST)' : '') : 'not connected') + b('hand', 'BY HAND', 'Porter, Rapido, our staff…') + '</div>';
  }
  /* cash on delivery: what is still to pay on this order (what Admin shows: total - paid) */
  const num = v => { const x = parseFloat(String(v == null ? '' : v).replace(/[,\s₹]/g, '')); return isFinite(x) ? x : 0; };
  const r2 = n => Math.round(n * 100) / 100;
  const dd = t => { try { const x = new Date(t); return isNaN(x) ? '' : x.toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' }); } catch (e) { return ''; } };
  function balanceOf(o) {
    const ps = o.payStatus || 'Unpaid';
    if (ps === 'Paid' || ps === 'Refunded') return 0;
    return Math.max(0, r2(num(o.total) - num(o.paid)));
  }
  const codAmt = s => { const c = s && s.cod; const a = c && typeof c === 'object' ? Number(c.amount) : 0; return a > 0 ? r2(a) : 0; };
  const viaName = s => s.via === 'shiprocket' ? 'Shiprocket' : s.via === 'borzo' ? 'Borzo' : (s.courier || 'the courier');
  function drawNew(o, part) {
    const c = CHECK || {}, a = addrOf(o), st = shopSet(), br = branches();
    /* Shiprocket first for every order (Mumbai too); the rider when Shiprocket is not connected (Mumbai, Thane, Navi
       Mumbai, Mira Road); otherwise by hand */
    const mumbai = /^(400\d{3}|4011\d\d)$/.test(a.pin);
    if (!MODE) MODE = o.express && c.borzo && mumbai ? 'borzo' : c.shiprocket ? 'shiprocket' : c.borzo && mumbai ? 'borzo' : 'hand';   /* d17.207: EXPRESS -> the same-day rider */
    const from = recall('from') && br.indexOf(recall('from')) >= 0 ? recall('from') : (br.indexOf(o.store) >= 0 ? o.store : (br.find(b => st.branchAddr && st.branchAddr[b] && st.branchAddr[b].address) || br[0] || ''));
    const box = Object.assign({ l: 20, b: 12, h: 8, kg: 0.5 }, (st.parcel && st.parcel.box) || {});
    const ps = o.payStatus || 'Unpaid', bal = balanceOf(o);
    let h = '';
    h += '<div class="who"><b>' + H(o.name || 'Customer') + '</b> &middot; ' + H(o.phone || 'no mobile') + (o.total ? ' &middot; ' + inr(o.total) : '') + ' &middot; ' + H(ps) + (num(o.paid) > 0 && ps !== 'Paid' ? ' (paid ' + inr(num(o.paid)) + ')' : '') + '</div>';
    if (ps === 'Refunded') h += '<div class="warn">This order is marked REFUNDED.</div>';
    else if (ps !== 'Paid' && !(num(o.total) > 0)) h += '<div class="warn">The order total is empty, so the cash to collect could not be worked out. Type the total on the order (or the amount in &ldquo;Collect on delivery&rdquo; below).</div>';
    if (o.fulfil === 'pickup') h += '<div class="warn">The customer chose to COLLECT from ' + H(o.store || 'a shop') + '. Send it only if they asked.</div>';
    if (o.status && ['Ready', 'Delivered'].indexOf(o.status) < 0) h += '<div class="info">This order is still <b>' + H(o.status) + '</b>. Usually you send it once it is Ready (QC passed).</div>';
    const pend = part && part.via === 'shiprocket' && part.srOrderId && !part.awb && (part.step === 'created' || part.step === 'booking');
    if (pend) h += '<div class="warn">A Shiprocket order (no. ' + H(part.srOrderId) + ') was made for this but has <b>no courier yet</b>' + (part.note ? ': ' + H(part.note) : '') + '.<br>BOOK COURIER again uses that order (if you change the address it is cancelled and made again). Choosing RIDER or BY HAND cancels it first.' +
      (canEdit() ? '<div class="act"><button type="button" class="red" data-d="cancel">CANCEL THAT SHIPROCKET ORDER</button><button type="button" class="red" data-d="closerec">CLOSE (NO COURIER CALL)</button></div><p class="muted" style="margin:6px 0 0">CLOSE only if it is already cancelled in the Shiprocket panel.</p>' : '') + '</div>';
    if (part && part.step === 'booking' && part.bzTry && !part.bzOrderId) h += '<div class="warn">The last rider booking may have gone through (the website lost Borzo\u2019s answer). <b>Look in the Borzo app first.</b> If a rider is booked, save it with BY HAND (Borzo + its number). If not, tap CLEAR and book again.' +
      (canEdit() ? '<div class="act"><button type="button" class="red" data-d="closerec">CLEAR</button></div>' : '') + '</div>';
    if (part && part.step === 'returned') {
      h += '<div class="warn">The last parcel came back' + (part.courier ? ' (' + H(part.courier) + (part.awb ? ' ' + H(part.awb) : '') + ')' : '') + '. ' +
        (part.backAt ? 'Received back at the shop on ' + H(dd(part.backAt)) + (part.backBy ? ' by ' + H(part.backBy) : '') + '. Send it again below, or cancel the order.' : 'When it is in the shop, tap RECEIVED BACK AT SHOP. Then send it again below, or cancel the order.') +
        (canEdit() ? '<div class="act">' + (part.backAt ? '' : '<button type="button" data-d="back">RECEIVED BACK AT SHOP</button>') + (o.status !== 'Cancelled' ? '<button type="button" class="red" data-d="cancelorder">CANCEL ORDER</button>' : '') + '</div>' : '') + '</div>';
    }
    if (o.status === 'Cancelled') h += '<div class="warn">This order is CANCELLED. To send it, change its status on the order first.</div>';
    h += histDueHtml(part);
    const refused = refusedBefore(o);
    if (refused.length) h += '<div class="warn">This mobile number refused cash on delivery before (' + refused.map(H).join(', ') + '). Consider asking for an advance before sending.</div>';
    if (c.missing) h += '<div class="err">The delivery part of the website is not uploaded yet.</div>';
    h += waysHtml(c);
    /* cash on delivery: the balance, filled in (staff can change it; 0 = nothing to collect) */
    const codStart = CODPRE && CODPRE.ref === o.ref ? CODPRE.v : (bal > 0 ? String(bal) : '0');
    h += '<div class="codbox"><label for="dvCod">Collect on delivery (cash) &#8377;</label><input id="dvCod" inputmode="decimal" maxlength="10" value="' + H(codStart) + '"><div class="muted" id="dvCodHint">' + codHint(num(codStart)) + '</div></div>';
    h += '<label for="dvAddr">Deliver to</label><textarea id="dvAddr">' + H(a.line) + '</textarea>';
    h += '<div class="g2"><div><label for="dvLand">Landmark</label><input id="dvLand" value="' + H(a.landmark) + '"></div><div><label for="dvPin">Pincode</label><input id="dvPin" inputmode="numeric" maxlength="6" value="' + H(a.pin) + '"></div></div>';
    h += '<div class="g2"><div><label for="dvCity">City</label><input id="dvCity" value="' + H(a.city) + '"></div><div><label for="dvState">State</label><input id="dvState" value="' + H(a.state) + '"></div></div>';
    if (MODE !== 'hand') {
      h += '<label for="dvFrom">Send from</label><select id="dvFrom">' + br.map(b => '<option' + (b === from ? ' selected' : '') + '>' + H(b) + '</option>').join('') + '</select>';
      if (MODE === 'borzo') { const ba = st.branchAddr && st.branchAddr[from]; if (!ba || !ba.address) h += '<div class="warn">The rider needs this shop&rsquo;s address and phone: <b>Settings &rarr; Delivery</b>.</div>'; }
      h += '<label>Box (cm) and weight (kg)</label><div class="g4"><input id="dvL" inputmode="decimal" value="' + H(box.l) + '" aria-label="Length cm"><input id="dvB" inputmode="decimal" value="' + H(box.b) + '" aria-label="Breadth cm"><input id="dvH" inputmode="decimal" value="' + H(box.h) + '" aria-label="Height cm"><input id="dvKg" inputmode="decimal" value="' + H(box.kg) + '" aria-label="Weight kg"></div>';
    }
    if (MODE === 'shiprocket') {
      h += '<label for="dvPick">Shiprocket pickup address</label><select id="dvPick"><option value="">' + (PICKUPS ? 'Matched to the shop above' : 'Loading…') + '</option>' + (PICKUPS || []).map(p => '<option value="' + H(p.name) + '" data-pin="' + H(p.pin) + '">' + H(p.name) + ' (' + H(p.pin) + ')' + (p.primary ? ' · main' : '') + '</option>').join('') + '</select>';
      h += '<div id="dvRates"></div>';
      h += '<div class="act"><button type="button" data-d="quote">SEE PRICES</button><button type="button" class="main" data-d="book"' + (c.shiprocket && canEdit() ? '' : ' disabled') + '>BOOK COURIER</button></div>';
      if (!c.shiprocket) h += '<div class="info">Shiprocket is not connected yet &mdash; see the setup guide (Vercel settings).</div>';
    } else if (MODE === 'borzo') {
      h += '<label for="dvNote">Note for the rider <span class="muted">(optional)</span></label><input id="dvNote" maxlength="200" placeholder="e.g. Call before coming">';
      h += '<div id="dvRates"></div>';
      h += '<div class="act"><button type="button" data-d="quote">SEE PRICE</button><button type="button" class="main" data-d="book"' + (c.borzo && canEdit() ? '' : ' disabled') + '>BOOK RIDER</button></div>';
      if (!c.borzo) h += '<div class="info">Borzo is not connected yet &mdash; see the setup guide (Vercel settings).</div>';
      else if (c.borzoTest) h += '<div class="info"><b>TEST MODE</b> &mdash; Borzo&rsquo;s test system: no real rider comes and nothing is charged. Remove BORZO_TEST in Vercel to go live.</div>';
    } else {
      h += '<div class="g2"><div><label for="dvKind">How</label><select id="dvKind"><option value="rider">Rider / same day</option><option value="courier">Courier</option></select></div>' +
        '<div><label for="dvCo">Who is delivering</label><input id="dvCo" list="dvCoList" placeholder="e.g. Porter"><datalist id="dvCoList"><option>Porter</option><option>Shiprocket Quick</option><option>Rapido</option><option>Uber</option><option>Our staff</option><option>Delhivery</option><option>DTDC</option><option>Blue Dart</option><option>India Post</option></datalist></div></div>';
      h += '<label for="dvAwb">Tracking number <span class="muted">(if any)</span></label><input id="dvAwb" maxlength="40">';
      h += '<label for="dvUrl">Tracking link <span class="muted">(if the app gave one &mdash; starts with https://)</span></label><input id="dvUrl" inputmode="url" placeholder="https://">';
      h += '<div class="act"><button type="button" class="main" data-d="hand"' + (canEdit() ? '' : ' disabled') + '>SAVE &amp; TELL THE CUSTOMER</button></div>';
      h += '<p class="muted">You move it along yourself (PICKED UP / OUT FOR DELIVERY / DELIVERED). The customer gets a WhatsApp with their tracking page.</p>';
    }
    h += '<div id="dvMsg" hidden></div>';
    paint(h);
    if (MODE === 'shiprocket' && !PICKUPS && c.shiprocket) loadPickups();
    if (QUOTE && QUOTE.ref === OPEN) showQuote();
  }
  /* the line under "Collect on delivery": what happens to the money */
  function codHint(v) {
    if (!(v > 0)) return 'Nothing to collect &mdash; the order is paid (prepaid parcel).';
    const t = 'The ' + (MODE === 'borzo' ? 'rider' : MODE === 'hand' ? 'person delivering' : 'courier') + ' collects <b>' + inr(v) + '</b> from the customer';
    if (MODE === 'shiprocket') return t + ' and Shiprocket pays it into your bank (about 8&ndash;9 days after delivery; 2&ndash;4 days with Early COD). The customer is told the amount.';
    if (MODE === 'borzo') return t + ' and sends it to the bank / UPI set in your Borzo account (the same day). The customer is told the amount.';
    return t + '. Tap MONEY RECEIVED once you have it. The customer is told the amount.';
  }
  let CODPRE = null;
  async function loadPickups() {
    const r = await api({ do: 'pickups' });
    PICKUPS = r.ok && Array.isArray(r.list) ? r.list : [];
    if (OPEN && MODE === 'shiprocket') { const keepF = form(); draw(); restore(keepF); }
    if (!r.ok) msg('err', r.error || 'Could not read your Shiprocket pickup addresses');
  }
  function form() { const v = id => ($id(id) ? $id(id).value : undefined); return { addr: v('dvAddr'), land: v('dvLand'), pin: v('dvPin'), city: v('dvCity'), state: v('dvState'), from: v('dvFrom'), l: v('dvL'), b: v('dvB'), h: v('dvH'), kg: v('dvKg'), note: v('dvNote'), pick: v('dvPick'), cod: v('dvCod') }; }
  function restore(f) { const put = (id, v) => { if (v !== undefined && $id(id)) $id(id).value = v; }; put('dvAddr', f.addr); put('dvLand', f.land); put('dvPin', f.pin); put('dvCity', f.city); put('dvState', f.state); put('dvFrom', f.from); put('dvL', f.l); put('dvB', f.b); put('dvH', f.h); put('dvKg', f.kg); put('dvNote', f.note); put('dvPick', f.pick); put('dvCod', f.cod);
    if ($id('dvCod') && $id('dvCodHint')) $id('dvCodHint').innerHTML = codHint(num($id('dvCod').value)); }
  /* the cash to collect as typed: a number from 0 up to the order total -- or an error to show */
  function codOf(o) {
    const raw = String(($id('dvCod') || {}).value || '').replace(/[,\s₹]/g, '');
    if (raw === '') return { v: 0 };
    const v = Number(raw);
    if (!isFinite(v) || v < 0) return { err: 'Type the cash to collect as a number (0 if the order is fully paid).' };
    if (v > 0 && v < 1) return { err: 'The cash to collect must be at least ₹1 (or 0 if the order is fully paid).' };
    if (num(o.total) > 0 && v > num(o.total) + 0.001) return { err: 'The cash to collect (' + inr(v) + ') is more than the order total (' + inr(o.total) + ').' };
    return { v: r2(v) };
  }
  function reqBody() {
    const f = form(), sel = $id('dvPick'), opt = sel && sel.selectedOptions && sel.selectedOptions[0], o = order(OPEN) || {}, cv = codOf(o);
    if (f.from) remember('from', f.from);
    return { from: f.from, to: { address: (f.addr || '').trim(), landmark: (f.land || '').trim(), pin: (f.pin || '').replace(/\D/g, ''), city: (f.city || '').trim(), state: (f.state || '').trim() },
      box: { l: f.l, b: f.b, h: f.h, kg: f.kg }, note: (f.note || '').trim(), pickup: f.pick || '', pickupPin: opt && opt.dataset.pin || '',
      cod: cv.err ? (f.cod || '') : cv.v, value: num(o.total) > 0 ? r2(num(o.total)) : undefined };
  }
  function showQuote() {
    const el = $id('dvRates'); if (!el || !QUOTE || QUOTE.ref !== OPEN) return;
    let h = '';
    if (MODE === 'shiprocket') {
      const q = QUOTE.shiprocket;
      if (!q) h = '<div class="info">Shiprocket is not connected.</div>';
      else if (!q.ok) h = '<div class="err">' + H(q.error) + '</div>';
      else if (!q.couriers.length) h = '<div class="err">' + (q.cod > 0 ? 'No courier collects cash on delivery at this pincode.' : 'No courier delivers to this pincode.') + '</div>';
      else h = (q.cod > 0 ? '<div class="info">Prices for a <b>cash-on-delivery</b> parcel (the courier collects ' + inr(q.cod) + ').</div>' : '') + '<div class="rates">' + q.couriers.map((c, i) => '<label><input type="radio" name="dvCourier" value="' + H(c.id) + '"' + ((q.recommended ? c.id === q.recommended : i === 0) ? ' checked' : '') + '><span>' + H(c.name) + (c.id === q.recommended ? ' &middot; <i>recommended</i>' : '') +
        '<small>' + (c.days ? H(c.days) + ' day' + (String(c.days) === '1' ? '' : 's') : '') + (c.etd ? ' &middot; by ' + H(c.etd) : '') + (c.codFee > 0 ? ' &middot; COD charge ' + inr(c.codFee) : '') + '</small></span><span class="r">' + inr(c.rate) + '</span></label>').join('') + '</div>';
    } else if (MODE === 'borzo') {
      const q = QUOTE.borzo;
      if (!q) h = '<div class="info">Borzo is not connected.</div>';
      else if (!q.ok) h = '<div class="err">' + H(q.error) + '</div>';
      else h = '<div class="good">Rider price: ' + inr(q.price) + (q.codFee > 0 ? ' (includes ' + inr(q.codFee) + ' for sending the cash to you)' : '') + (q.test ? ' (TEST &mdash; nothing charged)' : '') + (q.cod > 0 ? '<br>The rider collects ' + inr(q.cod) + ' from the customer.' : '') + '</div>';
    }
    /* d17.207: the other way's price beside it, so the choice is made per order (same day -> rider) */
    const other = MODE === 'shiprocket' ? QUOTE.borzo : MODE === 'borzo' ? QUOTE.shiprocket : null;
    if (other && other.ok) {
      const cheapest = MODE === 'borzo' && other.couriers && other.couriers.length ? other.couriers.reduce((m, c) => c.rate < m.rate ? c : m, other.couriers[0]) : null;
      const line = MODE === 'shiprocket' ? 'SAME-DAY RIDER (Borzo): <b>' + inr(other.price) + '</b> &middot; today' + (other.test ? ' (TEST)' : '')
        : cheapest ? 'COURIER (Shiprocket): from <b>' + inr(cheapest.rate) + '</b>' + (cheapest.days ? ' &middot; ' + H(cheapest.days) + ' day' + (String(cheapest.days) === '1' ? '' : 's') : '') : '';
      if (line) h += '<div class="info sbs"><span>' + line + '</span> <button type="button" class="use" data-way="' + (MODE === 'shiprocket' ? 'borzo' : 'shiprocket') + '">' + (MODE === 'shiprocket' ? 'USE RIDER' : 'USE COURIER') + '</button></div>';
    } else if (other && !other.ok && (MODE === 'shiprocket' || MODE === 'borzo')) h += '<p class="muted">' + (MODE === 'shiprocket' ? 'Same-day rider' : 'Courier') + ': ' + H(other.error || 'no price') + '</p>';
    el.innerHTML = h;
  }
  function drawBooked(o, s) {
    const rider = s.kind === 'rider', link = o.trackKey ? SITE + '/track?o=' + encodeURIComponent(o.ref) + '&k=' + encodeURIComponent(o.trackKey) : '';
    const ago = t => { const m = Math.round((Date.now() - new Date(t).getTime()) / 60000); return !t || isNaN(m) ? '' : m < 1 ? 'just now' : m < 60 ? m + ' min ago' : m < 1440 ? Math.round(m / 60) + ' h ago' : Math.round(m / 1440) + ' days ago'; };
    let h = '<div class="now">' + H(s.text || (CHIP[s.step] || [s.step])[0]) + '</div>';
    h += '<div class="muted">' + (s.checkedAt ? 'Checked ' + ago(s.checkedAt) : '') + (s.at ? ' &middot; last change ' + ago(s.at) : '') + '</div>';
    if (s.test) h += '<div class="info"><b>TEST booking</b> on Borzo&rsquo;s test system &mdash; no real rider.</div>';
    if (s.note) h += '<div class="warn">' + H(s.note) + '</div>';
    /* cash on delivery: to collect -> with the courier -> in the bank */
    const ca = codAmt(s), dd = t => { try { return new Date(t).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' }); } catch (e) { return ''; } };
    if (ca > 0) {
      if (s.cod.settledAt) h += '<div class="good">Cash on delivery ' + inr(ca) + ' &mdash; received' + (s.via === 'hand' ? '' : ' in the bank') + ' (' + H(dd(s.cod.settledAt)) + (s.cod.settledBy ? ', ' + H(s.cod.settledBy) : '') + ').</div>';
      else if (s.cod.collectedAt) h += '<div class="warn">Cash on delivery: the customer paid <b>' + inr(ca) + '</b> (' + H(dd(s.cod.collectedAt)) + '). It is with ' + H(viaName(s)) + ' &mdash; ' +
        (s.via === 'shiprocket' ? 'Shiprocket pays it into your bank about 8&ndash;9 days after delivery (2&ndash;4 days with Early COD) &mdash; see Shiprocket &rarr; COD Reconciliation.' : s.via === 'borzo' ? 'the rider sends it to the bank / UPI in your Borzo account (the same day).' : 'collect it from them.') + ' Tap <b>MONEY RECEIVED</b> once you see it.</div>';
      else if (['returning', 'returned', 'cancelled'].indexOf(s.step) >= 0) h += '<div class="info">Cash on delivery ' + inr(ca) + ' &mdash; not collected.</div>';
      else h += '<div class="info">Cash on delivery: the ' + (rider ? 'rider' : 'courier') + ' collects <b>' + inr(ca) + '</b> from the customer.' +
        /* part paid by courier: Shiprocket is told the paid part as a discount -- worth one look in Shiprocket the first times */
        (s.via === 'shiprocket' && Number(s.cod.value) - ca >= 1 ? '<br><b>Part paid:</b> please check once in Shiprocket &rarr; Orders that this order&rsquo;s COD amount shows ' + inr(ca) + ' before the courier picks it up.' : '') + '</div>';
    }
    h += '<dl>';
    const row = (k, v) => { if (v) h += '<dt>' + H(k) + '</dt><dd>' + v + '</dd>'; };
    row(rider ? 'Rider' : 'Courier', H(s.courier || (s.via === 'borzo' ? 'Borzo' : '')) + (s.via === 'hand' ? ' <span class="muted">(by hand)</span>' : ''));
    if (s.rider && s.rider.name) row('Rider', H(s.rider.name) + (s.rider.phone ? ' &middot; <a href="tel:+' + H(s.rider.phone) + '">CALL</a>' : ''));
    row('Tracking no.', H(s.awb));
    row('From', H(s.from));
    row('Pickup', H(s.pickupAt));
    if (s.eta && s.step !== 'delivered') row('Expected', H(new Date(s.eta).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })));
    if (s.price) row('Price', inr(s.price));
    if (s.bzOrderId) row('Borzo no.', H(s.bzOrderId));
    if (s.srOrderId) row('Shiprocket no.', H(s.srOrderId));
    row('Booked', H((s.bookedAt ? new Date(s.bookedAt).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' }) : '') + (s.bookedBy ? ' by ' + s.bookedBy : '')));
    h += '</dl>';
    /* every link says where it goes (a link typed by hand, or one in an order a stranger made up, is never hidden behind a button) */
    const host = u => { try { const x = new URL(u); return x.protocol === 'https:' ? x.hostname.replace(/^www\./, '') : ''; } catch (e) { return ''; } };
    const th = host(s.trackUrl), lh = host(s.label);
    h += '<div class="act">' + (th ? '<a class="lime" href="' + H(s.trackUrl) + '" target="_blank" rel="noopener noreferrer">' + (rider ? 'RIDER LIVE MAP' : 'COURIER TRACKING') + ' &#8599;<small style="display:block;font-weight:600;font-size:.66rem;letter-spacing:0">' + H(th) + '</small></a>' : '') +
      (lh && (/(^|\.)shiprocket\.(in|co)$/.test(lh) || /^kr-shipmultichannel(-mum)?\.s3(\.[a-z0-9-]+)?\.amazonaws\.com$/.test(lh)) ? '<a href="' + H(s.label) + '" target="_blank" rel="noopener noreferrer">LABEL PDF &#8599;</a>' : '') +
      (link ? '<a href="' + H(link) + '" target="_blank" rel="noopener">CUSTOMER&rsquo;S PAGE &#8599;</a><button type="button" data-d="copy">COPY LINK</button>' : '') + '</div>';
    if (canEdit()) {
      h += '<div class="act">';
      if (s.via !== 'hand') h += '<button type="button" data-d="refresh">CHECK NOW</button>';
      if (s.via === 'shiprocket' && s.live && (!s.pickupAt || /pickup not booked/i.test(s.note || ''))) h += '<button type="button" class="main" data-d="pickup">BOOK PICKUP</button>';
      if (s.via === 'shiprocket' && s.live && !s.label) h += '<button type="button" data-d="label">GET LABEL</button>';
      if (s.via === 'hand' && s.live) h += '<button type="button" data-step="picked">PICKED UP</button><button type="button" data-step="out">OUT FOR DELIVERY</button><button type="button" class="main" data-step="delivered">DELIVERED</button><button type="button" data-step="failed">NOT DELIVERED</button>';
      if (s.via === 'hand' && s.live) h += '<button type="button" data-d="edithand">CHANGE NUMBER / LINK</button>';
      if (s.step === 'returning') h += '<button type="button" class="main" data-d="back">RECEIVED BACK AT SHOP</button>';
      if (s.live && s.step !== 'returning') h += '<button type="button" class="red" data-d="cancel">CANCEL BOOKING</button>';
      /* lost, damaged, came back, or "delivered" by mistake: closed here without asking the courier -- then it can be sent again */
      h += '<button type="button" class="red" data-d="closerec">CLOSE (NO COURIER CALL)</button>';
      h += '</div>';
    }
    h += histDueHtml(s);
    if (ca > 0 && s.cod.collectedAt && canPay()) h += '<div class="act">' + (s.cod.settledAt ? '<button type="button" data-d="codunbank">NOT RECEIVED YET (UNDO)</button>' : '<button type="button" class="main" data-d="codbank">MONEY RECEIVED' + (s.via === 'hand' ? '' : ' IN BANK') + '</button>') + '</div>';
    h += '<div id="dvMsg" hidden></div>';
    const list = s.scans && s.scans.length ? s.scans : (s.events || []).slice().reverse();
    if (list.length) h += '<ul class="ev">' + list.slice(0, 12).map(e => '<li>' + H(e.text) + '<span>' + H([e.at ? new Date(e.at).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' }) : '', e.place].filter(Boolean).join(' · ')) + '</span></li>').join('') + '</ul>';
    if (s.history && s.history.length) h += '<p class="muted">Earlier booking' + (s.history.length > 1 ? 's' : '') + ' cancelled: ' + s.history.map(x => H([x.courier || x.via, x.awb || x.bzOrderId].filter(Boolean).join(' '))).join(', ') + '</p>';
    paint(h);
  }
  /* the order on this phone takes the parcel record the server sent (truth = null: the server has no real record --
     anything else on this phone, e.g. a record planted in a stranger's order, is dropped) */
  function keep(ref, d, truth) {
    if (!d || (!d.ship && !truth)) return;
    try {
      const list = getOrders(), o = list.find(x => x.ref === ref); if (!o) return;
      if (d.ship) { o.ship = d.ship; VERIFIED[ref] = vkey(d.ship); } else { delete o.ship; delete VERIFIED[ref]; }
      if (d.trackKey) o.trackKey = d.trackKey;
      if (d.link) { try { const k = new URL(d.link).searchParams.get('k'); if (k) o.trackKey = k; } catch (e) {} }
      if (d.ship && d.ship.step === 'delivered' && !d.ship.test && o.status !== 'Delivered') o.status = 'Delivered';
      if (d.orderStatus && typeof d.orderStatus === 'string') o.status = d.orderStatus;
      codMark(o); retMark(o);
      saveOrders(list);
    } catch (e) {}
  }
  /* COD collected (the website's own record says so): the order is marked paid on this phone -- once per parcel. The
     money is still with the courier: "Rs X TO COME" shows until MONEY RECEIVED IN BANK. Returns true when it changed. */
  /* one parcel's cash = when it was booked + when the cash was collected (a tracking number can be typed twice) */
  const codKey = (x, amt, at) => [x.via, x.bookedAt || x.bzOrderId || x.awb || '', amt, at || ''].join('|');
  function codMark(o) {
    const s = o && o.ship;
    if (!trusted(o)) return false;
    let changed = false;
    /* a cash parcel CLOSED as "delivered by mistake": the cash was never collected -- what this phone added comes off */
    if (o.codApplied && Array.isArray(s.history)) {
      const v = s.history.find(e => e && e.codVoid && codKey(e, r2(Number(e.cod) || 0), e.codAt) === o.codApplied);
      if (v) {
        const back = r2(Number(o.codAdded) || 0);
        if (back > 0) {
          const tot = num(o.total), pd = Math.max(0, r2(num(o.paid) - back));
          o.paid = String(pd);
          o.payStatus = pd <= 0 ? 'Unpaid' : (tot > 0 && pd >= tot - 0.001 ? 'Paid' : 'Partial');
        }
        o.codApplied = ''; o.codAdded = 0; changed = true;
      }
    }
    const ca = codAmt(s);
    if (!(ca > 0) || !s.cod.collectedAt || s.test) return changed;
    const key = codKey(s, ca, s.cod.collectedAt);
    if (o.codApplied === key) return changed;
    o.codApplied = key; o.codAdded = 0;
    const ps = o.payStatus || 'Unpaid';
    if (ps === 'Paid' || ps === 'Refunded') return true;             /* already settled here: nothing is added twice */
    const tot = num(o.total), pd = r2(num(o.paid) + ca);
    o.paid = String(pd); o.codAdded = ca;
    o.payStatus = !(tot > 0) || pd >= tot - 0.001 ? 'Paid' : 'Partial';
    if (!o.payMethod) o.payMethod = 'Cash on delivery';
    if (o.payStatus === 'Paid') { try { if (typeof deductPaidStock === 'function') deductPaidStock(o); } catch (e) {} }
    return true;
  }
  /* how cash-on-delivery parcels went (the shop: "first we see how many come back"): from each order's parcel record and
     its earlier bookings. A booking cancelled before it left the shop is not counted; TEST bookings are not counted. */
  function codStats(list) {
    const st = { sent: 0, delivered: 0, returned: 0, lost: 0, onway: 0, toCome: 0, toComeN: 0 };
    (list || []).forEach(o => {
      if (!trusted(o)) return;
      const s = o.ship;
      (Array.isArray(s.history) ? s.history : []).forEach(e => {
        if (!e || !(Number(e.cod) > 0) || e.test || e.codVoid) return;
        if (e.codAt) { st.sent++; st.delivered++; }
        else if (e.step === 'problem' || (e.step === 'cancelled' && e.wasStep === 'problem')) { st.sent++; st.lost++; }
        else if (['returning', 'returned', 'failed'].indexOf(e.step) >= 0 || e.why === 'returned' ||
          (e.step === 'cancelled' && ['picked', 'transit', 'out', 'failed', 'returning'].indexOf(e.wasStep) >= 0)) { st.sent++; st.returned++; }
      });
      histDue(s).forEach(e => { st.toCome = r2(st.toCome + Number(e.cod)); st.toComeN++; });
      const ca = codAmt(s); if (!(ca > 0) || s.test) return;
      if (s.cod.collectedAt) { st.sent++; st.delivered++; if (!s.cod.settledAt) { st.toCome = r2(st.toCome + ca); st.toComeN++; } }
      else if (['returning', 'returned'].indexOf(s.step) >= 0 || (s.step === 'cancelled' && ['picked', 'transit', 'out', 'failed', 'returning'].indexOf(s.wasStep) >= 0)) { st.sent++; st.returned++; }
      else if (s.step === 'cancelled' && s.wasStep === 'problem') { st.sent++; st.lost++; }
      else if (LIVE_STEPS.indexOf(s.step) >= 0) { st.sent++; st.onway++; }
    });
    return st;
  }
  function codStatsHtml(st) {
    const done = st.delivered + st.returned;
    return '<span>CASH ON DELIVERY</span><span><b>' + st.sent + '</b> sent</span><span><b>' + st.delivered + '</b> delivered</span><span><b>' + st.returned + '</b> came back' + (done ? ' (' + Math.round(st.returned * 100 / done) + '%)' : '') + '</span>' +
      (st.lost ? '<span><b>' + st.lost + '</b> lost / damaged</span>' : '') + (st.onway ? '<span><b>' + st.onway + '</b> on the way</span>' : '') + '<span><b>' + inr(st.toCome) + '</b> still to come from couriers' + (st.toComeN ? ' (' + st.toComeN + ' order' + (st.toComeN > 1 ? 's' : '') + ')' : '') + '</span>';
  }
  /* the line above the order list (only once there has been a cash parcel) */
  window.dlvCodLine = function (all) {
    try {
      const panel = $id('panel-orders'), stats = panel && panel.querySelector('.stats'); if (!stats) return;
      let el = $id('dlvCodLine');
      const st = codStats(all || (typeof getOrders === 'function' ? getOrders() : []));
      if (!st.sent) { if (el) el.remove(); return; }
      if (!el) { el = document.createElement('div'); el.id = 'dlvCodLine'; el.className = 'dlvCodLine'; stats.insertAdjacentElement('afterend', el); }
      el.innerHTML = codStatsHtml(st);
    } catch (e) {}
  };
  function codSweep() {
    try {
      if (typeof getOrders !== 'function') return;
      const list = getOrders(); let changed = false;
      list.forEach(o => { if (codMark(o)) changed = true; if (retMark(o)) changed = true; });
      if (changed) saveOrders(list);
    } catch (e) {}
  }
  /* one action at a time PER ORDER (another order's panel stays usable); whatever comes back is shown only on the
     panel of the order it belongs to */
  const BUSYSET = new Set();
  async function act(what, extra) {
    const ref = OPEN, o = order(ref); if (!o) return;
    if (BUSYSET.has(ref)) return;
    if (['book', 'hand', 'cancel', 'close', 'step', 'pickup', 'label', 'refresh', 'back'].indexOf(what) >= 0 && typeof need === 'function' && !need('orders.edit')) return;
    if ((what === 'codbank' || what === 'codunbank' || what === 'codbankh' || what === 'codunbankh') && typeof need === 'function' && !need('orders.payments')) return;
    BUSYSET.add(ref);
    document.querySelectorAll('#dlv .act button').forEach(b => { b.disabled = true; });
    msg('info', what === 'book' ? 'Booking… (this can take up to half a minute)' : 'Working…');
    let r;
    try {
      if (what === 'quote') {
        const qb = reqBody();
        r = await api(Object.assign({ do: 'quote', ref }, qb));
        if (OPEN !== ref) return;
        if (!r.ok) { draw(); restore(LASTF); msg('err', r.error || 'Could not get prices'); return; }
        /* the amount was changed while the prices were on their way: they are for the old amount -- not shown */
        if (codOf(o).v !== qb.cod) { QUOTE = null; const f0 = form(); draw(); restore(f0); msg('info', 'The cash amount changed while the prices were loading -- tap SEE PRICES again.'); return; }
        QUOTE = Object.assign({ ref }, r); const f = form(); draw(); restore(f); showQuote(); msg('', ''); return;
      }
      if (what === 'book') {
        const b = reqBody(), ch = document.querySelector('#dlv input[name="dvCourier"]:checked');
        r = await api(Object.assign({ do: 'book', ref, via: MODE, courierId: ch && QUOTE && QUOTE.ref === ref ? ch.value : '' }, b));
      } else if (what === 'hand') {
        const v = id => ($id(id) ? $id(id).value.trim() : ''), rb = reqBody();
        r = await api({ do: 'hand', ref, kind: v('dvKind') || (extra && extra.kind) || 'rider', courier: v('dvCo') || (extra && extra.courier), awb: v('dvAwb'), url: v('dvUrl'), from: recall('from'), cod: rb.cod, value: rb.value });
      } else if (what === 'step') r = await api({ do: 'step', ref, step: extra });
      else if (what === 'codbank' || what === 'codunbank') r = await api({ do: 'codbank', ref, undo: what === 'codunbank' });
      else if (what === 'codbankh' || what === 'codunbankh') r = await api({ do: 'codbank', ref, which: 'hist', key: extra || '', undo: what === 'codunbankh' });
      else r = await api({ do: what, ref });
      if (r.ship || (r.ok && r.ship === null)) keep(ref, r, r.ok && r.ship === null);
      if (!r.ok) {
        /* what is really on the order now (e.g. a Shiprocket order made before the courier was refused) */
        if (r.status && r.status !== 401) { const g = await api({ do: 'get', ref }); if (g.ok) keep(ref, { ship: g.ship || null, trackKey: g.trackKey }, true); }
        if (OPEN !== ref) { try { if (typeof toast === 'function') toast(ref + ': ' + (r.error || 'It did not work')); } catch (e) {} return; }
        const f = form(); draw(); restore(f);
        msg('err', r.error || 'It did not work -- try again');
        return;
      }
      const told = r.test ? ' (TEST: the message went to the manager’s WhatsApp, not the customer.)' : r.whatsapp ? ' The customer got a WhatsApp with the tracking link.' : ' The WhatsApp to the customer did not go -- COPY LINK and send it yourself.';
      const said = { book: 'Booked.' + told, hand: 'Saved.' + (r.whatsapp ? ' The customer got a WhatsApp with the tracking link.' : ''),
        cancel: 'Cancelled.', close: 'Closed. You can send it again.', refresh: 'Checked.', pickup: 'Pickup booked.', label: 'Label ready.', step: 'Saved.',
        codbank: 'Marked: the cash is in your bank.', codunbank: 'Undone: the cash is shown as still to come.', codbankh: 'Marked: the earlier parcel\u2019s cash is in your bank.', codunbankh: 'Undone: the earlier parcel\u2019s cash is shown as still to come.', back: 'Received back at the shop. Send it again, or cancel the order.' }[what] || 'Done.';
      try { if (typeof toast === 'function') toast(ref + ': ' + said); } catch (e) {}
      if (OPEN !== ref) return;
      draw();
      msg('good', said);
    } finally {
      BUSYSET.delete(ref);
      if (OPEN === ref) document.querySelectorAll('#dlv .act button').forEach(b => { if (b.dataset.locked !== '1') b.disabled = false; });
    }
  }
  let LASTF = {};

  document.addEventListener('click', e => {
    const t = e.target.closest && e.target.closest('.dlvBtn');
    if (t) { e.preventDefault(); e.stopPropagation(); window.dlvOpen(t.dataset.ref); return; }
    const w = $id('dlv'); if (!w || w.hidden || !w.contains(e.target)) return;
    const d = e.target.closest('[data-d],[data-way],[data-step]'); if (!d) return;
    if (d.dataset.way) { LASTF = form(); MODE = d.dataset.way; draw(); restore(LASTF); if (QUOTE && QUOTE.ref === OPEN) showQuote(); return; }
    if (d.dataset.step) {
      if (d.dataset.step === 'delivered' && !confirm('Mark ' + OPEN + ' DELIVERED? The customer gets a WhatsApp.')) return;
      return act('step', d.dataset.step);
    }
    const k = d.dataset.d;
    if (k === 'close') return close();
    if (k === 'cancelorder') return cancelOrder(OPEN);
    if (k === 'codbankh') { if (!confirm('Mark ' + inr(Number(d.dataset.amt) || 0) + ' (cash on delivery of the earlier parcel) as received in your bank?')) return; return act('codbankh', d.dataset.key); }
    if (k === 'codunbankh') return act('codunbankh', d.dataset.key);
    if (k === 'reopen') return window.dlvOpen(OPEN);
    if (k === 'copy') { const o = order(OPEN); const link = SITE + '/track?o=' + encodeURIComponent(o.ref) + '&k=' + encodeURIComponent(o.trackKey || ''); try { navigator.clipboard.writeText(link); msg('good', 'Link copied: ' + link); } catch (x) { msg('info', link); } return; }
    if (k === 'cancel') { const oc = order(OPEN), byHand = oc && oc.ship && oc.ship.via === 'hand';
      if (!confirm('Cancel the delivery booking for ' + OPEN + '? ' + (byHand ? 'This only clears it here -- tell the courier / rider yourself.' : 'The courier / rider is told.'))) return; return act('cancel'); }
    if (k === 'closerec') { const oc = order(OPEN), sc = oc && oc.ship, cash = sc && codAmt(sc) > 0 && sc.cod.collectedAt && !sc.cod.settledAt && !retOf(sc) ? codAmt(sc) : 0;
      if (!confirm('CLOSE the delivery record of ' + OPEN + ' WITHOUT telling the courier?\n\nOnly for a parcel that is lost, damaged, came back, or was marked delivered by mistake. If the courier still has to be stopped, use CANCEL BOOKING instead.' +
        (cash ? '\n\nCASH ON DELIVERY: the ' + inr(cash) + ' will be treated as NOT collected -- it comes off this order\u2019s payment again.' : ''))) return; return act('close'); }
    if (k === 'edithand') { const o = order(OPEN), s = o.ship; MODE = 'hand'; CODPRE = { ref: o.ref, v: String(codAmt(s)) }; drawNew(o, null);
      if ($id('dvCo')) $id('dvCo').value = s.courier || ''; if ($id('dvAwb')) $id('dvAwb').value = s.awb || ''; if ($id('dvUrl')) $id('dvUrl').value = /^https:/.test(s.trackUrl || '') ? s.trackUrl : ''; if ($id('dvKind')) $id('dvKind').value = s.kind === 'courier' ? 'courier' : 'rider';
      if (s.cod && s.cod.collectedAt && $id('dvCod')) { $id('dvCod').disabled = true; $id('dvCodHint').textContent = 'Already collected — this cannot be changed now.'; }
      return; }
    /* the cash to collect is checked before anything is asked or booked */
    let cv = null;
    if (k === 'quote' || k === 'book' || k === 'hand') { cv = codOf(order(OPEN) || {}); if (cv.err) { msg('err', cv.err); if ($id('dvCod')) $id('dvCod').focus(); return; } }
    const qv = QUOTE && QUOTE.ref === OPEN ? QUOTE[MODE === 'borzo' ? 'borzo' : 'shiprocket'] : null;
    if (k === 'book' && qv && qv.ok && Number(qv.cod || 0) !== cv.v) { msg('err', 'The prices shown were for ' + (qv.cod > 0 ? 'cash on delivery of ' + inr(qv.cod) : 'a prepaid parcel') + ' -- tap SEE PRICES again for ' + (cv.v > 0 ? inr(cv.v) : 'a prepaid parcel') + '.'); return; }
    if (k === 'book' && MODE === 'shiprocket' && !document.querySelector('#dlv input[name="dvCourier"]:checked') && !confirm('No courier chosen -- let Shiprocket choose the courier?')) return;
    if (k === 'book' && !confirm('Book ' + (MODE === 'borzo' ? 'a rider (Borzo)' : 'the courier (Shiprocket)') + ' for ' + OPEN + '? This spends money from your ' + (MODE === 'borzo' ? 'Borzo' : 'Shiprocket') + ' account.\n\n' +
      (cv.v > 0 ? 'CASH ON DELIVERY: the ' + (MODE === 'borzo' ? 'rider' : 'courier') + ' collects ' + inr(cv.v) + ' from the customer.' : 'PREPAID: nothing is collected from the customer.'))) return;
    if (k === 'hand' && cv.v > 0 && !confirm('The person delivering collects ' + inr(cv.v) + ' from the customer, and the customer is told to keep it ready. OK?')) return;
    LASTF = form();
    act(k);
  });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && OPEN) close(); });
  /* a new pincode fills in the city and state (only empty boxes) */
  document.addEventListener('input', e => {
    /* a new cash amount: the line under it follows, and old prices go (they were for the other amount) */
    if (e.target && e.target.id === 'dvCod') {
      if ($id('dvCodHint')) $id('dvCodHint').innerHTML = codHint(num(e.target.value));
      if (QUOTE && QUOTE.ref === OPEN) { QUOTE = null; if ($id('dvRates')) $id('dvRates').innerHTML = ''; }
      return;
    }
    if (!e.target || e.target.id !== 'dvPin') return;
    const v = e.target.value.replace(/\D/g, ''); if (v.length !== 6) return;
    const cs = cityState(v); if ($id('dvCity') && !$id('dvCity').value) $id('dvCity').value = cs[0]; if ($id('dvState') && !$id('dvState').value) $id('dvState').value = cs[1];
  });

  /* ---------- RETURNS AND EXCHANGES (d17.207) -- for the shop only: nothing of it shows on the customer's page ---------- */
  const REASONS = [['power', 'Wrong power'], ['lens', 'Lens fault'], ['fit', 'Frame does not fit'], ['dislike', 'Does not like it'], ['damaged', 'Damaged'], ['other', 'Other']];
  const REASON = {}; REASONS.forEach(x => { REASON[x[0]] = x[1]; });
  const OUR_FAULT = ['power', 'lens', 'damaged'];                     /* the shop pays the pickup */
  const OUTCOMES = [['remake', 'Remake lenses (free)'], ['exchange', 'Exchange frame'], ['refund', 'Refund'], ['repair', 'Repair'], ['none', 'Nothing needed']];
  const OUTCOME = { cancelled: 'Return cancelled' }; OUTCOMES.forEach(x => { OUTCOME[x[0]] = x[1]; });
  const RET_STEPS = ['open', 'booking', 'booked', 'pickupfail', 'picked', 'out', 'arrived', 'received'];
  const retOf = s => s && s.ret && typeof s.ret === 'object' && !Array.isArray(s.ret) && RET_STEPS.indexOf(s.ret.step) >= 0 ? s.ret : null;
  const retFresh = r => !!(r && r.lockAt && Date.now() - new Date(r.lockAt).getTime() < 150e3);
  const RCHIP = { open: 'AWAITED', booking: 'BOOKING', booked: 'PICKUP BOOKED', pickupfail: 'PICKUP FAILED', picked: 'COLLECTED', out: 'ARRIVING', arrived: 'AT SHOP — CHECK IT', received: 'CHECKED — DECIDE' };
  const WAYNAME = { shop: 'The customer brings it to a branch', shiprocket: 'Courier pickup (Shiprocket)', borzo: 'Rider pickup (Borzo)', hand: 'Collected by hand' };
  function retChip(o) {
    const r = retOf(o.ship);
    if (!r) return '';
    const st = r.step === 'booking' && !retFresh(r) ? (r.bzTry && !r.bzOrderId ? 'CHECK BORZO APP' : 'AWAITED') : (RCHIP[r.step] || 'OPEN');
    return ' <span class="dlv-chip ' + (['pickupfail', 'arrived', 'received'].indexOf(r.step) >= 0 || st === 'CHECK BORZO APP' ? 'due' : 'bad') + '">↩ RETURN: ' + H(st) + '</span>';
  }
  window.dlvReturnButton = function (o) {
    if (!o) return '';
    const s = trusted(o) ? o.ship : null, r = retOf(s);
    if (!r && !((s && s.step === 'delivered') || o.status === 'Delivered')) return '';
    return '<button class="btn ' + (r ? 'btn-dark' : 'btn-line') + ' btn-sm dlvRetBtn" data-ref="' + H(o.ref) + '">' + (r ? 'RETURN STATUS' : 'RETURN / EXCHANGE') + '</button>';
  };
  window.dlvReturnOpen = async function (ref) {
    const o = order(ref); if (!o) return;
    OPEN = ref; PANEL = 'ret'; RQUOTE = null; RMODE = ''; QUOTE = null;
    const w = wrap(); w.hidden = false;
    paint('<p class="muted">Loading&hellip;</p>');
    await check(true);
    const g = await api({ do: 'get', ref });
    if (OPEN !== ref || PANEL !== 'ret') return;
    if (g.ok) keep(ref, { ship: g.ship || null, trackKey: g.trackKey }, true);
    draw();
    if (!g.ok && g.status !== 404) msg('err', 'Could not check with the website: ' + (g.error || 'no answer') + ' -- close and open again.');
  };
  function deliveredOn(o, s) { const t = s && s.step === 'delivered' ? ((s.told && s.told.delivered) || s.at) : ''; return t || ''; }
  function drawRet() {
    const o = order(OPEN); if (!o) return close();
    const s = trusted(o) && typeof o.ship === 'object' ? o.ship : null, r = retOf(s);
    if (r && retFresh(r)) return paint('<div class="now">Being booked right now</div><div class="info">' + H(r.lockBy || 'Another phone') + ' started this a moment ago. Wait a minute, then tap CHECK AGAIN.</div><div class="act"><button type="button" data-r="reopen">CHECK AGAIN</button></div><div id="dvMsg" hidden></div>');
    if (!r || r.step === 'open' || (r.step === 'booking' && !(r.bzTry && !r.bzOrderId))) return drawRetForm(o, s, r);
    drawRetActive(o, s, r);
  }
  function rWays(c) {
    const b = (k, t, sm) => '<button type="button" data-rway="' + k + '" class="' + (RMODE === k ? 'on' : '') + '">' + t + '<small>' + sm + '</small></button>';
    return '<div class="ways r4">' + b('shop', 'AT A BRANCH', 'customer brings it') + b('shiprocket', 'COURIER PICKUP', c.shiprocket ? 'Shiprocket' : 'not connected') + b('borzo', 'RIDER PICKUP', c.borzo ? 'Borzo' + (c.borzoTest ? ' (TEST)' : '') : 'not connected') + b('hand', 'BY HAND', 'our staff') + '</div>';
  }
  function pastReturns(s) {
    const l = s && Array.isArray(s.returns) ? s.returns.filter(Boolean) : [];
    if (!l.length) return '';
    return '<p class="muted">Earlier return' + (l.length > 1 ? 's' : '') + ': ' + l.map(e => H((REASON[e.reason] || 'Return') + ' → ' + (OUTCOME[e.outcome] || e.outcome || '') + (e.outcome === 'refund' && e.refund ? ' ' + inr(e.refund) : '') + (e.doneAt ? ' (' + dd(e.doneAt) + ')' : ''))).join('; ') + '</p>';
  }
  function drawRetForm(o, s, r) {
    const c = CHECK || {}, a = addrOf(o), br = branches(), st = shopSet();
    if (!RMODE) RMODE = r && r.via && r.via !== 'shop' && r.srOrderId ? r.via : 'shop';
    /* the glasses go back to the branch that sent them (else the last one used, the order's branch, the first with an address) */
    const sentFrom = s && s.from && br.indexOf(s.from) >= 0 ? s.from : '';
    const from = r && r.from && br.indexOf(r.from) >= 0 ? r.from : sentFrom || (recall('rfrom') && br.indexOf(recall('rfrom')) >= 0 ? recall('rfrom') : (br.indexOf(o.store) >= 0 ? o.store : (br.find(b => st.branchAddr && st.branchAddr[b] && st.branchAddr[b].address) || br[0] || '')));
    const box = Object.assign({ l: 20, b: 12, h: 8, kg: 0.5 }, (st.parcel && st.parcel.box) || {});
    let h = '<div class="who"><b>' + H(o.name || 'Customer') + '</b> &middot; ' + H(o.phone || 'no mobile') + (o.total ? ' &middot; ' + inr(o.total) : '') + ' &middot; ' + H(o.payStatus || 'Unpaid') + '</div>';
    const dAt = deliveredOn(o, s);
    if (dAt) { const days = Math.floor((Date.now() - new Date(dAt).getTime()) / 86400e3); h += '<div class="' + (days > 7 ? 'warn' : 'info') + '">Delivered ' + H(dd(dAt)) + ' (' + days + ' day' + (days === 1 ? '' : 's') + ' ago). Your policy: returns within 7 days of delivery.</div>'; }
    if (r) h += '<div class="info"><b>Return open</b> &mdash; ' + H(REASON[r.reason] || 'Return') + (r.pays === 'customer' ? ' &middot; the customer pays the pickup' : ' &middot; the shop pays the pickup') + (r.note ? '<br>' + H(r.note) : '') + '</div>';
    if (r && r.srOrderId && !r.awb) h += '<div class="warn">A Shiprocket return order (no. ' + H(r.srOrderId) + ') was made but has <b>no courier yet</b>' + (r.note ? '' : '') + '. BOOK PICKUP again uses it (if you change the address it is cancelled and made again).</div>';
    if (!r) {
      h += '<label for="rvReason">Reason</label><select id="rvReason" class="rsel"><option value="">Choose&hellip;</option>' + REASONS.map(x => '<option value="' + x[0] + '">' + H(x[1]) + '</option>').join('') + '</select>';
      h += '<label for="rvPays">Pickup cost paid by</label><select id="rvPays" class="rsel"><option value="shop">The shop (our fault: wrong power, lens fault, damaged)</option><option value="customer">The customer (taken off the refund)</option></select>';
    }
    h += '<label>How the glasses come back</label>' + rWays(c);
    if (RMODE === 'shop') {
      h += '<div class="info">The customer brings the glasses to a branch. No message is sent &mdash; please call the customer.</div>';
      if (canEdit()) h += '<div class="act">' + (r ? '<button type="button" class="main" data-r="recv">RECEIVED AT SHOP</button><button type="button" class="red" data-r="cancel">CANCEL RETURN</button>' : '<button type="button" class="main" data-r="open">SAVE RETURN</button>') + '</div>';
      if (r) h += '<label for="rvCheck">Condition when received <span class="muted">(optional)</span></label><input id="rvCheck" maxlength="200" placeholder="e.g. frame fine, left lens scratched">';
    } else if (RMODE === 'hand') {
      h += '<label for="rvCo">Who collects it</label><input id="rvCo" list="rvCoList" placeholder="e.g. Our staff"><datalist id="rvCoList"><option>Our staff</option><option>Porter</option><option>Rapido</option></datalist>';
      h += '<div class="info">The customer gets one WhatsApp: who will collect the glasses, and to keep them packed in their case with the bill.</div>';
      if (canEdit()) h += '<div class="act"><button type="button" class="main" data-r="open">SAVE &amp; TELL THE CUSTOMER</button>' + (r ? '<button type="button" class="red" data-r="cancel">CANCEL RETURN</button>' : '') + '</div>';
    } else {
      h += '<label for="rvAddr">Collect from (the customer&rsquo;s address)</label><textarea id="rvAddr">' + H(a.line) + '</textarea>';
      h += '<div class="g2"><div><label for="rvLand">Landmark</label><input id="rvLand" value="' + H(a.landmark) + '"></div><div><label for="rvPin">Pincode</label><input id="rvPin" inputmode="numeric" maxlength="6" value="' + H(a.pin) + '"></div></div>';
      h += '<div class="g2"><div><label for="rvCity">City</label><input id="rvCity" value="' + H(a.city) + '"></div><div><label for="rvState">State</label><input id="rvState" value="' + H(a.state) + '"></div></div>';
      h += '<label for="rvFrom">Comes back to (branch)</label><select id="rvFrom">' + br.map(b => '<option' + (b === from ? ' selected' : '') + '>' + H(b) + '</option>').join('') + '</select>';
      { const ba = st.branchAddr && st.branchAddr[from]; if (!ba || !ba.address || !ba.phone) h += '<div class="warn">The glasses come back to this branch: its address and phone are needed in <b>Settings &rarr; Delivery</b>.</div>'; }
      if (RMODE === 'shiprocket') h += '<label>Box (cm) and weight (kg)</label><div class="g4"><input id="rvL" inputmode="decimal" value="' + H(box.l) + '" aria-label="Length cm"><input id="rvB" inputmode="decimal" value="' + H(box.b) + '" aria-label="Breadth cm"><input id="rvH" inputmode="decimal" value="' + H(box.h) + '" aria-label="Height cm"><input id="rvKg" inputmode="decimal" value="' + H(box.kg) + '" aria-label="Weight kg"></div>';
      h += '<div id="rvRates"></div>';
      const on = RMODE === 'borzo' ? c.borzo : c.shiprocket;
      h += '<div class="info">The customer gets one WhatsApp when the pickup is booked: who collects it' + (RMODE === 'shiprocket' ? ', the date and the tracking number' : '') + ', and to keep the glasses packed in their case with the bill.</div>';
      if (canEdit()) h += '<div class="act"><button type="button" data-r="quote">SEE PRICES</button><button type="button" class="main" data-r="book"' + (on ? '' : ' disabled') + '>BOOK PICKUP</button>' + (r ? '<button type="button" class="red" data-r="cancel">CANCEL RETURN</button>' : '') + '</div>';
      if (!on) h += '<div class="info">' + (RMODE === 'borzo' ? 'Borzo' : 'Shiprocket') + ' is not connected yet &mdash; see the setup guide.</div>';
      else if (RMODE === 'borzo' && c.borzoTest) h += '<div class="info"><b>TEST MODE</b> &mdash; no real rider comes and nothing is charged.</div>';
    }
    if (!r) h += '<label for="rvNote">Note <span class="muted">(optional)</span></label><input id="rvNote" maxlength="200" placeholder="e.g. customer says the left lens is blurry">';
    h += '<div id="dvMsg" hidden></div>' + pastReturns(s);
    paint(h);
    if (RQUOTE && RQUOTE.ref === OPEN) showRQuote();
  }
  function showRQuote() {
    const el = $id('rvRates'); if (!el || !RQUOTE || RQUOTE.ref !== OPEN) return;
    let h = '';
    if (RMODE === 'shiprocket') {
      const q = RQUOTE.shiprocket;
      if (!q) h = '<div class="info">Shiprocket is not connected.</div>';
      else if (!q.ok) h = '<div class="err">' + H(q.error) + '</div>';
      else if (!q.couriers.length) h = '<div class="err">No courier picks up returns at this pincode.</div>';
      else h = '<div class="rates">' + q.couriers.map((c, i) => '<label><input type="radio" name="rvCourier" value="' + H(c.id) + '" data-rate="' + H(c.rate) + '"' + ((q.recommended ? c.id === q.recommended : i === 0) ? ' checked' : '') + '><span>' + H(c.name) + (c.id === q.recommended ? ' &middot; <i>recommended</i>' : '') +
        '<small>' + (c.days ? H(c.days) + ' day' + (String(c.days) === '1' ? '' : 's') : '') + '</small></span><span class="r">' + inr(c.rate) + '</span></label>').join('') + '</div>';
    } else if (RMODE === 'borzo') {
      const q = RQUOTE.borzo;
      if (!q) h = '<div class="info">Borzo is not connected.</div>';
      else if (!q.ok) h = '<div class="err">' + H(q.error) + '</div>';
      else h = '<div class="good">Rider price: ' + inr(q.price) + ' &middot; today' + (q.test ? ' (TEST &mdash; nothing charged)' : '') + '</div>';
    }
    const other = RMODE === 'shiprocket' ? RQUOTE.borzo : RMODE === 'borzo' ? RQUOTE.shiprocket : null;
    if (other && other.ok) {
      const cheapest = RMODE === 'borzo' && other.couriers && other.couriers.length ? other.couriers.reduce((m, c) => c.rate < m.rate ? c : m, other.couriers[0]) : null;
      const line = RMODE === 'shiprocket' ? 'RIDER PICKUP (Borzo): <b>' + inr(other.price) + '</b> &middot; today' : cheapest ? 'COURIER PICKUP (Shiprocket): from <b>' + inr(cheapest.rate) + '</b>' : '';
      if (line) h += '<div class="info sbs"><span>' + line + '</span> <button type="button" class="use" data-rway="' + (RMODE === 'shiprocket' ? 'borzo' : 'shiprocket') + '">' + (RMODE === 'shiprocket' ? 'USE RIDER' : 'USE COURIER') + '</button></div>';
    }
    el.innerHTML = h;
  }
  function drawRetActive(o, s, r) {
    const rider = r.via === 'borzo';
    let h = '<div class="now">' + H(r.text || RCHIP[r.step] || '') + '</div>';
    if (r.test) h += '<div class="info"><b>TEST booking</b> on Borzo&rsquo;s test system &mdash; no real rider.</div>';
    if (r.note) h += '<div class="warn">' + H(r.note) + '</div>';
    if (r.step === 'booking' && r.bzTry && !r.bzOrderId) h += '<div class="warn">The last rider booking for this return may have gone through (the website lost Borzo&rsquo;s answer). <b>Look in the Borzo app first</b> and cancel any rider booked there. Then tap CANCEL PICKUP here and book again.</div>';
    if (r.step === 'pickupfail') h += '<div class="warn">The ' + (rider ? 'rider' : 'courier') + ' could not collect the glasses. Call the customer. Then: CHECK NOW (a new attempt may come), CANCEL PICKUP (the customer brings it to a branch instead), or CANCEL RETURN.</div>';
    if (r.step === 'arrived') h += '<div class="good">The ' + (rider ? 'rider' : 'courier') + ' has delivered the glasses at the shop. Check them, then tap RECEIVED AT SHOP.</div>';
    h += '<dl>';
    const row = (k, v) => { if (v) h += '<dt>' + H(k) + '</dt><dd>' + v + '</dd>'; };
    row('Reason', H(REASON[r.reason] || ''));
    row('Pickup paid by', r.pays === 'customer' ? 'The customer (off the refund)' : 'The shop');
    row('How', H(WAYNAME[r.via] || r.via || ''));
    row(rider ? 'Rider' : 'Collected by', H(r.courier || ''));
    if (r.rider && r.rider.name) row('Rider', H(r.rider.name) + (r.rider.phone ? ' &middot; <a href="tel:+' + H(r.rider.phone) + '">CALL</a>' : ''));
    row('Tracking no.', H(r.awb || ''));
    if (r.pickupAt) row('Pickup', H(r.pickupAt));
    row('Comes back to', H(r.from || ''));
    if (r.price) row('Pickup price', inr(r.price));
    if (r.srOrderId) row('Shiprocket no.', H(r.srOrderId));
    if (r.bzOrderId) row('Borzo no.', H(r.bzOrderId));
    row('Started', H(dd(r.startedAt) + (r.startedBy ? ' by ' + r.startedBy : '')));
    if (r.receivedAt) row('Received', H(dd(r.receivedAt) + (r.receivedBy ? ' by ' + r.receivedBy : '') + (r.checkNote ? ' — ' + r.checkNote : '')));
    h += '</dl>';
    const host = u => { try { const x = new URL(u); return x.protocol === 'https:' ? x.hostname.replace(/^www\./, '') : ''; } catch (e) { return ''; } };
    const th = host(r.trackUrl);
    if (th) h += '<div class="act"><a class="lime" href="' + H(r.trackUrl) + '" target="_blank" rel="noopener noreferrer">' + (rider ? 'RIDER LIVE MAP' : 'COURIER TRACKING') + ' &#8599;<small style="display:block;font-weight:600;font-size:.66rem;letter-spacing:0">' + H(th) + '</small></a></div>';
    const courierWay = r.via === 'shiprocket' || r.via === 'borzo';
    if (r.step === 'received') {
      const paid = num(o.paid), suggest = Math.max(0, r2(paid - (r.pays === 'customer' ? (Number(r.price) || 0) : 0)));
      h += '<label>What was done</label><div class="outs">' + OUTCOMES.map((x, i) => '<label><input type="radio" name="rvOut" value="' + x[0] + '"' + (i === 0 ? ' checked' : '') + '><span>' + H(x[1]) + '</span></label>').join('') + '</div>';
      h += '<label for="rvRefund">Refund amount &#8377; <span class="muted">(only for Refund' + (r.pays === 'customer' && r.price ? ' &mdash; paid ' + inr(paid) + ' less the pickup ' + inr(r.price) : '') + ')</span></label><input id="rvRefund" inputmode="decimal" value="' + H(suggest > 0 ? String(suggest) : '') + '">';
      h += '<label for="rvDoneNote">Note <span class="muted">(optional)</span></label><input id="rvDoneNote" maxlength="200">';
      h += '<div class="info">Remake / exchange / repair: after DONE, send the new pair with DELIVERY when it is ready. Refund: pay it back (UPI to UPI, cash at the branch).</div>';
      if (canEdit()) h += '<div class="act"><button type="button" class="main" data-r="done">DONE</button></div>';
    } else if (canEdit()) {
      if (!(r.step === 'booking')) h += '<label for="rvCheck">Condition when received <span class="muted">(optional)</span></label><input id="rvCheck" maxlength="200" placeholder="e.g. frame fine, left lens scratched">';
      h += '<div class="act">';
      if (courierWay && r.live) h += '<button type="button" data-r="refresh">CHECK NOW</button>';
      if (r.via === 'hand' && r.step === 'booked') h += '<button type="button" data-r="picked">PICKED UP</button>';
      if (!(courierWay && ['booked', 'pickupfail', 'booking'].indexOf(r.step) >= 0)) h += '<button type="button" class="main" data-r="recv">RECEIVED AT SHOP</button>';
      if (courierWay && ['booked', 'pickupfail', 'booking'].indexOf(r.step) >= 0) h += '<button type="button" data-r="cancelkeep">CANCEL PICKUP</button>';
      if (!(courierWay && ['picked', 'out', 'arrived'].indexOf(r.step) >= 0)) h += '<button type="button" class="red" data-r="cancel">CANCEL RETURN</button>';
      if (courierWay) h += '<button type="button" class="red" data-r="force">CLOSE (NO COURIER CALL)</button>';
      h += '</div>';
      if (courierWay) h += '<p class="muted">CLOSE only if the pickup is already cancelled in ' + (rider ? 'the Borzo app' : 'Shiprocket') + ', or the glasses are lost.</p>';
    }
    h += '<div id="dvMsg" hidden></div>';
    const list = r.scans && r.scans.length ? r.scans : (r.events || []).slice().reverse();
    if (list.length) h += '<ul class="ev">' + list.slice(0, 12).map(e => '<li>' + H(e.text) + '<span>' + H([dd(e.at), e.place].filter(Boolean).join(' · ')) + '</span></li>').join('') + '</ul>';
    h += pastReturns(s);
    paint(h);
  }
  function rform() { const v = id => ($id(id) ? $id(id).value : undefined); return { reason: v('rvReason'), pays: v('rvPays'), addr: v('rvAddr'), land: v('rvLand'), pin: v('rvPin'), city: v('rvCity'), state: v('rvState'), from: v('rvFrom'), l: v('rvL'), b: v('rvB'), h: v('rvH'), kg: v('rvKg'), note: v('rvNote'), co: v('rvCo'), check: v('rvCheck') }; }
  function rrestore(f) { const put = (id, v) => { if (v !== undefined && $id(id)) $id(id).value = v; }; put('rvReason', f.reason); put('rvPays', f.pays); put('rvAddr', f.addr); put('rvLand', f.land); put('rvPin', f.pin); put('rvCity', f.city); put('rvState', f.state); put('rvFrom', f.from); put('rvL', f.l); put('rvB', f.b); put('rvH', f.h); put('rvKg', f.kg); put('rvNote', f.note); put('rvCo', f.co); put('rvCheck', f.check); }
  function rBody() {
    const f = rform();
    if (f.from) remember('rfrom', f.from);
    return { from: f.from || recall('rfrom'), reason: f.reason || '', pays: f.pays || '', note: (f.note || '').trim(),
      to: { address: (f.addr || '').trim(), landmark: (f.land || '').trim(), pin: (f.pin || '').replace(/\D/g, ''), city: (f.city || '').trim(), state: (f.state || '').trim() }, box: { l: f.l, b: f.b, h: f.h, kg: f.kg } };
  }
  async function ract(what) {
    const ref = OPEN, o = order(ref); if (!o) return;
    if (BUSYSET.has(ref)) return;
    if (what !== 'quote' && what !== 'refresh' && typeof need === 'function' && !need('orders.edit')) return;
    BUSYSET.add(ref);
    document.querySelectorAll('#dlv .act button').forEach(b => { b.disabled = true; });
    msg('info', what === 'book' ? 'Booking the pickup… (this can take up to half a minute)' : 'Working…');
    let r;
    const f0 = rform();
    try {
      const v = id => ($id(id) ? $id(id).value.trim() : '');
      if (what === 'quote') {
        r = await api(Object.assign({ do: 'ret-quote', ref }, rBody()));
        if (OPEN !== ref || PANEL !== 'ret') return;
        if (!r.ok) { draw(); rrestore(f0); msg('err', r.error || 'Could not get prices'); return; }
        RQUOTE = Object.assign({ ref }, r); draw(); rrestore(f0); showRQuote(); msg('', ''); return;
      }
      if (what === 'book') {
        const ch = document.querySelector('#dlv input[name="rvCourier"]:checked'), mine = ch && RQUOTE && RQUOTE.ref === ref;
        r = await api(Object.assign({ do: 'ret-book', ref, via: RMODE, courierId: mine ? ch.value : '', rate: mine ? ch.dataset.rate : '' }, rBody()));
      } else if (what === 'open') r = await api(Object.assign(rBody(), { do: 'ret-open', ref, way: RMODE, courier: v('rvCo') }));
      else if (what === 'recv') r = await api({ do: 'ret-received', ref, note: v('rvCheck') });
      else if (what === 'picked') r = await api({ do: 'ret-step', ref });
      else if (what === 'refresh') r = await api({ do: 'ret-refresh', ref });
      else if (what === 'done') { const ch = document.querySelector('#dlv input[name="rvOut"]:checked'); r = await api({ do: 'ret-done', ref, outcome: ch ? ch.value : '', refund: v('rvRefund'), note: v('rvDoneNote'), value: num(o.total) > 0 ? r2(num(o.total)) : undefined }); }
      else r = await api({ do: 'ret-cancel', ref, keep: what === 'cancelkeep', force: what === 'force' });
      if (r.ship || (r.ok && r.ship === null)) keep(ref, r, r.ok && r.ship === null);
      if (!r.ok) {
        if (r.status && r.status !== 401) { const g = await api({ do: 'get', ref }); if (g.ok) keep(ref, { ship: g.ship || null, trackKey: g.trackKey }, true); }
        if (OPEN !== ref || PANEL !== 'ret') { try { if (typeof toast === 'function') toast(ref + ': ' + (r.error || 'It did not work')); } catch (e) {} return; }
        draw(); rrestore(f0); msg('err', r.error || 'It did not work -- try again');
        return;
      }
      const told = r.test ? ' (TEST: the message went to the manager’s WhatsApp.)' : r.whatsapp ? ' The customer got a WhatsApp about the pickup.' : ' The WhatsApp to the customer did not go -- please call them.';
      const said = { book: 'Pickup booked.' + told, open: RMODE === 'hand' ? 'Saved.' + told : 'Return saved. Please call the customer.', recv: 'Received at the shop.', picked: 'Saved.', refresh: 'Checked.',
        done: 'Done.' + (r.orderStatus === 'At Lab' ? ' The order is back At Lab. When the new pair is done, send it with DELIVERY (setting it Ready sends the customer the usual "ready" WhatsApp).' : ''), cancel: 'Return cancelled.', cancelkeep: 'Pickup cancelled -- the customer brings it to a branch.', force: 'Closed.' }[what] || 'Done.';
      if (what === 'done' || what === 'cancel' || what === 'force') { RMODE = ''; RQUOTE = null; }
      if (what === 'cancelkeep') RMODE = 'shop';
      try { if (typeof toast === 'function') toast(ref + ': ' + said); } catch (e) {}
      if (OPEN !== ref || PANEL !== 'ret') return;
      draw(); msg('good', said);
    } finally {
      BUSYSET.delete(ref);
      if (OPEN === ref) document.querySelectorAll('#dlv .act button').forEach(b => { if (b.dataset.locked !== '1') b.disabled = false; });
    }
  }
  document.addEventListener('click', e => {
    const t = e.target.closest && e.target.closest('.dlvRetBtn');
    if (t) { e.preventDefault(); e.stopPropagation(); window.dlvReturnOpen(t.dataset.ref); return; }
    const w = $id('dlv'); if (!w || w.hidden || !w.contains(e.target) || PANEL !== 'ret') return;
    const d = e.target.closest('[data-r],[data-rway]'); if (!d) return;
    if (d.dataset.rway) { const f = rform(); RMODE = d.dataset.rway; draw(); rrestore(f); return; }
    const k = d.dataset.r;
    if (k === 'reopen') return window.dlvReturnOpen(OPEN);
    const o = order(OPEN) || {};
    if ((k === 'open' || k === 'book') && $id('rvReason') && !$id('rvReason').value) { msg('err', 'Choose the reason for the return.'); $id('rvReason').focus(); return; }
    if (k === 'open' && RMODE === 'hand' && !($id('rvCo') && $id('rvCo').value.trim())) { msg('err', 'Type who collects it (e.g. Our staff).'); return; }
    if (k === 'book') {
      if (RMODE === 'shiprocket' && !document.querySelector('#dlv input[name="rvCourier"]:checked') && !confirm('No courier chosen -- let Shiprocket choose the courier?')) return;
      if (!confirm('Book a ' + (RMODE === 'borzo' ? 'rider (Borzo)' : 'courier pickup (Shiprocket)') + ' to collect the glasses for ' + OPEN + '? This spends money from your ' + (RMODE === 'borzo' ? 'Borzo' : 'Shiprocket') + ' account, and the customer gets a WhatsApp about the pickup.')) return;
    }
    if (k === 'open' && RMODE === 'hand' && !confirm('Save: ' + ($id('rvCo').value.trim()) + ' collects the glasses? The customer gets a WhatsApp about the pickup.')) return;
    if (k === 'cancel' && !confirm('Cancel the whole return for ' + OPEN + '?' + (o.ship && o.ship.ret && (o.ship.ret.awb || o.ship.ret.bzOrderId) ? ' The courier / rider is told.' : ''))) return;
    if (k === 'cancelkeep' && !confirm('Cancel the pickup? The courier / rider is told, and the return stays open: the customer brings the glasses to a branch.')) return;
    if (k === 'force' && !confirm('CLOSE this return WITHOUT telling the courier / rider?\n\nOnly if the pickup is already cancelled in their app, or the glasses are lost.')) return;
    if (k === 'done') {
      const ch = document.querySelector('#dlv input[name="rvOut"]:checked'), out = ch ? ch.value : '';
      if (out === 'refund') {
        if (typeof need === 'function' && !need('orders.payments')) return;
        const amt = num(($id('rvRefund') || {}).value);
        if (!(amt >= 1)) { msg('err', 'Type the refund amount.'); return; }
        if (num(o.total) > 0 && amt > num(o.total) + 0.001) { msg('err', 'The refund is more than the order total (' + inr(o.total) + ').'); return; }
        if (!confirm('Record a REFUND of ' + inr(amt) + ' for ' + OPEN + '? Pay it back to the customer (UPI to UPI, cash at the branch).')) return;
      } else if (!confirm('Close the return for ' + OPEN + ': ' + (OUTCOME[out] || '') + '?')) return;
    }
    ract(k);
  });
  /* a refund recorded on a return: the order's payment says so on this phone (once per return) */
  function retMark(o) {
    if (!trusted(o)) return false;
    const list = Array.isArray(o.ship.returns) ? o.ship.returns : [];
    const done = Array.isArray(o.refundsDone) ? o.refundsDone.slice() : [];
    let changed = false;
    list.forEach(e => {
      if (!e || e.outcome !== 'refund' || !(Number(e.refund) > 0) || !e.id || e.test || done.indexOf(e.id) >= 0) return;
      done.push(e.id); changed = true;
      o.refunded = String(r2(num(o.refunded) + Number(e.refund)));
      const fee = e.pays === 'customer' ? Number(e.price) || 0 : 0;
      if (num(o.paid) > 0 && num(o.refunded) >= num(o.paid) - fee - 0.001) o.payStatus = 'Refunded';
    });
    if (changed) o.refundsDone = done.slice(-20);
    return changed;
  }
  /* RETURNS line above the order list: how many, and why (only once there has been one) */
  window.dlvRetLine = function (all) {
    try {
      const panel = $id('panel-orders'), stats = panel && panel.querySelector('.stats'); if (!stats) return;
      let el = $id('dlvRetLine');
      const cnt = {}; let n = 0, open = 0;
      (all || []).forEach(o => {
        if (!trusted(o)) return;
        const s = o.ship;
        (Array.isArray(s.returns) ? s.returns : []).forEach(e => { if (!e || e.test || e.outcome === 'cancelled') return; n++; cnt[e.reason] = (cnt[e.reason] || 0) + 1; });
        const r = retOf(s); if (r && !r.test) { n++; open++; cnt[r.reason] = (cnt[r.reason] || 0) + 1; }
      });
      if (!n) { if (el) el.remove(); return; }
      if (!el) { el = document.createElement('div'); el.id = 'dlvRetLine'; el.className = 'dlvCodLine'; ($id('dlvCodLine') || stats).insertAdjacentElement('afterend', el); }
      el.innerHTML = '<span>RETURNS</span><span><b>' + n + '</b> in all</span>' + REASONS.filter(x => cnt[x[0]]).map(x => '<span><b>' + cnt[x[0]] + '</b> ' + H(x[1].toLowerCase()) + '</span>').join('') + (open ? '<span><b>' + open + '</b> open</span>' : '');
    } catch (e) {}
  };
  /* reason chosen -> who pays the pickup follows (the shop when it is our fault) */
  document.addEventListener('change', e => { if (e.target && e.target.id === 'rvReason' && $id('rvPays')) $id('rvPays').value = OUR_FAULT.indexOf(e.target.value) >= 0 ? 'shop' : 'customer'; });
  /* a mobile that refused cash on delivery before (another order of the same number) */
  function refusedBefore(o) {
    const me = String(o.phone || '').replace(/\D/g, '').slice(-10); if (me.length !== 10) return [];
    const out = [];
    (typeof getOrders === 'function' ? getOrders() : []).forEach(x => {
      if (!x || x.ref === o.ref || String(x.phone || '').replace(/\D/g, '').slice(-10) !== me || !trusted(x)) return;
      const s = x.ship, ca = codAmt(s);
      const now = ca > 0 && !s.cod.collectedAt && !s.test && ['returning', 'returned'].indexOf(s.step) >= 0;
      const before = (Array.isArray(s.history) ? s.history : []).some(e => e && Number(e.cod) > 0 && !e.codAt && !e.test && !e.codVoid && (['returning', 'returned', 'failed'].indexOf(e.step) >= 0 || e.why === 'returned'));
      if (now || before) out.push(x.ref);
    });
    return out.slice(0, 3);
  }
  /* CANCEL ORDER (a parcel that came back and will not be sent again) */
  function cancelOrder(ref) {
    if (typeof need === 'function' && !need('orders.edit')) return;
    const list = getOrders(), o = list.find(x => x.ref === ref); if (!o) return;
    const paid = num(o.paid);
    if (!confirm('CANCEL order ' + ref + '?' + (paid > 0 ? '\n\nThe customer has paid ' + inr(paid) + ' -- refund it, then set the payment to Refunded.' : ''))) return;
    o.status = 'Cancelled'; saveOrders(list);
    try { if (window.VGSync && VGSync.ready() && VGSync.updateStatus) Promise.resolve(VGSync.updateStatus(ref, 'Cancelled')).catch(() => {}); } catch (e) {}
    try { if (typeof toast === 'function') toast(ref + ' cancelled.' + (paid > 0 ? ' Refund ' + inr(paid) + ', then set the payment to Refunded.' : '')); } catch (e) {}
    if (OPEN === ref) draw();
  }

  /* ---------- the order list keeps itself fresh ---------- */
  /* parcels with no news for 20 minutes are asked about (the courier's updates usually come by themselves) */
  async function refreshAll() {
    try {
      if (document.hidden || typeof getOrders !== 'function') return;
      const live = getOrders().filter(o => trusted(o) && ((o.ship.live && o.ship.via !== 'hand') || (retOf(o.ship) && o.ship.ret.live)));
      if (!live.length) return;
      const r = await api({ do: 'refresh-all' });
      if (r.ok && Array.isArray(r.ships) && r.ships.length) r.ships.forEach(x => { if (x && x.ship) keep(x.ref, { ship: x.ship }); });
    } catch (e) {}
  }
  setTimeout(refreshAll, 20e3); setInterval(refreshAll, 15 * 60e3);
  /* every parcel record that arrives on this phone (with the orders, every 30 seconds) is confirmed with the website
     before it shows as booked, or the bill goes -- a record in an order a stranger made up is dropped here */
  let VERIFYING = false;
  async function verifyRound() {
    if (VERIFYING || typeof getOrders !== 'function') return;
    if (!(window.VGAuth && VGAuth.signedIn && VGAuth.signedIn())) return;
    const need = getOrders().filter(o => o && o.ref && o.ship && !trusted(o)).map(o => o.ref).slice(0, 60);
    if (!need.length) return;
    VERIFYING = true;
    try {
      const r = await api({ do: 'verify', refs: need });
      if (!r.ok || !r.ships) return;
      const list = getOrders(); let changed = false;
      need.forEach(ref => {
        const o = list.find(x => x.ref === ref); if (!o) return;
        const g = r.ships[ref];
        if (g) { o.ship = g; VERIFIED[ref] = vkey(g); codMark(o); retMark(o); changed = true; }
        else if (o.ship) { delete o.ship; delete VERIFIED[ref]; changed = true; }
      });
      if (changed) saveOrders(list);
    } catch (e) {} finally { VERIFYING = false; }
  }
  setTimeout(verifyRound, 3e3); setInterval(verifyRound, 30e3);
  window.dlvVerify = verifyRound;

  /* DELIVERED by the courier -> the shop's usual "Delivered" WhatsApp (thank-you, review link, the bill), sent once by
     whichever Admin phone sees it first (the server hands it to one phone only). Only for parcels delivered in the last
     3 days -- older ones have the SEND BILL button. */
  const DONE_TRY = {};
  async function sendDone() {
    try {
      if (typeof getOrders !== 'function' || typeof waAuto !== 'function') return;
      if (!(window.VGAuth && VGAuth.signedIn && VGAuth.signedIn())) return;
      codSweep();                                    /* a cash parcel delivered: marked paid before its bill goes */
      const fresh = getOrders().filter(o => trusted(o) && o.ship.step === 'delivered' && !o.ship.test && !o.doneSent && !DONE_TRY[o.ref] &&
        Date.now() - new Date((o.ship.told && o.ship.told.delivered) || o.ship.at || 0).getTime() < 3 * 86400e3);
      for (const o of fresh.slice(0, 5)) {
        DONE_TRY[o.ref] = 1;
        const r = await api({ do: 'claim', ref: o.ref });
        /* no answer (no internet, website busy): nothing is marked -- this phone asks again in a minute */
        if (!r.ok) { delete DONE_TRY[o.ref]; continue; }
        const list = getOrders(), x = list.find(y => y.ref === o.ref);
        if (x) { x.doneSent = x.doneSent || { at: new Date().toISOString(), here: !!r.claimed }; saveOrders(list); }
        /* the customer already had "delivered" + the review link from the website: this is the bill */
        if (r.claimed && x) { try { await waAuto(x, 'bill'); } catch (e) {} try { if (typeof waStaff === 'function') waStaff(x, 'done'); } catch (e) {} }
      }
    } catch (e) {}
  }
  setInterval(sendDone, 60e3); setTimeout(sendDone, 25e3);
  window.dlvSendDone = sendDone;
  /* staff marked an order Delivered by hand: that phone sends the message (as always) and this keeps a courier's
     "delivered" later from sending it a second time */
  window.dlvClaimManual = function (o) { if (o && o.ref) { DONE_TRY[o.ref] = 1; api({ do: 'claim', ref: o.ref, mode: 'manual' }).catch(() => {}); } };

  /* ---------- Settings -> Delivery ---------- */
  function settingsCard() {
    const panel = $id('panel-settings'); if (!panel || $id('dlvCard')) return;
    const card = document.createElement('div'); card.className = 'card'; card.id = 'dlvCard';
    const first = $id('upiCard'); if (first) panel.insertBefore(card, first); else panel.appendChild(card);
    fillCard();
  }
  async function fillCard() {
    const card = $id('dlvCard'); if (!card) return;
    const st = shopSet(), ba = st.branchAddr || {}, p = st.parcel || {}, box = Object.assign({ l: 20, b: 12, h: 8, kg: 0.5 }, p.box || {});
    card.innerHTML = '<div class="card-head"><h3>Delivery (courier, rider, Track my order)</h3></div>' +
      '<p class="muted" style="margin:0 0 10px">Orders &rarr; <b>DELIVERY</b> sends an order by courier (Shiprocket), by a same-day rider (Borzo) or by hand. The customer gets WhatsApp updates and a <b>Track my order</b> page. The rider collects from the branch address below.</p>' +
      '<p class="lens-hint" id="dlvState" style="margin:0 0 12px">Checking&hellip;</p>' +
      (function () { const cs = codStats(typeof getOrders === 'function' ? getOrders() : []); return cs.sent ? '<div class="dlvCodLine">' + codStatsHtml(cs) + '</div>' : ''; })() +
      '<table class="bt"><thead><tr><th>Branch</th><th>Full address (for the rider)</th><th>Pincode</th><th>Phone</th></tr></thead><tbody>' +
      branches().map(b => { const x = ba[b] || {}; return '<tr data-b="' + H(b) + '"><td><b>' + H(b) + '</b></td><td><input class="dA" value="' + H(x.address || '') + '" placeholder="Shop no., building, street, area, Mumbai"></td><td><input class="dP" inputmode="numeric" maxlength="6" value="' + H(x.pin || '') + '" placeholder="400098"></td><td><input class="dF" inputmode="tel" value="' + H(x.phone || '') + '" placeholder="98xxxxxxxx"></td></tr>'; }).join('') +
      '</tbody></table>' +
      '<div class="row2" style="margin-top:10px"><div class="fld"><label>Usual box (cm) and weight (kg)</label><div style="display:grid;grid-template-columns:repeat(4,1fr);gap:6px"><input id="dBl" value="' + H(box.l) + '" aria-label="Length"><input id="dBb" value="' + H(box.b) + '" aria-label="Breadth"><input id="dBh" value="' + H(box.h) + '" aria-label="Height"><input id="dBk" value="' + H(box.kg) + '" aria-label="Weight kg"></div><div class="hint">A pair in a hard case + bubble wrap fits 20 &times; 12 &times; 8 cm, 0.5 kg (the cheapest slab).</div></div>' +
      '<div class="fld"><label for="dPay">How Borzo is paid</label><select id="dPay"><option value="">Borzo account&rsquo;s own setting</option><option value="non_cash"' + (p.borzoPay === 'non_cash' ? ' selected' : '') + '>From the Borzo balance</option><option value="cash"' + (p.borzoPay === 'cash' ? ' selected' : '') + '>Cash to the rider at the shop</option></select></div></div>' +
      '<div style="display:flex;gap:8px;align-items:center;margin-top:10px;flex-wrap:wrap"><button type="button" class="btn btn-dark btn-sm" id="dlvSave">SAVE</button><span id="dlvSaved" class="pe-hint"></span></div>' +
      '<details style="margin-top:14px"><summary style="cursor:pointer;font-weight:700">Addresses for automatic updates (paste these once in Shiprocket and Borzo)</summary>' +
      '<p class="lens-hint" style="margin:8px 0 4px"><b>Shiprocket</b> &rarr; Settings &rarr; API &rarr; Webhooks: URL <code>' + SITE + '/api/parcel?do=news&amp;from=courier</code> and token = your <b>PARCEL_HOOK_KEY</b> (the one in Vercel).</p>' +
      '<p class="lens-hint" style="margin:4px 0"><b>Borzo</b> &rarr; API settings &rarr; Callback URL: <code>' + SITE + '/api/parcel?do=news&amp;from=rider&amp;k=</code> followed by your PARCEL_HOOK_KEY.</p>' +
      '<p class="lens-hint" style="margin:4px 0">Without these the website still checks each parcel every 20 minutes while Admin is open, and whenever a customer opens their tracking page.</p></details>' +
      '<details style="margin-top:10px"><summary style="cursor:pointer;font-weight:700">Cash on delivery &mdash; where the money goes</summary>' +
      '<p class="lens-hint" style="margin:8px 0 4px">In DELIVERY, <b>Collect on delivery</b> is filled with what is still to pay (total &minus; paid). 0 = a prepaid parcel.</p>' +
      '<p class="lens-hint" style="margin:4px 0"><b>Shiprocket</b> pays the cash into the bank account saved in your Shiprocket account, about 8&ndash;9 days after delivery (it pays out on Mondays, Wednesdays and Fridays). <b>Early COD</b> (Shiprocket &rarr; Settings &rarr; COD Payments) brings it in 2&ndash;4 days, for a fee. You see each payment in Shiprocket &rarr; COD Reconciliation.</p>' +
      '<p class="lens-hint" style="margin:4px 0"><b>Borzo</b>: the rider sends the cash the same day to the bank / UPI saved in your Borzo account (Borzo charges a small fee for this; it shows in the rider price).</p>' +
      '<p class="lens-hint" style="margin:4px 0">When a cash parcel is delivered the order is marked paid, and &ldquo;&#8377; TO COME&rdquo; shows on it until you tap <b>MONEY RECEIVED IN BANK</b> in its DELIVERY STATUS.</p></details>';
    const c = await check(true), el = $id('dlvState'); if (!el) return;
    const yes = (b, t) => (b ? '<b style="color:#17834F">&#10003; ' : '<b style="color:#B3261E">&#10007; ') + t + '</b>';
    el.innerHTML = c.missing ? '<b>The delivery part of the website is not uploaded yet.</b>' :
      [yes(c.shiprocket, 'Shiprocket'), yes(c.borzo, 'Borzo' + (c.borzoTest ? ' (TEST mode)' : '')), yes(c.news, 'automatic updates'), yes(c.whatsapp, 'WhatsApp to customers')].join(' &nbsp; ') +
      (!c.shiprocket || !c.borzo || !c.news ? '<br><span class="muted">Each one is switched on in Vercel &rarr; Settings &rarr; Environment Variables (see the setup guide). BY HAND works without any of them.</span>' : '');
  }
  document.addEventListener('click', e => {
    if (e.target && e.target.closest && e.target.closest('.tab[data-tab="settings"]')) setTimeout(() => { settingsCard(); fillCard(); }, 50);
    if (!e.target || e.target.id !== 'dlvSave') return;
    if (typeof need === 'function' && !need('settings.edit')) return;
    const said = $id('dlvSaved');
    /* the same rule as every other setting: never saved before the account's settings have arrived on this phone */
    if (typeof SHOP_READY !== 'undefined' && !SHOP_READY) { if (said) said.textContent = 'NOT SAVED — your settings have not loaded from your account yet. Reload the page and try again.'; return; }
    if (!(window.VGSync && VGSync.ready() && window.VGAuth && VGAuth.signedIn())) { if (said) said.textContent = 'NOT SAVED — you are signed out. Sign in and try again.'; return; }
    const next = Object.assign({}, shopSet(), window.dlvReadCard());
    try { SET = next; } catch (x) { window.SET = next; }
    write(LS.settings, next);
    if (said) said.textContent = 'Saved to your account — riders collect from these addresses.';
  });
  /* what Settings -> Delivery holds right now: the boxes as typed when the card is on screen, otherwise what is saved.
     Branches no longer in the shop list keep their saved address (a renamed branch is not wiped). */
  window.dlvReadCard = function () {
    const st = shopSet();
    const card = $id('dlvCard');
    if (!card || !card.querySelector('tr[data-b]')) return { branchAddr: st.branchAddr, parcel: st.parcel };
    const ba = Object.assign({}, st.branchAddr && typeof st.branchAddr === 'object' ? st.branchAddr : {});
    card.querySelectorAll('tr[data-b]').forEach(tr => {
      const a = tr.querySelector('.dA').value.trim(), p = tr.querySelector('.dP').value.replace(/\D/g, '').slice(0, 6), f = tr.querySelector('.dF').value.replace(/[^\d+ ]/g, '').trim();
      if (a || p || f) ba[tr.dataset.b] = { address: a.slice(0, 300), pin: p, phone: f.slice(0, 16) }; else delete ba[tr.dataset.b];
    });
    const num = (id, d, lo, hi) => { const v = Number(($id(id) || {}).value); return v >= lo && v <= hi ? v : d; };
    return { branchAddr: ba, parcel: Object.assign({}, st.parcel || {}, { box: { l: num('dBl', 20, 1, 100), b: num('dBb', 12, 1, 100), h: num('dBh', 8, 1, 100), kg: num('dBk', 0.5, 0.05, 20) }, borzoPay: ($id('dPay') || {}).value || '' }) };
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', settingsCard); else settingsCard();
})();

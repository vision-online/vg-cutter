/* Vision Gallery — the chat assistant's knowledge (d17.158, shop 20 Oct: "you train it, you know everything")

   One file for the website (chatbot.js) and the server (api/chat.js):
   - norm / qkey: a question reduced to its meaning-words, English and Hinglish alike
     ("chashma kitne ka hai" and "how much are glasses" both become "glasses price")
   - personal(): questions about one customer's own order, number or power -- never saved, never learned
   - facts(bag): everything true about the shop RIGHT NOW, read from Admin's settings (prices, branches, numbers)
   - KB + match(): the shop's own answers, written from the shop's rules; prices and numbers are filled in live
   - brief(): the same facts as text, handed to the smart answers for anything the list does not cover
   Prices are never typed into an answer: {sv_list}, {prog_list} etc. are filled from the current settings. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.VGBrain = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  /* ---------------- words ---------------- */
  /* every way a customer says the same thing -> one concept word */
  var SYN = {
    price: 'price kitna kitne kitni kitno rate rates cost costs costing charge charges daam dam paisa paise paisay amount mrp expensive cheap cheaper cheapest budget prices pricing kimat keemat',
    glasses: 'glasses glass chashma chasma chashme chasme chasmah specs spec spectacle spectacles eyeglass eyeglasses eyewear frame frames goggle',
    store: 'store stores shop shops dukaan dukan dukkan branch branches showroom outlet outlets',
    where: 'where kahan kaha kidhar address location located locate map directions direction near nearest area',
    timing: 'timing timings time open opens opening close closes closing hours hour khula khulta khulti khulte khulega band sunday sundays holiday',
    ready: 'ready banega bnega milega milenge milegi deliver delivered days day long take takes taking time duration jaldi',
    urgent: 'urgent urgently emergency fast faster quick quickly express asap tomorrow kal aaj today same',
    test: 'test tests testing checkup check checking exam examination checked',
    eye: 'eye eyes aankh aankhen ankh ankhen vision nazar sight',
    home: 'home ghar house doorstep visit',
    free: 'free muft',
    offer: 'offer offers discount discounts deal deals bogo sale scheme plus 1plus1',
    progressive: 'progressive progressives multifocal multifocals varifocal varifocals',
    bifocal: 'bifocal bifocals kryptok d-bifocal',
    difference: 'difference different differ vs versus compare comparison better best which',
    adapt: 'adapt adapting adaptation adjust adjusting used comfortable uncomfortable headache dizzy dizziness blur blurry problem problems issue',
    delivery: 'delivery deliveries courier ship shipping shipped post parcel dispatch',
    payment: 'payment payments pay paying upi gpay googlepay phonepe paytm cash cod card cards qr netbanking',
    warranty: 'warranty warranties guarantee guaranty broken break breaks toot toota tooti tuta damage damaged repair',
    scratch: 'scratch scratches scratched coating peel peeling peeled',
    returns: 'return returns returning refund refunds exchange exchanges wapas vapas replace replacement cancel cancellation',
    tryon: 'tryon try-on try virtual camera selfie mirror',
    face: 'face faces chehra chehre shape shapes round square oval heart long',
    colour: 'colour colours color colors rang shade shades',
    suits: 'suit suits suited suiting look looks achha accha acha sahi best nice good match matches',
    prescription: 'prescription prescriptions rx power powers number numbers upload paper slip report',
    pd: 'pd pupillary distance ipd',
    order: 'order orders ordered status track tracking',
    kids: 'kids kid child children bachcha bachche bacche baccha bachon school',
    contact: 'contact contacts lens-contact',
    lens: 'lens lenses',
    blue: 'blue computer screen screens laptop mobile phone digital cut block blocker radiation',
    sun: 'sunglass sunglasses shades goggles uv',
    photo: 'photochromatic photochromic transition transitions darken darkens sunlight dark tinted',
    thin: 'thin thinner thick thickness index heavy weight light high',
    reading: 'reading read padhai padhne near book books plus',
    human: 'call talk speak human person staff manager executive agent whatsapp',
    howorder: 'buy buying purchase purchasing place placing book booking',
    size: 'size sizes fit fitting width wide narrow big small',
    family: 'family wife husband mother father son daughter friend anyone second another',
    hello: 'hi hello hey hii hiii namaste namaskar salaam salam hola good morning evening',
    thanks: 'thanks thank thankyou thx ok okay great nice shukriya dhanyavad bye'
  };
  var MAP = {};
  Object.keys(SYN).forEach(function (k) { SYN[k].split(/\s+/).forEach(function (w) { if (w && !MAP[w]) MAP[w] = k; }); });
  var STOP = {};
  ('a an the is are am was were be been do does did i me my mine you your we our us it its this that these those to of in on for and or ' +
   'can could will would should shall may might what how when who whom why which please pls plz kya ka ki ke ko hai hain ho hoga hogi ' +
   'mujhe mera meri mere aap aapka aapki aapke apna apni hum ham se par pe me mein tha thi the bhi aur ya to toh na nahi nhi koi kuch ' +
   'have has had get got give gives need want wanted wants tell show know any some about there here with from at by as if so then than ' +
   'also just only very much more most sir madam bhai ji').split(/\s+/).forEach(function (w) { STOP[w] = 1; });

  function words(t) {
    return String(t || '').toLowerCase()
      .replace(/1\s*\+\s*1|buy\s*1\s*get\s*1|buy\s+one\s+get\s+one|ek\s+pe\s+ek|ek\s+par\s+ek|b1g1/g, ' 1plus1 ')
      .replace(/cash\s+on\s+delivery/g, ' cod ').replace(/how\s+much|kitne\s+ka|kitne\s+ki|kya\s+rate/g, ' price ')
      .replace(/how\s+(?:to|do\s+i|can\s+i|should\s+i)\s+(?:place\s+(?:an\s+)?)?order|order\s+kaise|kaise\s+order/g, ' buy ')
      .replace(/try[\s-]*on/g, ' tryon ').replace(/contact\s+lens(es)?/g, ' lens-contact ')
      .replace(/[^a-z0-9ऀ-ॿ\s-]/g, ' ').split(/\s+/).filter(Boolean);
  }
  /* the question's meaning-words: concepts first, other content words as they are */
  function norm(t) {
    var out = [];
    words(t).forEach(function (w) {
      var c = MAP[w] || (w.length > 4 && MAP[w.replace(/(es|s)$/, '')]) || null;
      if (c) { if (out.indexOf(c) < 0) out.push(c); return; }
      if (STOP[w] || w.length < 3 || /^\d+$/.test(w)) return;
      if (out.indexOf(w) < 0) out.push(w);
    });
    return out;
  }
  function qkey(t) { return norm(t).slice().sort().join(' '); }

  /* questions about one person -- never learned, never saved */
  function personal(t) {
    var s = String(t || '');
    return /\bVG[-\s]?[A-Z0-9]{3,}\b/i.test(s) ||                       /* an order reference */
      /(?:^|\D)(?:\+?91[\s-]?)?[6-9]\d{4}[\s-]?\d{5}(?:\D|$)/.test(s) ||   /* a mobile number */
      /[^\s@]+@[^\s@]+\.[a-z]{2,}/i.test(s) ||                            /* an e-mail */
      /[-+]\s?\d{1,2}(?:\.\d{1,2})?\b/.test(s) ||                         /* a power like -2.5 / +1.75 */
      /\b(?:sph|cyl|axis)\b/i.test(s) ||
      /\b(?:my|mera|meri|mere)\s+(?:order|orders|payment|parcel|delivery|glasses|chashma|chasma|frame|power|prescription|refund)\b/i.test(s) ||
      /\bmy name is\b|\bmera naam\b/i.test(s);
  }

  /* ---------------- the shop's facts, from Admin's settings ---------------- */
  var TIER_DEF = {
    sv: [{ name: 'Blue Block', price: 1500, on: true }, { name: 'Premium HD', price: 2500, on: true }, { name: 'Premium Plus', price: 3500, on: true }, { name: 'Premium Max', price: 4500, on: true }],
    prog: [{ name: 'Adaptive', price: 2800, on: true }, { name: 'Easy View', price: 4500, on: true }, { name: 'Ultra View', price: 5800, on: true }, { name: 'Max Clarity', price: 7000, on: true }]
  };
  /* the same reading of the 1+1 levels as the order page (sync.js offerTiers) */
  function tiers(shop) {
    var t = shop && shop.offerTiers && typeof shop.offerTiers === 'object' ? shop.offerTiers : null;
    var OLD = ['Progressive ARC', 'Progressive Blue Block', 'Progressive Premium', 'Progressive Max'];
    function pick(k) {
      return TIER_DEF[k].map(function (d, i) {
        var x = t && Array.isArray(t[k]) && t[k][i] ? t[k][i] : {};
        var oldName = k === 'prog' && x.name && x.name === OLD[i];
        var oldPrice = oldName && Number(x.price) === [2800, 3800, 4800, 5800][i];
        return { name: oldName ? d.name : String(x.name || d.name), price: oldPrice ? d.price : (Number(x.price) > 0 ? Number(x.price) : d.price), on: i === 0 ? true : (x.on === undefined || oldName ? d.on : !!x.on) };
      }).filter(function (x) { return x.on; });
    }
    return { sv: pick('sv'), prog: pick('prog') };
  }
  /* d17.210: the 1+1 SINGLE VISION SLOTS (the same reading as sync.js offerGroups) -- the single-vision 1+1 price is the
     FRAME's slot (frame + lenses): 1,500 Blue Block; 2,500 / 3,500 / 4,500 Premium HD free. Progressive is the same for
     every frame (the first design). A d17.209 list (no lens on its groups) gives way to the four slots, like sync.js. */
  function groups(shop) {
    var raw = shop && Array.isArray(shop.offerGroups) && shop.offerGroups.some(function (g) { return g && (g.lens === 'bb' || g.lens === 'hd'); }) ? shop.offerGroups : null;
    var all = raw ? raw.filter(function (g) { return g && g.id; }).map(function (g) { var pr = Math.round(Number(g.price) || 0); return { id: String(g.id), price: pr > 0 ? pr : 0, lens: g.lens === 'hd' ? 'hd' : 'bb', on: !!g.on && pr > 0 }; })
      : [{ id: 'g1', price: 1500, lens: 'bb', on: true }, { id: 'g2', price: 2500, lens: 'hd', on: true }, { id: 'g3', price: 3500, lens: 'hd', on: true }, { id: 'g5', price: 4500, lens: 'hd', on: true }];
    if (!all.some(function (g) { return g.on; })) {
      var g1 = null; all.forEach(function (g) { if (g.id === 'g1') g1 = g; });
      if (g1) { g1.price = g1.price || 1500; g1.on = true; } else all.unshift({ id: 'g1', price: 1500, lens: 'bb', on: true });
    }
    return all.filter(function (g) { return g.on; }).map(function (g) { g.text = g.lens === 'hd' ? 'Frame + Premium HD lenses (HD free in this range)' : 'Frame + Blue Block lenses'; return g; })
      .sort(function (a, b) { return a.price - b.price; });
  }
  /* d17.210: the 1+1 lens extras (sync.js svExtras): HD on Blue Block frames, Blue Block + Photochromic, thinner lenses */
  function extras(shop) {
    var x = shop && shop.svExtras && typeof shop.svExtras === 'object' ? shop.svExtras : {};
    var num = function (v) { var n = Math.round(Number(v)); return isFinite(n) && n > 0 ? n : 0; };
    var thin = []; ['1.61', '1.67', '1.74'].forEach(function (ix) { ['bb', 'hd', 'photo'].forEach(function (k) { if (x.thick && x.thick[k] && num(x.thick[k][ix]) && thin.indexOf(ix) < 0) thin.push(ix); }); });
    return { hd: x.hd === undefined ? 750 : num(x.hd), photo: num(x.photo), thin: thin };
  }
  var DESIGNS = [
    { name: 'Adaptive', desc: 'wide, sharp far and near zones; freeform technology widens the path between them' },
    { name: 'Easy View', desc: 'a wider, longer path from far to near with gentle side blur, quick to get used to' },
    { name: 'Ultra View', desc: 'shaped point-by-point, wide clear zones with little side blur' },
    { name: 'Max Clarity', desc: 'made for your frame, eye position and head posture, the biggest and smoothest clear zones' }
  ];
  function money(n) { return '₹' + Number(n || 0).toLocaleString('en-IN'); }
  function full(v) { var d = String(v || '').replace(/\D/g, ''); if (d.length === 11 && d[0] === '0') d = d.slice(1); return d.length === 10 ? '91' + d : d; }
  function pretty(d) { d = full(d); return d.length === 12 && d.slice(0, 2) === '91' ? '+91 ' + d.slice(2, 7) + ' ' + d.slice(7) : (d ? '+' + d : ''); }

  function facts(bag) {
    bag = bag || {}; var shop = bag.shop || {}, pay = bag.pay || {};
    var T = tiers(shop), G = groups(shop), X = extras(shop);
    var d0 = T.prog[0] ? T.prog[0].price : 2800, pBase = d0;   /* d17.210: progressive is the same for every frame */
    var sl = Number(shop.offerSphLimit), cl = Number(shop.offerCylLimit);
    var stores = (Array.isArray(shop.stores) && shop.stores.length ? shop.stores : ['JB Nagar', 'Chakala', 'Poonam Nagar', 'Marol', 'Marol Naka', 'Santacruz / Kalina', 'Mumbra'])
      .filter(function (s) { return s && !/deliver|goregaon/i.test(s); });
    var p = full(shop.phone), w = full(shop.wa); if (shop.sameNumber && p) w = p; if (!p) p = w; if (!w) w = p;
    var pays = [];
    if (!pay.upi || pay.upi.on !== false) pays.push('UPI / QR code at checkout');
    if (pay.link && pay.link.on) pays.push('an online payment link');
    if (!pay.cod || pay.cod.on !== false) pays.push('cash on delivery');
    if (!pay.card || pay.card.on !== false) pays.push('card or cash at the store');
    var designs = Array.isArray(bag.corr) && bag.corr.length ? bag.corr.filter(function (c) { return c && c.on !== false && c.name; }).map(function (c) { return { name: c.name, desc: String(c.desc || '').replace(/\.$/, '') }; }) : DESIGNS;
    return {
      shopName: shop.shopName || 'Vision Gallery',
      /* d17.210: single vision = the slots (with their lenses); progressive = the designs, the same for every frame */
      sv: G.map(function (g) { return { name: g.text, price: g.price }; }),
      prog: T.prog.map(function (t) { return { name: t.name, price: t.price }; }), groups: G, designs: designs, extras: X,
      stores: stores, hours: '10am to 10pm, every day',
      phone: pretty(p), wa: w, waDisplay: pretty(w),
      homeTest: String(shop.homeTest || '') === 'on',
      sphLimit: sl > 0 ? (sl === 6 && !shop.svExtras ? 8 : sl) : 8, cylLimit: cl > 0 ? cl : 4,   /* d17.210: as sync.js offerLimits */
      deliveryFee: 99, freeAbove: 1500, pays: pays,
      /* d17.158: Adaptive with anti-glare + blue filter -- the same price as the order page */
      oneOnly: !(shop.sellSingle === true),
      progAg: pBase + ((Number(shop.progAgBluePrice) > d0) ? Number(shop.progAgBluePrice) - d0 : 700)
    };
  }
  /* what a single-vision level's lenses have (order page: every level has anti-glare; a level named Blue adds the blue filter; Premium HD is HD, easy-clean, water-repellent) */
  function svWhat(name) {
    if (/blue/i.test(name)) return 'anti-glare + blue filter (for screens)';
    if (/hd/i.test(name)) return 'sharper HD lenses, easy-clean and water-repellent, with anti-glare';
    return 'premium lenses with anti-glare';
  }
  function list(xs) { return xs.length < 2 ? xs.join('') : xs.slice(0, -1).join(', ') + ' and ' + xs[xs.length - 1]; }
  function fill(tpl, F) {
    var V = {
      shop: F.shopName,
      sv_from: money(F.sv[0] && F.sv[0].price), prog_from: money(F.prog[0] && F.prog[0].price),
      sv_list: F.sv.map(function (t) { return '• ' + t.name + ' — ' + money(t.price); }).join('\n'),
      prog_list: F.prog.map(function (t, i) { return '• ' + t.name + ' — ' + money(t.price) + (i === 0 ? ' (hard coat), or ' + money(F.progAg) + ' with anti-glare + blue filter' : ''); }).join('\n'),
      sv_detail: F.sv.map(function (t) { return '• ' + t.name + ' — ' + money(t.price) + ': ' + svWhat(t.name); }).join('\n'),
      designs: F.designs.map(function (d) { return '• ' + d.name + ': ' + d.desc + '.'; }).join('\n'),
      stores: list(F.stores), store_count: String(F.stores.length), hours: F.hours,
      phone: F.phone || 'our customer care number', wa: F.waDisplay || 'our WhatsApp',
      pays: list(F.pays), fee: money(F.deliveryFee), free_above: money(F.freeAbove),
      sph: String(F.sphLimit), cyl: String(F.cylLimit),
      thin_line: F.extras && F.extras.thin.length ? 'You can add a thinner lens (' + F.extras.thin.join(' / ') + ') at checkout \u2014 the price for your frames shows there.' : 'WhatsApp us your prescription and we\u2019ll suggest the right lens.',
      hometest: F.homeTest ? 'You can also book a home eye test: tap BOOK A HOME EYE TEST on the home page, or WhatsApp us on ' + (F.waDisplay || 'our WhatsApp') + '.' : 'Just walk in to any branch.'
    };
    return String(tpl).replace(/\{(\w+)\}/g, function (m, k) { return V[k] !== undefined ? V[k] : m; });
  }

  /* ---------------- the shop's own answers ----------------
     need: every group must be present (a group = one of several concepts/words); any: extra words that help.
     {contact} at the end shows the WhatsApp / Call buttons under the answer. */
  var KB = [
    { id: 'hello', need: [['hello']], max: 3, a: 'Hello! 👋 Welcome to {shop}. Ask me about our 1+1 offer, frames, eye tests, Try On, delivery or your order.' },
    { id: 'thanks', need: [['thanks']], max: 3, a: 'You’re welcome! If you need anything else, I’m right here. 😊' },
    { id: 'timing', need: [['timing']], any: ['store', 'eye', 'test'], a: 'All our {store_count} branches are open {hours}.\n\nBranches: {stores}.' },
    { id: 'stores', need: [['store', 'where']], any: ['near', 'timing'], a: 'We have {store_count} branches in Mumbai: {stores}.\n\nAll open {hours}. Free eye test at every branch, no appointment needed.' },
    { id: 'eyetest', need: [['test', 'eye']], any: ['free', 'price', 'store', 'timing', 'book'], a: 'Eye tests are FREE at all our branches — no appointment needed. A qualified optometrist checks your eyes in a few minutes.\n\nBranches: {stores} (open {hours}).\n{hometest}' },
    { id: 'hometest', need: [['home'], ['test', 'eye']], a: '{hometest}\n\nOr visit any branch for a free eye test: {stores} (open {hours}).', contact: 1 },
    { id: 'offer', need: [['offer', '1plus1', 'free']], any: ['price', 'glasses', 'progressive'], a: 'Our 1+1 offer: TWO complete pairs — 2 frames + 2 pairs of lenses made to your power — for one price. Each frame shows its own 1+1 price.\n\nSingle vision:\n{sv_detail}\n\nProgressive (from):\n{prog_list}\n\nTwo frames with different 1+1 prices: each frame pays half of its own price. Different power is allowed, the second pair can be for anyone, and you can take it now or redeem it later.' },
    { id: 'price', need: [['price']], any: ['glasses', 'lens', 'offer'], a: 'Every frame comes with our 1+1 offer — two complete pairs (frame + lenses) for one price, shown on each frame:\n\nSingle vision:\n{sv_detail}\n\nProgressive (from):\n{prog_list}\n\nReading power is charged as single vision. Two frames with different 1+1 prices: each frame pays half of its own price. Pick a frame and you’ll see the exact price as you choose.' },
    { id: 'progprice', need: [['progressive']], any: ['price', 'offer', 'design', 'which', 'best'], a: 'Progressive 1+1 (two complete pairs), starting prices:\n{prog_list}\nFor a frame with a higher 1+1 price, each design costs that frame\u2019s progressive price plus the same extra.\nEasy View, Ultra View and Max Clarity all include anti-glare + blue filter.\n\nOur four designs:\n{designs}\n\nNot sure which? Easy View is the one most customers start with.' },
    { id: 'progbifocal', need: [['bifocal']], any: ['progressive', 'difference'], a: 'Bifocals have a visible line between distance and reading. Progressives have no line — distance, middle and reading blend smoothly, so they look like normal glasses.\n\nOur progressive 1+1 starts at {prog_from} for two pairs.' },
    { id: 'adapt', need: [['progressive'], ['adapt']], a: 'Most people get used to progressives in a few days. If you can’t get used to yours, come to any branch within 30 days — our progressive adaptation guarantee: we re-check, and if needed we re-make the lenses.', contact: 1 },
    { id: 'ready', need: [['ready']], any: ['glasses', 'progressive', 'lens', 'days'], a: 'Single-vision glasses are ready the next day. Progressive glasses take 3 days.\n\nNeed progressive urgently? WhatsApp us before you place the order — if we can make it by the next day we’ll confirm, and if not we’ll tell you straight away.', contact: 1 },
    { id: 'urgent', need: [['urgent']], any: ['glasses', 'progressive', 'ready', 'delivery'], a: 'Single vision is ready the next day, progressive in 3 days. If it’s urgent, WhatsApp us BEFORE you place the order — if we can do it faster we’ll confirm, and if not we’ll tell you straight away.', contact: 1 },
    { id: 'delivery', need: [['delivery', 'home']], any: ['price', 'free', 'ready', 'courier'], a: 'We deliver to your home. Delivery is free on orders above {free_above} (that’s every 1+1 order), otherwise {fee}. You can also collect from any branch — always free.\n\nSingle vision is ready the next day, progressive in 3 days.' },
    { id: 'payment', need: [['payment']], a: 'You can pay by {pays}. You’ll see the options at checkout. A UPI payment is confirmed to you on WhatsApp automatically.' },
    { id: 'warranty', need: [['warranty']], any: ['glasses', 'lens', 'scratch'], a: '1-year warranty on BOTH pairs, for manufacturing faults:\n• Frame faults are covered.\n• If the lens coating peels off, we replace the lens.\n\nNot covered: accidental damage (frame sat on, dropped or bent) and scratches on the lenses.' },
    { id: 'scratch', need: [['scratch']], a: 'If the lens coating peels off within 1 year, we replace the lens under warranty. Scratches and accidental damage are not covered.' },
    { id: 'returns', need: [['returns']], any: ['glasses', 'lens', 'days'], a: 'You can return within 7 days of delivery — the frame unused and undamaged, with the bill. Prescription lenses are made for you, so they are replaced only if there is a fault or the power is wrong.\n\nProgressive lenses also have a 30-day adaptation guarantee.', contact: 1 },
    { id: 'tryon', need: [['tryon']], any: ['face', 'glasses', 'camera'], a: 'Open any frame and tap TRY ON — your camera shows the frame live on your face, and it turns with you as you move. Nothing is recorded or saved. Hold the phone at arm’s length in good light for the best fit.' },
    { id: 'faceshape', need: [['face'], ['suits', 'glasses', 'which', 'difference']], a: 'A simple guide:\n• Round face: rectangle or square frames.\n• Square face: round or oval frames soften the jaw.\n• Oval face: almost any shape suits you.\n• Heart face: round, oval or light-bottom frames.\n• Long face: deep frames with a bold top line.\n\nThe easiest way: open a frame and tap TRY ON to see it on your face.' },
    { id: 'colour', need: [['colour'], ['suits', 'face', 'glasses', 'which', 'skin']], a: 'It mostly depends on your skin tone:\n• Wheatish / warm: brown, tortoise, gold, olive.\n• Fair / cool: black, silver, grey, blue, clear.\n• Dusky / deep: bold black, deep brown, gold, rich colours.\n\nTap TRY ON on any frame to see the colour on your own face.' },
    { id: 'suitme', need: [['suits'], ['glasses', 'difference']], a: 'Two quick tips:\n\u2022 Face shape: round face \u2192 rectangle or square frames; square face \u2192 round or oval; oval face \u2192 almost any shape.\n\u2022 Skin tone: wheatish \u2192 brown, tortoise, gold; fair \u2192 black, silver, blue; dusky \u2192 bold black, deep brown, gold.\n\nBest of all: open any frame and tap TRY ON to see it on your own face.' },
    { id: 'prescription', need: [['prescription']], any: ['upload', 'test', 'eye'], a: 'At checkout you can type your power, or upload a photo of your prescription slip. Don’t know your power? Choose the eye test — free at any branch — and we make your lenses after the test.' },
    { id: 'pd', need: [['pd']], a: 'PD is the distance between the centres of your pupils, in mm — it centres the lens in front of each eye. Most adults are between 54 and 74. If you don’t know it, leave it: we measure it for you.' },
    { id: 'myorder', need: [['order']], any: ['status', 'track', 'where', 'ready', 'delivery'], a: 'To check your order, open MY ORDERS (top menu), type the mobile number you ordered with, and tap SEND ON WHATSAPP — the details come to your WhatsApp. Or call us on {phone}.', contact: 1 },
    { id: 'howorder', need: [['howorder']], any: ['glasses', 'online', 'order'], a: 'It’s easy:\n1. Pick a frame (tap TRY ON to see it on your face).\n2. Choose your power type (single vision or progressive).\n3. Type your power, upload your prescription, or book a free eye test.\n4. Pay by {pays}.\nYou get two complete pairs with our 1+1 offer.' },
    { id: 'family', need: [['family']], any: ['offer', '1plus1', 'power', 'glasses'], a: 'Yes! With our 1+1 offer the second pair can be for anyone — family, friend or colleague — and a different power is allowed. You can also redeem the second pair later.' },
    { id: 'kids', need: [['kids']], a: 'We have kids’ frames sized for children from about age 5 — light and flexible for school. For a younger child, WhatsApp us and we’ll guide you.', contact: 1 },
    { id: 'contactlens', need: [['contact']], a: 'We stock daily, monthly and coloured contact lenses, with fitting support from our optometrists at every branch. WhatsApp us for brands and prices.', contact: 1 },
    { id: 'blue', need: [['blue']], any: ['lens', 'glasses', 'price'], a: 'Blue Block lenses cut the blue light from phones, laptops and TV screens — good if you spend long hours on screens. Our 1+1 starts at {sv_from} for two complete pairs — each frame shows its own 1+1 price and what lenses come with it.' },
    { id: 'sun', need: [['sun']], a: 'Yes, we have sunglasses — browse the Sunglasses shelf on the home page. Want sunglasses with your power? WhatsApp us and we’ll guide you.', contact: 1 },
    { id: 'photo', need: [['photo']], a: 'Photochromatic lenses stay clear indoors and darken automatically in sunlight. WhatsApp us for the options and price with your power.', contact: 1 },
    { id: 'thin', need: [['thin']], any: ['lens', 'power'], a: 'For higher powers we suggest a thinner, lighter lens so the glasses look slim: 1.61 above ±4.00, 1.67 above ±6.00 and 1.74 above ±8.00. {thin_line} The 1+1 price covers powers up to SPH ±{sph} and CYL −{cyl}; for higher powers our team will call you to confirm.', contact: 1 },
    { id: 'reading', need: [['reading']], any: ['glasses', 'price', 'power'], a: 'Reading glasses are charged as single vision with our 1+1 offer — two complete pairs from {sv_from}.' },
    { id: 'size', need: [['size']], any: ['glasses', 'face'], a: 'Every frame shows its size (lens, bridge, arm) on its page. Tap TRY ON to see how big it looks on your face — the try-on uses the real frame size.' },
    { id: 'human', need: [['human']], max: 4, a: 'Of course — WhatsApp us on {wa} or call our customer care on {phone}. We’re available {hours}.', contact: 1 }
  ];

  function has(ws, grp) { for (var i = 0; i < grp.length; i++) if (ws.indexOf(grp[i]) >= 0) return true; return false; }
  /* the best of the shop's answers for a question, with how sure it is */
  function match(q, extra) {
    var ws = norm(q); if (!ws.length) return null;
    var best = null;
    (extra || []).concat(KB).forEach(function (e) {
      if (!e || !e.need) return;
      for (var i = 0; i < e.need.length; i++) if (!has(ws, e.need[i])) return;
      if (e.max && ws.length > e.max) return;          /* "hi" alone, not "hi, what is the price" */
      var s = e.need.length * 3 + (e.any ? e.any.filter(function (a) { return ws.indexOf(a) >= 0; }).length : 0);
      var other = ws.filter(function (w) { return !(e.any && e.any.indexOf(w) >= 0) && !e.need.some(function (g) { return g.indexOf(w) >= 0; }); }).length;
      s -= other * 0.5;                                 /* words this answer says nothing about */
      if (!best || s > best.score) best = { e: e, score: s };
    });
    return best && best.score >= 2 ? best : null;
  }
  /* a learned (approved) answer for the same question asked another way */
  function sameQuestion(a, b) {
    var A = norm(a), B = norm(b); if (!A.length || !B.length) return false;
    if (A.slice().sort().join(' ') === B.slice().sort().join(' ')) return true;
    var inter = A.filter(function (w) { return B.indexOf(w) >= 0; }).length;
    var uni = A.length + B.length - inter;
    return A.length >= 2 && B.length >= 2 && inter / uni >= 0.75;
  }

  /* ---------------- the brief for the smart answers ---------------- */
  function brief(F, frames) {
    var L = [];
    L.push('You are the customer assistant on the website of ' + F.shopName + ', an optical shop chain in Mumbai (eyeglasses, sunglasses, contact lenses, eye tests).');
    L.push('');
    L.push('HOW TO ANSWER');
    L.push('- Reply like friendly, expert shop staff: short (under 80 words), warm, simple words. Use "• " bullets for lists. No markdown headings, no tables.');
    L.push('- Reply in the customer’s language: English, Hindi or Hinglish, matching how they wrote.');
    L.push('- Only use the facts below. NEVER invent a price, offer, discount, branch, timing, delivery date or promise. If a fact is not below, say our team will help and add [[CONTACT]].');
    L.push('- Never say you are an AI, a bot, a model, Gemini or Google. You are the ' + F.shopName + ' assistant.');
    L.push('- Never ask for or repeat a phone number, e-mail, order number or eye power in the chat. For anything about one customer’s own order or prescription, tell them to WhatsApp us and add [[CONTACT]].');
    L.push('- When you suggest a frame, use its exact name from the frame list. Encourage TRY ON to see a frame on their face.');
    L.push('- For medical worries (pain, redness, sudden vision loss, injury) advise seeing an eye doctor promptly; you may offer our free eye test for routine checks.');
    L.push('- Stay on eyewear and the shop. Politely decline anything else.');
    L.push('- If you cannot answer from these facts, reply: "Our team will help you with this." and add [[CONTACT]]. Put [[CONTACT]] at the very end, only when the customer should WhatsApp or call us.');
    L.push('');
    L.push('THE SHOP');
    L.push('- Branches (' + F.stores.length + '): ' + list(F.stores) + '. All open ' + F.hours + '.');
    L.push('- WhatsApp: ' + (F.waDisplay || '-') + '. Customer care calls: ' + (F.phone || '-') + '.');
    L.push('- Eye test: FREE at every branch, no appointment needed.' + (F.homeTest ? ' Home eye test can be booked on WhatsApp (home page: BOOK A HOME EYE TEST).' : ''));
    L.push('- 1+1 OFFER on every frame: two complete pairs (frame + lenses) for one price. Different power allowed; the second pair can be for anyone (family, friend, colleague); the second pair can be redeemed later after paying the full offer price.');
    L.push('- Single vision 1+1: the price depends on the FRAME \u2014 every frame is in a 1+1 slot and shows its own 1+1 price; the lenses come with it (both pairs): ' + F.sv.map(function (t) { return money(t.price) + ' = ' + t.name; }).join('; ') + '. Two frames with different 1+1 prices: each frame pays half of its own 1+1 price (e.g. ' + money(1500) + ' frame + ' + money(2500) + ' frame = ' + money(750) + ' + ' + money(1250) + ' = ' + money(2000) + '). Reading power is charged as single vision. If asked more about a lens than is written here, say our team will explain and add [[CONTACT]].');
    { var X = F.extras || { hd: 0, photo: 0, thin: [] }, ex = [];
      var bbP = (F.groups || []).filter(function (g) { return g.lens !== 'hd'; }).map(function (g) { return money(g.price); });
      if (X.hd && bbP.length) ex.push('Premium HD instead of Blue Block on a Blue Block frame (' + bbP.join(' / ') + '): +' + money(X.hd) + ' for the 1+1 (the HD frames already have it free)');
      if (X.photo) ex.push('Blue Block + Photochromic (clear indoors, dark in the sun) on any frame: +' + money(X.photo) + ' for the 1+1 (HD is not made photochromic)');
      if (X.thin.length) ex.push('thinner lenses ' + X.thin.join(' / ') + ' can be added at checkout, where the price for the customer\u2019s frames shows');
      L.push('- Single vision lens extras (prices for the whole 1+1; two frames with different 1+1 prices pay half each): ' + (ex.length ? ex.join('; ') : 'none at the moment') + '. We suggest 1.61 above ±4.00, 1.67 above ±6.00 and 1.74 above ±8.00 \u2014 the customer decides.'); }
    L.push('- Progressive 1+1 designs, the SAME price for every frame (both pairs): ' + F.prog.map(function (t, i) { return t.name + ' ' + money(t.price) + (i === 0 ? ' with hard coat (or ' + money(F.progAg) + ' with anti-glare + blue filter)' : ' with anti-glare + blue filter'); }).join('; ') + '.');
    L.push('');
    L.push('THE 1+1 OFFER IN DETAIL');
    L.push('- One price = TWO complete pairs: 2 frames + 2 pairs of lenses made to the customer\u2019s power. Lenses are 1.56 thin lenses as standard.');
    L.push('- Single vision = one power (for distance OR for reading). Progressive = distance, middle and reading in one lens with no line, for people who need reading power added (usually 40+).');
    L.push('- The second pair: the customer can add a second frame now, or pay the full offer price and keep the second pair for later and redeem it any time. It can be for anyone, with a different power.');
    L.push('- Example: "two pairs for ' + money(F.sv[0] ? F.sv[0].price : 0) + '" means the customer pays ' + money(F.sv[0] ? F.sv[0].price : 0) + ' once and gets both complete pairs.');
    L.push(F.oneOnly ? '- Every frame on the website is sold with the 1+1 offer; frames are not sold one at a time.' : '- Frames can also be bought one at a time at their own price; the 1+1 offer is the best value.');
    L.push('- Choosing: the frame decides the single-vision 1+1 price and its lenses; 40+ needing distance and reading in one -> progressive (Easy View is a good start; Adaptive is the lowest price; progressive costs the same for every frame).');
    L.push('- Progressive designs: ' + F.designs.map(function (d) { return d.name + ' (' + d.desc + ')'; }).join('; ') + '. Our progressives use freeform technology. Easy View is a good first choice.');
    L.push('- 1+1 prices cover powers up to SPH ±' + F.sphLimit + ' and CYL −' + F.cylLimit + '; for higher powers the customer can still order and our team calls to confirm the lenses and any extra.');
    L.push('- Ready time: single vision the next day; progressive 3 days. Urgent progressive: the customer must WhatsApp us BEFORE ordering; we confirm only if possible. Never promise next day yourself.');
    L.push('- Delivery: free above ' + money(F.freeAbove) + ' (every 1+1 order), otherwise ' + money(F.deliveryFee) + '. Collecting from a branch is always free.');
    L.push('- Payment: ' + list(F.pays) + '. A UPI payment is confirmed to the customer on WhatsApp automatically.');
    L.push('- Warranty: 1 year on BOTH pairs, for manufacturing faults only. Frame faults covered; if the lens coating peels off we replace the lens. NOT covered: accidental damage (sat on, dropped, bent) and scratches.');
    L.push('- Returns: within 7 days of delivery; frame unused and undamaged, with the bill. Prescription lenses are replaced only for a fault or a wrong power.');
    L.push('- Progressive adaptation guarantee: if the customer cannot get used to progressives, they visit any branch within 30 days; we re-check and re-make the lenses if needed.');
    L.push('- Kids frames: for children from about age 5. Contact lenses: daily, monthly and coloured, with fitting at our branches (prices on WhatsApp).');
    L.push('- On the website: TRY ON shows any frame live on the customer’s face through the camera (nothing recorded). Ordering: pick a frame, choose single vision or progressive (and the progressive design), type the power / upload the prescription / choose a free eye test, then pay. MY ORDERS (top menu): type the mobile number and the order details are sent on WhatsApp.');
    L.push('- Style help: round face -> rectangle/square frames; square face -> round/oval; oval face -> most shapes; heart face -> round/oval/light-bottom; long face -> deep frames with a bold top line. Warm/wheatish skin -> brown, tortoise, gold, olive; fair/cool skin -> black, silver, grey, blue, clear; dusky/deep skin -> bold black, deep brown, gold, rich colours.');
    L.push('');
    L.push('EXAMPLES OF GOOD ANSWERS');
    L.push('Q: 1+1 me kya milega? -> A: Ek price me do complete chashme \u2014 2 frames + 2 pairs lenses aapke power ke. Single vision ' + money(F.sv[0] ? F.sv[0].price : 0) + ' se, progressive ' + money(F.prog[0] ? F.prog[0].price : 0) + ' se. Dusra pair kisi aur ke liye bhi le sakte hain, alag power ke saath.');
    L.push('Q: Is the second pair also with lenses? -> A: Yes \u2014 both pairs are complete, frame + lenses made to power, with the lenses that come with the frame\u2019s 1+1 price.');
    L.push('Q: Can you make my progressive by tomorrow? -> A: Progressive normally takes 3 days. If it\u2019s urgent, please WhatsApp us before ordering \u2014 we\u2019ll confirm only if it\u2019s possible. [[CONTACT]]');
    L.push('Q: My frame broke after I sat on it, warranty? -> A: Sorry to hear that! The warranty covers manufacturing faults only, so accidental damage isn\u2019t covered \u2014 but bring it to any branch and we\u2019ll see what we can do. [[CONTACT]]');
    if (frames && frames.length) {
      L.push('');
      L.push('FRAMES ON THE WEBSITE NOW (name | type | shape | colour | 1+1 single vision | lenses in it) \u2014 progressive 1+1 is ' + money(F.prog[0] ? F.prog[0].price : 0) + ' (first design) for every frame:');
      var G = F.groups || [], gOf = function (p) { var id = p && p.offerGroup; var g = null; G.forEach(function (x) { if (x.id === id) g = x; }); if (!g) G.forEach(function (x) { if (x.id === 'g1') g = x; }); return g || G[0] || null; };
      frames.slice(0, 80).forEach(function (p) { var g = gOf(p); L.push('- ' + [p.name, p.cat, p.shape, p.colour, g ? money(g.price) : '', g ? (g.lens === 'hd' ? 'Premium HD free' : 'Blue Block') : ''].map(function (x) { return String(x || '-'); }).join(' | ')); });
      L.push('Every frame is sold with the 1+1 offer at ITS OWN 1+1 price shown above (two complete pairs, frame + lenses). Two frames with different 1+1 prices: each frame pays half of its own price. For a budget question, only suggest frames whose 1+1 price is within the budget.');
    }
    return L.join('\n');
  }

  return { norm: norm, qkey: qkey, personal: personal, tiers: tiers, facts: facts, fill: fill, KB: KB, match: match, sameQuestion: sameQuestion, brief: brief, money: money };
});

/* Vision Gallery — smart answers for the chat (d17.158, shop 20 Oct)

   The chat answers what it can from the shop's own list (chat-brain.js). Anything else comes here: the question,
   with the shop's facts and the frames on the website, goes to Google's free Gemini service, and the answer goes back
   to the customer. The question and answer are then kept as "to approve" in Admin -> CHATBOT; once a staff member
   approves one, the chat answers it from the shop's own list next time -- no outside service needed.

   Never learned: questions about one customer's order, number, e-mail or power.
   Needs on Vercel: GEMINI_KEY (free from aistudio.google.com) and SUPABASE_SERVICE_KEY (already there).
   Optional: GEMINI_MODEL (default gemini-flash-latest), CHAT_DAILY_MAX (default 400 answers a day).

   GET  /api/chat?check=1  -> { configured, learning }
   POST /api/chat          -> { q, history:[{who:'you'|'bot', text}] }   ->  { ok, answer, contact } */
'use strict';
const L = require('./_lib.js');
const B = require('../chat-brain.js');

const MODELS = () => [L.env('GEMINI_MODEL'), 'gemini-flash-latest', 'gemini-2.5-flash', 'gemini-flash-lite-latest'].filter((m, i, a) => m && a.indexOf(m) === i);
let DAY = '', COUNT = 0;
/* d17.203: the chat may have a Gemini key of its own (CHAT_GEMINI_KEY), so a stranger using up the chat can never stop
   the frame checks that share GEMINI_KEY */
const KEY = () => L.env('CHAT_GEMINI_KEY') || L.env('GEMINI_KEY');
/* d17.203: the day's total is kept in the database too (each copy of this function used to count on its own, from 0) */
async function dayGate(max) {
  const today = new Date(Date.now() + 5.5 * 3600e3).toISOString().slice(0, 10);
  try {
    const r = await L.db('/rest/v1/shop_private?select=data&id=eq.chatday');
    const d = r.ok && Array.isArray(r.body) && r.body[0] && r.body[0].data || {};
    const n = d.d === today ? (Number(d.n) || 0) : 0;
    if (n >= max) return false;
    await L.db('/rest/v1/shop_private?on_conflict=id', { method: 'POST', headers: { Prefer: 'resolution=merge-duplicates,return=minimal' },
      body: JSON.stringify([{ id: 'chatday', data: { d: today, n: n + 1 }, updated_at: new Date().toISOString() }]) });
  } catch (e) {}
  return true;
}

/* the customer never sees which service answered */
function scrub(t) {
  return String(t || '')
    .replace(/\b(?:as an? (?:ai|artificial intelligence|language model|virtual assistant)[^.,]*[.,]?\s*)/gi, '')
    .replace(/\b(?:gemini|google ai|bard|chatgpt|openai|large language model|language model)\b/gi, 'our team')
    .replace(/^#+\s*/gm, '').replace(/\*\*(.+?)\*\*/g, '$1').replace(/^\s*[-*]\s+/gm, '• ')
    .replace(/\n{3,}/g, '\n\n').trim();
}

async function frames() {
  try {
    const r = await L.db('/rest/v1/products?select=id,data&order=id.asc&limit=1000');
    if (!r.ok || !Array.isArray(r.body)) return [];
    /* the same frames a customer sees: no settings rows, nothing deleted, nothing the robot is still holding back */
    const live = p => p.tryOnFails === undefined || p.tryOnFails === null || !!(p.tryOnLocked || (p.tryOnReady && p.tryOnUrl));
    return r.body.filter(x => x && !String(x.id).startsWith('__') && x.data && !x.data.deleted)
      .map(x => Object.assign({}, x.data, { id: x.id }))
      .filter(p => p.name && live(p) && p.stock !== false)
      .map(p => ({ id: p.id, name: String(p.name), cat: p.cat || 'frames', shape: [p.shape, p.doubleBridge ? 'double bridge' : ''].filter(Boolean).join(', '), colour: p.colour || '', offerGroup: p.offerGroup || '' }));   /* d17.211: double bridge */   /* d17.209: its 1+1 price group */
  } catch (e) { return []; }
}
async function bag() {
  try { const r = await L.db('/rest/v1/products?select=data&id=eq.__shop'); return (r.ok && r.body && r.body[0] && r.body[0].data) || {}; } catch (e) { return {}; }
}

async function ask(system, history, q) {
  const contents = [];
  (Array.isArray(history) ? history : []).slice(-6).forEach(h => {
    const t = String(h && h.text || '').slice(0, 600); if (!t) return;
    contents.push({ role: h.who === 'you' ? 'user' : 'model', parts: [{ text: t }] });
  });
  while (contents.length && contents[0].role !== 'user') contents.shift();
  contents.push({ role: 'user', parts: [{ text: q }] });
  const body = JSON.stringify({ systemInstruction: { parts: [{ text: system }] }, contents, generationConfig: { temperature: 0.4, maxOutputTokens: 2048 } });
  let last = 'no answer';
  for (const m of MODELS()) {
    let r;
    try {
      r = await Promise.race([
        fetch('https://generativelanguage.googleapis.com/v1beta/models/' + encodeURIComponent(m) + ':generateContent', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-goog-api-key': KEY() }, body }),
        new Promise((_, j) => setTimeout(() => j(new Error('timeout')), 9000))
      ]);
    } catch (e) { last = e.message; continue; }
    let j = null; try { j = await r.json(); } catch (e) {}
    if (r.status === 404 || r.status === 400 && /not found|not supported/i.test(JSON.stringify(j || ''))) { last = 'model ' + m + ' not available'; continue; }
    if (!r.ok) return { ok: false, status: r.status, why: (j && j.error && j.error.message) || ('error ' + r.status) };
    const c = j && j.candidates && j.candidates[0];
    const text = c && c.content && Array.isArray(c.content.parts) ? c.content.parts.map(p => p.text || '').join('').trim() : '';
    if (text) return { ok: true, text, model: m };
    last = 'empty answer (' + (c && c.finishReason || 'no reason') + ')';
  }
  return { ok: false, why: last };
}

/* keep it for Admin -> CHATBOT -> TO APPROVE (one row per question, however it was worded) */
async function learn(q, a) {
  try {
    const key = B.qkey(q);
    const plain = String(a).replace(/\[\[CONTACT\]\]/g, '').trim();
    /* nothing worth keeping: a question about one person, or an answer that only says "ask our team" */
    if (!key || key.split(' ').length < 2 || B.personal(q) || plain.length < 50 || /^our team will help you/i.test(plain)) return 'skipped';
    const f = await L.db('/rest/v1/chat_learned?select=id,asks,status&qkey=eq.' + encodeURIComponent(key) + '&limit=1');
    if (!f.ok) return 'no table';
    const row = Array.isArray(f.body) && f.body[0];
    if (row) {
      await L.db('/rest/v1/chat_learned?id=eq.' + row.id, { method: 'PATCH', headers: { Prefer: 'return=minimal' }, body: JSON.stringify({ asks: (Number(row.asks) || 1) + 1, updated_at: new Date().toISOString() }) });
      return 'counted';
    }
    await L.db('/rest/v1/chat_learned', { method: 'POST', headers: { Prefer: 'return=minimal' }, body: JSON.stringify([{ qkey: key, q: String(q).slice(0, 300), a: plain.slice(0, 2000), status: 'pending', asks: 1 }]) });
    return 'saved';
  } catch (e) { return 'error'; }
}

module.exports = async function (req, res) {
  const q0 = L.query(req);
  const configured = !!KEY();
  if (req.method === 'GET' && q0.get('check')) return L.send(res, 200, { configured, learning: !!L.env('SUPABASE_SERVICE_KEY') });
  if (req.method !== 'POST') return L.send(res, 405, { ok: false, error: 'POST only' });
  if (!configured) return L.send(res, 501, { ok: false, configured: false });
  const b = await L.body(req) || {};
  const q = String(b.q || '').replace(/\s+/g, ' ').trim().slice(0, 400);
  if (!q) return L.send(res, 400, { ok: false, error: 'empty' });
  const ip = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim() || 'ip';
  if (L.tooMany('c:' + ip, 20, 3600e3)) return L.send(res, 429, { ok: false, busy: true });
  const today = new Date().toISOString().slice(0, 10);
  if (DAY !== today) { DAY = today; COUNT = 0; }
  if (COUNT >= (Number(L.env('CHAT_DAILY_MAX')) || 400)) return L.send(res, 429, { ok: false, busy: true });
  COUNT++;
  if (L.env('SUPABASE_SERVICE_KEY') && !(await dayGate(Number(L.env('CHAT_DAILY_MAX')) || 400))) return L.send(res, 429, { ok: false, busy: true });

  const [shopBag, list] = await Promise.all([bag(), frames()]);
  const F = B.facts(shopBag);
  const out = await ask(B.brief(F, list), b.history, q);
  if (!out.ok) return L.send(res, 502, { ok: false, why: out.why });
  let a = scrub(out.text);
  const contact = /\[\[CONTACT\]\]/.test(a);
  const learned = await learn(q, a);
  a = a.replace(/\s*\[\[CONTACT\]\]\s*/g, ' ').trim();
  return L.send(res, 200, { ok: true, answer: a, contact, learned });
};
module.exports.scrub = scrub;

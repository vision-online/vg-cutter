/* Vision Gallery — shared helpers for the website's small server functions (d17.155).
   These run on Vercel next to the website (folder /api). They hold the secret keys, so the
   browser never needs them:

     SUPABASE_SERVICE_KEY  the database's secret key (Supabase -> Project Settings -> API keys -> secret)
     SENDER_URL            the WhatsApp sender's send address, e.g. http://34.10.66.213:3000/send
     SENDER_KEY            the WhatsApp sender's key
     UPI_SMS_KEY           a password the phone's SMS-forwarding app puts in its link (?key=...)
     RESEND_KEY, MAIL_FROM optional: e-mail through Resend, from e.g. "Vision Gallery <orders@visiongallery.me>"

   Set them in Vercel -> the project -> Settings -> Environment Variables, then deploy again.
   Without them every function answers "not set up" and nothing else happens. */
'use strict';
const SB_URL = (process.env.SUPABASE_URL || 'https://oscpunukbyosckrmopeh.supabase.co').replace(/\/+$/, '');
const PUBLIC_KEY = process.env.SUPABASE_PUBLISHABLE_KEY || 'sb_publishable_WWAPQTu0lo-X51T4kDlgng_LR39PPkU';
const env = k => String(process.env[k] || '').trim();
const isJwt = k => /^ey[A-Za-z0-9_-]+\./.test(k);

function send(res, code, obj) {
  res.statusCode = code;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.end(JSON.stringify(obj));
}

function withTimeout(p, ms) { return Promise.race([p, new Promise((_, j) => setTimeout(() => j(new Error('timeout')), ms))]); }

/* the database, as the shop (secret key) */
async function db(path, opts) {
  opts = opts || {};
  const key = env('SUPABASE_SERVICE_KEY');
  if (!key) throw new Error('SUPABASE_SERVICE_KEY is not set');
  const h = { apikey: key, 'Content-Type': 'application/json' };
  if (isJwt(key)) h.Authorization = 'Bearer ' + key;
  Object.assign(h, opts.headers || {});
  const r = await withTimeout(fetch(SB_URL + path, { method: opts.method || 'GET', headers: h, body: opts.body }), 12000);
  let body = null; try { body = await r.json(); } catch (e) {}
  return { ok: r.ok, status: r.status, body };
}

/* is this request from a signed-in member of staff? (their Admin sign-in token) */
let ONLY = { at: 0, mail: '' };
async function onlyAccount() {                       /* the e-mail of the ONLY account in Supabase, or '' when there are more (10 min memory) */
  if (!env('SUPABASE_SERVICE_KEY')) return '';
  if (Date.now() - ONLY.at < 600e3) return ONLY.mail;
  const r = await db('/auth/v1/admin/users?page=1&per_page=200');
  if (!r.ok || !r.body) return '';
  const list = (Array.isArray(r.body) ? r.body : (r.body.users || [])).filter(x => x && x.email);
  ONLY = { at: Date.now(), mail: list.length === 1 ? String(list[0].email).toLowerCase() : '' };
  return ONLY.mail;
}
async function staffUser(req) {
  const a = String(req.headers.authorization || '');
  const tok = a.replace(/^Bearer\s+/i, '');
  if (!tok || tok === a) return null;
  try {
    const r = await withTimeout(fetch(SB_URL + '/auth/v1/user', { headers: { apikey: PUBLIC_KEY, Authorization: 'Bearer ' + tok } }), 8000);
    if (!r.ok) return null;
    const u = await r.json();
    /* d17.178 (review): only the SHOP account counts as staff (Admin signs in as it -- e-mail or name + passcode); any
       other account with an e-mail is not staff. SHOP_EMAIL in Vercel if the shop account ever changes; STAFF_EMAILS
       (comma separated) for extra staff accounts. */
    const mail = String((u && u.email) || '').toLowerCase(); if (!mail) return null;
    const allowed = [env('SHOP_EMAIL') || 'visionviewoptic@gmail.com'].concat(env('STAFF_EMAILS').split(',')).map(x => x.trim().toLowerCase()).filter(Boolean);
    if (allowed.indexOf(mail) >= 0) return u;
    return (await onlyAccount()) === mail ? u : null;   /* the shop's one account under another e-mail (same rule as the passcode sign-in) */
  } catch (e) { return null; }
}

/* d17.204: also "0091 98765 43210" and "+91 098765 43210" */
function phone10(v) { const d0 = String(v || '').replace(/\D/g, ''), d = /^00/.test(d0) && d0.length > 11 ? d0.slice(2) : d0; const m = /^(?:91)?0?([6-9]\d{9})$/.exec(d); return m ? m[1] : ''; }

function senderReady() { return !!(env('SENDER_URL') && env('SENDER_KEY')); }
async function whatsapp(phone, text, extra) {
  const url = env('SENDER_URL'), key = env('SENDER_KEY');
  if (!url || !key) return { ok: false, error: 'WhatsApp sender not set up' };
  const p = phone10(phone); if (!p) return { ok: false, error: 'bad number' };
  try {
    /* d17.161: the sender on the Google Cloud computer reads "number" and "message" (its log said "number and message are
       both needed"); "phone" and "text" are sent too, so either kind of sender understands */
    /* d17.162: the key goes the ways senders usually read it (header, Bearer, x-api-key, and in the body), so the sender
       finds it whichever it checks */
    /* d17.163: the sender on the Google Cloud computer (/opt/vg-sender/server.mjs) reads the key from ?key= or the x-key header (line 89),
       the number from ?phone= (line 97) or ?to= with ?text= (line 129) -- so they go in the address and the x-key header too */
    const q = new URLSearchParams({ key, phone: '91' + p, to: '91' + p, number: '91' + p });
    if (text && text.length <= 1500) { q.set('text', text); q.set('message', text); }
    const sendUrl = url + (url.indexOf('?') >= 0 ? '&' : '?') + q.toString();
    const r = await withTimeout(fetch(sendUrl, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Key': key, 'X-Send-Key': key, 'X-Api-Key': key, Authorization: 'Bearer ' + key },
      body: JSON.stringify(Object.assign({ phone: '91' + p, number: '91' + p, text, message: text, key }, extra || {})) }), 20000);
    const raw = await r.text().catch(() => ''); let b = {}; try { b = JSON.parse(raw); } catch (e) {}
    const why = b.error || b.message || b.reason || (!r.ok ? String(raw || '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 140) : '');
    return { ok: r.ok && b.ok !== false && b.success !== false, status: r.status, error: why || (r.ok ? '' : 'the sender answered ' + r.status) };
  } catch (e) { return { ok: false, error: e.message }; }
}

function mailReady() { return !!(env('RESEND_KEY') && env('MAIL_FROM')); }
async function email(to, subject, text) {
  if (!mailReady()) return { ok: false, error: 'e-mail not set up' };
  try {
    const r = await withTimeout(fetch('https://api.resend.com/emails', { method: 'POST', headers: { Authorization: 'Bearer ' + env('RESEND_KEY'), 'Content-Type': 'application/json' },
      body: JSON.stringify({ from: env('MAIL_FROM'), to: [to], subject, text }) }), 15000);
    return { ok: r.ok, status: r.status };
  } catch (e) { return { ok: false, error: e.message }; }
}

/* the shop's settings: public part + private part (staff numbers live in the private part since d17.155) */
async function shopSettings() {
  const out = {};
  try { const r = await db('/rest/v1/products?select=data&id=eq.__shop'); if (r.ok && r.body && r.body[0] && r.body[0].data) Object.assign(out, r.body[0].data.shop || {}); } catch (e) {}
  try { const r = await db('/rest/v1/shop_private?select=data&id=eq.shop'); if (r.ok && r.body && r.body[0] && r.body[0].data) Object.assign(out, r.body[0].data.shop || {}); } catch (e) {}
  return out;
}

async function body(req) {
  if (req.body !== undefined && req.body !== null && req.body !== '') {
    if (typeof req.body === 'string') { try { return JSON.parse(req.body); } catch (e) { return { text: req.body }; } }
    if (Buffer.isBuffer(req.body)) { const s = req.body.toString('utf8'); try { return JSON.parse(s); } catch (e) { return { text: s }; } }
    return req.body;
  }
  return await new Promise(resolve => {
    let s = ''; req.on('data', c => { s += c; if (s.length > 5e6) req.destroy(); });
    req.on('end', () => { try { resolve(JSON.parse(s)); } catch (e) {
      if (/=/.test(s) && !/\s/.test(s.split('&')[0])) { const o = {}; new URLSearchParams(s).forEach((v, k) => { o[k] = v; }); resolve(o); } else resolve({ text: s }); } });
    req.on('error', () => resolve({}));
  });
}

function query(req) { try { return new URL(req.url, 'http://x').searchParams; } catch (e) { return new URLSearchParams(); } }

/* a small memory of who asked recently (per running copy of the function) */
const HITS = new Map();
function tooMany(key, max, perMs) {
  const now = Date.now(), list = (HITS.get(key) || []).filter(t => now - t < perMs);
  if (list.length >= max) { HITS.set(key, list); return true; }
  list.push(now); HITS.set(key, list);
  if (HITS.size > 5000) HITS.clear();
  return false;
}

function rupees(n) { const v = Number(n) || 0; return '₹' + v.toLocaleString('en-IN', { maximumFractionDigits: 2 }); }

/* d17.158: the shop's two numbers as Admin -> Contact numbers holds them ("same number for both" honoured) */
function contactOf(shop) {
  shop = shop || {};
  const full = v => { let d = String(v || '').replace(/\D/g, ''); if (d.length === 11 && d[0] === '0') d = d.slice(1); return d.length === 10 ? '91' + d : d; };
  const pretty = d => d.length === 12 && d.startsWith('91') ? '+91 ' + d.slice(2, 7) + ' ' + d.slice(7) : (d ? '+' + d : '');
  let p = full(shop.phone), w = full(shop.wa);
  if (shop.sameNumber && p) w = p;
  if (!p) p = w; if (!w) w = p;
  return { phone: pretty(p), phoneDigits: p, wa: w, waDisplay: pretty(w) };
}
module.exports = { SB_URL, PUBLIC_KEY, env, send, db, staffUser, phone10, senderReady, whatsapp, mailReady, email, shopSettings, body, query, tooMany, rupees, contactOf };

/* Vision Gallery — the customer's side of an order, done by the website's own server (d17.203, security fix).

   The database no longer lets the public key READ or CHANGE orders (anyone could have read every customer's name,
   phone, address and prescription, or changed an order). The three things a customer's phone still needs are done
   here instead, with the secret key that never leaves the server:

     GET  /api/order?do=ref                                   -> { ok, ref: "VG-1024" }   the next order number
     POST /api/order  { do:"attach", ref, phone, patch }     -> the prescription attached to THAT order -- only when
                                                                 the order number AND the mobile number match it
     POST /api/order  { do:"vto", what:"open"|"share"|"basket" } -> today's try-on counts (+1)

   Nothing else can be changed through here: only the prescription fields, never the price, status (other than
   "Prescription Received") or payment. */
'use strict';
const L = require('./_lib.js');

const RX_KEYS = ['rxPath', 'rxUpload', 'od', 'os', 'pd', 'rxDate', 'prescriptionUpdatedAt'];
const EYE_KEYS = ['sph', 'cyl', 'axis', 'add', 'prism', 'pd'];
const ATTACH_FROM = ['New', 'Waiting for Prescription', 'Prescription Received', '', 'Confirmed'];   /* not once it is at the lab */
const IMG = /^data:image\/(jpeg|jpg|png|webp);base64,[A-Za-z0-9+/]+={0,2}$/;
const PDF = /^data:application\/pdf;base64,[A-Za-z0-9+/]+={0,2}$/;

const short = (v, n) => String(v == null ? '' : v).replace(/[<>"`]/g, '').trim().slice(0, n || 20);
function eye(x) { const o = {}; x = (x && typeof x === 'object') ? x : {}; EYE_KEYS.forEach(k => { o[k] = short(x[k], 12); }); return o; }
/* only the prescription, cleaned: short plain text, and a photo or PDF that really is one */
function cleanRx(p) {
  p = (p && typeof p === 'object') ? p : {};
  const out = {};
  if ('rxPath' in p) out.rxPath = p.rxPath === 'upload' ? 'upload' : 'manual';
  if ('od' in p) out.od = eye(p.od);
  if ('os' in p) out.os = eye(p.os);
  if ('pd' in p) out.pd = { total: short(p.pd && p.pd.total, 12) };
  if ('rxDate' in p) out.rxDate = short(p.rxDate, 20);
  out.prescriptionUpdatedAt = new Date().toISOString();
  const u = p.rxUpload;
  if (!('rxUpload' in p)) { /* not sent: left as it is */ }
  else if (u && typeof u === 'object' && typeof u.data === 'string') {
    const data = u.data.replace(/\s+/g, '');
    if ((IMG.test(data) || PDF.test(data)) && data.length <= 4.2e6)
      out.rxUpload = { name: short(u.name, 80) || 'Prescription', type: PDF.test(data) ? 'application/pdf' : (/^data:(image\/[a-z]+)/.exec(data) || [])[1] || 'image/jpeg', data };
    else return null;                            /* not a real photo or PDF -- refused */
  } else out.rxUpload = null;
  if (!('od' in out) && !('os' in out) && !out.rxUpload) return null;     /* nothing to attach */
  Object.keys(out).forEach(k => { if (RX_KEYS.indexOf(k) < 0) delete out[k]; });
  return out;
}

async function nextRef() {
  const r = await L.db('/rest/v1/orders?select=ref&order=created_at.desc&limit=300');
  if (!r.ok || !Array.isArray(r.body)) return null;
  let max = 1000;                                  /* the first order is VG-1001 */
  /* only normal numbers count (VG-1001 .. VG-999999), and a number far above all the others (a stranger's planted
     VG-999999) is passed over -- the shop's own numbers go up one by one */
  const nums = [...new Set(r.body.map(x => /^VG-(\d{4,6})$/.exec(String(x.ref || ''))).filter(Boolean).map(m => Number(m[1])))].sort((a, b) => b - a);
  for (let i = 0; i < 5 && nums.length > 1 && nums[0] - nums[1] > 1000; i++) nums.shift();
  if (nums.length) max = Math.max(max, nums[0]);
  if (max >= 999999) return null;
  return 'VG-' + (max + 1);
}

async function vto(what, frameId) {
  if (['open', 'frame', 'share', 'basket'].indexOf(what) < 0) return false;
  const r = await L.db('/rest/v1/products?select=data&id=eq.__vtoStats');
  const st = (r.ok && Array.isArray(r.body) && r.body[0] && r.body[0].data && typeof r.body[0].data === 'object') ? r.body[0].data : {};
  const day = new Date(Date.now() + 5.5 * 3600e3).toISOString().slice(0, 10);       /* India's date */
  const d = st[day] = Object.assign({ opened: 0, frames: 0, shares: 0, baskets: 0, frameIds: [] }, st[day] || {});
  if (what === 'open') d.opened = (Number(d.opened) || 0) + 1;
  if (what === 'frame') {
    d.frames = (Number(d.frames) || 0) + 1;
    const fid = String(frameId || '').replace(/[^A-Za-z0-9._\- ]/g, '').slice(0, 60);
    if (!Array.isArray(d.frameIds)) d.frameIds = [];
    if (fid && d.frameIds.indexOf(fid) < 0 && d.frameIds.length < 200) d.frameIds.push(fid);
  }
  if (what === 'share') d.shares = (Number(d.shares) || 0) + 1;
  if (what === 'basket') d.baskets = (Number(d.baskets) || 0) + 1;
  const days = Object.keys(st).filter(k => /^\d{4}-\d\d-\d\d$/.test(k)).sort();
  Object.keys(st).forEach(k => { if (!/^\d{4}-\d\d-\d\d$/.test(k)) delete st[k]; });
  while (days.length > 60) delete st[days.shift()];
  const w = await L.db('/rest/v1/products?on_conflict=id', { method: 'POST', headers: { Prefer: 'resolution=merge-duplicates,return=minimal' },
    body: JSON.stringify([{ id: '__vtoStats', data: st, updated_at: new Date().toISOString() }]) });
  return w.ok;
}

/* d17.203 GOOGLE: the list of every page Google should read -- the shop's pages and every frame on sale
   (https://visiongallery.me/sitemap.xml is sent here by vercel.json) */
const SITE = 'https://visiongallery.me';
const STATIC = [['/', 'daily', '1.0'], ['/prescription', 'monthly', '0.6'], ['/policies', 'monthly', '0.4'], ['/pd-guide', 'monthly', '0.4']];
const xmlEsc = v => String(v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&apos;');
async function sitemap(res) {
  let rows = [], full = false; const seen = new Set();
  try {
    /* d17.204: page by page -- the database answers at most 1,000 rows to one request */
    const yes = v => v === true || v === 'true';
    for (let off = 0; off < 50000; off += 1000) {
      const r = await L.db('/rest/v1/products?select=id,updated_at,deleted:data->>deleted,draft:data->>draft,waiting:data->>awaitingCheck&p_visible=is.true&or=(data->>tryOnReady.eq.true,data->>tryOnFails.is.null)&order=id.asc&limit=1000&offset=' + off);
      if (!r.ok || !Array.isArray(r.body)) break;
      /* only what a customer can open: never a deleted frame, a draft or one still waiting in TO CHECK (as the shop pages) */
      rows = rows.concat(r.body.filter(x => x && x.id && !/^__/.test(String(x.id)) && !yes(x.deleted) && !yes(x.draft) && !yes(x.waiting) && !seen.has(x.id) && seen.add(x.id)));
      if (r.body.length < 1000) { full = true; break; }
    }
  } catch (e) {}
  const day = v => { const d = new Date(v || Date.now()); return isNaN(d) ? new Date().toISOString().slice(0, 10) : d.toISOString().slice(0, 10); };
  const urls = STATIC.map(([p, f, pr]) => '<url><loc>' + SITE + p + '</loc><changefreq>' + f + '</changefreq><priority>' + pr + '</priority></url>')
    .concat(rows.map(x => '<url><loc>' + xmlEsc(SITE + '/product?id=' + encodeURIComponent(x.id)) + '</loc><lastmod>' + day(x.updated_at) + '</lastmod><changefreq>weekly</changefreq><priority>0.8</priority></url>'));
  res.statusCode = 200;
  res.setHeader('Content-Type', 'application/xml; charset=utf-8');
  res.setHeader('Cache-Control', full ? 'public, max-age=0, s-maxage=3600' : 'no-store');   /* d17.204: an incomplete list is never kept */
  res.end('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' + urls.join('\n') + '\n</urlset>\n');
}

/* d17.203 YOUR OWN REVIEWS (shop, 31 Oct: "whatever review we get, it has to come to our website, under our control -- if
   somebody types something wrong, we can delete it"). A customer's review is kept PRIVATE (waiting) until the shop taps
   APPROVE in Admin; nothing reaches the website by itself. With an order number + the mobile number on that order it is
   marked "Verified buyer". The manager hears about each one on WhatsApp. */
const BRANCHES = ['JB Nagar', 'Chakala', 'Poonam Nagar', 'Marol', 'Marol Naka', 'Santacruz / Kalina', 'Mumbra', 'Online'];
const plain = (v, n) => String(v == null ? '' : v).replace(/[\u0000-\u001f\u007f<>]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, n);
const noLinks = v => String(v || '').replace(/https?:\/\/\S+|www\.\S+|\S+@\S+|\+?\d[\d\s-]{5,}\d/gi, '…');
let REV_TOLD = { d: '', n: 0 };
async function review(b, ip) {
  const stars = Math.round(Number(b.stars));
  const text = plain(b.text, 600), name = plain(b.name, 40).replace(/[^\p{L}\p{M} .'-]/gu, '').trim();
  const store = BRANCHES.indexOf(String(b.store || '')) >= 0 ? String(b.store) : '';
  if (!(stars >= 1 && stars <= 5)) return { code: 400, body: { ok: false, error: 'Please tap the stars first.' } };
  if (text.length < 3) return { code: 400, body: { ok: false, error: 'Please write a few words.' } };
  if (!name) return { code: 400, body: { ok: false, error: 'Please type your first name.' } };
  let ref = '', verified = false;
  if (b.ref) {
    ref = String(b.ref || '').trim().toUpperCase();
    const phone = L.phone10(b.phone);
    if (!/^VG-(\d{4,6}|[A-Z0-9]{7})$/.test(ref) || !phone) return { code: 404, body: { ok: false, reason: 'not-found' } };
    if (L.tooMany('rr:' + ref, 6, 3600e3)) return { code: 429, body: { ok: false, error: 'Please wait a little before trying again.' } };
    const r = await L.db('/rest/v1/orders?select=ref,phone&ref=eq.' + encodeURIComponent(ref) + '&limit=2');
    const rows = r.ok && Array.isArray(r.body) ? r.body : [];
    if (rows.length !== 1 || L.phone10(rows[0].phone) !== phone) return { code: 404, body: { ok: false, reason: 'not-found' } };
    const had = await L.db('/rest/v1/shop_private?select=id&id=like.rv:*&data->>ref=eq.' + encodeURIComponent(ref) + '&limit=1');
    if (had.ok && Array.isArray(had.body) && had.body.length) return { code: 409, body: { ok: false, error: 'We already have your review for this order — thank you!' } };
    verified = true;
  }
  /* no more than 150 reviews waiting at once (a flood is stopped, the shop's list stays readable) */
  const waiting = await L.db('/rest/v1/shop_private?select=id&id=like.rv:*&limit=151');
  if (waiting.ok && Array.isArray(waiting.body) && waiting.body.length > 150) return { code: 429, body: { ok: false, error: 'Please try again tomorrow.' } };
  const id = 'rv:' + Date.now() + '-' + Math.random().toString(36).slice(2, 7);
  const data = { stars, text, name, store, ref, verified, at: new Date().toISOString() };
  const w = await L.db('/rest/v1/shop_private', { method: 'POST', headers: { Prefer: 'return=minimal' }, body: JSON.stringify([{ id, data, updated_at: data.at }]) });
  if (!w.ok) return { code: 502, body: { ok: false, error: 'Could not send it just now. Please try again.' } };
  /* the manager hears about it (at most 40 a day), with no links or numbers from the customer's text */
  try {
    const day = new Date(Date.now() + 5.5 * 3600e3).toISOString().slice(0, 10);
    if (REV_TOLD.d !== day) REV_TOLD = { d: day, n: 0 };
    if (REV_TOLD.n < 40) {
      REV_TOLD.n++;
      const shop = await L.shopSettings(), mgr = shop.mgrWa || shop.wa;
      if (mgr) await L.whatsapp(mgr, 'NEW REVIEW — waiting for your OK\n\n' + '★'.repeat(stars) + '☆'.repeat(5 - stars) + ' ' + name + (store ? ' (' + store + ')' : '') + (verified ? ' · verified buyer ' + ref : '') +
        '\n"' + noLinks(text).slice(0, 200) + '"\n\nAdmin → Settings → Customer reviews: APPROVE to show it on the website, or DELETE.');
    }
  } catch (e) {}
  return { code: 200, body: { ok: true, verified } };
}

module.exports = async function (req, res) {
  const q = L.query(req);
  if (req.method === 'GET' && (q.get('do') === 'sitemap' || /\/sitemap\.xml$/.test(String(req.url || '').split('?')[0]))) {
    if (!L.env('SUPABASE_SERVICE_KEY')) { res.statusCode = 200; res.setHeader('Content-Type', 'application/xml; charset=utf-8');
      return res.end('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' + STATIC.map(([p]) => '<url><loc>' + SITE + p + '</loc></url>').join('\n') + '\n</urlset>\n'); }
    return sitemap(res);
  }
  if (!L.env('SUPABASE_SERVICE_KEY')) return L.send(res, 501, { ok: false, configured: false });
  const ip = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim() || 'ip';
  if (req.method === 'GET') {
    if (q.get('do') !== 'ref') return L.send(res, 400, { ok: false });
    if (L.tooMany('r:' + ip, 30, 3600e3)) return L.send(res, 429, { ok: false });
    const ref = await nextRef();
    return ref ? L.send(res, 200, { ok: true, ref }) : L.send(res, 502, { ok: false });
  }
  if (req.method !== 'POST') return L.send(res, 405, { ok: false });
  const b = await L.body(req) || {};
  if (b.do === 'vto') {
    if (L.tooMany('v:' + ip, 200, 3600e3)) return L.send(res, 429, { ok: false });
    return L.send(res, 200, { ok: await vto(String(b.what || ''), b.id) });
  }
  if (b.do === 'review') {
    if (L.tooMany('rv:' + ip, 5, 3600e3)) return L.send(res, 429, { ok: false, error: 'Please wait a little before sending another review.' });
    const out = await review(b, ip);
    return L.send(res, out.code, out.body);
  }
  if (b.do !== 'attach') return L.send(res, 400, { ok: false });
  if (L.tooMany('a:' + ip, 10, 3600e3)) return L.send(res, 429, { ok: false, error: 'Please wait a little before trying again.' });
  const ref = String(b.ref || '').trim().toUpperCase(), phone = L.phone10(b.phone);
  if (!/^VG-(\d{4,6}|[A-Z0-9]{7})$/.test(ref) || !phone) return L.send(res, 404, { ok: false, reason: 'not-found' });
  if (L.tooMany('ar:' + ref, 8, 3600e3)) return L.send(res, 429, { ok: false, error: 'Please wait a little before trying again.' });
  const r = await L.db('/rest/v1/orders?select=ref,phone,status,payload&ref=eq.' + encodeURIComponent(ref) + '&limit=2');
  const rows = r.ok && Array.isArray(r.body) ? r.body : [];
  /* two orders with one number (an old copy, or someone copying a number): change neither -- the shop sorts it out */
  if (rows.length > 1) return L.send(res, 409, { ok: false, error: 'Please WhatsApp us your prescription with your order number.' });
  const row = rows[0] || null;
  /* the same answer for "no such order" and "wrong mobile number" -- nobody can find out which orders exist */
  if (!row || L.phone10(row.phone) !== phone) return L.send(res, 404, { ok: false, reason: 'not-found' });
  if (ATTACH_FROM.indexOf(row.status || '') < 0) return L.send(res, 409, { ok: false, error: 'This order is already being made. Please WhatsApp us your prescription.' });
  const rx = cleanRx(b.patch);
  if (!rx) return L.send(res, 400, { ok: false, error: 'The prescription file could not be read. Please upload a clear photo or a PDF.' });
  const payload = Object.assign({}, row.payload || {}, rx);
  /* d17.205: written only while the order is as it was read (a staff edit or the website's parcel news at the same moment is never lost) */
  const pp = row.payload || {}, sh = pp.ship, rv = sh && typeof sh === 'object' && !Array.isArray(sh) ? sh.rev : undefined, er = pp.editRev;
  const keepF = (rv == null ? '&payload->ship->>rev=is.null' : (Number.isSafeInteger(rv) ? '&payload->ship->>rev=eq.' + rv : '')) +
    (er == null ? '&payload->>editRev=is.null' : (Number.isSafeInteger(er) && er >= 0 && er < 1e9 ? '&payload->>editRev=eq.' + er : ''));
  payload.editRev = (Number.isSafeInteger(er) && er >= 0 && er < 1e9 ? er : 0) + 1;
  const w = await L.db('/rest/v1/orders?ref=eq.' + encodeURIComponent(ref) + keepF + '&select=ref', { method: 'PATCH', headers: { Prefer: 'return=representation' },
    body: JSON.stringify((row.status || '') === 'Confirmed' ? { payload } : { payload, status: 'Prescription Received' }) });   /* a paid, confirmed order stays Confirmed */
  if (!w.ok) return L.send(res, 502, { ok: false, error: 'Could not update the order.' });
  if (Array.isArray(w.body) && !w.body.length) return L.send(res, 409, { ok: false, error: 'Your order was being updated at that moment. Please try again.' });
  return L.send(res, 200, { ok: true });
};
module.exports.cleanRx = cleanRx;

/* Vision Gallery — "My Orders": send a customer their order details (d17.155, shop 19 Oct)

   No OTP, no SMS. The customer types their mobile number and picks WhatsApp
   or e-mail. The details go ONLY to the WhatsApp number / e-mail saved on
   their own orders -- never to whoever typed the number -- and the page
   always gives the same answer, so it never reveals whether a number has
   orders. A few requests per number per hour at most.

   GET  /api/order-details?check=1  -> { whatsapp, email }
   POST /api/order-details          -> { phone, via: 'whatsapp' | 'email' }   always { ok:true } when set up */
'use strict';
const L = require('./_lib.js');

const STATUS_WORDS = { 'New': 'Received', 'Waiting for Prescription': 'Waiting for your prescription', 'Prescription Received': 'Prescription received',
  'Confirmed': 'Confirmed', 'At Lab': 'Lenses being made', 'At QC': 'Quality check', 'Ready': 'Ready for collection / delivery', 'Delivered': 'Delivered' };

function day(iso) { try { return new Date(iso).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'Asia/Kolkata' }); } catch (e) { return ''; } }
function lensOf(p) {
  /* d17.210: a 1+1 single vision order names its thinner lens too (1.56 is the standard one, not mentioned) */
  const sx = p.svExtra && typeof p.svExtra === 'object' ? p.svExtra : null, thin = sx && sx.index && sx.index !== '1.56' ? String(sx.indexName || sx.index) : '';
  return [p.lensPackage || (p.offer && p.offer.lensLevel) || p.lens || '', p.corridor && !String(p.lensPackage || '').includes(p.corridor) ? p.corridor : '', thin].filter(Boolean).join(' · '); }
function summary(rows, shop) {
  const lines = ['Vision Gallery — your orders', ''];
  rows.forEach((r, i) => {
    const p = r.payload || {};
    lines.push((i + 1) + ') Order ' + r.ref + ' · ' + day(r.created_at || p.placed));
    if (p.frame) lines.push('Frame: ' + p.frame);
    const ln = lensOf(p); if (ln) lines.push('Lenses: ' + ln);
    lines.push('Total: ' + L.rupees((p.express && Number(p.total) > 0) ? p.total : (r.total || p.total)) + (p.express ? ' (express)' : '') + ' · Payment: ' + (p.payStatus || 'Unpaid'));
    /* an order waiting for the eye test the customer booked (at home or in the shop) says so, as the old My Orders page did */
    const eyeTest = r.status === 'Waiting for Prescription' && (p.rxPath === 'hometest' || p.rxPath === 'shoptest');
    lines.push('Status: ' + (eyeTest ? 'Eye test booked' + (p.rxPath === 'hometest' ? ' (at home)' : ' (at the shop)') : (STATUS_WORDS[r.status] || r.status || 'Received')));
    if (p.store) lines.push('Shop: ' + p.store);
    lines.push('');
  });
  const c = L.contactOf(shop);
  lines.push(c.phone ? 'Questions? Call us on ' + c.phone + (c.wa && c.wa !== c.phoneDigits ? ' or WhatsApp us on ' + c.waDisplay : ' (calls and WhatsApp)') + '.' : 'Questions? Reply to this message.');
  return lines.join('\n');
}

module.exports = async function (req, res) {
  const q = L.query(req);
  const dbReady = !!L.env('SUPABASE_SERVICE_KEY');
  if (req.method === 'GET' && q.get('check')) return L.send(res, 200, { whatsapp: dbReady && L.senderReady(), email: dbReady && L.mailReady() });
  if (req.method !== 'POST') return L.send(res, 405, { ok: false, error: 'POST only' });
  const b = await L.body(req);
  const via = b && b.via === 'email' ? 'email' : 'whatsapp';
  if (!dbReady || (via === 'whatsapp' ? !L.senderReady() : !L.mailReady())) return L.send(res, 501, { ok: false, configured: false });
  const p = L.phone10(b && b.phone);
  if (!p) return L.send(res, 400, { ok: false, error: 'Please type your 10-digit mobile number.' });
  const ip = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim() || 'ip';
  if (L.tooMany('p:' + p, 3, 3600e3) || L.tooMany('i:' + ip, 20, 3600e3)) return L.send(res, 429, { ok: false, error: 'Please wait a little before asking again.' });

  let rows = [];
  try {
    /* d17.204: the number may be stored as typed -- "98765 43210", "+91 98765-43210", "9876543210" -- so the 10 digits are
       not always together in the text. The last 3 digits always are: the newest orders ending in them are read, and the
       full number is compared here, digit by digit (mixed forms on one number are all found). */
    const r = await L.db('/rest/v1/orders?select=ref,created_at,status,total,phone,name,payload&phone=like.*' + p.slice(-3) + '&order=created_at.desc&limit=300');
    if (r.ok && Array.isArray(r.body)) rows = r.body.filter(x => L.phone10(x.phone) === p).slice(0, 5);
  } catch (e) {}
  if (rows.length) {
    const shop = await L.shopSettings();
    const text = summary(rows, shop);
    if (via === 'whatsapp') await L.whatsapp(p, text);
    else {
      /* d17.203 SECURITY: only when every e-mail on this number's orders is the SAME address -- someone who placed an order
         with another person's mobile number and their own e-mail gets nothing */
      const all = rows.map(x => String((x.payload || {}).email || '').trim().toLowerCase());
      const mails = all.filter(e => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e));
      /* every order of this number must carry the SAME e-mail (an order with no e-mail counts against it) */
      const to = mails.length === all.length && mails.every(e => e === mails[0]) ? mails[0] : '';
      if (to) await L.email(to, 'Your Vision Gallery orders', text);
      else if (mails.length) await L.whatsapp(p, text);          /* two different e-mails: it goes to the number's own WhatsApp instead */
    }
  }
  /* the same answer every time */
  return L.send(res, 200, { ok: true });
};
module.exports.summary = summary;

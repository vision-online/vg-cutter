/* Vision Gallery — automatic "payment received, order confirmed" (d17.155, shop 19 Oct)

   Customers keep paying exactly as now: your Kotak UPI QR, the quoted amount.
   Kotak then sends you an SMS ("Received Rs.2800.00 ... from ...@ybl ... UPI Ref ...").
   A small SMS-forwarding app on your phone passes ONLY those messages here:

     POST https://visiongallery.me/api/upi-sms?key=<UPI_SMS_KEY>     (body: the SMS text, in any common form)

   Here we read the amount, the payer's UPI ID and the UPI Ref, find the order
   waiting for that amount, mark it Confirmed + Paid in the database, and send
   the customer a WhatsApp from your sender:
     "Hi Manish, we have received your payment of ₹2,800. Your order no. VG-1023 is confirmed."
   Which order (d17.203, made strict -- the same Kotak account also takes payments at the shop counters, and a stranger
   could place an order for a common amount, or text the shop's phone a fake "Received" message):
     confirmed AUTOMATICALLY only when ALL of these hold:
       - the forwarding app says who sent the SMS, and it is the bank (KOTAK in the sender name, e.g. AX-KOTAKB);
       - the SMS has a UPI Ref;
       - the payer's UPI ID holds the order's mobile number, and only one order has that number;
     anything else goes to the manager on WhatsApp ("PAYMENT TO CHECK") to confirm by hand in Admin.
   An SMS that came from a phone NUMBER is ignored (a real bank SMS never does). With UPI_ACCOUNT_END set in Vercel
   (the last 4 digits of the shop's account), an SMS that does not name that account is ignored too.
   The same UPI Ref is never counted twice.

   GET /api/upi-sms?check=1 -> { configured } */
'use strict';
const L = require('./_lib.js');
const P = require('../upi-parse.js');

const WAITING = ['New', 'Waiting for Prescription', 'Prescription Received', ''];

function textOf(b, q) {
  if (!b) b = {};
  const keys = ['text', 'message', 'msg', 'body', 'sms', 'content', 'key_text'];
  for (const k of keys) if (typeof b[k] === 'string' && b[k].trim()) return b[k];
  if (b.data && typeof b.data === 'object') for (const k of keys) if (typeof b.data[k] === 'string') return b.data[k];
  if (typeof b === 'string') return b;
  return q.get('text') || q.get('message') || q.get('msg') || '';
}
function words(s) { return String(s || '').toLowerCase().replace(/[^a-z ]/g, ' ').split(/\s+/).filter(w => w.length > 2); }
/* who sent the SMS, when the forwarding app says it (from / sender / address ...) */
function senderOf(b, q) {
  b = (b && typeof b === 'object') ? b : {};
  for (const k of ['from', 'sender', 'address', 'originatingAddress', 'phoneNumber', 'number', 'smsFrom']) {
    const v = b[k] != null ? b[k] : (b.data && typeof b.data === 'object' ? b.data[k] : null);
    if (typeof v === 'string' || typeof v === 'number') return String(v).trim();
  }
  return String(q.get('from') || q.get('sender') || '').trim();
}

async function note(result) {
  /* the Health page reads when the last payment SMS came in (time and outcome only -- no amounts, no names) */
  try { await L.db('/rest/v1/products?on_conflict=id', { method: 'POST', headers: { Prefer: 'resolution=merge-duplicates,return=minimal' },
    body: JSON.stringify([{ id: '__upi', data: { lastSms: new Date().toISOString(), lastResult: result }, updated_at: new Date().toISOString() }]) }); } catch (e) {}
}

module.exports = async function (req, res) {
  const q = L.query(req);
  const ready = !!(L.env('SUPABASE_SERVICE_KEY') && L.env('UPI_SMS_KEY'));
  if (req.method === 'GET' && q.get('check')) return L.send(res, 200, { configured: ready, whatsapp: L.senderReady() });
  if (!ready) return L.send(res, 501, { ok: false, configured: false });
  const b = await L.body(req);
  const key = q.get('key') || req.headers['x-key'] || (b && b.key) || '';
  if (key !== L.env('UPI_SMS_KEY')) return L.send(res, 401, { ok: false, error: 'wrong key' });

  const sms = textOf(b, q);
  const from = senderOf(b, q);
  if (from && /\d{6,}/.test(from.replace(/[\s+\-]/g, ''))) { await note('ignored (sent from a phone number, not the bank)'); return L.send(res, 200, { ok: true, ignored: 'sent from a phone number, not the bank' }); }
  const acct = String(L.env('UPI_ACCOUNT_END') || '').replace(/\D/g, '');
  if (acct.length >= 3 && !new RegExp('(?:x|\\*|\\b)' + acct + '\\b', 'i').test(String(sms))) { await note('ignored (not the shop\'s account)'); return L.send(res, 200, { ok: true, ignored: 'not the shop\'s account' }); }
  const pay = P.parse(sms);
  if (!pay.ok) { await note('ignored'); return L.send(res, 200, { ok: true, ignored: pay.why }); }

  /* the same payment twice (an app that forwards twice, a retry) is counted once */
  if (pay.ref) {
    const dup = await L.db('/rest/v1/orders?select=ref&payload->>upiRef=eq.' + encodeURIComponent(pay.ref) + '&limit=1');
    if (dup.ok && Array.isArray(dup.body) && dup.body.length) return L.send(res, 200, { ok: true, duplicate: dup.body[0].ref });
  }

  const since = new Date(Date.now() - 3 * 86400e3).toISOString();
  const r = await L.db('/rest/v1/orders?select=ref,created_at,status,total,phone,name,payload&created_at=gte.' + encodeURIComponent(since) + '&order=created_at.desc&limit=500');   /* d17.204: the NEWEST orders (the ones being paid) */
  const all = (r.ok && Array.isArray(r.body)) ? r.body : [];
  const cands = all.filter(o => {
    const p = o.payload || {};
    if (p.upiRef || p.payStatus === 'Paid' || p.payStatus === 'Refunded') return false;
    if (WAITING.indexOf(o.status || '') < 0) return false;
    /* d17.158: an EXPRESS order expects its total with the extra charge (kept in the order's details) */
    const due = (p.express && Number(p.total) > 0) ? Number(p.total) : (Number(o.total) || Number(p.total) || 0);
    return Math.abs(due - pay.amount) < 0.5;
  });
  let pick = null, how = '', why = '';
  const bankRe = new RegExp(String(L.env('UPI_BANK_SENDER') || 'KOTAK').replace(/[^A-Za-z0-9]/g, '') || 'KOTAK', 'i');
  const fromBank = !!from && bankRe.test(from);
  if (!fromBank) why = from ? 'the SMS did not come from the bank (' + from.slice(0, 20) + ')' : 'the SMS app did not say who sent the SMS';
  else if (!pay.ref) why = 'the SMS has no UPI Ref';
  else if (!pay.phone) why = 'the payer\'s UPI ID has no mobile number';
  else {
    const mine = cands.filter(o => L.phone10(o.phone) === pay.phone);
    if (!mine.length) why = 'no order for this amount has the mobile number in the UPI ID';
    else {
      /* the order number must belong to ONE order only, or the payment could land on a copy */
      const same = await L.db('/rest/v1/orders?select=ref&ref=eq.' + encodeURIComponent(mine[0].ref) + '&limit=2');
      if (same.ok && Array.isArray(same.body) && same.body.length === 1) { pick = mine[0]; how = 'mobile number in the UPI ID'; }
      else why = 'two orders share the number ' + mine[0].ref;
    }
  }

  const shop = await L.shopSettings();
  if (!pick && cands.length) {
    /* d17.203: never guess -- the manager confirms it in Admin by hand */
    const mgr = shop.mgrWa || shop.wa;
    if (mgr) await L.whatsapp(mgr, 'PAYMENT TO CHECK\n\n' + L.rupees(pay.amount) + ' received by UPI' + (pay.vpa ? ' from ' + pay.vpa : pay.name ? ' from ' + pay.name : '') + (pay.ref ? '\nUPI Ref ' + pay.ref : '\nNo UPI Ref in the SMS') +
      '\n\nIt could be for: ' + cands.slice(0, 5).map(o => o.ref + ' (' + String(o.name || '').slice(0, 30) + ')').join(', ') +
      '\n\nIt was NOT confirmed automatically (' + why + '). Check the bank app, then mark the right order Paid in Admin → Orders.');
    await note('sent to the manager to check: ' + why);
    return L.send(res, 200, { ok: true, matched: false, check: cands.map(o => o.ref), amount: pay.amount });
  }
  if (!pick) {
    const mgr = shop.mgrWa || shop.wa;
    if (mgr) await L.whatsapp(mgr, 'PAYMENT WITH NO ORDER\n\n' + L.rupees(pay.amount) + ' received by UPI' + (pay.vpa ? ' from ' + pay.vpa : '') + (pay.ref ? '\nUPI Ref ' + pay.ref : '') + '\n\nNo order is waiting for this amount. Please check and confirm by hand.');
    await note('no matching order');
    return L.send(res, 200, { ok: true, matched: false, amount: pay.amount });
  }

  const p = Object.assign({}, pick.payload || {}, { payStatus: 'Paid', paid: pay.amount, payMethod: 'UPI', upiRef: pay.ref || ('noref-' + Date.now()), upiFrom: pay.vpa || pay.name || '', upiAt: new Date().toISOString(), upiPaid: true, upiMatch: how });
  const upd = { payload: p };
  if ((pick.status || 'New') === 'New') upd.status = 'Confirmed';
  /* d17.204: only while the order is still unpaid, and the rows changed are counted -- the customer is told "confirmed" only
     when the order really was confirmed (not when someone marked it by hand a moment before) */
  const stF = pick.status != null ? '&status=eq.' + encodeURIComponent(pick.status) : '&status=is.null';
  /* d17.205: the order's parcel record and staff edits are kept: written only while both are as they were read */
  const pp = pick.payload || {}, sh = pp.ship, rv = sh && typeof sh === 'object' && !Array.isArray(sh) ? sh.rev : undefined, er = pp.editRev;
  const keepF = (rv == null ? '&payload->ship->>rev=is.null' : (Number.isSafeInteger(rv) ? '&payload->ship->>rev=eq.' + rv : '')) +
    (er == null ? '&payload->>editRev=is.null' : (Number.isSafeInteger(er) && er >= 0 && er < 1e9 ? '&payload->>editRev=eq.' + er : ''));
  upd.payload.editRev = (Number.isSafeInteger(er) && er >= 0 && er < 1e9 ? er : 0) + 1;
  const w = await L.db('/rest/v1/orders?ref=eq.' + encodeURIComponent(pick.ref) + stF + '&payload->>upiRef=is.null' + keepF + '&select=ref',
    { method: 'PATCH', headers: { Prefer: 'return=representation' }, body: JSON.stringify(upd) });
  if (!w.ok) { await note('could not update the order'); return L.send(res, 502, { ok: false, error: 'could not update the order', status: w.status }); }
  if (!Array.isArray(w.body) || w.body.length !== 1) {
    await note('the order changed meanwhile -- not confirmed automatically');
    const mgr = shop.mgrWa || shop.wa;
    if (mgr) await L.whatsapp(mgr, 'PAYMENT TO CHECK\n\n' + L.rupees(pay.amount) + ' received by UPI for order ' + pick.ref + ', but the order changed at the same moment, so it was NOT confirmed automatically. Please check it in Admin → Orders.');
    return L.send(res, 200, { ok: true, matched: false, changed: pick.ref });
  }

  const first = String(pick.name || '').trim().split(/\s+/)[0] || 'there';
  const msg = 'Hi ' + first + ', we have received your payment of ' + L.rupees(pay.amount) + '. Your order no. ' + pick.ref + ' is confirmed.' +
    (pick.status === 'Waiting for Prescription' ? ' We will start as soon as we have your prescription.' : '') + '\n\nThank you — Vision Gallery';
  const sent = await L.whatsapp(pick.phone, msg);
  await note(sent.ok ? 'confirmed and messaged' : 'confirmed, WhatsApp not sent');
  return L.send(res, 200, { ok: true, matched: pick.ref, how, whatsapp: sent.ok });
};

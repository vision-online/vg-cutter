/* Vision Gallery — DAILY BACKUP (d17.178; d17.183: every night, kept as dated files; RESTORE; d17.182, shop 25 Oct: "not on the Google Cloud computer -- it runs the bills, the
   WhatsApp, the robot timer, the staff app; if it gets stuck everything gets stuck. Keep the backup somewhere else.")

   GitHub's own computers make it: the private repository "vg-backup" has a nightly job (.github/workflows/backup.yml) that
   reads everything from here, page by page, and saves it there as one dated file a night (Releases; the last 60 nights and
   the 1st of every month are kept). Nothing runs on, or is stored on,
   the WhatsApp computer. Photos are not in it (they stay in the photo storage); records only: frames, orders, settings
   (public and private), the chat's approved answers. Admin -> HEALTH shows the last backup and has DOWNLOAD BACKUP.

   GET  /api/backup?table=<name>&page=<n>    -> { ok, rows:[...], more }     key = BACKUP_KEY (x-key header) or a signed-in staff token
   GET  /api/backup?tables=1                 -> { ok, tables:[...] }
   GET  /api/backup?check=1                  -> { configured, BACKUP_KEY, BACKUP_KEY2 }  (anyone: is a backup password set? never the password)
   POST /api/backup?done=1  { ok, at, file, bytes, kept, note }   (the backup job, key)  -> kept for HEALTH and the watchman
   GET  /api/backup?status=1                 -> { ok, last }                  (staff)
   POST /api/backup?plan=1    { table, keys:[...] }               -> { ok, have:[...], gone:[...] }   (staff: what is there now)
   POST /api/backup?restore=1 { table, rows:[...], mode }         -> { ok, added, replaced, skipped, failed:[...] }
        (staff only, never the backup's own key. mode 'missing': only records not in the account now -- for frames also
        those marked deleted -- are put back, nothing there is changed; mode 'replace': the backup's version replaces what
        is there now. Records made after the backup are never removed.)
   Needs on Vercel: BACKUP_KEY or BACKUP_KEY2 (a long password you make up; the same one goes into the vg-backup repository's secret BACKUP_KEY). */
'use strict';
const crypto = require('crypto');
const L = require('./_lib.js');
/* d17.185 (shop, 26 Oct: the password in Vercel could not be changed from the phone -- the menu would not open): a second name,
   BACKUP_KEY2, is read too. A good BACKUP_KEY2 (16 characters or more) wins; otherwise BACKUP_KEY. */
function backupKey() { const b = L.env('BACKUP_KEY2'); return b.length >= 16 ? b : L.env('BACKUP_KEY'); }
function keyState(v) { return !v ? 'not seen' : v.length >= 16 ? 'seen, long enough' : 'seen, TOO SHORT (needs 16 or more characters)'; }

const TABLES = { products: 'id.asc', orders: 'created_at.asc,ref.asc', shop_private: 'id.asc', chat_learned: 'id.asc' };
const PAGE = 100;      /* small pages: a frame or order record can be large, and an answer must stay under 4.5 MB */
/* RESTORE: which column names a record in each table, and the private notes that are never put back (sign-in tries; the
   backup's and the watchman's own state -- putting old ones back would only confuse HEALTH) */
const RESTORE_KEY = { products: 'id', orders: 'ref', shop_private: 'id', chat_learned: 'qkey' };   /* a chat answer is its question (qkey is unique) */
const SKIP_PRIVATE = /^(login:|__backup$|__watch$)/;
function inList(keys) { return 'in.(' + keys.map(k => '"' + String(k).replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"').join(',') + ')'; }
/* the database, never throwing: a slow answer is one failed record, not a lost batch */
async function sdb(path, opts) { try { return await L.db(path, opts); } catch (e) { return { ok: false, status: 0, body: { message: 'the database did not answer in time' } }; } }
async function present(t, KEY, keys) {                                     /* -> { have:[keys there now], gone:[frames marked deleted] } */
  const have = [], gone = [];
  for (let i = 0; i < keys.length; i += 100) {
    const part = keys.slice(i, i + 100); if (!part.length) continue;
    const sel = t === 'products' ? 'id,deleted:data->>deleted' : KEY;
    const r = await sdb('/rest/v1/' + t + '?select=' + sel + '&' + KEY + '=' + encodeURIComponent(inList(part)) + '&limit=' + (part.length + 5));
    if (!r.ok || !Array.isArray(r.body)) return null;
    r.body.forEach(x => { const k = String(x[KEY]); if (t === 'products' && String(x.deleted) === 'true') gone.push(k); else have.push(k); });
  }
  return { have, gone };
}
function why(r) { const b = r && r.body; return String((b && (b.message || b.error || b.hint)) || ('error ' + (r && r.status))).slice(0, 160); }
function same(a, b) { const x = crypto.createHash('sha256').update(String(a)).digest(), y = crypto.createHash('sha256').update(String(b)).digest(); return crypto.timingSafeEqual(x, y) && String(a) === String(b); }
const PASS_KEYS = /^(pass|passcode|password|pin)$/i;
/* d17.183 (review): putting back private settings never changes today's staff passcodes -- a laptop copy has none (they
   were left out of it), and an old file would bring back old ones, even for staff removed since. Today's passcode stays
   wherever the same place exists today (staff matched by id); anyone not there today comes back WITHOUT a passcode. */
function keepPass(inc, cur) {
  if (Array.isArray(inc)) return inc.map((el, i) => {
    if (el && typeof el === 'object' && !Array.isArray(el) && el.id !== undefined) { const m = Array.isArray(cur) ? cur.find(c => c && typeof c === 'object' && String(c.id) === String(el.id)) : null; return m ? keepPass(el, m) : noPass(el); }
    return el && typeof el === 'object' ? keepPass(el, Array.isArray(cur) ? cur[i] : undefined) : el; });
  if (inc && typeof inc === 'object') {
    const o = {}, c = cur && typeof cur === 'object' && !Array.isArray(cur) ? cur : null;
    for (const k of Object.keys(inc)) if (!PASS_KEYS.test(k)) o[k] = keepPass(inc[k], c ? c[k] : undefined);
    if (c) for (const k of Object.keys(c)) if (PASS_KEYS.test(k)) o[k] = c[k];
    return o;
  }
  return inc;
}
function noPass(v) { if (Array.isArray(v)) return v.map(noPass); if (v && typeof v === 'object') { const o = {}; for (const k of Object.keys(v)) { if (!PASS_KEYS.test(k)) o[k] = noPass(v[k]); } return o; } return v; }
async function allowed(req, q) {
  const k = String(req.headers['x-key'] || '');                           /* header only: a key in the address ends up in logs */
  const bk = backupKey();
  if (k && bk.length >= 16 && same(k, bk)) return 'computer';   /* d17.182: the backup's own key only */
  const u = await L.staffUser(req); return u ? 'staff' : '';
}

module.exports = async (req, res) => {
  if (!L.env('SUPABASE_SERVICE_KEY')) return L.send(res, 501, { ok: false, notSetUp: true });
  const q = L.query(req);
  if (req.method === 'GET' && q.get('check')) return L.send(res, 200, { ok: true, configured: backupKey().length >= 16,
    BACKUP_KEY: keyState(L.env('BACKUP_KEY')), BACKUP_KEY2: keyState(L.env('BACKUP_KEY2')) });   /* d17.185: what the website sees -- never the password */
  const who = await allowed(req, q);
  if (!who) return L.send(res, 403, { ok: false, error: 'not allowed' });

  if (req.method === 'POST' && q.get('done')) {
    if (who !== 'computer') return L.send(res, 403, { ok: false });
    const b = await L.body(req);
    const last = { at: String(b.at || new Date().toISOString()).slice(0, 40), file: String(b.file || '').slice(0, 80), bytes: Number(b.bytes) || 0,
      kept: Number(b.kept) || 0, ok: b.ok === true || b.ok === 'true', note: String(b.note || '').slice(0, 200), where: 'github' };
    const r = await L.db('/rest/v1/shop_private?on_conflict=id', { method: 'POST', headers: { Prefer: 'resolution=merge-duplicates,return=minimal' },
      body: JSON.stringify([{ id: '__backup', data: last, updated_at: new Date().toISOString() }]) });
    return L.send(res, r.ok ? 200 : 502, { ok: r.ok });
  }
  if (req.method === 'POST' && (q.get('plan') || q.get('restore'))) {
    if (who !== 'staff') return L.send(res, 403, { ok: false, error: 'only signed-in staff can put records back' });
    if (L.tooMany('rs:' + String(req.headers['x-forwarded-for'] || 'ip'), 900, 3600e3)) return L.send(res, 429, { ok: false, error: 'too many at once -- wait a few minutes' });
    const b = await L.body(req), t = String(b.table || ''), KEY = RESTORE_KEY[t];
    if (!KEY) return L.send(res, 400, { ok: false, error: 'unknown table' });
    if (q.get('plan')) {
      const keys = (Array.isArray(b.keys) ? b.keys : []).map(String).filter(Boolean).slice(0, 1000);
      const now = await present(t, KEY, keys);
      if (!now) return L.send(res, 502, { ok: false, error: 'the database did not answer' });
      return L.send(res, 200, { ok: true, have: now.have, gone: now.gone });
    }
    const mode = b.mode === 'replace' ? 'replace' : 'missing';
    const rows = (Array.isArray(b.rows) ? b.rows : []).filter(r => r && typeof r === 'object' && !Array.isArray(r) && r[KEY] !== undefined && r[KEY] !== null && String(r[KEY]) !== '');
    if (!rows.length || rows.length > 60) return L.send(res, 400, { ok: false, error: 'send 1 to 60 records at a time' });
    const out = { ok: true, added: 0, replaced: 0, skipped: 0, failed: [] };
    const stamp = new Date().toISOString();
    const use = rows.filter(r => !(t === 'shop_private' && SKIP_PRIVATE.test(String(r.id))))
      .map(r => (t !== 'orders' && 'updated_at' in r) ? Object.assign({}, r, { updated_at: stamp }) : r)   /* put back = changed now (shows first) */
      /* d17.204: a frame goes back as its own record only -- id, data, time. The backup also holds the database's search
         columns (p_visible, p_price ...), which the database works out itself and may refuse to be written. */
      .map(r => t === 'products' ? { id: r.id, data: r.data, updated_at: r.updated_at || stamp } : r);
    out.skipped += rows.length - use.length;
    const now = await present(t, KEY, use.map(r => String(r[KEY])));
    if (!now) return L.send(res, 502, { ok: false, error: 'the database did not answer' });
    const have = new Set(now.have), gone = new Set(now.gone);
    const toAdd = use.filter(r => !have.has(String(r[KEY])) && !gone.has(String(r[KEY])));
    let toPut = use.filter(r => mode === 'replace' ? (have.has(String(r[KEY])) || gone.has(String(r[KEY]))) : gone.has(String(r[KEY])));
    out.skipped += use.length - toAdd.length - toPut.length;
    const fail1 = (row, r) => out.failed.push({ key: String(row[KEY]).slice(0, 80), error: why(r) });
    if (toAdd.length) {
      const r = await sdb('/rest/v1/' + t, { method: 'POST', headers: { Prefer: 'return=minimal' }, body: JSON.stringify(toAdd) });
      if (r.ok) out.added += toAdd.length;
      else for (const row of toAdd) {                                         /* one bad record must not stop the others */
        const r1 = await sdb('/rest/v1/' + t, { method: 'POST', headers: { Prefer: 'return=minimal' }, body: JSON.stringify([row]) });
        if (r1.ok) out.added++; else fail1(row, r1);
      }
    }
    if (toPut.length && t === 'shop_private') {                                /* today's passcodes stay */
      const cur = await sdb('/rest/v1/shop_private?select=id,data&id=' + encodeURIComponent(inList(toPut.map(r => String(r.id)))) + '&limit=' + (toPut.length + 5));
      if (!cur.ok || !Array.isArray(cur.body)) { toPut.forEach(row => fail1(row, cur)); toPut = []; }
      else { const by = {}; cur.body.forEach(x => { by[String(x.id)] = x.data; }); toPut = toPut.map(row => Object.assign({}, row, { data: keepPass(row.data, by[String(row.id)]) })); }
    }
    if (toPut.length && (t === 'products' || t === 'shop_private')) {          /* one write for the lot */
      const r = await sdb('/rest/v1/' + t + '?on_conflict=id', { method: 'POST', headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }, body: JSON.stringify(toPut) });
      if (r.ok) { out.replaced += toPut.length; toPut = []; }
    }
    for (const row of toPut) {                                                 /* orders, chat answers (or the one write failed): one by one */
      const put = t === 'chat_learned' ? Object.assign({}, row) : row; if (t === 'chat_learned') delete put.id;   /* the answer keeps today's number */
      const r = await sdb('/rest/v1/' + t + '?' + KEY + '=eq.' + encodeURIComponent(String(row[KEY])), { method: 'PATCH', headers: { Prefer: 'return=minimal' }, body: JSON.stringify(put) });
      if (r.ok) out.replaced++; else fail1(row, r);
    }
    out.ok = !out.failed.length;
    return L.send(res, 200, out);
  }
  if (req.method !== 'GET') return L.send(res, 405, { ok: false });
  if (q.get('tables')) return L.send(res, 200, { ok: true, tables: Object.keys(TABLES), page: PAGE });
  if (q.get('status')) {
    const r = await L.db('/rest/v1/shop_private?select=data,updated_at&id=eq.__backup');
    return L.send(res, 200, { ok: true, last: (r.ok && r.body && r.body[0] && r.body[0].data) || null });
  }
  const t = q.get('table'), page = Math.max(0, Math.floor(Number(q.get('page')) || 0));
  if (!TABLES[t]) return L.send(res, 400, { ok: false, error: 'unknown table' });
  if (L.tooMany('bk:' + (who === 'computer' ? 'pc' : String(req.headers['x-forwarded-for'] || 'ip')), 600, 3600e3)) return L.send(res, 429, { ok: false });
  let path = '/rest/v1/' + t + '?select=*&order=' + TABLES[t] + '&limit=' + (PAGE + 1) + '&offset=' + (page * PAGE);
  if (t === 'shop_private') path += '&id=not.like.login:*';                   /* the passcode-try notes are not worth keeping */
  const r = await L.db(path);
  if (!r.ok || !Array.isArray(r.body)) return L.send(res, 502, { ok: false, error: 'the database did not answer (' + r.status + ')' });
  const more = r.body.length > PAGE;
  let rows = r.body.slice(0, PAGE);
  if (t === 'shop_private' && who !== 'computer') rows = noPass(rows);            /* DOWNLOAD BACKUP on a laptop: no staff passcodes in the file */
  return L.send(res, 200, { ok: true, table: t, page, rows, more });
};
module.exports.TABLES = TABLES; module.exports.RESTORE_KEY = RESTORE_KEY; module.exports._inList = inList; module.exports._keepPass = keepPass;

/* try45.js -- THE 45-DEGREE TRY-ON ENGINE (d17.23, 1 Oct 2026)

   What it does: puts the frame's own 45-degree cut-out (the robot's photographed near
   arm, the far arm already removed) on a customer's turned face, at the frame's true
   size. No drawn arms: the arm is the photographed one, faded out behind the ear.

   What it never does: touch the front try-on. This file stands on its own; nothing in
   onface.js or the front flow calls it. It reads the face the same way the front does
   (VGOnFace.findFace / faceFromLandmarks give the face object) and only adds placing.

   The pieces
     fitPointsFromImage(img)   where the bridge and the two lens openings are in a
                               cut-out (the same rule the robot uses; used when the
                               robot's own fit points are missing)
     frontReference(frontImg, sizes, frontFace)
                               true size from the FRONT cut-out and the face's own
                               scale from the FRONT photo, carried over to the turned view
     pickView(face, views)     which of the frame's two 45 views belongs to this turn
     fit45(o)                  the placing; returns {canvas, report} or {error, advice}
     headTurn(face)            for the guide: turn more / good / turn back

   Everything that depends on how a real face looks is a named constant below, so it
   can be tuned from the numbers the test page prints, not by guessing. */
(function (global) {
  'use strict';

  var VERSION = '2026-10-08 try45.28';

  /* THE HEAD-TURN WINDOW. yaw is the engine's own number: (distance nose-to-far-cheek minus
     nose-to-near-cheek) / face width, 0 square on, about 0.6 at most. 0.20 to 0.58 is a
     starting window around "halfway"; the test page prints the real number for each photo
     so it can be set from the six AI models. */
  /* d17.40: the window for a half turn (about 25 to 55 degrees) on the uncapped turn measure; it used to end at 0.58,
     so a real 45-degree turn (about 0.75) was refused as 'turned too far' */
  var YAW_MIN = 0.32, YAW_MAX = 0.99;   /* d17.67: frames are shot at 30 degrees now; a customer's 30-degree turn reads about 0.5-0.6; 45-degree photos still work */
  var ROLL_MAX = 14 * Math.PI / 180;
  var IRIS_MM = 12.0;                 /* the same figure the front uses */
  var SEAT_DROP_MM = 2.0;             /* lens centre sits this far below the pupil line (the front's rule) */
  var FADE_START = 0.84;   /* d17.54 (shop): the temple runs straight back and reaches the ear; it slips into the hair only over the last stretch */              /* the arm is full strength this far (as a share of eye-to-ear) ... */
  var FADE_END = 1.00;                /* ... and gone by the ear root, plus a little */
  var ASSUMED_LENS_H_RATIO = 0.78;    /* only when the front cut-out is missing: lens height / lens width */
  var ASSUMED_FACE_LEN_MM = 188;      /* only when no front photo is available: brow to chin */

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function isNum(v) { return typeof v === 'number' && isFinite(v); }

  /* ---------- fit points from a cut-out (the JavaScript twin of the robot's angle_anchors) ---------- */
  function alphaOf(img, maxSide, thr) {
    var w0 = img.naturalWidth || img.width, h0 = img.naturalHeight || img.height;
    if (!w0 || !h0) return null;
    var k = Math.min(1, (maxSide || 640) / Math.max(w0, h0)), t = thr == null ? 127 : thr;
    var w = Math.max(1, Math.round(w0 * k)), h = Math.max(1, Math.round(h0 * k));
    var c = document.createElement('canvas'); c.width = w; c.height = h;
    var x = c.getContext('2d'); x.drawImage(img, 0, 0, w, h);
    var d = x.getImageData(0, 0, w, h).data, a = new Uint8Array(w * h);
    for (var i = 0, j = 3; i < a.length; i++, j += 4) a[i] = d[j] > t ? 1 : 0;
    return { a: a, w: w, h: h, k: k, w0: w0, h0: h0 };
  }

  function floodOutside(a, w, h) {
    var out = new Uint8Array(w * h), stack = [], i;
    function push(p) { if (!a[p] && !out[p]) { out[p] = 1; stack.push(p); } }
    for (i = 0; i < w; i++) { push(i); push((h - 1) * w + i); }
    for (i = 0; i < h; i++) { push(i * w); push(i * w + w - 1); }
    while (stack.length) {
      var p = stack.pop(), x = p % w, y = (p - x) / w;
      if (x > 0) push(p - 1); if (x < w - 1) push(p + 1);
      if (y > 0) push(p - w); if (y < h - 1) push(p + w);
    }
    return out;
  }
  /* d17.72 square dilate / erode (separable), for closing small breaks in a thin rim */
  function morph(a, w, h, r, grow) {
    var t = new Uint8Array(w * h), o = new Uint8Array(w * h), x, y, k, v;
    for (y = 0; y < h; y++) for (x = 0; x < w; x++) {
      v = grow ? 0 : 1;
      for (k = -r; k <= r; k++) { var xx = x + k; var q = (xx < 0 || xx >= w) ? 0 : a[y * w + xx]; if (grow ? q : !q) { v = grow ? 1 : 0; break; } }
      t[y * w + x] = v;
    }
    for (y = 0; y < h; y++) for (x = 0; x < w; x++) {
      v = grow ? 0 : 1;
      for (k = -r; k <= r; k++) { var yy = y + k; var q2 = (yy < 0 || yy >= h) ? 0 : t[yy * w + x]; if (grow ? q2 : !q2) { v = grow ? 1 : 0; break; } }
      o[y * w + x] = v;
    }
    return o;
  }

  /* the lens openings in a mask: [{cx,cy,x0,x1,y0,y1,w,h,area}], biggest first */
  function lensBoxes(a, w, h, fx0, fy0, fx1, fy1) {
    var n = w * h, i, out = floodOutside(a, w, h), lab = new Int32Array(n), comps = [], stack = [];
    for (i = 0; i < n; i++) {
      if (a[i] || out[i] || lab[i]) continue;
      var id = comps.length + 1, c = { area: 0, sx: 0, sy: 0, x0: w, x1: -1, y0: h, y1: -1 };
      lab[i] = id; stack.push(i);
      while (stack.length) {
        var p = stack.pop(), px = p % w, py = (p - px) / w;
        c.area++; c.sx += px; c.sy += py;
        if (px < c.x0) c.x0 = px; if (px > c.x1) c.x1 = px; if (py < c.y0) c.y0 = py; if (py > c.y1) c.y1 = py;
        var nb = [px > 0 ? p - 1 : -1, px < w - 1 ? p + 1 : -1, py > 0 ? p - w : -1, py < h - 1 ? p + w : -1];
        for (var q = 0; q < 4; q++) { var m = nb[q]; if (m >= 0 && !a[m] && !out[m] && !lab[m]) { lab[m] = id; stack.push(m); } }
      }
      comps.push(c);
    }
    var fh = fy1 - fy0 + 1, fw = fx1 - fx0 + 1, boxes = [];
    comps.sort(function (p, q) { return q.area - p.area; });
    for (i = 0; i < Math.min(6, comps.length); i++) {
      var c2 = comps[i], bh = c2.y1 - c2.y0 + 1, bw = c2.x1 - c2.x0 + 1;
      if (bh < 0.25 * fh || c2.area < 0.015 * fh * fw || bw < 0.06 * fw) continue;       /* a lens, not a speck */
      boxes.push({ cx: c2.sx / c2.area, cy: c2.sy / c2.area, x0: c2.x0, x1: c2.x1, y0: c2.y0, y1: c2.y1, w: bw, h: bh, area: c2.area });
    }
    return boxes;
  }
  /* d17.72 (VG-1019): an opening can be only PART of the lens -- the far temple runs across the far lens and the glass above
     it was left solid, so the opening is the lower half. The lens's real top and bottom are found from the solid run right
     above and below the opening (rim + glass + arm, up to the background), minus one rim thickness. */
  function trueLensSpan(a, w, h, b) {
    var tops = [], bots = [], rims = [];
    var xa = Math.round(b.x0 + b.w * 0.3), xb = Math.round(b.x1 - b.w * 0.3);
    for (var x = xa; x <= xb; x++) {
      var y0 = -1, y1 = -1, y;
      for (y = b.y0; y < b.y1; y++) if (!a[y * w + x]) { y0 = y; break; }                    /* first open pixel of the opening in this column */
      for (y = b.y1; y > b.y0; y--) if (!a[y * w + x]) { y1 = y; break; }
      if (y0 < 0 || y1 < 0) continue;
      var up = 0; for (y = y0 - 1; y >= 0 && a[y * w + x]; y--) up++;
      var dn = 0; for (y = y1 + 1; y < h && a[y * w + x]; y++) dn++;
      if (!up || !dn) continue;
      tops.push(y0 - up); bots.push(y1 + dn); rims.push(Math.min(up, dn));
    }
    if (tops.length < 3) return null;
    var med = function (v) { v = v.slice().sort(function (p, q) { return p - q; }); return v[v.length >> 1]; };
    var t = med(rims), top = med(tops) + t, bot = med(bots) - t;
    return bot > top ? { y0: top, y1: bot, h: bot - top + 1, cy: (top + bot) / 2 } : null;
  }

  function fitPointsFromImage(img) {
    try {
      /* strict first (as the robot), then -- d17.72, thin metal rims (VG-1019) -- a softer edge and small breaks closed */
      var passes = [{ thr: 127, close: 0 }, { thr: 40, close: 1 }];
      for (var pi = 0; pi < passes.length; pi++) {
        var A = alphaOf(img, 640, passes[pi].thr); if (!A) return null;
        var a = A.a, w = A.w, h = A.h, n = w * h, i;
        var solid = 0, fx0 = w, fy0 = h, fx1 = -1, fy1 = -1;
        for (i = 0; i < n; i++) if (a[i]) { solid++; var x = i % w, y = (i - x) / w; if (x < fx0) fx0 = x; if (x > fx1) fx1 = x; if (y < fy0) fy0 = y; if (y > fy1) fy1 = y; }
        if (solid < 200) return null;
        if (passes[pi].close) { var r = Math.max(2, Math.round((fy1 - fy0 + 1) * 0.0125)); a = morph(morph(a, w, h, r, true), w, h, r, false); }
        var boxes = lensBoxes(a, w, h, fx0, fy0, fx1, fy1), fh = fy1 - fy0 + 1;
        if (boxes.length < 2) continue;
        boxes = boxes.slice(0, 2);
        /* a lens cut short by solid glass above an arm gets its real height back (never taller than the other lens) */
        for (var bi = 0; bi < 2; bi++) {
          var other = boxes[1 - bi], sp = trueLensSpan(a, w, h, boxes[bi]);
          if (sp && sp.h > boxes[bi].h * 1.2 && sp.h <= Math.max(other.h, boxes[bi].h) * 1.08) { boxes[bi].y0 = sp.y0; boxes[bi].y1 = sp.y1; boxes[bi].h = sp.h; boxes[bi].cy = sp.cy; boxes[bi].fixed = true; }
        }
        boxes.sort(function (p, q) { return (q.w * q.h) - (p.w * p.h); });                    /* the near lens is the bigger one */
        if (boxes[1].area < 0.12 * boxes[0].area && !boxes[1].fixed) continue;                /* the far lens is not really visible */
        if (Math.abs(boxes[0].cy - boxes[1].cy) > 0.35 * fh) continue;                       /* not two lenses side by side */
        var near = boxes[0], far = boxes[1];
        var left = near.cx < far.cx ? near : far, right = near.cx < far.cx ? far : near;
        var s = 1 / A.k;                                                                      /* back to the picture's own pixels */
        var sc = function (b) { return { cx: b.cx * s, cy: b.cy * s, w: b.w * s, h: b.h * s }; };
        return {
          w: A.w0, h: A.h0, frame: [fx0 * s, fy0 * s, fx1 * s, fy1 * s],
          bridge: [((left.x1 + right.x0) / 2) * s, ((left.cy + right.cy) / 2) * s],
          near: sc(near), far: sc(far), nearSide: near === left ? 'left' : 'right',
          lensHeightPx: near.h * s, lensLine: ((near.cy + far.cy) / 2) * s, source: pi ? 'page (thin rim)' : 'page'
        };
      }
      return null;
    } catch (e) { return null; }
  }

  /* the robot writes its own fit points (in the cut-out's own pixels, with w and h); use them when they are sound */
  function usableFit(fit, img) {
    if (!fit || !fit.bridge || !fit.near || !fit.far || !isNum(fit.bridge[0])) return null;
    var w0 = img.naturalWidth || img.width, h0 = img.naturalHeight || img.height, k = (fit.w && w0) ? w0 / fit.w : 1;
    function sc(b) { return { cx: b.cx * k, cy: b.cy * k, w: b.w * k, h: b.h * k }; }
    return {
      w: w0, h: h0, frame: (fit.frame || [0, 0, w0, h0]).map(function (v) { return v * k; }),
      bridge: [fit.bridge[0] * k, fit.bridge[1] * k], near: sc(fit.near), far: sc(fit.far),
      nearSide: fit.nearSide, lensHeightPx: (fit.lensHeightPx || fit.near.h) * k, lensLine: (fit.lensLine || fit.bridge[1]) * k, source: 'robot', robotClean: fit.robotClean || null
    };
  }

  function fitFor(img, robotFit) {
    var f = usableFit(robotFit, img) || fitPointsFromImage(img) || hullFit(img);   /* d17.92: lens outlines when the openings are cut apart */
    if (f && robotFit && robotFit.robotClean) f.robotClean = robotFit.robotClean;   /* d17.82: kept after a hand FIX too */
    return f;
  }


  /* d17.91 (shop, 8 Oct, VG-1018: "you have the entire data and still the 30 degree is not fitting"): on a frame with CLEAR
     glass the far arm is seen through both lenses as a bar across their top third, and the lens openings found in the
     30° cut-out are only the part BELOW that bar. The frame was then scaled from lens heights about a third too small --
     drawn ~40% too big -- and its lens centres read too low, so it sat too high on the face. The frame's OUTER height at
     each lens (top of the top rim to bottom of the bottom rim) does not depend on what is seen through the glass and does
     not change when the frame is turned, so it is measured here, at the middle of each lens, in the front and the 30° cut-outs. */
  function pixelsOf(img, W, H) {
    var c = document.createElement('canvas'); c.width = W; c.height = H;
    var x = c.getContext('2d'); x.drawImage(img, 0, 0, W, H);
    return x.getImageData(0, 0, W, H).data;
  }
  function outerSpan(d, W, H, L) {
    var tops = [], bots = [], x0 = Math.round(L.cx - L.w * 0.2), x1 = Math.round(L.cx + L.w * 0.2), y;
    for (var x = Math.max(0, x0); x <= Math.min(W - 1, x1); x++) {
      var t = -1, b = -1;
      for (y = 0; y < H; y++) if (d[(y * W + x) * 4 + 3] > 100) { t = y; break; }
      for (y = H - 1; y >= 0; y--) if (d[(y * W + x) * 4 + 3] > 100) { b = y; break; }
      if (t >= 0 && b > t) { tops.push(t); bots.push(b); }
    }
    if (tops.length < 3) return null;
    var med = function (v) { v = v.slice().sort(function (p, q) { return p - q; }); return v[v.length >> 1]; };
    var top = med(tops), bot = med(bots);
    return { top: top, bot: bot, h: bot - top + 1 };
  }
  /* the lens openings of a 30° fit put right from the outer heights, using the front's own proportions; returns what changed */
  function fixLensSpans(cut, fit, ref) {
    if (!cut || !fit || !ref || !(ref.outerToLens > 1) || !isNum(ref.lensCyFrac)) return null;
    var d = pixelsOf(cut, fit.w, fit.h), out = { lenses: [] }, any = false;
    [['near', fit.near], ['far', fit.far]].forEach(function (pr) {
      var L = pr[1]; if (!L || !(L.w > 8) || !(L.h > 8)) return;
      var sp = outerSpan(d, fit.w, fit.h, L); if (!sp) return;
      var hTrue = sp.h / ref.outerToLens, cyTrue = sp.top + ref.lensCyFrac * sp.h;
      var info = { lens: pr[0], openingH: Math.round(L.h), trueH: Math.round(hTrue), outerH: sp.h, fixed: false };
      /* only when the opening is clearly cut short (more than 8%), and never past the frame itself */
      if (hTrue > L.h * 1.08 && hTrue < sp.h) {
        info.fixed = true; info.cyFrom = Math.round(L.cy); L.h = hTrue; L.cy = cyTrue; L.fixed = true; any = true; info.cyTo = Math.round(cyTrue);
        /* the same arm crosses the near lens slantwise and leaves its OUTER side out of the opening too; the frame's
           real outer side is where its bottom edge stops (beyond it only the arm runs, much higher) */
        var O = pr[0] === 'near' ? fit.far : fit.near, dir = O && O.cx < L.cx ? 1 : -1, base = sp.bot, lim = sp.h * 0.12, edge = -1, miss = 0;
        var bottomAt = function (x) { for (var y = fit.h - 1; y >= 0; y--) if (d[(y * fit.w + x) * 4 + 3] > 100) return y; return -1; };
        for (var x = Math.round(L.cx); x >= 0 && x < fit.w && Math.abs(x - L.cx) < L.w * 1.5; x += dir) {
          var bt = bottomAt(x);
          if (bt < base - lim) { if (++miss >= 3) break; } else { miss = 0; edge = x; }
        }
        if (edge >= 0) {
          var inner = L.cx - dir * L.w / 2, rimS = Math.max(2, (sp.h - hTrue) / 2 * 0.8), openOut = edge - dir * rimS;
          L.outerEdge = edge; info.outerEdge = edge;
          if ((openOut - inner) * dir > L.w * 1.04) { info.wFrom = Math.round(L.w); L.w = Math.abs(openOut - inner); L.cx = (openOut + inner) / 2; info.wTo = Math.round(L.w); }
        }
      }
      out.lenses.push(info);
    });
    if (any && fit.near && fit.far) { fit.bridge = [fit.bridge[0], (fit.near.cy + fit.far.cy) / 2]; fit.lensLine = fit.bridge[1]; fit.lensHeightPx = fit.near.h; }
    out.fixed = any;
    return out;
  }


  /* ---------- d17.92 (shop, 8 Oct, VG-1018: "the left temple is not cut, the side is thinner than the real one, the
     bridge, and the size is still a little big -- make it right once, for every frame") ---------- */
  /* the enclosed see-through pieces of a cut-out (glass areas); a lens crossed by the far arm is two or three of them */
  function holePieces(a, W, H) {
    var out = floodOutside(a, W, H), lab = new Int32Array(W * H), comps = [], stack = [];
    for (var i = 0; i < W * H; i++) {
      if (a[i] || out[i] || lab[i]) continue;
      var c = { area: 0, sx: 0, sy: 0, x0: W, x1: -1, y0: H, y1: -1, rows: {} }; lab[i] = comps.length + 1; stack.push(i);
      while (stack.length) {
        var p = stack.pop(), px = p % W, py = (p - px) / W; c.area++; c.sx += px; c.sy += py;
        if (px < c.x0) c.x0 = px; if (px > c.x1) c.x1 = px; if (py < c.y0) c.y0 = py; if (py > c.y1) c.y1 = py;
        var r = c.rows[py]; if (!r) c.rows[py] = [px, px]; else { if (px < r[0]) r[0] = px; if (px > r[1]) r[1] = px; }
        if (px > 0 && !a[p - 1] && !out[p - 1] && !lab[p - 1]) { lab[p - 1] = lab[i]; stack.push(p - 1); }
        if (px < W - 1 && !a[p + 1] && !out[p + 1] && !lab[p + 1]) { lab[p + 1] = lab[i]; stack.push(p + 1); }
        if (py > 0 && !a[p - W] && !out[p - W] && !lab[p - W]) { lab[p - W] = lab[i]; stack.push(p - W); }
        if (py < H - 1 && !a[p + W] && !out[p + W] && !lab[p + W]) { lab[p + W] = lab[i]; stack.push(p + W); }
      }
      c.cx = c.sx / c.area; c.cy = c.sy / c.area; comps.push(c);
    }
    return { comps: comps, out: out };
  }
  function convexHull(pts) {
    pts = pts.slice().sort(function (p, q) { return p[0] - q[0] || p[1] - q[1]; });
    if (pts.length < 3) return pts;
    var cr = function (o, a, b) { return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]); }, lo = [], up = [], i;
    for (i = 0; i < pts.length; i++) { while (lo.length >= 2 && cr(lo[lo.length - 2], lo[lo.length - 1], pts[i]) <= 0) lo.pop(); lo.push(pts[i]); }
    for (i = pts.length - 1; i >= 0; i--) { while (up.length >= 2 && cr(up[up.length - 2], up[up.length - 1], pts[i]) <= 0) up.pop(); up.push(pts[i]); }
    up.pop(); lo.pop(); return lo.concat(up);
  }
  /* the two lenses of a turned cut-out: the see-through pieces grouped by where they sit side to side (the pieces of one
     lens, cut apart by the far arm, lie one above the other), each lens the outline round all its pieces */
  function lensGroups(a, W, H) {
    /* d17.92: a rim with a crack lets its lens leak to the outside -- closed a little, then a little more, if needed */
    var best = null, rs = [0, Math.max(2, Math.round(H * 0.012)), Math.max(3, Math.round(H * 0.025)), Math.max(4, Math.round(H * 0.04))];
    for (var ri = 0; ri < rs.length; ri++) {
      var g = lensGroups1(rs[ri] ? morph(morph(a, W, H, rs[ri], true), W, H, rs[ri], false) : a, W, H);
      if (g && (!best || g.groups.length > best.groups.length)) best = g;
      if (best && best.groups.length >= 2) break;
    }
    return best;
  }
  function lensGroups1(a, W, H) {
    var hp = holePieces(a, W, H), cs = hp.comps.slice().sort(function (p, q) { return q.area - p.area; });
    if (!cs.length) return null;
    var big = cs[0].area; cs = cs.filter(function (c) { return c.area >= big * 0.02 && (c.x1 - c.x0) >= W * 0.015 && (c.y1 - c.y0) >= H * 0.03; });
    var groups = [];
    cs.forEach(function (c) {
      var g = null;
      for (var k = 0; k < groups.length && !g; k++) { var G = groups[k], ov = Math.min(G.x1, c.x1) - Math.max(G.x0, c.x0);
        if (ov > 0.3 * Math.min(G.x1 - G.x0, c.x1 - c.x0)) g = G; }
      if (!g) groups.push({ x0: c.x0, x1: c.x1, y0: c.y0, y1: c.y1, area: c.area, pieces: [c] });
      else { g.x0 = Math.min(g.x0, c.x0); g.x1 = Math.max(g.x1, c.x1); g.y0 = Math.min(g.y0, c.y0); g.y1 = Math.max(g.y1, c.y1); g.area += c.area; g.pieces.push(c); }
    });
    groups.forEach(function (g) {
      var pts = []; g.pieces.forEach(function (c) { for (var y in c.rows) { pts.push([c.rows[y][0], +y]); pts.push([c.rows[y][1] + 1, +y]); pts.push([c.rows[y][0], +y + 1]); pts.push([c.rows[y][1] + 1, +y + 1]); } });
      g.hull = convexHull(pts); var A = 0, cx = 0, cy = 0, n = g.hull.length;
      for (var i = 0; i < n; i++) { var p = g.hull[i], q = g.hull[(i + 1) % n], cr = p[0] * q[1] - q[0] * p[1]; A += cr; cx += (p[0] + q[0]) * cr; cy += (p[1] + q[1]) * cr; }
      g.hullArea = Math.abs(A / 2); g.cx = A ? cx / (3 * A) : (g.x0 + g.x1) / 2; g.cy = A ? cy / (3 * A) : (g.y0 + g.y1) / 2;
    });
    groups.sort(function (p, q) { return q.hullArea - p.hullArea; });
    groups = groups.filter(function (g) { return g.hullArea >= groups[0].hullArea * 0.12; }).slice(0, 2);
    return { groups: groups, out: hp.out };
  }
  /* fit points from those lens outlines -- used when the robot's own and the older reading both find no lenses */
  function hullFit(img) {
    var W0 = img.naturalWidth || img.width, H0 = img.naturalHeight || img.height, k = Math.min(1, 1000 / Math.max(W0, H0));
    var W = Math.max(1, Math.round(W0 * k)), H = Math.max(1, Math.round(H0 * k)), d = pixelsOf(img, W, H), a = new Uint8Array(W * H);
    for (var i = 0; i < a.length; i++) a[i] = d[i * 4 + 3] > 100 ? 1 : 0;
    var lg = lensGroups(a, W, H); if (!lg || lg.groups.length < 2) return null;
    var nr = lg.groups[0], fr = lg.groups[1];
    if (Math.abs(nr.cy - fr.cy) > 0.35 * H) return null;
    var left = nr.cx < fr.cx ? nr : fr, right = nr.cx < fr.cx ? fr : nr, s = 1 / k;
    var box = function (g) { return { cx: (g.x0 + g.x1 + 1) / 2 * s, cy: (g.y0 + g.y1 + 1) / 2 * s, w: (g.x1 - g.x0 + 1) * s, h: (g.y1 - g.y0 + 1) * s }; };
    var fx0 = W, fx1 = 0, fy0 = H, fy1 = 0; for (i = 0; i < a.length; i++) if (a[i]) { var x = i % W, y = (i - x) / W; if (x < fx0) fx0 = x; if (x > fx1) fx1 = x; if (y < fy0) fy0 = y; if (y > fy1) fy1 = y; }
    var N = box(nr), F = box(fr);
    /* the far lens can be found only in part (the far arm across it); then the bridge is put a fifth of the near lens's
       width beyond the near lens's inner edge, as on a whole frame */
    var nIn = nr === left ? nr.x1 + 1 : nr.x0, fIn = fr === left ? fr.x1 + 1 : fr.x0, nWg = nr.x1 - nr.x0 + 1, bx = (nIn + fIn) / 2;
    if (Math.abs(fIn - nIn) > 0.8 * nWg) bx = nIn + (fr.cx > nr.cx ? 1 : -1) * 0.19 * nWg;
    return { w: W0, h: H0, frame: [fx0 * s, fy0 * s, fx1 * s, fy1 * s], bridge: [bx * s, (N.cy + F.cy) / 2],
             near: N, far: F, nearSide: nr === left ? 'left' : 'right', lensHeightPx: N.h, lensLine: (N.cy + F.cy) / 2, source: 'page (lens outlines)' };
  }
  /* THE STUDIO CAMERA IS CLOSE: in a 30° photo the near lens comes out up to 15% taller than the far one, so the frame
     drawn on a face looked too big on the near side. The cut-out is flattened -- every column brought to the size it
     has in the middle of the frame, the near side shrunk, the far side grown -- so both lenses are their true size, as
     on a face seen from a normal distance. Fit points are carried over. */
  function flattenPerspective(cut, fit) {
    if (!fit || !fit.near || !fit.far || !(fit.w > 20)) return null;
    var W = Math.round(fit.w), H = Math.round(fit.h), d = pixelsOf(cut, W, H);
    var sn = outerSpan(d, W, H, fit.near), sf = outerSpan(d, W, H, fit.far);
    if (!sn || !sf) return null;
    var H0 = (sn.h + sf.h) / 2, mn = sn.h / H0, mf = sf.h / H0;
    if (Math.abs(mn - mf) < 0.02 || mn > 1.25 || mn < 0.8 || mf > 1.25 || mf < 0.8) return null;   /* nothing to put right, or a reading not to trust */
    var xn = fit.near.cx, xf = fit.far.cx;
    var m = function (x) { var t = (x - xf) / (xn - xf); t = clamp(t, 0, 1); return mf + (mn - mf) * t; };
    var yL = isNum(fit.lensLine) ? fit.lensLine : fit.bridge[1];
    var X = new Float64Array(W + 1); for (var x = 0; x < W; x++) X[x + 1] = X[x] + 1 / m(x + 0.5);
    var offY = 0, botY = 0; for (x = 0; x < W; x++) { var mm = m(x + 0.5); offY = Math.max(offY, yL / mm - yL); botY = Math.max(botY, yL + (H - yL) / mm); }
    var W2 = Math.ceil(X[W]), H2 = Math.ceil(botY + offY);
    var c = document.createElement('canvas'); c.width = W2; c.height = H2;
    var cx2 = c.getContext('2d'), img2 = cx2.createImageData(W2, H2), o = img2.data;
    var j = 0;
    for (var x2 = 0; x2 < W2; x2++) {
      while (j < W - 1 && X[j + 1] <= x2 + 0.5) j++;
      var xs = j + (x2 + 0.5 - X[j]) / (X[j + 1] - X[j]) - 0.5, mx = m(xs + 0.5);
      for (var y2 = 0; y2 < H2; y2++) {
        var ys = yL + (y2 + 0.5 - offY - yL) * mx - 0.5;
        if (xs < 0 || ys < 0 || xs > W - 1 || ys > H - 1) continue;
        var ix = Math.floor(xs), iy = Math.floor(ys), ux = xs - ix, uy = ys - iy, ix1 = Math.min(W - 1, ix + 1), iy1 = Math.min(H - 1, iy + 1);
        var p00 = (iy * W + ix) * 4, p10 = (iy * W + ix1) * 4, p01 = (iy1 * W + ix) * 4, p11 = (iy1 * W + ix1) * 4, q = (y2 * W2 + x2) * 4;
        var w00 = (1 - ux) * (1 - uy), w10 = ux * (1 - uy), w01 = (1 - ux) * uy, w11 = ux * uy;
        var A = d[p00 + 3] * w00 + d[p10 + 3] * w10 + d[p01 + 3] * w01 + d[p11 + 3] * w11;
        o[q + 3] = Math.round(A);
        if (A > 0) for (var ch = 0; ch < 3; ch++) o[q + ch] = Math.round((d[p00 + ch] * d[p00 + 3] * w00 + d[p10 + ch] * d[p10 + 3] * w10 + d[p01 + ch] * d[p01 + 3] * w01 + d[p11 + ch] * d[p11 + 3] * w11) / A);
      }
    }
    cx2.putImageData(img2, 0, 0);
    var mapX = function (x) { x = clamp(x, 0, W); var i = Math.min(W - 1, Math.floor(x)); return X[i] + (x - i) / m(i + 0.5); };
    var mapY = function (x, y) { return offY + yL + (y - yL) / m(x); };
    [fit.near, fit.far].forEach(function (L) {
      var x0 = mapX(L.cx - L.w / 2), x1 = mapX(L.cx + L.w / 2), mm = m(L.cx);
      var cy = mapY(L.cx, L.cy); L.cx = (x0 + x1) / 2; L.w = x1 - x0; L.h = L.h / mm; L.cy = cy;
      if (isNum(L.outerEdge)) L.outerEdge = mapX(L.outerEdge);
    });
    fit.bridge = [mapX(fit.bridge[0]), mapY(fit.bridge[0], fit.bridge[1])]; fit.lensLine = fit.bridge[1]; fit.lensHeightPx = fit.near.h;
    if (fit.frame) fit.frame = [mapX(fit.frame[0]), 0, mapX(fit.frame[2]), H2];
    fit.w = W2; fit.h = H2;
    return { canvas: c, nearWas: +mn.toFixed(3), farWas: +mf.toFixed(3) };
  }
  /* THE NEAR ARM AS IT REALLY IS: followed column by column from the hinge, keeping its true thickness as it runs back
     (it used to be cut to a level band, which made a thick acetate arm a thin wedge); anything else beside it -- the far
     arm passing behind, its ear tip -- is not part of the run and goes */
  function trackArm(d, W, H, xs, dir, yc, tExp, minCols) {
    var al = function (x, y) { return d[(y * W + x) * 4 + 3]; }, runs = {}, x = xs, y, t0 = 0, prevT = 0, prevB = 0, miss = 0, n = 0, recent = [], grow = 0, lastX = xs;
    var runAt = function (x, wantT, wantB) {
      var best = null, bestOv = -1e9; y = 0;
      while (y < H) { if (al(x, y) > 60) { var s0 = y; while (y < H && al(x, y) > 60) y++; var e0 = y - 1, ov = Math.min(e0, wantB + 2) - Math.max(s0, wantT - 2);
          if (ov > bestOv) { bestOv = ov; best = [s0, e0]; } } else y++; }
      return bestOv >= 0 ? best : null;
    };
    var r0 = runAt(xs, yc, yc); if (!r0) return null;
    if (tExp > 2 && r0[1] - r0[0] + 1 > tExp * 1.8) r0 = [Math.max(r0[0], Math.round(yc - tExp / 2)), Math.min(r0[1], Math.round(yc + tExp / 2))];   /* still on the end piece: the arm's own band */
    t0 = r0[1] - r0[0] + 1; prevT = r0[0]; prevB = r0[1];
    for (x = xs; x >= 0 && x < W; x += dir) {
      var r = runAt(x, prevT, prevB);
      if (!r) { if (++miss > 3) break; continue; }
      miss = 0;
      var a0 = r[0], b0 = r[1];
      /* the arm thins as it runs away from the camera; where it suddenly grows downwards it bends over the ear -- that tip
         is behind the ear on a head, so the arm ends there */
      if (n >= Math.max(12, minCols || 0)) { var th = recent.slice().sort(function (p, q) { return p - q; })[recent.length >> 1];
        if (b0 - a0 + 1 > th * 1.35 && b0 > prevB + th * 0.15) { if (++grow >= 3) { for (var k = 1; k <= 2; k++) delete runs[x - k * dir]; n -= 2; lastX = x - 3 * dir; break; } } else grow = 0; }
      if (b0 - a0 + 1 > Math.max(t0, prevB - prevT + 1) * 1.6) { var mid = (prevT + prevB) / 2, hh = (prevB - prevT) / 2 + 1; a0 = Math.max(a0, Math.round(mid - hh)); b0 = Math.min(b0, Math.round(mid + hh)); }
      runs[x] = [a0, b0]; prevT = a0; prevB = b0; n++; lastX = x;
      recent.push(b0 - a0 + 1); if (recent.length > 12) recent.shift();
    }
    if (n <= 5) return null;
    /* the straight part: top edge and thickness fitted as lines over the first half; where the bottom drops clearly below
       that (the bend over the ear, curving down) the arm ends */
    var xsArr = Object.keys(runs).map(Number).sort(function (p, q) { return (p - q) * dir; });
    var half = xsArr.slice(Math.round(xsArr.length * 0.1), Math.round(xsArr.length * 0.5));
    if (half.length >= 8) {
      var fitL = function (f) { var sx = 0, sy = 0, sxx = 0, sxy = 0, k = half.length; half.forEach(function (x) { var v = f(x); sx += x; sy += v; sxx += x * x; sxy += x * v; });
        var den = k * sxx - sx * sx, sl = den ? (k * sxy - sx * sy) / den : 0; return { a: (sy - sl * sx) / k, b: sl }; };
      var tl = fitL(function (x) { return runs[x][0]; }), kl = fitL(function (x) { return runs[x][1] - runs[x][0] + 1; });
      var thMed = half.map(function (x) { return runs[x][1] - runs[x][0] + 1; }).sort(function (p, q) { return p - q; })[half.length >> 1], over = 0;
      for (var i2 = Math.round(xsArr.length * 0.5); i2 < xsArr.length; i2++) {
        var xx = xsArr[i2], pb = tl.a + tl.b * xx + Math.max(2, kl.a + kl.b * xx) - 1;
        if (runs[xx][1] - pb > Math.max(3, thMed * 0.5)) { if (++over >= 3) { for (var j2 = i2 - 2; j2 < xsArr.length; j2++) delete runs[xsArr[j2]]; lastX = xsArr[Math.max(0, i2 - 3)]; n = i2 - 2; break; } }
        else over = 0;
      }
    }
    return { runs: runs, thick: t0, cols: n, endX: lastX };
  }
  /* inside each lens outline: everything seen through the glass goes (the far arm, its hinge, glass that was left solid);
     the rim is outside the outline and never touched; the inner lower side, where nose pads sit, is kept */
  function clearInsideLenses(cm, fit, onlyFixed) {
    var W = fit.w, H = fit.h, im = cm.getImageData(0, 0, W, H), d = im.data, a = new Uint8Array(W * H), i;
    for (i = 0; i < a.length; i++) a[i] = d[i * 4 + 3] > 100 ? 1 : 0;
    var lg = lensGroups(a, W, H); if (!lg || !lg.groups.length) return null;
    var done = [];
    [fit.near, fit.far].forEach(function (L) {
      if (!L || (onlyFixed && !L.fixed)) return;
      var g = null, bd = 1e9; lg.groups.forEach(function (G) { var dd = Math.abs(G.cx - L.cx) + Math.abs(G.cy - L.cy); if (dd < bd && G.cx > L.cx - L.w * 0.7 && G.cx < L.cx + L.w * 0.7) { bd = dd; g = G; } });
      if (!g || g.hull.length < 3) return;
      if (L.fixed) {   /* the part of the lens above the far arm can be left solid (glass + arm): the outline reaches the lens's real top and bottom */
        var gx0 = Infinity, gx1 = -Infinity; g.hull.forEach(function (p) { gx0 = Math.min(gx0, p[0]); gx1 = Math.max(gx1, p[0]); });
        var top = L.cy - L.h / 2 + 2, bot = L.cy + L.h / 2 - 2, ext = g.hull.slice();
        for (var t = 0.2; t <= 0.81; t += 0.15) { var px = gx0 + (gx1 - gx0) * t; ext.push([px, top]); ext.push([px, bot]); }
        g.hull = convexHull(ext); g.y0 = Math.min(g.y0, Math.floor(top)); g.y1 = Math.max(g.y1, Math.ceil(bot));
      }
      var O = L === fit.near ? fit.far : fit.near, inward = O && O.cx > L.cx ? 1 : -1;
      var c = document.createElement('canvas'); c.width = W; c.height = H; var x = c.getContext('2d');
      x.beginPath(); g.hull.forEach(function (p, k) { var px = p[0] + (g.cx - p[0]) * 0.012, py = p[1] + (g.cy - p[1]) * 0.012; if (k) x.lineTo(px, py); else x.moveTo(px, py); }); x.closePath(); x.fill();
      var md = x.getImageData(0, 0, W, H).data, rx = Math.max(4, (g.x1 - g.x0) / 2), ry = Math.max(4, (g.y1 - g.y0) / 2), n = 0;
      var a0 = Math.atan2(-0.45, 0.89 * inward), a1 = Math.atan2(0.85, 0.53 * inward);
      for (var y = g.y0 - 2; y <= g.y1 + 2; y++) for (var xx = g.x0 - 2; xx <= g.x1 + 2; xx++) {
        if (xx < 0 || y < 0 || xx >= W || y >= H) continue; var q = (y * W + xx) * 4;
        if (md[q + 3] < 128 || d[q + 3] === 0) continue;
        var ex = (xx - g.cx) / rx, ey = (y - g.cy) / ry, rr = Math.sqrt(ex * ex + ey * ey), th = Math.atan2(ey, ex * inward);
        var inPad = rr > 0.62 && th >= Math.atan2(-0.45, 0.89) && th <= Math.atan2(0.85, 0.53);
        if (inPad) continue;                                                           /* the nose pads */
        d[q + 3] = 0; n++;
      }
      done.push({ lens: L === fit.near ? 'near' : 'far', cleared: n, pieces: g.pieces.length });
    });
    if (done.length) cm.putImageData(im, 0, 0);
    return done;
  }


  /* between the lenses, under the bridge, a turned photo shows the far arm passing behind (on a face the nose is
     there): below the bridge bar, clear of both rims, it goes */
  function clearBridgeGap(cm, fit) {
    var N = fit.near, F = fit.far; if (!N || !F) return null;
    var W = fit.w, H = fit.h, im = cm.getImageData(0, 0, W, H), d = im.data;
    var lft = F.cx < N.cx ? F : N, rgt = F.cx < N.cx ? N : F;
    var spL = outerSpan(d, W, H, lft), spR = outerSpan(d, W, H, rgt);
    var T = Math.max(3, Math.min(spL ? (spL.h - lft.h) / 2 : 99, spR ? (spR.h - rgt.h) / 2 : 99));
    if (!(T < 60)) return null;
    var gx0 = Math.round(lft.cx + lft.w / 2 + T * 1.5), gx1 = Math.round(rgt.cx - rgt.w / 2 - T * 1.5);
    if (gx1 - gx0 < 3) return null;
    var yMax = Math.round(Math.max(lft.cy + lft.h / 2, rgt.cy + rgt.h / 2)), n = 0;
    for (var x = gx0; x <= gx1; x++) {
      var y = 0; while (y < H && d[(y * W + x) * 4 + 3] <= 100) y++;
      if (y >= H) continue;
      var y0 = y; while (y < H && d[(y * W + x) * 4 + 3] > 100) y++;
      var bBot = y0 + Math.min(y - y0, Math.round(T * 1.8));
      for (var yy = bBot + 1; yy <= Math.min(H - 1, yMax); yy++) { var q = (yy * W + x) * 4; if (d[q + 3]) { d[q + 3] = 0; n++; } }
    }
    if (n) cm.putImageData(im, 0, 0);
    return { cols: gx1 - gx0 + 1, cleared: n, rimPx: Math.round(T) };
  }

  /* ---------- scale: the face's own scale, and the frame's true size, both from the FRONT ---------- */
  function perMMFromFace(face) {                       /* pixels per millimetre on a square-on face: the front's own rule */
    if (!face) return 0;
    if (face.irisPx > 0) { var share = face.irisPx / (face.pd || 1); if (share > 0.10 && share < 0.40) return face.irisPx / IRIS_MM; }
    return face.pd > 0 ? face.pd / 63 : 0;
  }

  /* frontImg: the FRONT cut-out; sizes: {lens, bridge} as typed in admin (mm); frontFace: the face measured on the FRONT photo */
  function frontReference(frontImg, sizes, frontFace, frontRobotFit) {
    var ref = { face: frontFace || null, perMM: perMMFromFace(frontFace), mmppFront: 0, lensHpx: 0, source: [] };
    var fp = frontImg ? fitFor(frontImg, frontRobotFit) : null;
    if (fp && sizes && sizes.lens && isNum(+sizes.lens) && sizes.bridge != null) {
      var centres = Math.abs(fp.near.cx - fp.far.cx);                      /* lens centre to lens centre, in the cut-out's pixels */
      if (centres > 10) { ref.mmppFront = (Number(sizes.lens) + Number(sizes.bridge)) / centres; ref.lensHpx = (fp.near.h + fp.far.h) / 2; ref.source.push('front cut-out + typed lens/bridge'); }
      /* d17.91: the frame's outer height at each lens, and where the lens centre sits in it (the front is never cut short) */
      try {
        var d = pixelsOf(frontImg, fp.w, fp.h), r = [], c = [];
        [fp.near, fp.far].forEach(function (L) { var sp = outerSpan(d, fp.w, fp.h, L); if (sp && L.h > 8 && sp.h > L.h) { r.push(sp.h / L.h); c.push((L.cy - sp.top) / sp.h); } });
        if (r.length) { ref.outerToLens = r.reduce(function (p, q) { return p + q; }, 0) / r.length; ref.lensCyFrac = c.reduce(function (p, q) { return p + q; }, 0) / c.length; }
      } catch (e) {}
    }
    return ref;
  }


  /* ---------- d17.68 THE REAL TEMPLE from the side (90) cut-out ---------- */
  /* templeStrip(img): the arm out of a side cut-out -- the front is the tall slab at one end; the arm is the top run of
     the long low strip after it (the lower arm of an opened frame is left out). Returns {canvas, hingeFirst, slabH, thickPx}. */
  function templeStrip(img) {
    var W = img.naturalWidth || img.width, H = img.naturalHeight || img.height, c = document.createElement('canvas'); c.width = W; c.height = H;
    var x = c.getContext('2d'); x.drawImage(img, 0, 0); var d = x.getImageData(0, 0, W, H).data;
    var top = new Int16Array(W), run = new Int16Array(W), hgt = new Int16Array(W), maxH = 0;
    for (var cx = 0; cx < W; cx++) { var t = -1, bt = -1, rl = 0; for (var y = 0; y < H; y++) { var on = d[(y * W + cx) * 4 + 3] > 100; if (on) { if (t < 0) t = y; bt = y; if (rl >= 0) rl++; } else if (t >= 0 && rl > 0) { rl = -rl; } }
      top[cx] = t; run[cx] = Math.abs(rl); hgt[cx] = t < 0 ? 0 : bt - t + 1; if (hgt[cx] > maxH) maxH = hgt[cx]; }
    if (maxH < 10) return null;
    var tall = function (i) { return hgt[i] >= maxH * 0.6; };
    var leftTall = 0, rightTall = 0; for (var i = 0; i < Math.round(W * 0.3); i++) { if (tall(i)) leftTall++; if (tall(W - 1 - i)) rightTall++; }
    var dir = leftTall >= rightTall ? 1 : -1, e = dir > 0 ? 0 : W - 1; while (e >= 0 && e < W && tall(e)) e += dir;
    var a0 = dir > 0 ? e : 0, a1 = dir > 0 ? W : e + 1, cols = []; for (var k = a0; k < a1; k++) if (hgt[k] > 0 && run[k] > 0) cols.push(k);
    if (cols.length < 10) return null;
    /* d17.72 (VG-1019): the arm's thickness is read along its MIDDLE (the hinge end carries the nose pad and rims hanging
       below it). d17.73 (shop: "something like a trigger at the hinge"): the arm is followed as a LINE fitted through its
       middle, and each column takes only a band around that line -- the rims seen edge-on and the nose pad near the hinge,
       which used to come along as a squiggle, stay out. */
    var m0 = Math.round(cols.length * 0.25), m1 = Math.max(m0 + 3, Math.round(cols.length * 0.65)), midC = cols.slice(m0, m1);
    var mid = midC.map(function (k) { return run[k]; }).sort(function (p, q) { return p - q; });
    var thick = mid.length ? mid[mid.length >> 1] : 0;
    if (!thick) return null;
    var sx = 0, sy = 0, sxx = 0, sxy = 0, nn = 0;
    midC.forEach(function (k) { if (run[k] > 0 && run[k] <= thick * 1.6) { sx += k; sy += top[k]; sxx += k * k; sxy += k * top[k]; nn++; } });
    var slope = nn > 2 && (nn * sxx - sx * sx) ? (nn * sxy - sx * sy) / (nn * sxx - sx * sx) : 0, icpt = nn ? (sy - slope * sx) / nn : top[cols[0]];
    var line = function (k) { return icpt + slope * k; };
    var bandA = Math.round(thick * 0.35), bandH = Math.round(thick * 1.7);
    var y0 = H, y1 = 0; cols.forEach(function (k) { var a = Math.round(line(k)) - bandA; if (a < y0) y0 = a; if (a + bandH > y1) y1 = a + bandH; });
    y0 = Math.max(0, y0); y1 = Math.min(H, y1);
    var out = document.createElement('canvas'); out.width = cols[cols.length - 1] - cols[0] + 1; out.height = Math.max(2, y1 - y0); var ox = out.getContext('2d');
    cols.forEach(function (k) { var a = Math.max(0, Math.round(line(k)) - bandA), hh = Math.min(H - a, bandH); if (hh > 0) ox.drawImage(c, k, a, 1, hh, k - cols[0], a - y0, 1, hh); });
    var k0 = dir > 0 ? cols[0] : cols[cols.length - 1];
    var hingeYpx = line(k0) - y0 + thick / 2;                                                   /* d17.73: the arm's centre at its hinge end, in strip px */
    return { canvas: out, hingeFirst: dir > 0, slabH: maxH, thickPx: thick, lenPx: out.width, hingeYpx: hingeYpx };
  }
  /* d17.69 TWO SIDE PHOTOS (shop, 7 Oct: "option 2"): the 90 photo of the LEFT temple and, when the shop took it, the 90
     photo of the RIGHT temple. Each side of the head gets the photo whose arm runs the same way as it is drawn, so a
     printed logo reads the right way round; with only one photo it is mirrored for the other side (the old way).
     Which photo is which is read from the photo itself (where the front slab is), never from its label. */
  function templeUrls(p) {
    var hid = (p && Array.isArray(p.hideViews)) ? p.hideViews : [], pend = (p && Array.isArray(p.pendingViews)) ? p.pendingViews : [], out = [];
    [['side', 'tryOnSideUrl'], ['side2', 'tryOnSide2Url']].forEach(function (a) { var u = p && p[a[1]]; if (u && hid.indexOf(a[0]) < 0 && pend.indexOf(a[0]) < 0) out.push(u); });
    return out;
  }
  function loadTemples(p, load) {
    return Promise.all(templeUrls(p).map(function (u) { return Promise.resolve().then(function () { return load(u); }).then(templeStrip).catch(function () { return null; }); }))
      .then(function (a) { return a.filter(Boolean); });
  }
  /* drawDir +1 = the arm is drawn towards the right of the picture, -1 = towards the left */
  function pickTemple(temples, drawDir) {
    var list = Array.isArray(temples) ? temples.filter(Boolean) : (temples ? [temples] : []);
    if (!list.length) return null;
    for (var i = 0; i < list.length; i++) if ((list[i].hingeFirst ? 1 : -1) === drawDir) return { t: list[i], mirror: false };
    return { t: list[0], mirror: true };
  }
  /* paints the strip with its hinge at (0,0) of the current transform, the arm running along drawDir * x;
     the fade starts from the HINGE end whichever way the photo was taken.
     d17.73 (shop, 7 Oct: "the side is very thin, faded, and the hinge is up and down"): `thick` is the arm's TRUE
     thickness on the face, so the arm itself (not the strip's box) is drawn that thick; only the front part of the arm
     -- hinge to about the ear, the part that shows -- is used, so it is not squeezed; the arm's centre sits on the hinge. */
  var TEMPLE_SHOWN = 0.62;
  function paintTemple(ctx, pick, drawDir, len, thick, fadeFrom) {
    var t = pick.t, photoDir = t.hingeFirst ? 1 : -1, cw = t.canvas.width, ch = t.canvas.height;
    var ky = Math.max(0.05, thick / Math.max(1, t.thickPx || ch));
    var tmp = document.createElement('canvas'); tmp.width = Math.max(2, Math.round(len)); tmp.height = Math.max(2, Math.round(ch * ky));
    var sw = Math.max(2, Math.round(cw * TEMPLE_SHOWN)), sx = photoDir > 0 ? 0 : cw - sw;
    var tx = tmp.getContext('2d'); tx.drawImage(t.canvas, sx, 0, sw, ch, 0, 0, tmp.width, tmp.height);
    var g = photoDir > 0 ? tx.createLinearGradient(0, 0, tmp.width, 0) : tx.createLinearGradient(tmp.width, 0, 0, 0);
    g.addColorStop(0, 'rgba(0,0,0,1)'); g.addColorStop(fadeFrom, 'rgba(0,0,0,1)'); g.addColorStop(1, 'rgba(0,0,0,0)');
    tx.globalCompositeOperation = 'destination-in'; tx.fillStyle = g; tx.fillRect(0, 0, tmp.width, tmp.height);
    if (pick.mirror) ctx.scale(-1, 1);                       /* only when the photo shows the other arm (one photo only) */
    var hy = (t.hingeYpx != null ? t.hingeYpx : (t.thickPx || ch) / 2) * ky;
    ctx.drawImage(tmp, photoDir > 0 ? 0 : -tmp.width, -hy);
  }
  /* d17.81 (shop: "the rim is zigzag up and down at the bottom; the top is very good"): around each lens the rim's
     inner and outer edges are read along rays from the lens centre, one per degree. The rim's true thickness is the one
     read along the top. Along the bottom (4 to 8 o'clock) the rim's middle line is smoothed -- a local curve over +-26
     degrees that ignores teeth and bites -- and the rim is painted again there as one even band of the top's thickness,
     in the rim's own colour, edges soft. Towards the sides it blends back into the original rim (no step); the nose-pad
     side and the hinge are not touched. Same as the robot's build 2026-10-07r, so a robot-cleaned picture stays as it is. */
  function smoothBottoms(d, W, H, lenses, R, G, B) {
    var n = W * H, al = new Float32Array(n), i, changed = 0, SPAN = 26, d0 = d.slice(0);   /* d0: the picture before any change */
    for (i = 0; i < n; i++) al[i] = d[i * 4 + 3];
    var med = function (v) { var t = v.slice().sort(function (p, q) { return p - q; }); var m = t.length >> 1; return t.length % 2 ? t[m] : (t[m - 1] + t[m]) / 2; };
    lenses.forEach(function (L) {
      var cx = +L.cx, cy = +L.cy, w = +L.w, h = +L.h, k, q;
      if (!(w >= 20 && h >= 20)) return;
      if (bottomRimShare(d, W, H, L) < 0.6) return;                            /* d17.84: no rim along the bottom (supra / rimless) */
      var r0 = 0.3 * Math.min(w, h) / 2, nR = Math.ceil((0.8 * Math.max(w, h) - r0) / 0.25), rin = [], tk = [];
      var a = new Float32Array(nR);
      for (k = 0; k < 360; k++) {
        rin[k] = NaN; tk[k] = NaN;
        var th = (k - 180) * Math.PI / 180, co = Math.cos(th), si = Math.sin(th), first = -1;
        for (q = 0; q < nR; q++) {
          var rr = r0 + q * 0.25, fx = cx + rr * co, fy = cy + rr * si;
          if (fx >= 0 && fx < W - 1 && fy >= 0 && fy < H - 1) {
            var ix = Math.floor(fx), iy = Math.floor(fy), ux = fx - ix, uy = fy - iy, o = iy * W + ix;
            a[q] = al[o] * (1 - ux) * (1 - uy) + al[o + 1] * ux * (1 - uy) + al[o + W] * (1 - ux) * uy + al[o + W + 1] * ux * uy;
          } else a[q] = 0;
          if (first < 0 && a[q] > 127.5) first = q;
        }
        if (first < 0) continue;
        /* d17.82: every run along the ray; the RIM is the outermost one starting where the opening's own outline is,
           so a nose pad seen inside the lens is never read as the rim */
        var runs = [], st0 = first, j, gap;
        while (st0 >= 0) {
          j = st0; gap = 0;
          while (j < nR) { if (a[j] > 127.5) gap = 0; else { gap++; if (gap > 8) { j -= gap - 1; break; } } j++; }
          runs.push([st0, j]);
          var nx = -1; for (q = j; q < nR; q++) if (a[q] > 127.5) { nx = q; break; }
          st0 = nx;
        }
        var re_ = 1 / Math.sqrt(Math.pow(co / (w / 2), 2) + Math.pow(si / (h / 2), 2)), pick = runs[0];
        for (q = 0; q < runs.length; q++) { var rs = r0 + runs[q][0] * 0.25; if (rs >= 0.85 * re_ && rs <= 1.15 * re_) pick = runs[q]; }
        first = pick[0]; j = pick[1];
        var cross = function (p, qq) {
          if (p < 0 || qq >= nR || a[p] === a[qq]) return r0 + Math.min(Math.max(qq, 0), nR - 1) * 0.25;
          return r0 + p * 0.25 + (127.5 - a[p]) / (a[qq] - a[p]) * 0.25;
        };
        var eIn = cross(first - 1, first), eOut = j < nR ? cross(j - 1, j) : r0 + (nR - 1) * 0.25;
        rin[k] = eIn; tk[k] = Math.max(0, eOut - eIn);
      }
      var tops = [];
      for (k = 45; k <= 135; k++) if (!isNaN(tk[k])) tops.push(tk[k]);          /* -135..-45 degrees: the top of the lens */
      if (tops.length < 20) return;
      var T = med(tops);
      if (!(T >= 1.5 && T <= 0.12 * Math.min(w, h))) return;
      var mid = [], wt = [];
      for (k = 0; k < 360; k++) {
        mid[k] = NaN; wt[k] = 0; if (isNaN(rin[k])) continue;
        var t = tk[k];
        if (t >= 0.6 * T && t <= 1.5 * T) { mid[k] = rin[k] + t / 2; wt[k] = 1; }
        else if (t > 1.5 * T) { mid[k] = rin[k] + T / 2; wt[k] = 0.7; }      /* shadow outside: the inner edge is right */
        else { mid[k] = rin[k] + T / 2; wt[k] = 0.25; }                       /* bitten: a guess */
      }
      var NA = 171, sm = new Array(NA), rob = [], it, nn;
      for (k = 0; k < 360; k++) rob[k] = 1;
      var interpA = function (arr, x) {                                     /* arr over 5..175 degrees, ends held */
        if (x <= 5) return arr[0]; if (x >= 175) return arr[NA - 1];
        var f = x - 5, i0 = Math.floor(f), u = f - i0; return arr[i0] * (1 - u) + arr[Math.min(NA - 1, i0 + 1)] * u;
      };
      for (it = 0; it < 4; it++) {
        for (nn = 0; nn < NA; nn++) {
          var thc = 5 + nn, s0 = 0, s1 = 0, s2 = 0, s3 = 0, s4 = 0, t0 = 0, t1 = 0, t2 = 0, cnt = 0;
          for (k = 0; k < 360; k++) {
            var dd = (k - 180) - thc; if (Math.abs(dd) > SPAN || isNaN(mid[k]) || !(wt[k] > 0)) continue;
            cnt++;
            var uu = Math.abs(dd) / SPAN, ww = Math.pow(1 - uu * uu * uu, 3) * wt[k] * rob[k], X = dd / SPAN, Y = mid[k];
            s0 += ww; s1 += ww * X; s2 += ww * X * X; s3 += ww * X * X * X; s4 += ww * X * X * X * X; t0 += ww * Y; t1 += ww * X * Y; t2 += ww * X * X * Y;
          }
          sm[nn] = NaN;
          if (cnt < 6 || s0 <= 1e-6) continue;
          /* the local curve's value at the centre: solve [s0 s1 s2; s1 s2 s3; s2 s3 s4] c = [t0 t1 t2] for c0 */
          var det = s0 * (s2 * s4 - s3 * s3) - s1 * (s1 * s4 - s3 * s2) + s2 * (s1 * s3 - s2 * s2);
          if (Math.abs(det) < 1e-12) { sm[nn] = t0 / s0; continue; }
          sm[nn] = (t0 * (s2 * s4 - s3 * s3) - s1 * (t1 * s4 - s3 * t2) + s2 * (t1 * s3 - s2 * t2)) / det;
        }
        var okv = sm.filter(function (v) { return !isNaN(v); });
        if (!okv.length) return;
        var fill = med(okv), smf = sm.map(function (v) { return isNaN(v) ? fill : v; }), res = [], band = [];
        for (k = 0; k < 360; k++) { res[k] = mid[k] - interpA(smf, k - 180); if (k - 180 >= 0 && !isNaN(res[k])) band.push(Math.abs(res[k])); }
        var sc = Math.max(0.75, (band.length ? med(band) : 1) * 1.4826);
        for (k = 0; k < 360; k++) { var uv = isNaN(res[k]) ? 9 : Math.abs(res[k]) / (4 * sc); rob[k] = uv < 1 ? (1 - uv * uv) * (1 - uv * uv) : 0; }
      }
      var bad = 0, gx = [], gy = [];
      for (nn = 0; nn < NA; nn++) { if (isNaN(sm[nn])) bad++; else { gx.push(nn); gy.push(sm[nn]); } }
      if (bad > 20 || gx.length < 2) return;
      for (nn = 0; nn < NA; nn++) if (isNaN(sm[nn])) {                       /* holes filled along the curve */
        var pI = -1, nI = -1, m2;
        for (m2 = 0; m2 < gx.length; m2++) { if (gx[m2] < nn) pI = m2; else { nI = m2; break; } }
        sm[nn] = pI < 0 ? gy[nI] : nI < 0 ? gy[pI] : gy[pI] + (gy[nI] - gy[pI]) * (nn - gx[pI]) / (gx[nI] - gx[pI]);
      }
      var smax = Math.max.apply(null, sm), rmx = smax + T * 3.5 + 3;
      var x0 = Math.max(0, Math.trunc(cx - rmx)), x1 = Math.min(W, Math.trunc(cx + rmx) + 1), y0 = Math.max(0, Math.trunc(cy)), y1 = Math.min(H, Math.trunc(cy + rmx) + 1);
      for (var y = y0; y < y1; y++) for (var x = x0; x < x1; x++) {
        var dx = x - cx, dy = y - cy, TH = Math.atan2(dy, dx) * 180 / Math.PI;
        if (TH < 12 || TH > 168) continue;
        var Rr = Math.sqrt(dx * dx + dy * dy), M = interpA(sm, TH), inner = M - T / 2, outer = M + T / 2;
        if (Rr < inner - ((TH >= 30 && TH <= 150) ? 4 : 1) || Rr > outer + 2.5 * T + 2) continue;
        var wg = Math.min(1, Math.max(0, Math.min(TH - 12, 168 - TH) / 18)); wg = 0.5 - 0.5 * Math.cos(Math.PI * wg);
        var cov = Math.min(1, Math.max(0, Math.min(Rr + 0.5, outer) - Math.max(Rr - 0.5, inner)));
        var o4 = (y * W + x) * 4, a0 = d[o4 + 3], na = wg * cov * 255 + (1 - wg) * a0;
        if (cov <= 0 && a0 > 0 && 0.299 * d[o4] + 0.587 * d[o4 + 1] + 0.114 * d[o4 + 2] > 150) continue;   /* light: a clear nose pad, kept */
        var mix = a0 > 0 ? wg * (cov > 0 ? 1 : 0) : 1;
        if (Math.abs(na - a0) > 20) changed++;
        /* d17.84: the frame's own colours -- a pixel that was rim keeps its colour (a tortoise or two-tone rim keeps its
           pattern); a filled gap takes the colour of the nearest rim pixel that was there */
        var tR = R, tG = G, tB = B;
        if (a0 > 200) { tR = d0[o4]; tG = d0[o4 + 1]; tB = d0[o4 + 2]; }
        else if (mix > 0) {
          var found = false, rad;
          for (rad = 1; rad <= Math.ceil(T) + 3 && !found; rad++) {
            for (var oy = -rad; oy <= rad && !found; oy++) for (var ox = -rad; ox <= rad; ox++) {
              if (Math.max(Math.abs(ox), Math.abs(oy)) !== rad) continue;
              var xx2 = x + ox, yy2 = y + oy; if (xx2 < 0 || yy2 < 0 || xx2 >= W || yy2 >= H) continue;
              var q4 = (yy2 * W + xx2) * 4; if (d0[q4 + 3] <= 200) continue;
              var dxq = xx2 - cx, dyq = yy2 - cy, Rq = Math.sqrt(dxq * dxq + dyq * dyq);
              if (Rq < inner - 3 || Rq > outer + 3) continue;
              tR = d0[q4]; tG = d0[q4 + 1]; tB = d0[q4 + 2]; found = true; break;
            }
          }
        }
        d[o4] = Math.round(d[o4] * (1 - mix) + tR * mix); d[o4 + 1] = Math.round(d[o4 + 1] * (1 - mix) + tG * mix); d[o4 + 2] = Math.round(d[o4 + 2] * (1 - mix) + tB * mix);
        d[o4 + 3] = Math.max(0, Math.min(255, Math.round(na)));
      }
    });
    return changed;
  }
  /* d17.84 (shop, 8 Oct: "it must work for every frame -- metal, TR, supra, rimless"): does this lens have a rim along
     its bottom? Each ray from the centre over the bottom (4 to 8 o'clock) is checked for a solid, rim-coloured piece
     where the lens outline is. A full rim gives nearly every ray; a supra or rimless lens only has its thin bright edge
     there, and its bottom is then never "healed" or "smoothed" (that would paint a rim the frame does not have). */
  function bottomRimShare(d, W, H, L) {
    var hits = 0, tot = 0;
    for (var th = 40; th <= 140; th += 2) {
      var t = th * Math.PI / 180, co = Math.cos(t), si = Math.sin(t);
      var re = 1 / Math.sqrt(Math.pow(co / (L.w / 2), 2) + Math.pow(si / (L.h / 2), 2)), any = false, inside = false;
      for (var r = 0.88 * re; r < 1.2 * re; r += 0.5) {
        var x = Math.round(L.cx + r * co), y = Math.round(L.cy + r * si);
        if (x < 0 || y < 0 || x >= W || y >= H) continue;
        inside = true;
        var o = (y * W + x) * 4;
        if (d[o + 3] > 100 && 0.3 * d[o] + 0.59 * d[o + 1] + 0.11 * d[o + 2] < 225) { any = true; break; }
      }
      if (inside) { tot++; if (any) hits++; }
    }
    return tot ? hits / tot : 0;
  }
  function healRims(cm, fit) {
    var W = fit.w, H = fit.h; if (!(W > 10 && H > 10)) return;
    var img = cm.getImageData(0, 0, W, H), d = img.data, n = W * H, a = new Uint8Array(n), i;
    var lenses = [fit.near, fit.far].filter(function (L) { return L && L.w > 8 && L.h > 8; });
    if (!lenses.length) return;
    lenses.forEach(function (L) { L._noBottom = bottomRimShare(d, W, H, L) < 0.6; });   /* d17.84: supra / rimless */
    /* d17.77 (shop: "check the entire rim"): the whole ring, except the inner side (nose pads, bridge joint) and the
       outer top (hinge, end piece) -- closing there turned pads into blocks. Glare is removed along the bottom only. */
    var zone = function (x, y, bottomOnly) {
      for (var k = 0; k < lenses.length; k++) {
        var L = lenses[k], O = lenses[1 - k] || L, ex = (x - L.cx) / (L.w / 2), ey = (y - L.cy) / (L.h / 2), q = Math.sqrt(ex * ex + ey * ey);
        if (!(q > 0.97 && q < 1.15)) continue;
        var ux = ex / q, uy = ey / q, inward = O.cx > L.cx ? 1 : -1;
        if (ux * inward > 0.45 || (ux * inward < -0.6 && uy < 0.25)) continue;
        if (L._noBottom && uy > -0.1) continue;                                  /* d17.84: a supra / rimless bottom is left alone */
        if (bottomOnly && uy <= 0.4) continue;
        return true;
      }
      return false;
    };
    var inRing = function (x, y) { return zone(x, y, false); };
    var lum = function (o) { return 0.3 * d[o] + 0.59 * d[o + 1] + 0.11 * d[o + 2]; };
    /* the rim's own colour: the darker half of the solid pixels on the rings (light speckles are glare from the floor) */
    var px = [];
    for (i = 0; i < n; i += 2) { if (d[i * 4 + 3] <= 100) continue; var x = i % W, y = (i - x) / W; if (inRing(x, y)) px.push(i * 4); }
    if (px.length < 20) return;
    px.sort(function (p, q) { return lum(p) - lum(q); });
    var dark = px.slice(0, Math.max(10, px.length >> 1)), mid = dark[dark.length >> 1];
    var R = d[mid], G = d[mid + 1], B = d[mid + 2], rimLum = lum(mid), darkFrame = rimLum < 110;
    /* solid = opaque and (on a dark frame) not a light speckle */
    for (i = 0; i < n; i++) { var o = i * 4; a[i] = d[o + 3] > 30 && (!darkFrame || lum(o) < rimLum + 70) ? 1 : 0; }   /* a faint rim pixel counts too */
    var r = Math.max(2, Math.round(Math.min.apply(null, lenses.map(function (L) { return L.h; })) * 0.035));
    var c = morph(morph(a, W, H, r, true), W, H, r, false), changed = 0;
    for (i = 0; i < n; i++) {
      if (a[i]) {                                                          /* a faint rim pixel BETWEEN solid ones is a crack: made solid */
        var o4 = i * 4; if (d[o4 + 3] >= 250) continue;
        var xa = i % W, ya = (i - xa) / W; if (xa < 1 || ya < 1 || xa >= W - 1 || ya >= H - 1 || !inRing(xa, ya)) continue;
        var nb2 = 0; for (var dy2 = -1; dy2 <= 1; dy2++) for (var dx2 = -1; dx2 <= 1; dx2++) if ((dx2 || dy2) && d[((ya + dy2) * W + xa + dx2) * 4 + 3] > 140) nb2++;
        if (nb2 >= 4) { var al4 = d[o4 + 3] / 255; d[o4] = Math.round(d[o4] * al4 + R * (1 - al4)); d[o4 + 1] = Math.round(d[o4 + 1] * al4 + G * (1 - al4)); d[o4 + 2] = Math.round(d[o4 + 2] * al4 + B * (1 - al4)); d[o4 + 3] = 255; changed++; }
        continue;
      }
      var x2 = i % W, y2 = (i - x2) / W; if (!inRing(x2, y2)) continue;
      var o2 = i * 4;
      if (c[i]) { d[o2] = R; d[o2 + 1] = G; d[o2 + 2] = B; d[o2 + 3] = 255; changed++; }          /* a break in the rim: closed */
      else if (darkFrame && d[o2 + 3] > 0 && zone(x2, y2, true)) { d[o2 + 3] = 0; changed++; }   /* a light speckle beside the bottom rim: glare, gone */
    }
    /* d17.80 (shop: "the shadow at the bottom is very heavy"): the rim's thickness is read at the top of each lens (the
       thinner of the two); along the bottom, a rim thicker than that by a third is the table's shadow -- trimmed */
    var runs = function (L) {
      var tops = [], bots = [];
      for (var x = Math.round(L.cx - L.w * 0.25); x <= Math.round(L.cx + L.w * 0.25); x += 2) {
        if (x < 0 || x >= W) continue;
        var y0 = -1, y1 = -1, y;
        for (y = 0; y < H; y++) if (d[(y * W + x) * 4 + 3] > 100) { y0 = y; break; }
        for (y = H - 1; y >= 0; y--) if (d[(y * W + x) * 4 + 3] > 100) { y1 = y; break; }
        if (y0 < 0 || y1 <= y0 + 3) continue;
        var nt = 0; while (y0 + nt < H && d[((y0 + nt) * W + x) * 4 + 3] > 100) nt++;
        var nb = 0; while (y1 - nb >= 0 && d[((y1 - nb) * W + x) * 4 + 3] > 100) nb++;
        tops.push(nt); bots.push([x, y1, nb]);
      }
      return [tops, bots];
    };
    var refs = [], per = [];
    lenses.forEach(function (L) { var rr = runs(L); per.push(L._noBottom ? [] : rr[1]); if (rr[0].length) { var t = rr[0].slice().sort(function (p, q) { return p - q; }); refs.push(t[t.length >> 1]); } });
    if (refs.length) {
      var rimT = Math.max(2, Math.min.apply(null, refs));
      per.forEach(function (bl) { bl.forEach(function (b) {
        if (b[2] > rimT * 1.35) { var cutN = Math.round(b[2] - rimT * 1.1);
          for (var yy = b[1] - cutN + 1; yy <= b[1]; yy++) for (var xx = b[0] - 1; xx <= b[0] + 1; xx++) if (xx >= 0 && xx < W && yy >= 0) { d[(yy * W + xx) * 4 + 3] = 0; changed++; } }
      }); });
    }
    try { changed += smoothBottoms(d, W, H, lenses, R, G, B); } catch (e) {}   /* d17.81: bottom rim smooth and even */
    if (changed) cm.putImageData(img, 0, 0);
  }
  /* drawRealTemple: from the near hinge (the near lens's outer top corner in the picture) back to the hair line at the
     top of the ear, with the temple's true thickness and colour, slipping into the hair over its last third. */
  function drawRealTemple(lx, temples, q) {
    var fit = q.fit, s = q.s, cr = Math.cos(q.roll), sr = Math.sin(q.roll);
    var side = q.nearIsRight ? 1 : -1;
    var hxC = fit.near.cx + side * fit.near.w * 0.5, hyC = isNum(q.hingeY) ? q.hingeY : fit.near.cy - fit.near.h * 0.30;   /* hinge in cut-out px: d17.73 where the 30° photo's own arm starts */
    var dx = (hxC - fit.bridge[0]) * (q.sx || s), dy = (hyC - fit.bridge[1]) * s;
    var hx = q.ax + dx * cr - dy * sr, hy = q.ayLine + dx * sr + dy * cr;                             /* hinge in the picture */
    var hair = q.nearIsRight ? (q.face.templeL || q.face.cheekL) : (q.face.templeR || q.face.cheekR);
    var ear = q.nearIsRight ? (q.face.cheekL || q.face.templeL) : (q.face.cheekR || q.face.templeR);
    var endX = hair && isFinite(hair.x) ? hair.x + side * (Math.abs((ear && ear.x != null ? ear.x : hair.x) - hair.x) * 0.5 + 4 * q.perMM) : hx + side * q.templeMM * q.perMM * 0.5;   /* d17.75: 4 mm further */
    var pupil = q.nearIsRight ? q.face.pupilL : q.face.pupilR;
    var endY = pupil && isFinite(pupil.y) ? pupil.y + (q.face.irisPx || 10) * 0.3 : hy;              /* at the top of the ear: eye level */
    var len = Math.hypot(endX - hx, endY - hy); if (len < 8) return null;
    var ang = Math.atan2(endY - hy, endX - hx), drawDir = Math.cos(ang) >= 0 ? 1 : -1;
    var pick = pickTemple(temples, drawDir); if (!pick) return null;
    var thick = isNum(q.armThick) && q.armThick > 0 ? Math.max(2, q.armThick * s) : Math.max(2, (pick.t.thickPx / pick.t.slabH) * fit.near.h * s * 1.25);   /* d17.73: as thick as the arm in the 30° photo */
    lx.save(); lx.translate(hx, hy); lx.rotate(drawDir > 0 ? ang : ang - Math.PI);                  /* never upside down */
    lx.globalAlpha = 0.98; paintTemple(lx, pick, drawDir, len, thick, 0.8); lx.restore();
    return { mirrored: pick.mirror, photos: Array.isArray(temples) ? temples.filter(Boolean).length : 1, drawDir: drawDir, hingeFrom: isNum(q.hingeY) ? '30-degree photo' : 'estimate', thickPx: Math.round(thick * 10) / 10 };
  }
  /* ---------- the guide: how turned is this head? ---------- */
  function headTurn(face) {
    if (!face) return { state: 'no-face', yaw: 0, text: 'I cannot see your face. Hold the phone at eye level.' };
    var y = face.yaw || 0, ay = Math.abs(y);
    if (ay < YAW_MIN) return { state: 'turn-more', yaw: y, text: 'Turn your head a little more, until you can see your ear in the picture\u2019s edge.' };
    if (ay > YAW_MAX) return { state: 'turn-less', yaw: y, text: 'That is too far \u2014 turn back a little so both eyes still show.' };
    return { state: 'ok', yaw: y, text: 'Good \u2014 hold it there.' };
  }

  var ADVICE = {
    'no-face': 'I could not find your face in that photo. Take it again at eye level with good light.',
    'turn-more': 'Your head is not turned enough for a side look. Turn it a little more (about 30\u00b0) and take it again.',
    'turn-less': 'Your head is turned too far. Turn back until both eyes still show, then take it again.',
    'no-ear': 'I could not see your ear on the near side. Tuck your hair back and take it again.',
    'no-view': 'This frame has no 45\u00b0 picture for that side yet.',
    'no-fit': 'This frame\u2019s 45\u00b0 picture cannot be placed (no lens openings found).',
    'tilted': 'Your head is tilted. Keep it level and take it again.'
  };

  function pickView(face, views) {
    if (!face || !views) return null;
    var want = (face.yaw || 0) > 0 ? 'right' : 'left';              /* the near eye is the image-right one when yaw > 0 */
    for (var i = 0; i < views.length; i++) if (views[i] && views[i].fit && views[i].fit.nearSide === want) return views[i];
    return null;
  }

  /* ---------- the placing ----------
     o = { faceImg, face, cutImg, fit, frontRef, sizes:{lens,bridge}, perMM (optional override) } */
  function fit45(o) {
    try {
      var face = o.face, cut = o.cutImg, notes = [];
      if (!face || !o.faceImg) return { error: 'no-face', advice: ADVICE['no-face'] };
      var fit = cut ? fitFor(cut, o.fit) : null;                 /* d17.63: the robot's fit points, or the page's own from the cut-out */
      if (!cut || !fit) return { error: 'no-fit', advice: ADVICE['no-fit'] };
      var spanFix = null; try { spanFix = fixLensSpans(cut, fit, o.frontRef); } catch (e) { spanFix = null; }   /* d17.91 */
      var flat = null; try { flat = flattenPerspective(cut, fit); if (flat) cut = flat.canvas; } catch (e) { flat = null; }   /* d17.92 */
      var yaw = face.yaw || 0, ay = Math.abs(yaw);
      if (ay < YAW_MIN) return { error: 'turn-more', advice: ADVICE['turn-more'], report: { yaw: yaw } };
      if (ay > YAW_MAX) return { error: 'turn-less', advice: ADVICE['turn-less'], report: { yaw: yaw } };
      var roll = face.roll || 0;
      if (Math.abs(roll) > ROLL_MAX) return { error: 'tilted', advice: ADVICE.tilted, report: { yaw: yaw, roll: roll } };

      var temples = Array.isArray(o.temple) ? o.temple.filter(Boolean) : (o.temple ? [o.temple] : []), templeInfo = null;   /* d17.69: one or two side photos */
      var nearIsRight = yaw > 0, sgn = nearIsRight ? 1 : -1;
      var pupilNear = nearIsRight ? face.pupilL : face.pupilR;           /* the engine names pupils by image side: pupilL is the image-RIGHT one */
      var earNear = nearIsRight ? face.templeL : face.templeR;
      if (!pupilNear) return { error: 'no-face', advice: ADVICE['no-face'] };
      if (!earNear) return { error: 'no-ear', advice: ADVICE['no-ear'] };
      var wantSide = nearIsRight ? 'right' : 'left';
      if (fit.nearSide !== wantSide) return { error: 'no-view', advice: ADVICE['no-view'], report: { needs: wantSide, has: fit.nearSide } };

      /* 1. pixels per millimetre ON THIS TURNED FACE */
      var ref = o.frontRef || {}, perMM = 0, perMMsrc = '';
      if (isNum(o.perMM) && o.perMM > 0) { perMM = o.perMM; perMMsrc = 'given'; }
      else if (ref.face && ref.perMM > 0 && ref.face.faceL > 0 && face.faceL > 0) {
        perMM = ref.perMM * (face.faceL / ref.face.faceL); perMMsrc = 'front photo scale x (face length turned / front)';   /* length is not shortened by a turn */
      } else if (face.irisUsed && face.irisPx > 0) {
        var th = Math.asin(clamp(ay / 0.85, 0, 0.95)); perMM = (face.irisPx / Math.max(0.6, Math.cos(th * 0.5))) / IRIS_MM; perMMsrc = 'iris, corrected for the turn (rough)';
        notes.push('no front photo: scale is rough');
      } else if (face.faceL > 0) { perMM = face.faceL / ASSUMED_FACE_LEN_MM; perMMsrc = 'face length, assumed 188 mm (rough)'; notes.push('no front photo: scale is rough'); }
      if (!(perMM > 0)) return { error: 'no-face', advice: ADVICE['no-face'] };

      /* 2. millimetres per pixel of THIS 45 cut-out, from the lens height (a turn does not change heights) */
      var mmpp = 0, mmppSrc = '';
      /* d17.68 (shop: "the frame looks almost double"): the studio photo is taken close, so its NEAR lens is inflated by
         perspective (near 236 px against far 191 px on VG-1015); scaling by the near lens alone drew the whole frame too
         big. The frame's true size is between the two, so the mean of the near and far lens heights is used. */
      var hMean = (fit.near && fit.near.h > 0 && fit.far && fit.far.h > 0) ? (fit.near.h + fit.far.h) / 2 : (fit.near && fit.near.h) || 0;
      if (ref.mmppFront > 0 && ref.lensHpx > 0 && hMean > 0) { mmpp = ref.lensHpx * ref.mmppFront / hMean; mmppSrc = 'front cut-out lens height (mean of near and far)'; }
      else {
        var lensMM = Number(o.sizes && o.sizes.lens) || 52;
        mmpp = (ASSUMED_LENS_H_RATIO * lensMM) / (hMean || fit.near.h); mmppSrc = 'assumed lens height (' + ASSUMED_LENS_H_RATIO + ' x lens width) (rough)'; notes.push('no front cut-out: frame size is rough');
      }
      var s = mmpp * perMM;                                         /* cut-out pixel -> picture pixel */
      /* d17.92 (shop: "the bridge portion"): THE SAME TURN AS THE FACE. The frame's 30° photos are never turned exactly as
         much as the model's head (the right one of VG-1018 was turned well past 30°), so the frame came out squeezed side
         to side and its near lens slid towards the nose. The head's own turn is read from its eyes (their distance apart
         against the front photo); the frame is widened or narrowed so its lens centres sit where they must on that turn:
         half of lens + bridge either side of the nose bridge, seen at the head's angle. Heights are never changed. */
      var kx = 1, kxInfo = null;
      try {
        var rfF = o.frontRef && o.frontRef.face, LB = (Number(o.sizes && o.sizes.lens) || 0) + (Number(o.sizes && o.sizes.bridge) || 0);
        if (rfF && rfF.pd > 0 && o.frontRef.perMM > 0 && face.pd > 0 && LB > 40) {
          var pdF = rfF.pd / o.frontRef.perMM, pdT = face.pd / perMM, cosC = clamp(pdT / pdF, 0.4, 1), sinC = Math.sqrt(1 - cosC * cosC);
          var wantC = (LB / 2 * cosC - 4 * sinC) * perMM, haveC = Math.abs(fit.near.cx - fit.bridge[0]) * s;
          if (haveC > 5) { kx = clamp(wantC / haveC, 0.7, 1.6); kxInfo = { headTurnDeg: Math.round(Math.acos(cosC) * 180 / Math.PI), widen: +kx.toFixed(3) }; }
        }
      } catch (e) { kx = 1; }
      var sx = s * kx;

      /* 3. where: the bridge on the nose midline, the lens line a little below the pupil line (the front's rule) */
      /* d17.55 (shop: "the nose pads have to sit ON the nose"): on a turned face the nose ridge further down sticks out
         towards the far side, so the old average along the nose (168, 6, 197, 195) pulled the bridge off the nose. The
         bridge now sits on the nose ROOT between the eyes (point 6), where the pads rest. */
      var ax = (face.noseSeat && isFinite(face.noseSeat.x) && face.noseSeat.x) || face.noseAxisX || ((pupilNear.x + (nearIsRight ? face.pupilR : face.pupilL).x) / 2);
      var ayLine = pupilNear.y + (ax - pupilNear.x) * Math.tan(roll) + SEAT_DROP_MM * perMM;
      var W = (o.faceImg.naturalWidth || o.faceImg.width) || face.w, H = (o.faceImg.naturalHeight || o.faceImg.height) || face.h;     /* the picture's own size */

      var layer = document.createElement('canvas'); layer.width = W; layer.height = H;
      var lx = layer.getContext('2d'); lx.imageSmoothingEnabled = true; if ('imageSmoothingQuality' in lx) lx.imageSmoothingQuality = 'high';
      /* d17.41 (shop): ONLY THE FRONT AND THE STRAIGHT ARM. Beside the near lens, a 45 photo also shows the far arm seen
         through the glass and the arms' hanging ear tips; on a face those land on the cheek. So, in the cut-out: past the
         near lens's outer edge only the arm's own band (from the top of the lens to just above its middle, where hinges
         sit) is kept, and past the far lens's outer edge nothing (the far arm is behind the head). */
      var cutM = document.createElement('canvas'); cutM.width = fit.w; cutM.height = fit.h;
      var cm = cutM.getContext('2d'); cm.drawImage(cut, 0, 0, fit.w, fit.h);
      /* d17.76 (shop, 7 Oct: "the bottom part of the rim is cut"): a thin metal rim can come out of the robot with small
         breaks, mostly along the bottom. Only along each lens's rim, breaks of a few pixels are closed with the rim's own
         colour; nothing else in the picture is touched. */
      /* d17.82 (shop: "the nose pad is not visible -- compare with the original"): a 30° picture the robot has already
         cleaned (rims healed and smoothed, glass and far temple cleared, nose pads put back from the photo; build 07s on)
         says so in its fit points. The page then does NOT clean it again -- its clean-ups were made for older cut-outs and
         would cut the nose pads away. Only the arm and far-temple stub steps run. */
      var RC = !!fit.robotClean;
      if (!RC) try { healRims(cm, fit); } catch (e) {}
      cm.globalCompositeOperation = 'destination-out';
      var nW = fit.near.w, nH = fit.near.h, fW = fit.far.w;
      var armRight = fit.near.cx > fit.far.cx;                       /* the near lens is on the right of the cut-out: its arm goes right */
      var bandTop = fit.near.cy - nH * 0.56, bandBot = fit.near.cy - nH * 0.04;
      var armYfound = null, armThickFound = null, armRawThick = 0, armDbg = null;
      /* find the arm itself: beside the near lens, the row where the straight arm runs (the median height of what the
         cut-out kept there); then keep only a slim band around it, so a diagonal piece near the hinge goes too */
      try {
        var armSide = fit.near.cx > fit.far.cx ? 1 : -1;
        var nEdge = isNum(fit.near.outerEdge) ? fit.near.outerEdge : fit.near.cx + armSide * nW / 2;   /* d17.91: the frame's real outer side */
        var ax0 = armSide > 0 ? Math.round(nEdge + nW * 0.06) : Math.round(nEdge - nW * 0.06 - nW * 0.6);
        var aw = Math.round(nW * 0.6), ay0 = Math.max(0, Math.round(bandTop)), ah = Math.max(1, Math.round(bandBot - bandTop));
        ax0 = Math.max(0, Math.min(fit.w - 1, ax0)); aw = Math.max(1, Math.min(fit.w - ax0, aw)); ah = Math.min(fit.h - ay0, ah);
        if (aw > 4 && ah > 4) {
          /* d17.54: the arm is the LONGEST straight horizontal run beside the lens -- the row (band of rows) holding the
             most frame pixels; an average was pulled down by the far temple's dark tip and missed the real arm */
          var ad = cm.getImageData(ax0, ay0, aw, ah).data, rowN = new Array(ah).fill(0);
          for (var cyy = 0; cyy < ah; cyy++) for (var cxx = 0; cxx < aw; cxx++) if (ad[(cyy * aw + cxx) * 4 + 3] > 100) rowN[cyy]++;
          var bestY = -1, bestN = 0, win = Math.max(2, Math.round(nH * 0.03));
          for (var r0 = 0; r0 < ah; r0++) { var sN = 0; for (var k = -win; k <= win; k++) { var rr = r0 + k; if (rr >= 0 && rr < ah) sN += rowN[rr]; } if (sN > bestN) { bestN = sN; bestY = r0; } }
          if (bestY >= 0 && bestN > aw * 0.25) {
            var armY = ay0 + bestY, half = Math.max(4, nH * 0.06);
            bandTop = Math.max(bandTop, armY - half); bandBot = Math.min(bandBot, armY + half);
            /* d17.73: the arm's own height and thickness in this 30° photo -- where the real temple is hung, and how thick */
            var peak = rowN[bestY], ta = bestY, tb = bestY;
            while (ta > 0 && rowN[ta - 1] > peak * 0.45) ta--;
            while (tb < ah - 1 && rowN[tb + 1] > peak * 0.45) tb++;
            /* d17.74: it only counts as THE ARM if it really runs back from the hinge -- solid across most of the window at
               that height (an end piece or the rim alone is not an arm) */
            var hh = Math.max(2, Math.round((tb - ta + 1) / 2 + nH * 0.02)), cyA = Math.round((ta + tb) / 2), cov = 0;
            for (var cx2 = 0; cx2 < aw; cx2++) { var hit = false; for (var ry = Math.max(0, cyA - hh); ry <= Math.min(ah - 1, cyA + hh) && !hit; ry++) if (ad[(ry * aw + cx2) * 4 + 3] > 100) hit = true; if (hit) cov++; }
            armDbg = { aw: aw, cov: cov, nW: Math.round(nW), ta: ta, tb: tb, ay0: ay0, ax0: ax0, ncx: Math.round(fit.near.cx), fcx: Math.round(fit.far.cx), fw: fit.w };
            if (aw >= nW * 0.3 && cov >= aw * 0.6) { armYfound = ay0 + (ta + tb + 1) / 2; armThickFound = Math.min(nH * 0.12, tb - ta + 1); armRawThick = tb - ta + 1; }
          }
        }
      } catch (e) {}
      /* d17.74 (shop, 7 Oct: "use the 30 degree photo's own arm -- front and side together, the actual frame"): the near arm
         as photographed in this 30° picture is used whenever it is there -- same photo as the front, so hinge, thickness,
         colour and shine are the frame's own. The 90° photo's arm is only a backup, for a 30° picture with no arm in it. */
      var usePhotoArm = armYfound != null;
      if (!usePhotoArm && temples.length) { bandTop = bandBot = -1; }        /* backup: the 90° arm replaces a missing one */
      /* d17.92: the near arm followed as it really runs, at its real thickness; everything else beside the near lens goes */
      var armTrack = null;
      if (usePhotoArm) try {
        var tdir = armRight ? 1 : -1, tEdge = isNum(fit.near.outerEdge) ? fit.near.outerEdge + tdir * 2 : fit.near.cx + tdir * (nW / 2 + nW * 0.04);
        var xs0 = Math.round(tEdge), tim = cm.getImageData(0, 0, fit.w, fit.h), td = tim.data;
        armTrack = trackArm(td, fit.w, fit.h, xs0, tdir, Math.round(armYfound), armRawThick, Math.round(nW * 0.8));
        if (armTrack) {
          for (var tx = xs0; tx >= 0 && tx < fit.w; tx += tdir) { var trr = armTrack.runs[tx];
            for (var ty = 0; ty < fit.h; ty++) if (!trr || ty < trr[0] - 1 || ty > trr[1] + 1) td[(ty * fit.w + tx) * 4 + 3] = 0; }
          cm.save(); cm.globalCompositeOperation = 'copy'; cm.putImageData(tim, 0, 0); cm.restore();
        }
      } catch (e) { armTrack = null; }
      if (armRight) {
        var xa = isNum(fit.near.outerEdge) ? fit.near.outerEdge + 2 : fit.near.cx + nW / 2 + nW * 0.04;
        if (!armTrack) { cm.fillRect(xa, 0, fit.w - xa, Math.max(0, bandTop)); cm.fillRect(xa, bandBot, fit.w - xa, fit.h - bandBot); }
        var xf = fit.far.cx - fW / 2 - fW * 0.20; if (xf > 0) cm.fillRect(0, 0, xf, fit.h);
      } else {
        var xb = isNum(fit.near.outerEdge) ? fit.near.outerEdge - 2 : fit.near.cx - nW / 2 - nW * 0.04;
        if (!armTrack) { cm.fillRect(0, 0, xb, Math.max(0, bandTop)); cm.fillRect(0, bandBot, xb, fit.h - bandBot); }
        var xg = fit.far.cx + fW / 2 + fW * 0.20; if (xg < fit.w) cm.fillRect(xg, 0, fit.w - xg, fit.h);
      }
      /* d17.49 (shop): ONLY THE NEAR ARM. Beside the near lens the 45 photo also shows the far arm's dark tip crossing
         at hinge height; on a face it looked like a black stub on the cheek. The near arm is the same colour as the
         frame's end piece beside it, so in the arm band only pixels of that colour stay. */
      var R0, G0, B0;
      try {
        cm.globalCompositeOperation = 'source-over';
        var armSide2 = fit.near.cx > fit.far.cx ? 1 : -1, edgeX = isNum(fit.near.outerEdge) ? fit.near.outerEdge : fit.near.cx + armSide2 * (nW / 2);
        var y0b = Math.max(0, Math.floor(bandTop)), hb = Math.max(1, Math.min(fit.h, Math.ceil(bandBot)) - y0b);
        /* the frame's own colour: the OUTER SIDE of the near rim at mid-height -- no arm crosses it there (the top rim can
           carry the far temple's dark line seen through the glass, which made the near temple look "foreign" and erased it) */
        var refW = Math.max(3, Math.round(nW * 0.07)), refX0 = Math.round(armSide2 > 0 ? edgeX - refW : edgeX);
        refX0 = Math.max(0, Math.min(fit.w - refW, refX0));
        var refY0 = Math.max(0, Math.round(fit.near.cy - nH * 0.25)), refH = Math.max(2, Math.min(fit.h - refY0, Math.round(nH * 0.5)));
        var rd = cm.getImageData(refX0, refY0, refW, refH).data, rs = [];
        for (var q = 0; q < rd.length; q += 4) if (rd[q + 3] > 160) rs.push([rd[q], rd[q + 1], rd[q + 2]]);
        if (rs.length > 8) {
          var med = function (k) { var a = rs.map(function (c) { return c[k]; }).sort(function (u, v) { return u - v; }); return a[a.length >> 1]; };
          R0 = med(0); G0 = med(1); B0 = med(2);
          var ax0 = armSide2 > 0 ? Math.round(edgeX + nW * 0.03) : 0, aw0 = armSide2 > 0 ? fit.w - ax0 : Math.round(edgeX - nW * 0.03);
          if (aw0 > 2 && !armTrack) {
            var ad = cm.getImageData(ax0, y0b, aw0, hb), dd = ad.data;
            /* d17.91 (VG-1018): the near arm's OWN rows are never touched -- a black hinge plate, a logo or a two-tone arm is a
               different colour from the rim beside it and was erased, leaving the arm cut off from the frame */
            var keepA = armYfound != null ? armYfound - (armThickFound || 0) * 0.75 - 2 : 1e9, keepB = armYfound != null ? armYfound + (armThickFound || 0) * 0.75 + 2 : -1e9;
            for (var q2 = 0; q2 < dd.length; q2 += 4) { if (dd[q2 + 3] < 8) continue;
              var rowY = y0b + Math.floor(q2 / 4 / aw0); if (rowY >= keepA && rowY <= keepB) continue;
              var dist = Math.abs(dd[q2] - R0) + Math.abs(dd[q2 + 1] - G0) + Math.abs(dd[q2 + 2] - B0);
              if (dist > 150) dd[q2 + 3] = 0; }                       /* a different colour beside the near lens: the far arm */
            cm.putImageData(ad, ax0, y0b);
          }
        }
      } catch (e) {}
      /* d17.50 (shop: "when they turn, the far temple is disturbing on the face"): the far temple is also seen THROUGH
         the lenses at 45 -- a dark line across the glass. Inside each lens opening only the nose pads (on the bridge
         side, lower part) are kept; everything else seen through the glass is cleared, so only the near temple shows. */
      if (!RC) try {
        cm.globalCompositeOperation = 'destination-out';
        [fit.near, fit.far].forEach(function (L) {
          if (!L || !L.w || !L.h) return;
          var bridgeSide = (fit.bridge[0] > L.cx) ? 1 : -1;
          var px0 = Math.round(bridgeSide > 0 ? L.cx + L.w * 0.12 : L.cx - L.w * 0.5), pw = Math.round(L.w * 0.38);
          var py0 = Math.round(L.cy - L.h * 0.12), ph = Math.round(L.h * 0.62);
          px0 = Math.max(0, Math.min(fit.w - 1, px0)); pw = Math.max(1, Math.min(fit.w - px0, pw));
          py0 = Math.max(0, Math.min(fit.h - 1, py0)); ph = Math.max(1, Math.min(fit.h - py0, ph));
          var pads = cm.getImageData(px0, py0, pw, ph);
          cm.beginPath(); cm.ellipse(L.cx, L.cy, L.w * 0.47, L.h * 0.47, 0, 0, Math.PI * 2); cm.fill();
          cm.putImageData(pads, px0, py0);
          /* and right under the rims, inside the lens box: anything NOT the frame's own colour (the far temple's dark
             tip runs along the top rim there) goes; the rim itself is the frame's colour and stays */
          if (typeof R0 === 'number') {
            var bx0 = Math.max(0, Math.round(L.cx - L.w / 2)), by0 = Math.max(0, Math.round(L.cy - L.h / 2));
            var bw = Math.max(1, Math.min(fit.w - bx0, Math.round(L.w))), bh = Math.max(1, Math.min(fit.h - by0, Math.round(L.h)));
            var bd = cm.getImageData(bx0, by0, bw, bh), bdd = bd.data;
            for (var yy = 0; yy < bh; yy++) for (var xx = 0; xx < bw; xx++) {
              var gx = bx0 + xx, gy = by0 + yy;
              if (gx >= px0 && gx < px0 + pw && gy >= py0 && gy < py0 + ph) continue;      /* the nose pads */
              var q3 = (yy * bw + xx) * 4; if (bdd[q3 + 3] < 8) continue;
              if (Math.abs(bdd[q3] - R0) + Math.abs(bdd[q3 + 1] - G0) + Math.abs(bdd[q3 + 2] - B0) > 150) bdd[q3 + 3] = 0;
            }
            cm.putImageData(bd, bx0, by0);
          }
        });
        cm.globalCompositeOperation = 'source-over';
      } catch (e) {}
      /* d17.57 (shop) A. THE FAR TEMPLE SEEN THROUGH THE GLASS: a straight bar crossing each lens just under its top rim.
         The robot's lens box is the big opening BELOW that bar, so look from a little above the box: top rim (a long run),
         a thin strip of glass, then the bar (another long run) right on top of the opening -- that lower run goes. */
      if (!RC) try {
        [fit.near, fit.far].forEach(function (L) {
          if (!L || !L.w || !L.h) return;
          var bx = Math.max(0, Math.round(L.cx - L.w / 2)), bw = Math.max(4, Math.min(fit.w - bx, Math.round(L.w)));
          var top = Math.round(L.cy - L.h / 2), by = Math.max(0, Math.round(top - L.h * 0.40)), bh = Math.max(4, Math.min(fit.h - by, Math.round(top + L.h * 0.12) - by));
          var id = cm.getImageData(bx, by, bw, bh), d = id.data, m0 = Math.round(bw * 0.08), cnt = [];
          for (var y = 0; y < bh; y++) { var c = 0; for (var x = m0; x < bw - m0; x++) if (d[(y * bw + x) * 4 + 3] > 100) c++; cnt.push(c); }
          /* the opening continues ABOVE its box (side rims still crossing those rows, nothing long across) only when a
             bar splits the lens: then the band at the box's top edge is that bar -- the far temple -- and goes. A normal
             lens has nothing above its top rim (outside the frame), so it is never touched. */
          var innerW = bw - 2 * m0, topRow = top - by;
          var a0 = Math.max(0, Math.round(topRow - L.h * 0.20)), a1 = Math.max(0, Math.round(topRow - L.h * 0.08));
          var above = cnt.slice(a0, a1).sort(function (u, v) { return u - v; }), med = above.length ? above[above.length >> 1] : 0;
          /* or (the narrow far lens): the real top rim a little higher up, with clear glass between it and the bar */
          var rimAbove = false;
          for (var ry = Math.max(0, Math.round(topRow - L.h * 0.38)); ry < Math.max(0, Math.round(topRow - L.h * 0.12)); ry++) {
            if (cnt[ry] >= innerW * 0.45) { var clear = true;
              for (var qy = ry + 3; qy < Math.round(topRow - L.h * 0.07); qy++) if (cnt[qy] > innerW * 0.15) { clear = false; break; }
              if (clear) { rimAbove = true; break; } } }
          if (above.length && ((med >= 6 && med < innerW * 0.3) || rimAbove)) {
            var c0 = Math.max(0, Math.round(topRow - L.h * 0.06)), c1 = Math.min(bh, Math.round(topRow + L.h * 0.10));
            for (var yy = c0; yy < c1; yy++) for (var xx = m0; xx < bw - m0; xx++) d[(yy * bw + xx) * 4 + 3] = 0;
            cm.putImageData(id, bx, by);
          }
        });
      } catch (e) {}
      /* B. THE NEAR TEMPLE RESTS ON THE EAR: it is lifted out of the picture and drawn again turned slightly down about its
         hinge, so that at the ear it is at eye level (the top of the ear) instead of up at the hinge's height. */
      /* d17.75 (shop, 7 Oct: "the centre part is not clean"): whatever shows THROUGH the lenses in the 30° photo -- the far
         arm, its tip, solid glass -- is behind the face on a real head. Each lens opening is cleared inside, keeping a
         margin of 8% so the rim itself is never touched. */
      /* ... and the far arm seen BETWEEN the lenses, under the bridge (behind the nose on a real head): in the gap between
         the two lenses, the bars running across it are found; the top one inside the lens height is the bridge and stays
         (a brow bar above the lenses is not even looked at); a thin bar below it is the far arm and goes. */
      if (!RC) try {
        var F = fit.far, N = fit.near;
        if (F && N && F.w > 8 && N.w > 8) {   /* (d17.80: light glass is cleared only between the bridge and that bar -- the clear nose pads hang lower) */
          var lft = F.cx < N.cx ? F : N, rgt = F.cx < N.cx ? N : F;
          var gx0 = Math.round(lft.cx + lft.w / 2 + 2), gx1 = Math.round(rgt.cx - rgt.w / 2 - 2), gw = gx1 - gx0;
          var top = Math.round(Math.min(F.cy - F.h / 2, N.cy - N.h / 2)), bot = Math.round(Math.max(F.cy, N.cy) + Math.min(F.h, N.h) * 0.1);
          top = Math.max(0, top); bot = Math.min(fit.h, bot);
          if (gw > 6 && bot - top > 6) {
            /* the frame's own darkness, from the near rim; light see-through glass in the gap does not count as a bar */
            var lums = [], nd = cm.getImageData(0, 0, fit.w, fit.h).data;
            for (var ang = 0; ang < 72; ang++) { var tt = ang / 72 * Math.PI * 2;
              for (var rr2 = 1.03; rr2 <= 1.12; rr2 += 0.03) { var px2 = Math.round(N.cx + Math.cos(tt) * N.w / 2 * rr2), py2 = Math.round(N.cy + Math.sin(tt) * N.h / 2 * rr2);
                if (px2 < 0 || py2 < 0 || px2 >= fit.w || py2 >= fit.h) continue; var o4 = (py2 * fit.w + px2) * 4; if (nd[o4 + 3] > 160) lums.push(0.3 * nd[o4] + 0.59 * nd[o4 + 1] + 0.11 * nd[o4 + 2]); } }
            lums.sort(function (p, q) { return p - q; });
            var fLum = lums.length ? lums[lums.length >> 1] : 60, darkFrame = fLum < 130;
            var gd = cm.getImageData(gx0, top, gw, bot - top).data, gr = [], gh = bot - top;
            var isBar = function (o) { return gd[o + 3] > 100 && (!darkFrame || (0.3 * gd[o] + 0.59 * gd[o + 1] + 0.11 * gd[o + 2]) < fLum + 55); };
            for (var gy = 0; gy < gh; gy++) { var gn = 0; for (var gx = 0; gx < gw; gx++) if (isBar((gy * gw + gx) * 4)) gn++; gr.push(gn); }
            var bands = [], inB = false, b0 = 0;
            for (var gy2 = 0; gy2 <= gh; gy2++) { var on = gy2 < gh && gr[gy2] > gw * 0.6; if (on && !inB) { inB = true; b0 = gy2; } else if (!on && inB) { inB = false; bands.push([b0, gy2 - 1]); } }
            var thinMax = Math.min(F.h, N.h) * 0.12;
            bands = bands.filter(function (b) { return (b[1] - b[0] + 1) <= thinMax; });
            if (bands.length >= 2) {
              cm.save(); cm.globalCompositeOperation = 'destination-out';
              var rimT = Math.max(3, Math.round(Math.min(F.h, N.h) * 0.045));            /* keep clear of the two rims */
              for (var bi2 = 1; bi2 < bands.length; bi2++) cm.fillRect(gx0 + rimT, top + bands[bi2][0] - 2, Math.max(0, gw - 2 * rimT), bands[bi2][1] - bands[bi2][0] + 5);
              cm.restore();
              if (darkFrame) {                                    /* the light glass left between the bridge and that arm goes too */
                var cy0 = bands[0][1] + 1, cy1 = Math.min(gh, bands[bands.length - 1][1] + 5), im2 = cm.getImageData(gx0, top + cy0, gw, Math.max(1, cy1 - cy0)), d2 = im2.data;
                for (var q2 = 0; q2 < d2.length; q2 += 4) if (d2[q2 + 3] > 0 && (0.3 * d2[q2] + 0.59 * d2[q2 + 1] + 0.11 * d2[q2 + 2]) >= fLum + 55) d2[q2 + 3] = 0;
                cm.putImageData(im2, gx0, top + cy0);
                /* d17.80: lower down are the clear silicone nose pads -- light, so they are made see-through (as they are) */
                var py0 = top + cy1, ph = Math.max(1, bot - py0 + Math.round(Math.min(F.h, N.h) * 0.25));
                var im3 = cm.getImageData(gx0 - Math.round(gw * 0.3), py0, Math.round(gw * 1.6), Math.min(fit.h - py0, ph)), d3 = im3.data;
                for (var q3 = 0; q3 < d3.length; q3 += 4) if (d3[q3 + 3] > 80 && (0.3 * d3[q3] + 0.59 * d3[q3 + 1] + 0.11 * d3[q3 + 2]) >= fLum + 55) d3[q3 + 3] = 80;
                cm.putImageData(im3, gx0 - Math.round(gw * 0.3), py0);
              }
            }
          }
        }
      } catch (e) {}
      /* d17.77 (shop, 7 Oct: "keep the far temple a little from the hinge, so it looks like it goes back behind the head,
         not cut at the hinge"): the far end piece's height is read, and the first ~7 mm of the far temple behind it is
         kept from the photo -- fading out as it goes behind the face -- although the far lens is cleared inside. */
      var farStub = null;
      /* d17.79 (shop: "don't cut it at the edge -- keep 5 to 6 mm more, then it looks natural"): the far temple keeps
         its first 5.5 mm behind the hinge, fading out; the rest across the demo goes */
      var FAR_STUB_ON = true;
      try {
        var Fs = fit.far, Ns = fit.near;
        if (FAR_STUB_ON && Fs && Ns && Fs.w > 8 && mmpp > 0) {
          var outS = Fs.cx < Ns.cx ? -1 : 1, edgeF = Fs.cx + outS * Fs.w / 2;
          var ex0 = Math.round(outS > 0 ? edgeF + 2 : edgeF - 2 - Fs.w * 0.2), ew = Math.max(2, Math.round(Fs.w * 0.2));
          var ey0 = Math.max(0, Math.round(Fs.cy - Fs.h * 0.6)), eh = Math.max(2, Math.round(Fs.h * 0.7));
          ex0 = Math.max(0, Math.min(fit.w - 2, ex0)); ew = Math.min(fit.w - ex0, ew); eh = Math.min(fit.h - ey0, eh);
          var ed = cm.getImageData(ex0, ey0, ew, eh).data, er = [];
          for (var yy3 = 0; yy3 < eh; yy3++) { var cnt = 0; for (var xx3 = 0; xx3 < ew; xx3++) if (ed[(yy3 * ew + xx3) * 4 + 3] > 100) cnt++; er.push(cnt); }
          var bestT = -1, bestB = -1, curT = -1;
          for (var yy4 = 0; yy4 <= eh; yy4++) { var onr = yy4 < eh && er[yy4] > ew * 0.5;
            if (onr && curT < 0) curT = yy4; else if (!onr && curT >= 0) { if (bestT < 0 || (yy4 - curT) > (bestB - bestT + 1)) { bestT = curT; bestB = yy4 - 1; } curT = -1; } }
          if (bestT >= 0 && (bestB - bestT + 1) <= Fs.h * 0.15) {
            var sT = ey0 + bestT - 2, sH = bestB - bestT + 5, sLen = Math.round(5.5 / mmpp);
            var sX = outS > 0 ? Math.round(edgeF - sLen) : Math.round(edgeF);
            sX = Math.max(0, sX); sLen = Math.min(fit.w - sX, sLen);
            if (sLen > 3 && sH > 2) {
              var snap = document.createElement('canvas'); snap.width = sLen; snap.height = sH;
              var kx = (cut.naturalWidth || cut.width) / fit.w, ky2 = (cut.naturalHeight || cut.height) / fit.h;   /* from the photo's own cut-out, before anything was cleared */
              var sx2 = snap.getContext('2d'); sx2.drawImage(cut, sX * kx, sT * ky2, sLen * kx, sH * ky2, 0, 0, sLen, sH);
              var gF = outS > 0 ? sx2.createLinearGradient(sLen, 0, 0, 0) : sx2.createLinearGradient(0, 0, sLen, 0);
              gF.addColorStop(0, 'rgba(0,0,0,1)'); gF.addColorStop(0.6, 'rgba(0,0,0,1)'); gF.addColorStop(1, 'rgba(0,0,0,0)');
              sx2.globalCompositeOperation = 'destination-in'; sx2.fillStyle = gF; sx2.fillRect(0, 0, sLen, sH);
              farStub = { c: snap, x: sX, y: sT };
            }
          }
        }
      } catch (e) { farStub = null; }
      var gapClear = null;
      var lensClear = null, anyFixed = !!(spanFix && spanFix.fixed);
      if (anyFixed) try { cm.globalCompositeOperation = 'source-over'; lensClear = clearInsideLenses(cm, fit, true); } catch (e) { lensClear = null; }   /* d17.92 */
      if (anyFixed) try { gapClear = clearBridgeGap(cm, fit); } catch (e) { gapClear = null; }
      if (!RC || anyFixed) try {
        cm.save(); cm.globalCompositeOperation = 'destination-out'; cm.fillStyle = '#000';
        [fit.near, fit.far].forEach(function (L) {
          if (!L || !(L.w > 4) || !(L.h > 4)) return;
          if (RC && !L.fixed) return;                 /* d17.91: a robot-cleaned lens is left alone unless the far arm was left across it */
          if (lensClear && lensClear.some(function (c) { return c.lens === (L === fit.near ? 'near' : 'far'); })) return;   /* d17.92: done by its outline */
          /* d17.80 (shop: "where is the nose pad"): the inner side of each lens, from just above the middle to near the
             bottom, is left alone -- the nose pads sit there. The ellipse is cleared except that wedge. */
          var O = L === fit.near ? fit.far : fit.near, inward = O && O.cx > L.cx ? 1 : -1;
          var a0 = Math.atan2(-0.45, 0.89 * inward), a1 = Math.atan2(0.85, 0.53 * inward);   /* the pad wedge, in angles */
          cm.save(); cm.beginPath(); cm.ellipse(L.cx, L.cy, L.w / 2 * 0.92, L.h / 2 * 0.92, 0, 0, Math.PI * 2); cm.clip();
          cm.beginPath(); cm.rect(0, 0, fit.w, fit.h);                                  /* everything... */
          cm.moveTo(L.cx, L.cy);                                                         /* ...minus the pad wedge (outer 30%) */
          var R = Math.max(L.w, L.h);
          var st = inward > 0 ? a0 : a1, en = inward > 0 ? a1 : a0;
          cm.arc(L.cx, L.cy, R, st, en, false); cm.closePath();
          cm.fill('evenodd'); cm.restore();
          /* the centre of the wedge (inner 70%) is still cleared */
          cm.beginPath(); cm.ellipse(L.cx, L.cy, L.w / 2 * 0.92 * 0.7, L.h / 2 * 0.92 * 0.7, 0, 0, Math.PI * 2); cm.fill();
        });
        cm.restore();
      } catch (e) {}
      if (farStub) try { cm.drawImage(farStub.c, farStub.x, farStub.y); } catch (e) {}
      var armCv = null, hinge = null, armTurn = 0, armStretch = 1;
      try {
        var aSide = fit.near.cx > fit.far.cx ? 1 : -1, eX = isNum(fit.near.outerEdge) ? fit.near.outerEdge : fit.near.cx + aSide * (nW / 2);
        var hingeY = (bandTop + bandBot) / 2;
        hinge = [eX, hingeY];
        armCv = document.createElement('canvas'); armCv.width = fit.w; armCv.height = fit.h;
        var ac = armCv.getContext('2d'), x0a = aSide > 0 ? Math.round(eX + nW * 0.02) : 0, wa = aSide > 0 ? fit.w - x0a : Math.round(eX - nW * 0.02);
        if (wa > 2) {
          ac.drawImage(cutM, x0a, 0, wa, fit.h, x0a, 0, wa, fit.h);
          cm.save(); cm.globalCompositeOperation = 'destination-out'; cm.fillRect(x0a, 0, wa, fit.h); cm.restore();
          /* where the hinge lands on the face, and how far down the ear's top is from there */
          var cr0 = Math.cos(roll), sr0 = Math.sin(roll);
          var hdx = (eX - fit.bridge[0]) * sx, hdy = (hingeY - fit.bridge[1]) * s;
          var hFaceX = ax + hdx * cr0 - hdy * sr0, hFaceY = ayLine + hdx * sr0 + hdy * cr0;
          var earX = (nearIsRight ? face.cheekL : face.cheekR) ? (nearIsRight ? face.cheekL : face.cheekR).x : earNear.x;
          var hairP = nearIsRight ? (face.templeL || face.cheekL) : (face.templeR || face.cheekR);
          if (hairP && isFinite(hairP.x)) earX = hairP.x + (nearIsRight ? 1 : -1) * Math.abs(earX - hairP.x) * 0.5;   /* d17.74: the hair line, as the backup arm */
          var run = Math.abs(earX - hFaceX), drop = (pupilNear.y + (face.irisPx || 10) * 0.3) - hFaceY;
          if (run > 10 && drop > 0) armTurn = aSide * Math.atan2(drop, run);
          /* d17.92: the photographed arm reaches the hair line over the ear (4 mm past it), as a real arm does -- a short one
             is drawn longer along its own line; its thickness is never changed */
          if (armTrack && isNum(armTrack.endX)) {
            var hairE = nearIsRight ? (face.templeL || face.cheekL) : (face.templeR || face.cheekR), earE = nearIsRight ? (face.cheekL || face.templeL) : (face.cheekR || face.templeR);
            if (hairE && isFinite(hairE.x)) {
              var wantX = hairE.x + aSide * (Math.abs(((earE && isFinite(earE.x)) ? earE.x : hairE.x) - hairE.x) * 0.5 + 4 * perMM);
              var earFront = (earE && isFinite(earE.x) && Math.abs(earE.x - hFaceX) > Math.abs(hairE.x - hFaceX)) ? earE.x : hairE.x, wantE = earFront + aSide * 4 * perMM;
              if ((wantE - wantX) * aSide > 0) wantX = wantE;
              var have = Math.abs(armTrack.endX - eX) * sx * Math.cos(armTurn), want = Math.abs(wantX - hFaceX);
              if (have > 5 && want > have) armStretch = Math.min(1.5, want / have);
            }
          }
        } else armCv = null;
      } catch (e) { armCv = null; }
      lx.save(); lx.translate(ax, ayLine); lx.rotate(roll); lx.scale(sx, s); lx.translate(-fit.bridge[0], -fit.bridge[1]);
      lx.drawImage(cutM, 0, 0, fit.w, fit.h);
      if (armCv && hinge && (usePhotoArm || !temples.length)) { lx.translate(hinge[0], hinge[1]); lx.rotate(armTurn); lx.scale(armStretch, 1); lx.translate(-hinge[0], -hinge[1]); lx.drawImage(armCv, 0, 0, fit.w, fit.h); }
      lx.restore();
      if (temples.length && !usePhotoArm) try { templeInfo = drawRealTemple(lx, temples, { ax: ax, ayLine: ayLine, roll: roll, s: s, sx: sx, fit: fit, nearIsRight: nearIsRight, face: face, perMM: perMM, templeMM: Number(o.sizes && o.sizes.temple) || 140, yaw: yaw, hingeY: armYfound, armThick: armThickFound }); } catch (e) {}
      if (o.debugMask) o.debugMask.canvas = cutM;

      /* 4. the near arm runs straight back to the EAR (shop, 5 Oct): the ear's front edge is the face point at ear level
         (234 / 454) -- further back than the temple point at eye level, where the arm used to stop. It is not drawn lower
         than that, nor past the ear, nor bent behind it; over the last stretch it slips into the hair. */
      var cheekNear = nearIsRight ? face.cheekL : face.cheekR;
      if (cheekNear && Math.abs(cheekNear.x - pupilNear.x) > Math.abs(earNear.x - pupilNear.x)) earNear = cheekNear;
      var dist = Math.abs(earNear.x - pupilNear.x);
      var f0 = pupilNear.x + sgn * FADE_START * dist, f1 = pupilNear.x + sgn * (FADE_END * dist + 0.04 * (face.faceW || dist));
      if (usePhotoArm || temples.length) {                    /* d17.74: the arm reaches the hair line and slips into the hair over its last fifth */
        var hairN = nearIsRight ? (face.templeL || face.cheekL) : (face.templeR || face.cheekR);
        if (hairN && isFinite(hairN.x)) {
          /* d17.75 (shop: "let it go 3 to 4 mm further, then cut"): 4 mm past the hair line before it fades out */
          var endN = hairN.x + sgn * (Math.abs(earNear.x - hairN.x) * 0.5 + 4 * perMM);
          /* d17.92: never short of the ear -- the arm reaches the ear's front edge and 4 mm on, where it goes over the ear */
          var endE = earNear.x + sgn * 4 * perMM; if ((endE - endN) * sgn > 0) endN = endE;
          var dN = Math.abs(endN - pupilNear.x);
          f0 = pupilNear.x + sgn * dN * 0.86; f1 = pupilNear.x + sgn * dN * 1.0;
        }
      }
      var mask = document.createElement('canvas'); mask.width = W; mask.height = H;
      var mx = mask.getContext('2d'), g = mx.createLinearGradient(f0, 0, f1, 0);
      g.addColorStop(0, 'rgba(0,0,0,1)'); g.addColorStop(1, 'rgba(0,0,0,0)');
      mx.fillStyle = g; mx.fillRect(0, 0, W, H);
      lx.globalCompositeOperation = 'destination-in'; lx.drawImage(mask, 0, 0);

      var out = document.createElement('canvas'); out.width = W; out.height = H;
      var ox = out.getContext('2d'); ox.imageSmoothingEnabled = true; if ('imageSmoothingQuality' in ox) ox.imageSmoothingQuality = 'high';
      ox.drawImage(o.faceImg, 0, 0, W, H); ox.drawImage(layer, 0, 0);

      /* how well does the near lens sit on the near pupil? (a check, not a correction) */
      var cr = Math.cos(roll), sr = Math.sin(roll), dxc = (fit.near.cx - fit.bridge[0]) * sx, dyc = (fit.near.cy - fit.bridge[1]) * s;
      var lensX = ax + dxc * cr - dyc * sr, lensY = ayLine + dxc * sr + dyc * cr;
      var offX = lensX - pupilNear.x, offY = lensY - pupilNear.y;
      var report = {
        engine: VERSION, yaw: +yaw.toFixed(3), yawWindow: [YAW_MIN, YAW_MAX], rollDeg: +(roll * 180 / Math.PI).toFixed(1),
        nearSide: wantSide, lensSpans: spanFix, flattened: flat ? { nearWas: flat.nearWas, farWas: flat.farWas } : null, lensClear: lensClear, gapClear: gapClear, armTrack: armTrack ? { thick: armTrack.thick, cols: armTrack.cols, endX: armTrack.endX, stretch: +armStretch.toFixed(2) } : null, farStub: farStub ? { x: Math.round(farStub.x), y: Math.round(farStub.y), w: farStub.c.width, h: farStub.c.height } : null, armCheck: armDbg, arm: usePhotoArm ? '30-degree photo' : (templeInfo ? '90-degree backup' : 'none'), temple: templeInfo, fitSource: fit.source || '?', perMM: +perMM.toFixed(3), perMMsource: perMMsrc,
        mmPerCutPx: +mmpp.toFixed(4), mmPerCutPxSource: mmppSrc, scale: +s.toFixed(4), sameTurn: kxInfo,
        anchor: { x: Math.round(ax), y: Math.round(ayLine) },
        nearLensVsPupil: { dxPx: Math.round(offX), dyPx: Math.round(offY), dxMM: +(offX / perMM).toFixed(1), dyMM: +(offY / perMM).toFixed(1) },
        earRootDistPx: Math.round(dist), armFadePx: [Math.round(f0), Math.round(f1)], notes: notes
      };
      if (Math.abs(report.nearLensVsPupil.dxMM) > 14) report.notes.push('near lens is far from the near eye: frame size or head turn may be off');
      return { canvas: out, report: report };
    } catch (e) { return { error: 'failed', advice: 'Something went wrong placing the frame.', detail: String(e && e.message || e) }; }
  }

  global.VG45 = { VERSION: VERSION, YAW_MIN: YAW_MIN, YAW_MAX: YAW_MAX, fitPointsFromImage: fitPointsFromImage, usableFit: usableFit, fitFor: fitFor,
                  perMMFromFace: perMMFromFace, frontReference: frontReference, templeStrip: templeStrip, templeUrls: templeUrls, loadTemples: loadTemples, pickTemple: pickTemple, paintTemple: paintTemple, headTurn: headTurn, pickView: pickView, fit45: fit45, ADVICE: ADVICE, hullFit: hullFit, _lensGroups: lensGroups, _pixelsOf: pixelsOf };
})(typeof window !== 'undefined' ? window : this);

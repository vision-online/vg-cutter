/* pe-pro.js -- d17.86 (shop, 8 Oct: "make the edit page professional"). The product edit page, laid out clean:
   a header with the frame's photo, name and status; six short sections that open with a tap (Basics, Price & stock,
   Size, Look, Photos & try-on, Shop only); one-line help with the rest behind a small (i); the common colours first and
   the rest under "More colours"; SAVE and CANCEL always at the bottom of the screen. Nothing about what is saved changes:
   every box, button and id is the same one as before -- this file only moves them into place and styles them. */
(function () {
  'use strict';
  var CSS = [
    '#prodEdit.pp .pe-card{max-width:820px;padding:0;border:0;border-radius:16px;background:#F4F7FB;overflow:clip;box-shadow:0 20px 60px rgba(14,24,38,.35);margin:16px auto 90px}',
    '@media(max-width:640px){#prodEdit.pp{padding:0}#prodEdit.pp .pe-card{margin:0;border-radius:0;min-height:100vh}}',
    '#prodEdit.pp .pe-card>h3{display:none}',
    '.pp-head{position:sticky;top:0;z-index:5;display:flex;gap:12px;align-items:center;padding:12px 16px;background:#0E1826;color:#fff}',
    '.pp-head img{width:76px;height:52px;object-fit:contain;background:#fff;border-radius:8px;flex:none}',
    '.pp-head .pp-t{flex:1;min-width:0}',
    '.pp-head b{display:block;font-size:1.02rem;letter-spacing:.02em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.pp-head small{opacity:.75;font-size:.72rem}',
    '.pp-chip{display:inline-block;font-size:.62rem;font-weight:700;letter-spacing:.08em;padding:3px 8px;border-radius:999px;margin-right:6px;vertical-align:1px}',
    '.pp-chip.live{background:#2E7D53}.pp-chip.check{background:#B8862B}.pp-chip.draft{background:#5B6675}.pp-chip.off{background:#B3452E}',
    '.pp-x{background:none;border:1px solid rgba(255,255,255,.35);color:#fff;border-radius:10px;width:36px;height:36px;font-size:1.1rem;cursor:pointer;flex:none}',
    '.pp-body{padding:12px 14px 4px}',
    '.pp-sec{background:#fff;border:1px solid #D9E3EF;border-radius:14px;margin:0 0 12px;overflow:hidden}',
    '.pp-sec>summary{list-style:none;cursor:pointer;display:flex;align-items:center;gap:10px;padding:14px 16px;font-weight:600;font-size:.95rem;color:#172333;white-space:nowrap}',
    '.pp-sec>summary::-webkit-details-marker{display:none}',
    '.pp-sec>summary .pp-ic{width:30px;height:30px;border-radius:9px;background:#EAF0F8;color:#1F6FD0;display:grid;place-items:center;font-size:.9rem;flex:none}',
    '.pp-sec>summary .pp-sum{margin-left:auto;font-weight:400;font-size:.74rem;color:#5B6675;text-align:right;max-width:55%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.pp-sec>summary:after{content:"";width:8px;height:8px;border-right:2px solid #5B6675;border-bottom:2px solid #5B6675;transform:rotate(45deg);margin:0 4px 4px 6px;transition:transform .2s;flex:none}',
    '.pp-sec[open]>summary:after{transform:rotate(-135deg);margin-bottom:-4px}',
    '.pp-sec[open]>summary{border-bottom:1px solid #EEF2F7}',
    '.pp-in{padding:6px 16px 16px}',
    '#prodEdit.pp .pe-card h4{font-family:inherit;font-size:.72rem;letter-spacing:.1em;text-transform:uppercase;color:#5B6675;margin:16px 0 6px;font-weight:600}',
    '#prodEdit.pp .pe-l{font-size:.66rem;letter-spacing:.09em;color:#5B6675;margin:12px 0 5px}',
    '#prodEdit.pp .pe-card input[type=text],#prodEdit.pp .pe-card input[type=number],#prodEdit.pp .pe-card select{width:100%;box-sizing:border-box;height:44px;padding:0 12px;border:1px solid #CFD8E3;border-radius:10px;background:#fff;font-size:.95rem;color:#172333}',
    '#prodEdit.pp .pe-card input:focus,#prodEdit.pp .pe-card select:focus{outline:none;border-color:#1F6FD0;box-shadow:0 0 0 3px rgba(31,111,208,.15)}',
    '#prodEdit.pp .pe-row{display:grid;grid-template-columns:1fr 1fr;gap:12px}',
    '#prodEdit.pp .pe-row>div:only-child{grid-column:1/-1}',
    '#prodEdit.pp .pe-row3{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}',
    '#prodEdit.pp .pe-row3 small{font-size:.66rem;color:#5B6675}',
    '@media(max-width:480px){#prodEdit.pp .pe-row{grid-template-columns:1fr}}',
    '#prodEdit.pp .pe-hint{font-size:.78rem;line-height:1.45;color:#5B6675;margin:6px 0}',
    '.pp-more{display:inline;margin-left:4px}.pp-more>summary{display:inline;cursor:pointer;color:#1F6FD0;font-size:.74rem;list-style:none}',
    '.pp-more>summary::-webkit-details-marker{display:none}',
    '.pp-more[open]>summary{display:none}',
    '#prodEdit.pp .tchips,#prodEdit.pp .cchips{display:flex;flex-wrap:wrap;gap:6px;margin:8px 0}',
    '#prodEdit.pp .cchips.pp-few>*:nth-child(n+13){display:none}',
    '.pp-morecol{background:none;border:1px dashed #9FB3CC;color:#1F6FD0;border-radius:999px;padding:6px 12px;font-size:.78rem;cursor:pointer;margin:2px 0 8px}',
    '#prodEdit.pp .btn{border-radius:10px}',
    '#prodEdit.pp .pe-btns{position:sticky;bottom:0;z-index:5;margin:0;padding:12px 16px;background:#fff;border-top:1px solid #D9E3EF;display:flex;gap:10px;justify-content:flex-end;box-shadow:0 -6px 18px rgba(14,24,38,.06)}',
    '#prodEdit.pp .pe-btns .btn{min-width:130px;height:46px}',
    '#prodEdit.pp #peSave{background:#1F6FD0;border-color:#1F6FD0;color:#fff}',
    '@media(max-width:640px){#prodEdit.pp .pe-btns .btn{flex:1}}',
    '#prodEdit.pp .pe-draftnote{margin:12px 14px 0;background:#FFF8E8;border:1px solid #F0D9A6;border-radius:12px;padding:12px}',
    '#prodEdit.pp .pe-chk,#prodEdit.pp .ai-opt{display:flex;gap:10px;align-items:flex-start;background:#F4F7FB;border:1px solid #E3EAF3;border-radius:10px;padding:10px 12px;margin:10px 0}',
    '#prodEdit.pp .pe-try{display:flex;gap:12px;align-items:center;background:#F4F7FB;border-radius:12px;padding:10px}',
    '#prodEdit.pp .pe-try img{width:140px;border-radius:8px;background:#fff}',
    '#prodEdit.pp .pe-side2{border:1px dashed #CFD8E3;border-radius:12px;padding:12px;margin:10px 0}',
    '.pp-chosen{font-size:.8rem;color:#172333;margin:2px 0 8px}.pp-chosen b{font-weight:600}',
    '.pp-link{background:none;border:0;color:#1F6FD0;font-size:.78rem;cursor:pointer;padding:0;margin-left:8px;text-decoration:underline}',
    '.pp-tick{display:flex;gap:10px;align-items:center;background:#F4F7FB;border:1px solid #E3EAF3;border-radius:10px;padding:10px 12px;margin:10px 0;font-size:.85rem;cursor:pointer}',
    '.pp-tick input{width:18px;height:18px}',
    '#prodEdit.pp .req-msg{display:block;color:#B3452E;font-size:.74rem;margin:4px 0}',
    '#prodEdit.pp .pe-gal{display:flex;gap:8px;flex-wrap:wrap}'
  ].join('\n');

  var SECTIONS = [
    { k: 'basic', t: 'Basics', ic: '☰', open: true },
    { k: 'price', t: 'Price & stock', ic: '₹', open: true },
    { k: 'size', t: 'Size', ic: '↔' },
    { k: 'look', t: 'Look', ic: '◐' },
    { k: 'photo', t: 'Photos & try-on', ic: '▣' },
    { k: 'shop', t: 'Shop only', ic: '⌂' }
  ];
  var built = false;
  function $(id) { return document.getElementById(id); }
  function top(card, el) { while (el && el.parentElement !== card) el = el.parentElement; return el; }

  function build() {
    var wrap = $('prodEdit'); if (!wrap || built) return;
    var card = wrap.querySelector('.pe-card'); if (!card) return;
    built = true;
    var st = document.createElement('style'); st.textContent = CSS; document.head.appendChild(st);
    wrap.classList.add('pp');
    var kids = Array.prototype.slice.call(card.children);
    /* which section each piece goes to: by its own box ids, and the headings it sits under */
    var by = function (id) { var e = $(id); return e ? top(card, e) : null; };
    var place = new Map();
    function put(el, k) { if (el && !place.has(el)) place.set(el, k); }
    ['peName', 'peTags'].forEach(function (id) { put(by(id), 'basic'); });
    kids.forEach(function (el, i) {
      if (el.tagName === 'LABEL' && el.classList.contains('pe-l') && kids[i + 1] && (kids[i + 1].id === 'peName' || kids[i + 1].id === 'peTags')) put(el, 'basic');
      if (el.classList && el.classList.contains('tchips')) put(el, 'basic');
    });
    ['peCat', 'peOffer', 'peFor', 'peSub'].forEach(function (id) { put(by(id), 'basic'); });
    ['peBrand', 'peModel'].forEach(function (id) { put(by(id), 'basic'); });
    ['peSku', 'peLoc'].forEach(function (id) { put(by(id), 'shop'); });
    ['pePrice', 'peQty', 'peStock'].forEach(function (id) { put(by(id), 'price'); });
    ['peLens', 'peRead', 'peReadBtn', 'peReadOut', 'peSizeFile', 'peReadSize', 'peSizeState'].forEach(function (id) { put(by(id), 'size'); });
    ['peColour', 'cchipsTopPe', 'peShape', 'peShapeState', 'peRim', 'cchipsBotPe', 'peLensCol'].forEach(function (id) { put(by(id), 'look'); });
    ['peGallery', 'peAddPhoto', 'peExtraFiles', 'peSideWhy', 'peTryState', 'peTryBox', 'peSide2Box', 'peTryOn'].forEach(function (id) { put(by(id), 'photo'); });
    /* the rest follows the piece before it (its heading, its hint) */
    var cur = 'basic', keepTop = { peDraftNote: 1, peId: 1 };
    kids.forEach(function (el) {
      if (el.tagName === 'H3' || keepTop[el.id] || el.classList.contains('pe-btns')) return;
      if (place.has(el)) { cur = place.get(el); return; }
      if (el.tagName === 'H4') {                                       /* a heading belongs with what comes after it */
        var nx = el.nextElementSibling;
        while (nx && !place.has(nx) && nx.tagName !== 'H4') nx = nx.nextElementSibling;
        if (nx && place.has(nx)) { cur = place.get(nx); place.set(el, cur); return; }
      }
      place.set(el, cur);
    });
    /* the stock warning, rim and second colour: their own sections */
    var low = by('peLow'); if (low) place.set(low, 'price');
    /* build the sections */
    var head = document.createElement('div'); head.className = 'pp-head';
    head.innerHTML = '<img id="ppThumb" alt=""><div class="pp-t"><b id="ppName">Frame</b><small id="ppSub"></small></div><button type="button" class="pp-x" id="ppClose" aria-label="Close">✕</button>';
    card.insertBefore(head, card.firstChild);
    var body = document.createElement('div'); body.className = 'pp-body';
    var secs = {};
    SECTIONS.forEach(function (s) {
      var d = document.createElement('details'); d.className = 'pp-sec'; d.dataset.k = s.k; if (s.open) d.open = true;
      d.innerHTML = '<summary><span class="pp-ic">' + s.ic + '</span>' + s.t + '<span class="pp-sum" data-sum="' + s.k + '"></span></summary><div class="pp-in"></div>';
      secs[s.k] = d.querySelector('.pp-in'); body.appendChild(d);
    });
    kids.forEach(function (el) { var k = place.get(el); if (k && secs[k]) secs[k].appendChild(el); });
    var btns = card.querySelector('.pe-btns');
    var note = $('peDraftNote');
    if (note) card.insertBefore(note, head.nextSibling);
    card.insertBefore(body, btns || null);
    if (btns) card.appendChild(btns);
    /* headings that only repeat the section's own name go */
    card.querySelectorAll('.pp-in > h4').forEach(function (h) {
      var t = (h.textContent || '').trim().toLowerCase();
      if (/^(size|stock|photos|frame measurements|description)$/.test(t)) h.style.display = 'none';
    });
    /* the duplicate size explanation: the stamp is explained once */
    var szHelp = $('peSizeFile') && $('peSizeFile').previousElementSibling;
    if (szHelp && szHelp.classList.contains('pe-hint')) szHelp.style.display = 'none';
    /* clearer labels */
    var lab = function (id, txt) { var e = $(id); var l = e && e.parentElement && e.parentElement.querySelector('.pe-l'); if (l) l.innerHTML = txt; };
    lab('peSku', 'Shop code <small>e.g. VF-2043 C3</small>');
    lab('peModel', 'Model number <small>on the arm</small>');
    /* long help: the first sentence shows, the rest behind (i) */
    card.querySelectorAll('.pe-hint, .cchips-hint').forEach(function (p) {
      if (p.id || p.querySelector('input,button,select')) return;
      var txt = p.textContent.replace(/\s+/g, ' ').trim();
      if (txt.length < 110) return;
      var html = p.innerHTML, m = txt.match(/^(.{40,140}?[.:—])\s/);
      if (!m) return;
      var first = m[1];
      p.innerHTML = '';
      var lead = document.createElement('span'); lead.textContent = first + ' ';
      var more = document.createElement('details'); more.className = 'pp-more';
      more.innerHTML = '<summary>ⓘ more</summary>';
      var full = document.createElement('span'); full.innerHTML = html; more.appendChild(full);
      p.appendChild(lead); p.appendChild(more);
      more.addEventListener('toggle', function () { if (more.open) lead.style.display = 'none'; });
    });
    /* colours: the common twelve first, the rest a tap away */
    ['cchipsTopPe', 'cchipsBotPe'].forEach(function (id) {
      var c = $(id); if (!c) return;
      c.classList.add('pp-few');
      var b = document.createElement('button'); b.type = 'button'; b.className = 'pp-morecol'; b.textContent = 'More colours ▾';
      b.onclick = function () { var few = c.classList.toggle('pp-few'); b.textContent = few ? 'More colours ▾' : 'Fewer colours ▴'; };
      c.parentElement.insertBefore(b, c.nextSibling);
    });

    /* d17.86 (shop, 8 Oct): COLOUR is the buttons only -- the typed box only behind "other colour"; the second colour only for
       a two-tone frame; lens colour and finish only for sunglasses */
    var col = $('peColour'), topc = $('cchipsTopPe');
    if (col && topc) {
      col.parentElement.style.display = 'none';
      var ch0 = topc.previousElementSibling;                                   /* the long colour note becomes a plain label */
      if (ch0 && ch0.classList.contains('cchips-hint')) { ch0.className = 'pe-l'; ch0.textContent = 'Colour'; }
      var mat = $('peMaterial'); if (mat) mat.parentElement.style.gridColumn = '1/-1';
      var chosen = document.createElement('div'); chosen.className = 'pp-chosen'; chosen.id = 'ppColChosen';
      var anchor = topc.nextElementSibling && topc.nextElementSibling.classList.contains('pp-morecol') ? topc.nextElementSibling : topc;
      anchor.parentElement.insertBefore(chosen, anchor.nextSibling);
      var typed = document.createElement('input'); typed.type = 'text'; typed.id = 'ppColTyped'; typed.placeholder = 'Type the colour, e.g. Matte black'; typed.style.display = 'none';
      typed.addEventListener('input', function () { col.value = typed.value; col.dispatchEvent(new Event('input', { bubbles: true })); });
      chosen.parentElement.insertBefore(typed, chosen.nextSibling);
      var two = document.createElement('label'); two.className = 'pp-tick'; two.innerHTML = '<input type="checkbox" id="ppTwoTone"> <span><b>Two-tone frame</b> &mdash; the bottom is a different colour</span>';
      typed.parentElement.insertBefore(two, typed.nextSibling);
      var bot = $('cchipsBotPe'), c2 = $('peColour2');
      if (bot) {
        var bh = bot.previousElementSibling, bm = bot.nextElementSibling;
        var after = two;
        [bh && bh.classList.contains('cchips-hint') ? bh : null, bot, bm && bm.classList.contains('pp-morecol') ? bm : null].forEach(function (n) {
          if (n) { after.parentElement.insertBefore(n, after.nextSibling); after = n; n.classList.add('pp-two'); }
        });
      }
      if (c2) { c2.parentElement.style.display = 'none'; var rim = $('peRim'); if (rim) rim.parentElement.style.gridColumn = '1/-1'; }
      $('ppTwoTone').addEventListener('change', function () {
        if (!this.checked && c2) { c2.value = ''; c2.dispatchEvent(new Event('input', { bubbles: true })); }
        look();
      });
      card.addEventListener('click', function (e) { if (e.target.closest && e.target.closest('.cchip')) setTimeout(look, 0); });
    }
    var cat = $('peCat'); if (cat) cat.addEventListener('change', look);
    $('ppClose').onclick = function () { var c = $('peCancel'); if (c) c.click(); };
    /* live summaries on the closed sections */
    card.addEventListener('input', summarise); card.addEventListener('change', summarise);
  }
  function v(id) { var e = $(id); return e ? String(e.value || '').trim() : ''; }
  function summarise() {
    var set = function (k, t) { var e = document.querySelector('[data-sum="' + k + '"]'); if (e) e.textContent = t; };
    var price = v('pePrice'), was = v('peWas'), qty = v('peQty');
    set('price', (price ? '₹' + Number(price).toLocaleString('en-IN') : '') + (was ? ' (was ₹' + Number(was).toLocaleString('en-IN') + ')' : '') + ' · ' + (qty || '1') + ' in stock');
    set('size', [v('peLens'), v('peBridge'), v('peTemple')].every(Boolean) ? v('peLens') + '–' + v('peBridge') + '–' + v('peTemple') : 'not filled');
    set('look', [v('peColour'), v('peMaterial'), v('peShape'), v('peRim')].filter(Boolean).join(' · '));
    set('shop', [v('peSku'), v('peLoc')].filter(Boolean).join(' · '));
    set('basic', [($('peCat') && $('peCat').selectedOptions[0] ? $('peCat').selectedOptions[0].text : ''), v('peFor') || 'Unisex'].filter(Boolean).join(' · '));
    var n = $('ppName'); if (n) n.textContent = v('peName') || 'Frame';
  }
  function look() {
    var col = $('peColour'), ch = $('ppColChosen'), typed = $('ppColTyped');
    if (col && ch) {
      var v = String(col.value || '').trim();
      var onChip = !!document.querySelector('#cchipsTopPe .cchip.on');
      ch.innerHTML = (v ? 'Colour: <b>' + v.replace(/</g, '&lt;') + '</b>' : 'Colour: <b style="color:#B3452E">not chosen</b>') +
        ' <button type="button" class="pp-link" id="ppColOther">' + (v && !onChip ? 'change' : 'other colour') + '</button>';
      $('ppColOther').onclick = function () { typed.style.display = ''; typed.value = col.value; typed.focus(); };
      if (onChip && typed) typed.style.display = 'none';
    }
    var c2 = $('peColour2'), two = $('ppTwoTone');
    if (two) {
      if (c2 && String(c2.value || '').trim()) two.checked = true;
      document.querySelectorAll('#prodEdit .pp-two').forEach(function (n) { n.style.display = two.checked ? '' : 'none'; });
    }
    var lr = $('peLensRow'), cat = $('peCat');
    if (lr) lr.style.display = (cat && cat.value === 'sunglasses') ? '' : 'none';
  }
  function header(id) {
    /* PRODUCTS is the page's own list (a top-level let, not on window) */
    var list = (typeof PRODUCTS !== 'undefined' && PRODUCTS) || window.PRODUCTS || [];
    var p = list.find(function (x) { return x.id === id; }); summarise(); if (!p) return;
    var img = $('ppThumb'); if (img) img.src = p.whiteUrl || p.tryOnUrl || p.cleanUrl || p.url || '';
    var chip = p.draft ? '<span class="pp-chip draft">DRAFT</span>' : p.awaitingCheck || (p.pendingViews || []).length ? '<span class="pp-chip check">TO CHECK</span>'
      : (p.stock === false || Number(p.qty) === 0) ? '<span class="pp-chip off">OFF THE SHOP</span>' : '<span class="pp-chip live">LIVE</span>';
    var sub = $('ppSub'); if (sub) sub.innerHTML = chip + (p.sku ? 'code ' + String(p.sku).replace(/</g, '&lt;') : '');
    var two = $('ppTwoTone'); if (two) two.checked = !!String(p.colour2 || '').trim();
    look();
    var card = document.querySelector('#prodEdit .pe-card'); if (card) card.scrollTop = 0;
    var wrap = $('prodEdit'); if (wrap) wrap.scrollTop = 0;
    summarise();
  }
  function hook() {
    if (typeof window.openProdEdit !== 'function' || window.openProdEdit.__pp) return;
    var orig = window.openProdEdit;
    window.openProdEdit = function (id) { build(); var r = orig.apply(this, arguments); try { header(id); } catch (e) {} return r; };
    window.openProdEdit.__pp = true;
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { hook(); build(); });
  else { hook(); build(); }
  window.VGEditPro = { build: build, header: header, summarise: summarise, look: look };
})();

/* frame-centre.js -- d17.83 (shop, 7 Oct: "the frame is not sitting in the centre ... going towards the right side; all
   the frames have to be uniform and in the centre"). Every FRONT picture of a frame -- the robot's cut-out on white, or
   the shop photo -- is placed on its card by the frame's own middle, the BRIDGE, not by the picture's box: the frame is
   symmetric, so its middle is the line it mirrors about (an arm tip, a shadow or a photo taken off-centre on one side
   no longer pulls it sideways). And every frame is shown at the SAME WIDTH, so the shop page looks even.
   Nothing is re-cut: the picture is only moved and sized on the page. */
(function (global) {
  'use strict';
  var VERSION = 'centre.5';
  var MEM = {};
  var LS = 'vg_centre5:';

  function readLS(k) { try { var v = localStorage.getItem(LS + k); return v ? JSON.parse(v) : null; } catch (e) { return null; } }
  function writeLS(k, v) { try { localStorage.setItem(LS + k, JSON.stringify(v)); } catch (e) {} }

  /* where the frame is in a picture: its mirror line (ax), half its front's width (hw), its top and bottom -- all as
     fractions of the picture's own width / height */
  function measure(im) {
    var nw = im.naturalWidth || im.width, nh = im.naturalHeight || im.height;
    if (!(nw > 20 && nh > 20)) return null;
    var s = Math.min(1, 480 / nw), W = Math.max(20, Math.round(nw * s)), H = Math.max(10, Math.round(nh * s));
    var c = document.createElement('canvas'); c.width = W; c.height = H;
    var x = c.getContext('2d'); x.drawImage(im, 0, 0, W, H);
    var d = x.getImageData(0, 0, W, H).data, n = W * H, ink = new Uint8Array(n), i;
    /* a cut-out (see-through background) or a photo (a sheet behind the frame)? */
    var photo = null, clear = 0, corners = [[0, 0], [W - 1, 0], [0, H - 1], [W - 1, H - 1], [W >> 1, 0], [W >> 1, H - 1]];
    corners.forEach(function (p) { if (d[(p[1] * W + p[0]) * 4 + 3] < 30) clear++; });
    if (clear >= 4) {
      for (i = 0; i < n; i++) ink[i] = d[i * 4 + 3] > 60 ? 1 : 0;
    } else {
      /* a photo: the sheet is the border's colour; the frame is what differs from it clearly */
      var br = [], bg = [], bb = [];
      for (var xx = 0; xx < W; xx += 2) { [0, H - 1].forEach(function (yy) { var o = (yy * W + xx) * 4; br.push(d[o]); bg.push(d[o + 1]); bb.push(d[o + 2]); }); }
      for (var yy2 = 0; yy2 < H; yy2 += 2) { [0, W - 1].forEach(function (x2) { var o = (yy2 * W + x2) * 4; br.push(d[o]); bg.push(d[o + 1]); bb.push(d[o + 2]); }); }
      var med = function (a) { a.sort(function (p, q) { return p - q; }); return a[a.length >> 1]; };
      var R = med(br), G = med(bg), B = med(bb), L0 = 0.3 * R + 0.59 * G + 0.11 * B;
      /* d17.84 (every frame -- silver, gold, coloured, clear): the sheet is judged row by row from the picture's own left
         and right edges (studio light falls off from top to bottom), and the frame is what differs from it -- darker, or
         of another colour */
      var rowBg = [];
      for (var ry = 0; ry < H; ry++) {
        var rr0 = [], gg0 = [], bb0 = [];
        for (var e2 = 0; e2 < 6; e2++) [e2, W - 1 - e2].forEach(function (xq2) { var o = (ry * W + xq2) * 4; rr0.push(d[o]); gg0.push(d[o + 1]); bb0.push(d[o + 2]); });
        rowBg.push([med(rr0), med(gg0), med(bb0)]);
      }
      /* the sheet's colour along the top and the bottom: the card is filled with it around a photo, so no edge shows */
      var rowCol = function (y0, y1) { var r = [], g = [], b2 = []; for (var yy3 = y0; yy3 <= y1; yy3++) for (var x3 = 0; x3 < W; x3 += 3) { var o = (yy3 * W + x3) * 4; r.push(d[o]); g.push(d[o + 1]); b2.push(d[o + 2]); } return 'rgb(' + med(r) + ',' + med(g) + ',' + med(b2) + ')'; };
      /* down the photo's left and right edges: the sheet's colour, top to bottom (it is lit unevenly) */
      var prof = [];
      for (var st = 0; st <= 8; st++) {
        var yc = Math.round(st / 8 * (H - 1)), r1 = [], g1 = [], b1 = [];
        for (var yy4 = Math.max(0, yc - 2); yy4 <= Math.min(H - 1, yc + 2); yy4++) for (var e = 0; e < 4; e++) [e, W - 1 - e].forEach(function (x4) { var o = (yy4 * W + x4) * 4; r1.push(d[o]); g1.push(d[o + 1]); b1.push(d[o + 2]); });
        prof.push('rgb(' + med(r1) + ',' + med(g1) + ',' + med(b1) + ')');
      }
      photo = { prof: prof };
      for (i = 0; i < n; i++) {
        var o4 = i * 4, yq = (i / W) | 0, bgc = rowBg[yq];
        var l = 0.3 * d[o4] + 0.59 * d[o4 + 1] + 0.11 * d[o4 + 2], lb = 0.3 * bgc[0] + 0.59 * bgc[1] + 0.11 * bgc[2];
        var cd = Math.abs(d[o4] - bgc[0]) + Math.abs(d[o4 + 1] - bgc[1]) + Math.abs(d[o4 + 2] - bgc[2]);
        ink[i] = ((lb - l) > 14 || cd > 60) ? 1 : 0;
      }
    }
    var P = new Float32Array(W), y, xq;
    for (y = 0; y < H; y++) for (xq = 0; xq < W; xq++) if (ink[y * W + xq]) P[xq]++;
    var thr = Math.max(1.5, H * 0.006), L = -1, Rr = -1;
    for (xq = 0; xq < W; xq++) if (P[xq] >= thr) { if (L < 0) L = xq; Rr = xq; }
    if (L < 0 || Rr - L < W * 0.15) return null;
    /* the mirror line: where the left and right halves match best */
    var span = Rr - L, D = Math.round(span * 0.48), best = null;
    for (var a2 = L + span * 0.3; a2 <= Rr - span * 0.3; a2 += 0.5) {
      var diff = 0, tot = 0;
      for (var dd = 0; dd <= D; dd++) {
        var pl = sample(P, a2 - dd), pr = sample(P, a2 + dd);
        diff += Math.abs(pl - pr); tot += pl + pr;
      }
      var cost = tot > 0 ? diff / tot : 1;
      if (!best || cost < best.cost) best = { a: a2, cost: cost };
    }
    if (!best || best.cost > 0.55) return null;           /* not a front view (a turned frame does not mirror) */
    var ax = best.a;
    /* the front's half width: as far out as BOTH sides still have frame (a one-sided arm tip does not count) */
    var hw = 0, thr2 = Math.max(1, thr * 0.5);                       /* a clear or thin frame's ends are faint: a lower bar here */
    for (var d2 = 0; d2 <= D + span * 0.1; d2++) {
      if (sample(P, ax - d2) >= thr2 && sample(P, ax + d2) >= thr2) hw = d2;
      else if (d2 > span * 0.3 && sample(P, ax - d2) < thr2 && sample(P, ax + d2) < thr2) break;
    }
    if (hw < span * 0.2) return null;
    var top = -1, bot = -1, x0 = Math.max(0, Math.floor(ax - hw)), x1 = Math.min(W - 1, Math.ceil(ax + hw));
    for (y = 0; y < H; y++) { var cnt = 0; for (xq = x0; xq <= x1; xq++) if (ink[y * W + xq]) cnt++; if (cnt >= 2) { if (top < 0) top = y; bot = y; } }
    if (top < 0) return null;
    return { ax: ax / W, hw: hw / W, top: top / H, bot: (bot + 1) / H, ar: nw / nh, cost: +best.cost.toFixed(3), photo: photo, v: VERSION };
  }
  function sample(P, x) {
    var i = Math.floor(x), f = x - i;
    var a = (i >= 0 && i < P.length) ? P[i] : 0, b = (i + 1 >= 0 && i + 1 < P.length) ? P[i + 1] : 0;
    return a * (1 - f) + b * f;
  }

  function analyse(url) {
    if (!url) return Promise.resolve(null);
    if (MEM[url]) return MEM[url];
    var hit = readLS(url);
    if (hit && hit.v === VERSION) return (MEM[url] = Promise.resolve(hit));
    MEM[url] = new Promise(function (res) {
      var im = new Image(); im.crossOrigin = 'anonymous';
      im.onload = function () { var r = null; try { r = measure(im); } catch (e) { r = null; } if (r) writeLS(url, r); res(r); };
      im.onerror = function () { res(null); };
      im.src = url;
    });
    return MEM[url];
  }

  /* the transform that puts the bridge in the middle of the picture's box and the front at `fill` of its width */
  function transformFor(img, r, o) {
    var cs = getComputedStyle(img), elW = img.clientWidth, elH = img.clientHeight;
    if (!(elW > 10 && elH > 10) || !r) return '';
    var pl = parseFloat(cs.paddingLeft) || 0, pr = parseFloat(cs.paddingRight) || 0, pt = parseFloat(cs.paddingTop) || 0, pb = parseFloat(cs.paddingBottom) || 0;
    var cw = elW - pl - pr, ch = elH - pt - pb;
    var cover = cs.objectFit === 'cover';
    var dispW = cover ? Math.max(cw, ch * r.ar) : Math.min(cw, ch * r.ar), dispH = dispW / r.ar;   /* object-fit: contain or cover */
    var fill = o.fill || 0.84, k = (fill * elW) / (2 * r.hw * dispW);
    var fh = (r.bot - r.top) * dispH;
    if (fh * k > (o.maxH || 0.74) * elH) k = (o.maxH || 0.74) * elH / fh;   /* a deep frame: limited by the height */
    k = Math.max(0.4, Math.min(3.5, k));
    var fx = (r.ax - 0.5) * dispW, fy = ((r.top + r.bot) / 2 - 0.5) * dispH;
    var tx = -fx * k, ty = -fy * k + (o.down || 0) * elH;
    var t = 'translate(' + tx.toFixed(1) + 'px,' + ty.toFixed(1) + 'px) scale(' + k.toFixed(3) + ')';
    return o.geo ? { t: t, elH: elH, dispH: dispH, k: k, ty: ty } : t;
  }
  /* a gradient with the photo's sheet colours placed where the photo's rows are: from `top` px over `h` px of a box `H` high */
  function sheetGrad(prof, top, h, H) {
    return 'linear-gradient(' + prof.map(function (c, i) { return c + ' ' + ((top + i / (prof.length - 1) * h) / H * 100).toFixed(1) + '%'; }).join(',') + ')';
  }

  var LIVE = [];
  /* img: a front picture; url: what to measure (the same file it shows); o: {fill, maxH, down, isFront: fn} */
  function apply(img, url, o) {
    o = o || {};
    if (!img || !url) return Promise.resolve(null);
    return analyse(url).then(function (r) {
      if (!r) { if (o.fallback) try { o.fallback(img); } catch (e) {} return null; }
      if (o.isFront && !o.isFront(img)) return null;            /* it has moved on to another view meanwhile */
      img._vgc = { r: r, o: o, url: url };
      if (LIVE.indexOf(img) < 0) LIVE.push(img);
      if (r.photo) img.style.objectFit = 'contain';             /* a photo is shown whole, not cropped to the card */
      var t = transformFor(img, r, o);
      if (!t) return null;
      if (r.photo && r.photo.prof) {
        /* ... and the card around it takes the sheet's own colours, row by row, so no edge shows */
        var g = transformFor(img, r, Object.assign({}, o, { geo: true }));
        img.style.background = sheetGrad(r.photo.prof, (g.elH - g.dispH) / 2, g.dispH, g.elH);
        if (img.parentElement) img.parentElement.style.background = sheetGrad(r.photo.prof, g.elH / 2 + g.ty - g.k * g.dispH / 2, g.k * g.dispH, g.elH);
      }
      img.style.transform = t;
      img.style.transformOrigin = 'center center';
      var st = img.getAttribute('style') || '';
      /* the card's own "put the front back" memories get this placement too */
      if (img.dataset.cutStyle != null) img.dataset.cutStyle = st;
      if (img.dataset.origStyle != null && (!img.dataset.orig || img.dataset.orig === img.getAttribute('src'))) img.dataset.origStyle = st;
      img.dataset.centred = '1';
      return t;
    });
  }
  var rz = null;
  function reflow() {
    LIVE = LIVE.filter(function (img) { return img.isConnected; });
    LIVE.forEach(function (img) {
      var v = img._vgc; if (!v) return;
      if (v.o.isFront && !v.o.isFront(img)) return;
      apply(img, v.url, v.o);
    });
  }
  if (typeof window !== 'undefined') window.addEventListener('resize', function () { clearTimeout(rz); rz = setTimeout(reflow, 150); });

  /* a picture that is not a centred front (another view, a selfie): the card's own background again */
  function release(img) { if (img && img.parentElement && img.dataset.centred === '1') { img.parentElement.style.background = ''; img.dataset.centred = ''; } }
  global.VGCentre = { VERSION: VERSION, release: release, measure: measure, analyse: analyse, apply: apply, transformFor: transformFor, reflow: reflow };
})(this);

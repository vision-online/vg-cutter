/* Vision Gallery — reading a bank's "money received" UPI SMS (d17.155)

   Used in two places: the website helper that confirms orders when a
   payment SMS arrives (api/upi-sms.js), and Admin -> Settings, where
   you can paste an SMS and see exactly what the robot reads from it.

   It answers only for MONEY COMING IN by UPI. Money sent out, card
   refunds ("will be credited in 48 hours"), OTPs and balance messages
   are ignored on purpose.

   Kotak's wording seen so far (money out):
     "Sent Rs.22726.00 from Kotak Bank AC X4410 to abc@okhdfcbank on
      11-08-26.UPI Ref 622320655843. Not you, https://kotak.com/..."
   The money-in message is the same shape:
     "Received Rs.2800.00 in your Kotak Bank AC X4410 from abc@ybl on
      19-10-26.UPI Ref 622320655843."
   Other common wordings ("Rs 2800 credited to your a/c ... by UPI ...
   from ... Ref No ...") are understood too. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.VGUpiParse = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  var NEVER = /will be credited|reversal|reversed|refund|\botp\b|one time password|collect request|requested? money|balance is|avl\.? bal/i;
  var OUT = /\b(debited|spent|withdrawn|paid to|sent|transferred to)\b/i;
  var IN = /\b(received|credited|deposited)\b/i;
  var STARTS_IN = /^(received\b|rs\.?\s*[0-9][0-9,.]*\s+(?:has been\s+|is\s+)?(?:received|credited)|inr\s*[0-9][0-9,.]*\s+(?:has been\s+|is\s+)?(?:received|credited)|(?:your\s+)?(?:a\/c|ac|account)\b[^.]{0,60}\bcredited)/i;
  function amountOf(t) {
    var m = /(?:rs\.?|inr|₹)\s*([0-9][0-9,]*(?:\.[0-9]{1,2})?)/i.exec(t);
    if (!m) return null;
    var n = Number(m[1].replace(/,/g, ''));
    return n > 0 ? Math.round(n * 100) / 100 : null;
  }
  function parse(text) {
    var t = String(text || '').replace(/\s+/g, ' ').trim();
    if (!t) return { ok: false, why: 'empty' };
    if (!IN.test(t)) return { ok: false, why: 'not a money-received message' };
    if (NEVER.test(t)) return { ok: false, why: 'a refund, OTP or request, not a payment' };
    if (/^\s*sent\b/i.test(t) || (OUT.test(t) && !STARTS_IN.test(t))) return { ok: false, why: 'money going out' };
    if (!/\bupi\b|@[a-z]{2,}/i.test(t)) return { ok: false, why: 'not a UPI payment' };
    var amount = amountOf(t);
    if (!amount) return { ok: false, why: 'no amount found' };
    var vpa = (/(?:from|by|frm)\s+(?:vpa\s+)?([a-z0-9._\-]{2,}@[a-z][a-z0-9]{1,})(?![a-z0-9.]*\.[a-z]{2,}\b)/i.exec(t) || [])[1] ||
              (/\b([a-z0-9._\-]{2,}@(?:ok[a-z]+|ybl|ibl|axl|paytm|ptyes|ptaxis|pthdfc|ptsbi|upi|apl|yapl|kotak|kotak811|icici|hdfcbank|sbi|axisbank|axisb|jupiteraxis|fbl|idfcbank|federal|barodampay|rbl|yesbank|airtel|freecharge|waaxis|wahdfcbank|waicici|wasbi|abfspay|naviaxis|superyes|slc|pingpay|timecosmos|dbs|aubank|indus|kbl|cnrb|pnb|boi|unionbank|mahb|citi|hsbc|sc|equitas|jio|ikwik|amazonpay|apay|mbk|zoicici|tapicici|goaxb|yespay|okbizaxis)[a-z0-9]*)\b/i.exec(t) || [])[1] || '';
    var ref = (/(?:upi\s*ref(?:erence)?(?:\s*no)?|ref(?:erence)?\s*(?:no|number|id)?|rrn|utr)\s*[.:#-]?\s*(\d{9,18})/i.exec(t) || [])[1] || '';
    var name = '';
    if (!vpa) { var nm = /\bfrom\s+([A-Za-z][A-Za-z .]{1,40}?)(?:\s+(?:on|via|to|upi|ref|in)\b|[.,]|$)/i.exec(t); if (nm) name = nm[1].trim(); }
    var digits = vpa.replace(/\D/g, '');
    var phone = /^(?:91)?([6-9]\d{9})$/.test(digits) ? digits.slice(-10) : '';
    return { ok: true, amount: amount, vpa: vpa.toLowerCase(), ref: ref, name: name, phone: phone, bank: /kotak/i.test(t) ? 'Kotak' : '' };
  }
  return { parse: parse };
});

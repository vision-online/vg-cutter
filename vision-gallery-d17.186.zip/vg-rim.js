/* Vision Gallery — RIM CHECK ALL ROUND (d17.186, shop 26 Oct: "in the original photo the rim is clearly visible -- measure the
   thickness of the entire rim: top, bottom, sides, front and side views. If the thickness is missing, they cut the rim.
   Very easy to find. And repair it at that particular place, in the same colour.")

   For one try-on picture (FRONT, 30° LEFT or 30° RIGHT) and the ORIGINAL photo it was cut from (the robot keeps the same
   crop beside every cut-out, same size):
     1. the lens openings are found in the cut-out (a small break in the rim is bridged, so a lens is still found);
     2. from the middle of each lens, 360 lines go out, one every degree. On each line the rim is measured twice:
          CUT   = from the lens edge to where the cut-out ends;
          PHOTO = from the lens edge to the frame's own outline in the photo (the last sharp edge of the frame -- a soft
                  shadow under the frame is not frame), plus any frame the cut ate from the lens side;
     3. where the cut is clearly thinner than the photo (less than 85% of it, and 2 px or more) over a stretch of the rim,
        that place is reported: which lens, where (top, bottom, outer side, nose side, corners), photo px and cut px;
     4. REPAIR puts exactly the missing part back FROM THE PHOTO'S OWN PIXELS (same colour, same pattern -- nothing painted),
        only between the cut's edge and the photo's outline, and only where the photo shows frame.
   Lines that cross a bridge, a hinge, an arm or a nose pad (much thicker than the rim) are not counted as rim.
   VGRim.check(cutImage, photoImage, { marks, repair }) -> { measured, ok, lenses, places, thinPct, medRim, marks, repair, added } */
(function (g) {
  'use strict';
  if (g.VGRim) return;
  const NR = 360;
  function data(img, W, H) {
    const c = document.createElement('canvas'); c.width = W; c.height = H;
    const x = c.getContext('2d', { willReadFrequently: true }); x.drawImage(img, 0, 0, W, H);
    return x.getImageData(0, 0, W, H);
  }
  /* the sheet behind the frame, from the photo itself: shrunk 8 times, a median that wipes out anything thin (rims, arms,
     bars), spread back smoothly -- what is left is the sheet with its shading */
  function background(sd, W, H) {
    const sw = Math.max(8, Math.round(W / 8)), sh = Math.max(8, Math.round(H / 8)), sn = sw * sh;
    const sm = new Float32Array(sn * 3), cnt = new Float32Array(sn);
    for (let y = 0; y < H; y++) { const yy = Math.min(sh - 1, Math.floor(y * sh / H));
      for (let x = 0; x < W; x++) { const xx = Math.min(sw - 1, Math.floor(x * sw / W)), q = yy * sw + xx, j = (y * W + x) * 4;
        sm[q * 3] += sd[j]; sm[q * 3 + 1] += sd[j + 1]; sm[q * 3 + 2] += sd[j + 2]; cnt[q]++; } }
    for (let q = 0; q < sn; q++) { const c = cnt[q] || 1; sm[q * 3] /= c; sm[q * 3 + 1] /= c; sm[q * 3 + 2] /= c; }
    const MR = Math.max(4, Math.round(Math.min(sw, sh) * 0.12)), med = new Float32Array(sn * 3), buf = [];
    for (let y = 0; y < sh; y++) for (let x = 0; x < sw; x++) for (let ch = 0; ch < 3; ch++) {
      buf.length = 0;
      for (let dy = -MR; dy <= MR; dy++) { const yy = Math.min(sh - 1, Math.max(0, y + dy));
        for (let dx = -MR; dx <= MR; dx++) { const xx = Math.min(sw - 1, Math.max(0, x + dx)); buf.push(sm[(yy * sw + xx) * 3 + ch]); } }
      buf.sort((a, b) => a - b); med[(y * sw + x) * 3 + ch] = buf[buf.length >> 1];
    }
    const bg = new Float32Array(W * H * 3);
    for (let y = 0; y < H; y++) { const fy = Math.min(sh - 1, Math.max(0, (y + 0.5) * sh / H - 0.5)), y0 = Math.floor(fy), y1 = Math.min(sh - 1, y0 + 1), wy = fy - y0;
      for (let x = 0; x < W; x++) { const fx = Math.min(sw - 1, Math.max(0, (x + 0.5) * sw / W - 0.5)), x0 = Math.floor(fx), x1 = Math.min(sw - 1, x0 + 1), wx = fx - x0, i = (y * W + x) * 3;
        for (let ch = 0; ch < 3; ch++) {
          const a = med[(y0 * sw + x0) * 3 + ch] * (1 - wx) + med[(y0 * sw + x1) * 3 + ch] * wx, b = med[(y1 * sw + x0) * 3 + ch] * (1 - wx) + med[(y1 * sw + x1) * 3 + ch] * wx;
          bg[i + ch] = a * (1 - wy) + b * wy; } } }
    return bg;
  }
  function photoMaps(sd, W, H) {
    const N = W * H, bg = background(sd, W, H), F = new Uint8Array(N), Fs = new Uint8Array(N), Dk = new Uint8Array(N), G = new Float32Array(N), gray = new Float32Array(N);
    for (let i = 0, j = 0; i < N; i++, j += 4) {
      const r = sd[j], gg = sd[j + 1], b = sd[j + 2]; gray[i] = 0.299 * r + 0.587 * gg + 0.114 * b;
      const d = Math.max(Math.abs(r - bg[i * 3]), Math.abs(gg - bg[i * 3 + 1]), Math.abs(b - bg[i * 3 + 2]));
      const bgG = 0.299 * bg[i * 3] + 0.587 * bg[i * 3 + 1] + 0.114 * bg[i * 3 + 2], sat = (Math.max(r, gg, b) - Math.min(r, gg, b)) / 255;
      F[i] = (d > 24 || gray[i] < bgG - 18 || sat > 0.22) ? 1 : 0;
      Fs[i] = (d > 45 || gray[i] < bgG - 35 || sat > 0.3) ? 1 : 0;      /* clearly frame (not the camera's soft halo) */
      Dk[i] = (gray[i] < bgG - 8 || sat > 0.15) ? 1 : 0;                /* darker than the sheet or coloured (a shine is lighter) */
    }
    for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) { const i = y * W + x; G[i] = Math.abs(gray[i + 1] - gray[i - 1]) + Math.abs(gray[i + W] - gray[i - W]); }
    return { F, Fs, Dk, G };
  }
  function dilate(m, W, H, r) {               /* square, separable */
    const N = W * H, t = new Uint8Array(N), o = new Uint8Array(N);
    for (let y = 0; y < H; y++) { let last = -1e9; const row = y * W;
      for (let x = 0; x < W; x++) { if (m[row + x]) last = x; if (x - last <= r) t[row + x] = 1; }
      last = 1e9; for (let x = W - 1; x >= 0; x--) { if (m[row + x]) last = x; if (last - x <= r) t[row + x] = 1; } }
    for (let x = 0; x < W; x++) { let last = -1e9;
      for (let y = 0; y < H; y++) { if (t[y * W + x]) last = y; if (y - last <= r) o[y * W + x] = 1; }
      last = 1e9; for (let y = H - 1; y >= 0; y--) { if (t[y * W + x]) last = y; if (last - y <= r) o[y * W + x] = 1; } }
    return o;
  }
  /* the lens openings: see-through areas closed in by the frame (a break of a few px in the rim is bridged first), with any
     speck inside them counted as lens */
  function lensesOf(op, W, H) {
    const N = W * H, R = Math.max(3, Math.round(Math.max(W, H) / 300)), dil = dilate(op, W, H, R), lab = new Int32Array(N), pieces = [];
    let L = 0; const st = [];
    for (let s = 0; s < N; s++) { if (dil[s] || lab[s]) continue;
      L++; let size = 0, edge = false; lab[s] = L; st.push(s);
      while (st.length) { const q = st.pop(), x = q % W, y = (q - x) / W; size++;
        if (x === 0 || y === 0 || x === W - 1 || y === H - 1) edge = true;
        if (x > 0 && !dil[q - 1] && !lab[q - 1]) { lab[q - 1] = L; st.push(q - 1); }
        if (x < W - 1 && !dil[q + 1] && !lab[q + 1]) { lab[q + 1] = L; st.push(q + 1); }
        if (y > 0 && !dil[q - W] && !lab[q - W]) { lab[q - W] = L; st.push(q - W); }
        if (y < H - 1 && !dil[q + W] && !lab[q + W]) { lab[q + W] = L; st.push(q + W); } }
      if (!edge && size >= N * 0.001) pieces.push(L);
    }
    /* one lens can be split in two by a far arm or a bar seen through it (kept in the cut): two pieces one above the other
       (mostly the same columns) with only a thin band between them are one lens -- the band is counted as lens. Two lenses
       side by side are never joined. */
    let fy0 = H, fy1 = -1; for (let i = 0; i < N; i++) if (op[i]) { const y = (i - i % W) / W; if (y < fy0) fy0 = y; if (y > fy1) fy1 = y; }
    const fh = Math.max(1, fy1 - fy0 + 1), band = Math.max(16, Math.round(fh * 0.35));
    const info = {}; pieces.forEach(l => { info[l] = { l, x0: W, x1: -1, y0: H, y1: -1, top: null, bot: null }; });
    for (let i = 0; i < N; i++) { const pi = info[lab[i]]; if (!pi) continue; const x = i % W, y = (i - x) / W;
      if (x < pi.x0) pi.x0 = x; if (x > pi.x1) pi.x1 = x; if (y < pi.y0) pi.y0 = y; if (y > pi.y1) pi.y1 = y; }
    pieces.forEach(l => { const pi = info[l], w = pi.x1 - pi.x0 + 1; pi.top = new Int32Array(w).fill(H); pi.bot = new Int32Array(w).fill(-1); });
    for (let i = 0; i < N; i++) { const pi = info[lab[i]]; if (!pi) continue; const x = i % W, y = (i - x) / W, c = x - pi.x0;
      if (y < pi.top[c]) pi.top[c] = y; if (y > pi.bot[c]) pi.bot[c] = y; }
    const par = {}; pieces.forEach(l => { par[l] = l; }); const find = l => { while (par[l] !== l) l = par[l] = par[par[l]]; return l; };
    const fills = [];
    for (let i1 = 0; i1 < pieces.length; i1++) for (let i2 = i1 + 1; i2 < pieces.length; i2++) {
      let A = info[pieces[i1]], B = info[pieces[i2]]; if (A.y0 > B.y0) { const t = A; A = B; B = t; }   /* A above */
      const ox0 = Math.max(A.x0, B.x0), ox1 = Math.min(A.x1, B.x1), ov = ox1 - ox0 + 1;
      if (ov < 0.6 * Math.min(A.x1 - A.x0 + 1, B.x1 - B.x0 + 1)) continue;
      const gaps = [];
      for (let x = ox0; x <= ox1; x++) { const ab = A.bot[x - A.x0], bt = B.top[x - B.x0]; if (ab >= 0 && bt < H && bt > ab) gaps.push([x, ab, bt]); }
      if (gaps.length < ov * 0.5) continue;
      const gm = median(gaps.map(gq => gq[2] - gq[1]));
      if (gm > band) continue;
      par[find(A.l)] = find(B.l); fills.push(gaps.filter(gq => gq[2] - gq[1] <= band * 1.5));
    }
    const lab2 = new Int32Array(N), out = [];
    for (let i = 0; i < N; i++) if (info[lab[i]]) lab2[i] = find(lab[i]);
    fills.forEach(gs => gs.forEach(([x, ab, bt]) => { const g0 = lab2[ab * W + x]; for (let y = ab + 1; y < bt; y++) if (!lab2[y * W + x]) lab2[y * W + x] = g0; }));
    const grp = {};
    for (let i = 0; i < N; i++) { const g0 = lab2[i]; if (!g0) continue; const x = i % W, y = (i - x) / W;
      const o = grp[g0] || (grp[g0] = { id: g0, size: 0, own: 0, sx: 0, sy: 0, x0: W, x1: -1, y0: H, y1: -1 });
      o.size++; if (lab[i]) o.own++; o.sx += x; o.sy += y; if (x < o.x0) o.x0 = x; if (x > o.x1) o.x1 = x; if (y < o.y0) o.y0 = y; if (y > o.y1) o.y1 = y; }
    Object.values(grp).forEach(o => {
      if (o.own >= N * 0.003 && (o.y1 - o.y0 + 1) >= fh * 0.3 && o.size / ((o.x1 - o.x0 + 1) * (o.y1 - o.y0 + 1)) >= 0.45)
        out.push({ id: o.id, size: o.size, cx: o.sx / o.size, cy: o.sy / o.size, x0: o.x0, x1: o.x1, y0: o.y0, y1: o.y1 }); });
    out.sort((a, b) => b.size - a.size); out.length = Math.min(out.length, 2);
    /* each lens with everything inside it (specks, a far arm across it) counted as lens */
    out.forEach(ln => {
      const m = new Uint8Array(N); for (let i = 0; i < N; i++) if (lab2[i] === ln.id) m[i] = 1;
      const reach = new Uint8Array(N);
      const seed = q => { if (!m[q] && !reach[q]) { reach[q] = 1; st.push(q); } };
      for (let x = 0; x < W; x++) { seed(x); seed(N - W + x); } for (let y = 0; y < H; y++) { seed(y * W); seed(y * W + W - 1); }
      while (st.length) { const q = st.pop(), x = q % W;
        if (x > 0) seed(q - 1); if (x < W - 1) seed(q + 1); if (q >= W) seed(q - W); if (q < N - W) seed(q + W); }
      for (let i = 0; i < N; i++) if (!reach[i]) m[i] = 1;
      ln.mask = m; ln.grow = R;
    });
    return out;
  }
  function median(a) { if (!a.length) return 0; const b = a.slice().sort((x, y) => x - y); return b[b.length >> 1]; }
  function whereOf(dx, dy) {
    const a = Math.atan2(dy, dx) * 180 / Math.PI;           /* image: y down */
    if (a >= -112.5 && a < -67.5) return 'top';
    if (a >= 67.5 && a < 112.5) return 'bottom';
    if (a >= -22.5 && a < 22.5) return 'R';
    if (a >= 157.5 || a < -157.5) return 'L';
    if (a >= -67.5 && a < -22.5) return 'top R';
    if (a >= -157.5 && a < -112.5) return 'top L';
    if (a >= 22.5 && a < 67.5) return 'bottom R';
    return 'bottom L';
  }
  /* THE TOP OF THE FRAME, column by column (lines from the lens middle cannot reach the top over the bridge, where the rim
     runs into it): in every column over the lenses and the bridge, where the frame's top outline is in the photo and where
     the cut-out starts. A cut-out that starts clearly lower than the photo's outline over 20 px or more has lost the top of
     the rim there (a soft glow above a frame is a weak edge and does not count). */
  function topScan(op, P, W, H, lenses) {
    const res = { places: [], cols: [] };
    if (!lenses.length) return res;
    const x0 = Math.max(0, Math.min(...lenses.map(l => l.x0)) - 4), x1 = Math.min(W - 1, Math.max(...lenses.map(l => l.x1)) + 4);
    const cols = [];
    for (let x = x0; x <= x1; x++) {
      /* where the cut really starts: 3 solid pixels in a row (a loose soft pixel left above an eaten rim is not the rim) */
      let ct = -1; for (let y = 0; y < H - 2; y++) if (op[y * W + x] && op[(y + 1) * W + x] && op[(y + 2) * W + x]) { ct = y; break; }
      if (ct < 0) continue;
      let cb = ct; while (cb < H && op[cb * W + x]) cb++;
      const thick = cb - ct, reach = Math.max(6, Math.round(thick * 1.2) + 4);
      /* the photo's frame joined to the top of the cut, going up */
      const up = M => { let y = ct - 1, last = ct, miss = 0; for (; y >= Math.max(0, ct - reach); y--) { if (M[y * W + x]) { last = y; miss = 0; } else if (++miss > 1) break; } return last; };
      let pt = up(P.Fs); if (pt === ct) pt = up(P.F);
      let gmax = 0; for (let y = pt; y <= Math.min(H - 1, ct + 3); y++) gmax = Math.max(gmax, P.G[y * W + x]);
      if (gmax > 20) for (let y = Math.max(0, pt - 2); y <= ct + 1; y++) if (P.G[y * W + x] >= gmax * 0.5) { pt = Math.min(pt + 2, Math.max(y, pt)); break; }
      cols.push({ x, ct, cb, thick, pt, loss: ct - pt });
    }
    if (cols.length < 10) return res;
    const bias = Math.max(0, median(cols.map(c => c.loss))); res.bias = bias;
    /* the top edge is sharp in both: what counts is how much LOWER the cut starts -- 3 px or more on a fine rim, a fifth of
       the rim on a thick one (over the bridge the frame is tall, so a share of its height would hide a real loss) */
    const mr = median(lenses.map(q => q.medRim || 1)) || 1, need = Math.max(3, 0.15 * mr);
    cols.forEach(c => { const l = c.loss - bias; c.thin = l >= need && c.thick < 0.85 * (Math.min(c.thick, 2 * mr) + l); });
    res.cols = cols;
    /* stretches of thin columns (2 fine columns in between may be fine), 20 px or more */
    let cur = null; const groups = [];
    cols.forEach((c, i) => { if (c.thin) { if (cur && c.x - cur.last <= 3) { cur.cs.push(c); cur.last = c.x; } else { if (cur) groups.push(cur); cur = { cs: [c], last: c.x }; } } });
    if (cur) groups.push(cur);
    groups.filter(gq => gq.cs.length >= 20).forEach(gq => {
      const mx = median(gq.cs.map(c => c.x)), ln = lenses.find(l => mx >= l.x0 && mx <= l.x1);
      res.places.push({ lens: ln ? ln.name : 'bridge', where: 'top', photoPx: median(gq.cs.map(c => c.thick + c.loss - bias)), cutPx: median(gq.cs.map(c => c.thick)), arcPx: gq.cs.length, topCols: gq.cs.map(c => c.x) });
    });
    return res;
  }
  function measure(A, P, W, H) {
    const N = W * H, op = new Uint8Array(N);
    for (let i = 0; i < N; i++) op[i] = A[i] >= 60 ? 1 : 0;          /* a clear (see-through) rim is half solid in the cut: still rim */
    let lenses = lensesOf(op, W, H), helped = false;
    if (lenses.length < 2) {
      /* a lens open to the outside (the rim cut right through): the photo's own clear frame next to the cut closes it, so
         that lens is still measured -- and its break shows as the place where the rim is missing */
      const op2 = new Uint8Array(op), st2 = [];
      for (let i = 0; i < N; i++) if (op[i]) st2.push(i);
      while (st2.length) { const q = st2.pop(), x = q % W;                   /* the photo's clear frame joined to the cut's frame */
        for (const k of [q - 1, q + 1, q - W, q + W]) { if (k < 0 || k >= N || op2[k] || !P.Fs[k]) continue; if (Math.abs((k % W) - x) > 1) continue; op2[k] = 1; st2.push(k); } }
      const l2 = lensesOf(op2, W, H);
      if (l2.length > lenses.length) {
        const own = lenses;                                       /* the lenses the cut closes by itself are not "broken" */
        l2.forEach(l => { const c = Math.round(l.cy) * W + Math.round(l.cx); l.broken = !own.some(o => o.mask[c]); });
        lenses = l2; helped = op2; }
    }
    if (!lenses.length) return { measured: false, reason: 'no closed lens found in the cut-out (a rim may be broken right through)', lenses: [] };
    lenses.sort((a, b) => a.cx - b.cx);
    const midX = lenses.reduce((s, l) => s + l.cx, 0) / lenses.length;
    const at = (x, y) => { const xi = Math.round(x), yi = Math.round(y); return (xi < 0 || yi < 0 || xi >= W || yi >= H) ? -1 : yi * W + xi; };
    const maxLen = Math.hypot(W, H);
    lenses.forEach((ln, li) => {
      ln.name = lenses.length === 1 ? 'lens' : li === 0 ? 'left lens' : li === lenses.length - 1 ? 'right lens' : 'middle lens';
      ln.outerIsLeft = ln.cx < midX || (lenses.length === 1 && ln.cx < W / 2);
      const rays = [];
      for (let k = 0; k < NR; k++) {
        const a = k * Math.PI / 180, dx = Math.cos(a), dy = Math.sin(a), ray = { k, dx, dy, valid: false };
        let t = 0, q;
        while (t < maxLen) { q = at(ln.cx + dx * t, ln.cy + dy * t); if (q < 0 || !ln.mask[q]) break; t++; }
        if (q < 0) { rays.push(ray); continue; }
        const t0 = t; let gap = false;
        while (t < t0 + 2 * ln.grow + 3) { q = at(ln.cx + dx * t, ln.cy + dy * t); if (q < 0 || op[q]) break; t++; }
        if (q < 0) { rays.push(ray); continue; }
        if (!op[q]) {                                             /* the cut has no rim here: start at the photo's own rim */
          gap = true; t = t0 + ln.grow;
          for (let u = t0; u < t0 + 2 * ln.grow + 3; u++) { const qq = at(ln.cx + dx * u, ln.cy + dy * u); if (qq < 0) break; if (helped ? helped[qq] : P.Fs[qq]) { t = u; break; } }
        }
        const rin = t;
        let last = rin - 1, miss = 0;
        for (let u = rin; u < maxLen; u++) { const qq = at(ln.cx + dx * u, ln.cy + dy * u); if (qq < 0) break; if (op[qq]) { last = u; miss = 0; } else if (++miss > 1) break; }
        ray.rin = rin; ray.cutEnd = last + 1; ray.tC = gap ? 0 : last + 1 - rin; ray.gap = gap;
        rays.push(ray);
      }
      const tcs = rays.filter(r => r.rin !== undefined && r.tC > 0).map(r => r.tC);
      ln.medRim = median(tcs);
      const reach = Math.max(8, Math.round(3 * ln.medRim + 10)), inMax = Math.max(3, Math.round(0.6 * ln.medRim)), cap = 2.5 * ln.medRim + 4;
      rays.forEach(r => {
        if (r.rin === undefined) return;
        const pos = u => at(ln.cx + r.dx * u, ln.cy + r.dy * u);
        /* the photo's frame from the lens edge outwards, then its outline: the outermost edge at least half as strong as
           the strongest one on that stretch (the soft edge of a shadow is weak and does not count) */
        /* clearly-frame first (a dark or strongly coloured rim: the camera's halo, a clear nose pad beside the rim or a soft
           shadow do not count); a pale or clear rim that reads thinner than the cut that way is measured the gentler way */
        const runOf = M => { let last = r.rin - 1, miss = 0;
          for (let u = r.rin; u < r.rin + reach; u++) { const q = pos(u); if (q < 0) break; if (M[q]) { last = u; miss = 0; } else if (++miss > 1) break; }
          return last + 1; };
        let pEnd = runOf(P.Fs);
        if (pEnd - r.rin < r.tC) pEnd = runOf(P.F);
        let gmax = 0;
        for (let u = r.rin; u <= pEnd + 2; u++) { const q = pos(u); if (q >= 0 && P.G[q] > gmax) gmax = P.G[q]; }
        let outl = pEnd;
        if (gmax > 20) for (let u = pEnd + 2; u >= r.rin; u--) { const q = pos(u); if (q >= 0 && P.G[q] >= gmax * 0.5) { outl = Math.max(r.rin, Math.min(u, pEnd + 1)); break; } }
        /* frame the cut ate from the lens side: photo frame just inside the cut's lens edge, ending within reach */
        let inn = 0;
        while (inn < inMax) { const q = pos(r.rin - 1 - inn); if (q < 0 || !P.Fs[q] || op[q]) break; inn++; }
        if (inn >= inMax) inn = 0;                                 /* runs on: an arm or a reflection in the lens, not rim */
        r.outl = outl; r.inn = inn; r.tP = outl - r.rin + inn;
        r.valid = r.tP >= 2 && Math.max(r.tP, r.tC) <= cap;
      });
      /* the camera blurs a fine rim a little wider than it is: how much wider the photo reads on THIS lens where the cut is
         fine (most of it) is taken off before comparing, so only a real loss counts */
      const diffs = rays.filter(r => r.valid && r.tC > 0).map(r => r.tP - r.tC);
      ln.bias = Math.max(0, Math.min(0.5 * ln.medRim + 2, median(diffs)));
      /* thin = a real part of the rim is gone: on a fine rim (under 15 px) less than 60% of the photo's is left (the camera's
         blur makes a fine rim read unevenly), on a thick one less than 85% -- and at least 3 px is missing */
      const keep = ln.medRim >= 15 ? 0.85 : 0.6, minLoss = Math.max(3, (ln.medRim >= 15 ? 0.15 : 0.2) * ln.medRim);
      rays.forEach(r => { if (!r.valid) return; const tp = r.tP - ln.bias;
        r.thin = r.tC < keep * tp && (tp - r.tC) >= minLoss; });
      ln.rays = rays;
      /* places: stretches of thin lines round the lens (one line in between may be fine), at least 6 px of rim long */
      const places = [], n = NR;
      let start = -1;
      for (let k0 = 0; k0 < n; k0++) if (!rays[k0].thin) { start = k0; break; }
      if (start < 0) start = 0;
      let cur = null;
      for (let s = 1; s <= n; s++) {
        const k = (start + s) % n, r = rays[k];
        if (r.thin) { if (!cur) cur = { ks: [k], miss: 0 }; else { cur.ks.push(k); cur.miss = 0; } }
        else if (cur) { if (++cur.miss > 1) { places.push(cur); cur = null; } }
      }
      if (cur) places.push(cur);
      const val0 = rays.filter(r => r.valid), photoMed = median(val0.map(r => r.tP));
      ln.places = places.map(pl => {
        const rs = pl.ks.map(k => rays[k]), rr = median(rs.map(r => r.rin)), arc = pl.ks.length * Math.PI / 180 * rr;
        const sx = rs.reduce((s, r) => s + r.dx, 0), sy = rs.reduce((s, r) => s + r.dy, 0);
        let w = whereOf(sx, sy);
        w = w.replace(/\bL\b/, ln.outerIsLeft ? 'outer side' : 'nose side').replace(/\bR\b/, ln.outerIsLeft ? 'nose side' : 'outer side');
        if (/^(top|bottom) (outer|nose) side$/.test(w)) w = w.replace(' side', ' corner');
        return { lens: ln.name, where: w, photoPx: median(rs.map(r => r.tP)), cutPx: median(rs.map(r => r.tC)), arcPx: Math.round(arc), ks: pl.ks };
      }).filter(pl => pl.photoPx - pl.cutPx >= 3 && (pl.cutPx <= 1
        /* a gap: where the cut really leaves this lens open, from 8 px of rim; otherwise only a long stretch (30 px or more)
           that looks like this lens's ordinary rim in the photo -- a short one beside a nose pad or an arm is not counted */
        ? (ln.broken && pl.arcPx >= 8) || (pl.arcPx >= 30 && Math.abs(pl.photoPx - photoMed) <= Math.max(3, 0.5 * ln.medRim))
        : pl.arcPx >= 20));                  /* a thinner rim: from 20 px of rim */
      const val = rays.filter(r => r.valid);
      ln.photoPx = median(val.map(r => r.tP)); ln.cutPx = median(val.map(r => r.tC)); ln.validRays = val.length; ln.thinRays = val.filter(r => r.thin).length;
    });
    const top = topScan(op, P, W, H, lenses);
    const valid = lenses.reduce((s, l) => s + l.validRays, 0), thin = lenses.reduce((s, l) => s + l.thinRays, 0);
    const places = [].concat.apply([], lenses.map(l => l.places));
    top.places.forEach(tp => {                                    /* the top seen both ways is listed once: the column count */
      for (let i = places.length - 1; i >= 0; i--) if (places[i].lens === tp.lens && /^top/.test(places[i].where) && !places[i].topCols) places.splice(i, 1);
      places.push(tp); });
    const medRim = median(lenses.map(l => l.medRim));
    if (medRim < 2.5) return { measured: false, reason: 'the rim is too thin to measure (rimless or a very fine wire)', lenses, medRim };
    if (valid < NR * 0.25 * lenses.length) return { measured: false, reason: 'too little plain rim to measure', lenses, medRim };
    let closed = null; if (helped) { closed = new Uint8Array(N); for (let i = 0; i < N; i++) if (helped[i] && !op[i]) closed[i] = 1; }
    return { measured: true, ok: places.length === 0, lenses, places, thinPct: valid ? Math.round(100 * thin / valid) : 0, medRim: Math.round(medRim), broken: !!helped, closed, top };
  }
  /* THE MISSING PART of each place, to put back to EXACTLY the photo's thickness (shop, 26 Oct: "if it is 32 px in the photo,
     after the repair it has to be 32 px -- it should not cut, it should not dot"): the whole band from the photo's inner rim
     edge to the photo's own outline, solid -- every pixel of it, shine included -- over the whole stretch and 3 lines more at
     each end (so it blends into the rim that is there); a line inside the stretch that could not be measured takes its
     neighbours' band. Only where the cut has less than the photo. Nothing is ever taken away. */
  function missingMask(res, A, P, W, H) {
    const N = W * H, m = new Uint8Array(N), from = new Int32Array(N).fill(-1);
    m.from = from;                     /* the outline pixel takes the colour of the rim just inside it (no light line along the edge) */
    res.lenses.forEach(ln => {
      if (!(ln.places && ln.places.length)) return;
      const rays = ln.rays, want = new Uint8Array(NR);
      const short = k => { const r = rays[(k + NR) % NR]; return r && r.valid && (r.tP - ln.bias) - r.tC >= 2; };
      ln.places.forEach(pl => { let a0 = pl.ks[0], n0 = (pl.ks[pl.ks.length - 1] - a0 + NR) % NR;
        /* the stretch goes on as long as the rim next to it is still short of the photo (the ends of a loss are shallower) */
        for (let g2 = 0; g2 < 40 && short(a0 - 1); g2++) { a0 = (a0 - 1 + NR) % NR; n0++; }
        for (let g2 = 0; g2 < 40 && short(a0 + n0 + 1); g2++) n0++;
        for (let d = -3; d <= n0 + 3; d++) want[(a0 + d + NR) % NR] = 1; });
      const lo = new Float32Array(NR).fill(NaN), hi = new Float32Array(NR).fill(NaN);
      for (let k = 0; k < NR; k++) { if (!want[k]) continue; const r = rays[k];
        if (r.valid && (r.tP - ln.bias) - r.tC >= 1) { lo[k] = r.rin - r.inn; hi[k] = r.outl; } }
      for (let k = 0; k < NR; k++) { if (!want[k] || !isNaN(lo[k])) continue;
        let da = 0, db = 0;
        for (let d = 1; d <= 6; d++) { if (!da && !isNaN(lo[(k - d + NR) % NR])) da = d; if (!db && !isNaN(lo[(k + d) % NR])) db = d; }
        if (da && db) { const ka = (k - da + NR) % NR, kb = (k + db) % NR, f = da / (da + db);
          lo[k] = lo[ka] * (1 - f) + lo[kb] * f; hi[k] = hi[ka] * (1 - f) + hi[kb] * f; } }
      let R = 0; for (let k = 0; k < NR; k++) if (!isNaN(hi[k]) && hi[k] > R) R = hi[k];
      if (!R) return; R = Math.ceil(R) + 2;
      const x0 = Math.max(0, Math.floor(ln.cx - R)), x1 = Math.min(W - 1, Math.ceil(ln.cx + R)), y0 = Math.max(0, Math.floor(ln.cy - R)), y1 = Math.min(H - 1, Math.ceil(ln.cy + R));
      for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) {
        const i = y * W + x; if (A[i] >= 230) continue;
        const dx = x - ln.cx, dy = y - ln.cy, d = Math.hypot(dx, dy);
        let deg = Math.atan2(dy, dx) * 180 / Math.PI; if (deg < 0) deg += 360;
        const ka = Math.floor(deg) % NR, kb = (ka + 1) % NR, f = deg - Math.floor(deg);
        let L, Hh;
        if (!isNaN(lo[ka]) && !isNaN(lo[kb])) { L = lo[ka] * (1 - f) + lo[kb] * f; Hh = hi[ka] * (1 - f) + hi[kb] * f; }
        else if (!isNaN(lo[ka]) && f < 0.5) { L = lo[ka]; Hh = hi[ka]; }
        else if (!isNaN(lo[kb]) && f >= 0.5) { L = lo[kb]; Hh = hi[kb]; }
        else continue;
        if (d < L - 0.5 || d > Hh + 0.3) continue;
        /* UNDER the frame (the table side) a light reflection can sit right against the rim: the outer 2 px there are only put
           back where the photo is darker than the sheet or coloured. On top, the rim's own light edge is kept (it catches the
           light -- the Skechers top rim was exactly that) */
        if (d > Hh - 2.5 && dy > 0.3 * d && !P.Dk[i]) continue;
        if (d > Hh - 1) { m[i] = 2;                                 /* the outline pixel itself: half frame, a softer edge */
          const t = d - 1.5, xi = Math.round(ln.cx + dx / d * t), yi = Math.round(ln.cy + dy / d * t); if (xi >= 0 && yi >= 0 && xi < W && yi < H) from[i] = yi * W + xi; }
        else m[i] = 1;
      }
    });
    /* the top of the frame, column by column: every column of the stretch (and 3 more each side) that starts lower than the
       photo is filled up to the photo's own outline */
    if (res.top && res.top.places.length) {
      const byX = {}; res.top.cols.forEach(c => { byX[c.x] = c; });
      const shortX = x => byX[x] && byX[x].loss - res.top.bias >= 2;
      res.top.places.forEach(pl => { let xa = Math.min(...pl.topCols), xb = Math.max(...pl.topCols);
        while (shortX(xa - 1) || shortX(xa - 2)) xa--;               /* as long as the top next to it is still lower than the photo */
        while (shortX(xb + 1) || shortX(xb + 2)) xb++;
        xa -= 3; xb += 3;
        res.top.cols.forEach(c => { if (c.x < xa || c.x > xb || c.loss - res.top.bias < 1) return;
          for (let y = c.pt; y < c.ct; y++) { const i = y * W + c.x; if (A[i] >= 230) continue;
            if (y <= c.pt) { m[i] = 2; if (y + 2 < H) from[i] = (y + 2) * W + c.x; } else m[i] = 1; } }); });
    }
    return m;
  }
  /* after the repair, every place measured again on the repaired picture: photo px, what the cut had, what it has now */
  function verify(b, a) {
    return b.places.map(pl => {
      let after = null, photo = pl.photoPx;
      if (pl.topCols && a.top && a.top.cols && a.top.cols.length) {
        const set = new Set(pl.topCols), cs = a.top.cols.filter(c => set.has(c.x));
        if (cs.length) { after = median(cs.map(c => c.thick)); photo = median(cs.map(c => c.thick + Math.max(0, c.loss - a.top.bias))); }
      } else if (pl.ks && a.lenses && a.lenses.length) {
        const lb = b.lenses.find(l => l.name === pl.lens) || b.lenses[0];
        const la = a.lenses.slice().sort((p, q) => Math.hypot(p.cx - lb.cx, p.cy - lb.cy) - Math.hypot(q.cx - lb.cx, q.cy - lb.cy))[0];
        const rs = la && la.rays ? pl.ks.map(k => la.rays[k]).filter(r => r && r.valid) : [];
        if (rs.length) { after = median(rs.map(r => r.tC)); photo = median(rs.map(r => Math.max(r.tC, r.tP - la.bias))); }
      }
      return { lens: pl.lens, where: pl.where, photoPx: Math.round(photo), beforePx: Math.round(pl.cutPx), afterPx: after == null ? null : Math.round(after) };
    });
  }
  function check(cutImg, srcImg, opts) {
    opts = opts || {};
    const W = cutImg.naturalWidth || cutImg.width, H = cutImg.naturalHeight || cutImg.height;
    if (!(W > 32 && H > 32)) return { measured: false, reason: 'no picture' };
    const cd = data(cutImg, W, H), sd = data(srcImg, W, H).data, N = W * H, A = new Uint8Array(N);
    for (let i = 0; i < N; i++) A[i] = cd.data[i * 4 + 3];
    const P = photoMaps(sd, W, H);
    const res = measure(A, P, W, H);
    res.w = W; res.h = H;
    if (opts.debug) res.debugP = P;
    if (!res.measured) { res.summary = summary(res); return res; }
    if ((opts.marks || opts.repair) && !res.ok) {
      const m = missingMask(res, A, P, W, H);
      if (opts.marks) {
        const c = document.createElement('canvas'); c.width = W; c.height = H; const x = c.getContext('2d');
        const id = new ImageData(new Uint8ClampedArray(cd.data), W, H);
        for (let i = 0; i < N; i++) if (m[i]) { const j = i * 4; id.data[j] = 235; id.data[j + 1] = 25; id.data[j + 2] = 25; id.data[j + 3] = 255; }
        x.putImageData(id, 0, 0); res.marks = c;
      }
      if (opts.repair) {
        /* put back, measure again, and once more where it is still short (up to 3 rounds) */
        const out = new Uint8ClampedArray(cd.data), A2 = new Uint8Array(A); let added = 0, cur = res, mm = m;
        for (let pass = 0; pass < 3; pass++) {
          let n = 0;
          for (let i = 0; i < N; i++) if (mm[i]) { const j = i * 4, want = mm[i] === 2 ? 150 : 255, fr = mm.from[i], js = (mm[i] === 2 && fr >= 0 ? fr : i) * 4;
            if (want > out[j + 3]) { out[j] = sd[js]; out[j + 1] = sd[js + 1]; out[j + 2] = sd[js + 2]; out[j + 3] = want; A2[i] = want; n++; } }
          added += n;
          cur = measure(A2, P, W, H);
          if (!n || !cur.measured || cur.ok) break;
          mm = missingMask(cur, A2, P, W, H);
        }
        const c = document.createElement('canvas'); c.width = W; c.height = H; c.getContext('2d').putImageData(new ImageData(out, W, H), 0, 0);
        res.repair = c; res.added = added; res.after = summary(cur); res.verify = verify(res, cur);
      }
    }
    /* small enough to save with the frame */
    res.summary = summary(res);
    return res;
  }
  function summary(res) {
    if (!res.measured) return { measured: false, reason: res.reason };
    return { measured: true, ok: res.ok, thinPct: res.thinPct, medRim: res.medRim, broken: !!res.broken, verify: res.verify,
      lenses: res.lenses.map(l => ({ name: l.name, photoPx: Math.round(l.photoPx), cutPx: Math.round(l.cutPx) })),
      places: res.places.slice(0, 8).map(p => ({ lens: p.lens, where: p.where, photoPx: Math.round(p.photoPx), cutPx: Math.round(p.cutPx), arcPx: p.arcPx })) };
  }
  g.VGRim = { check, VERSION: 'd17.186' };
})(window);

/* Vision Gallery — the watchman (d17.166, shop 22 Oct: "a customer gets a 404 / 504 and we never come to know")

   The Google Cloud computer (the WhatsApp one, it never sleeps) opens this every 5 minutes:
     GET /api/watch?key=<the WhatsApp sender key>
   Each time it:
   1. opens the shop's own pages and server parts -- home, frame, checkout, My Orders, eye test, the database --
      and notes any that answer with an error (404, 500, 504 ...) or do not answer at all;
   2. reads the problems customers' phones reported since the last look (Admin -> HEALTH keeps the same notes);
   3. sends ONE WhatsApp per problem to the alert number (Admin -> Settings -> Contact numbers -> Alerts),
      and "back to normal" when a page that was down answers again. Nothing is repeated every 5 minutes.
   If the whole website is down this function cannot run at all -- the computer's own script sees that and sends
   the alert straight from the sender (see the setup line in HEALTH).

   Needs on Vercel: SENDER_URL + SENDER_KEY (WhatsApp) and SUPABASE_SERVICE_KEY (to read the reports and keep notes). */
'use strict';
const crypto = require('crypto');
const L = require('./_lib.js');

const PAGES = [
  ['Home page', '/'], ['Frame page', '/product'], ['Checkout', '/order'], ['My Orders', '/account'],
  ['Eye test / prescription', '/prescription'], ['Site check', '/check'], ['Policies page', '/policies'],
  ['My Orders server', '/api/order-details?check=1'], ['Chat server', '/api/chat?check=1']
];
/* a single one of these is worth an alert; anything else needs 3 phones (or 3 times) in 30 minutes */
const URGENT = { order: 1, prescription: 1, server: 1, notfound: 1, database: 1 };
const LABEL = { order: 'An order could not be saved', prescription: 'A prescription could not be saved', server: 'Server error',
  notfound: 'Page not found (404)', database: 'Database problem', photo: 'Pictures not loading', file: 'Site files not loading',
  script: 'Program error on the page', login: 'Admin sign-in failing', slow: 'Pages opening slowly', otp: 'My Orders sign-in problem' };
const PAGE_NAME = { home: 'Home page', frame: 'Frame page', checkout: 'Checkout', prescription: 'Eye test / prescription',
  myorders: 'My Orders', admin: 'Admin', notfound: 'Missing page', pd: 'PD guide' };

function ist(d) { try { return new Date(d || Date.now()).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' }); } catch (e) { return ''; } }
async function probe(origin, path) {
  const t0 = Date.now();
  try {
    /* pages are asked with HEAD (the answer without the page itself), so 288 looks a day cost almost no traffic */
    const get = m => Promise.race([fetch(origin + path, { method: m, redirect: 'follow', headers: { 'User-Agent': 'VG-watchman', 'Cache-Control': 'no-cache' } }),
      new Promise((_, j) => setTimeout(() => j(new Error('no answer in 7 s')), 7000))]);
    let r = await get(path.startsWith('/api/') ? 'GET' : 'HEAD');
    if (r.status === 405) r = await get('GET');
    return { ok: r.status < 400, status: r.status, ms: Date.now() - t0 };
  } catch (e) { return { ok: false, status: 0, ms: Date.now() - t0, why: e.message }; }
}
async function note(data) {
  try { await L.db('/rest/v1/products?on_conflict=id', { method: 'POST', headers: { Prefer: 'resolution=merge-duplicates,return=minimal' },
    body: JSON.stringify([{ id: '__watch', data, updated_at: new Date().toISOString() }]) }); } catch (e) {}
}
/* null = the notes could not be read (then nothing is written back, so old notes are never wiped) */
async function state() {
  try { const r = await L.db('/rest/v1/products?select=data&id=eq.__watch'); if (!r.ok || !Array.isArray(r.body)) return null; return (r.body[0] && r.body[0].data) || {}; } catch (e) { return null; }
}
/* the key compared without giving away how much of it was right */
function same(a, b) { const x = Buffer.from(String(a)), y = Buffer.from(String(b)); return x.length === y.length && crypto.timingSafeEqual(x, y); }
/* the notes row can be read by anyone (like the shop settings), so problems are kept as a short code, not their words */
function code(s) { return crypto.createHash('sha1').update(String(s)).digest('hex').slice(0, 12); }
/* a step that may hang (the database) gets a time limit; on time-out the fallback is used */
function limit(p, ms, fallback) { return Promise.race([Promise.resolve(p).catch(() => fallback), new Promise(z => setTimeout(() => z(fallback), ms))]); }
const DAY_MAX = 20;          /* at most 20 WhatsApps a day about customers' reports */
const PER_LOOK = 5;          /* at most 5 problems in one WhatsApp */

module.exports = async function (req, res) {
  let replied = false;
  const reply = (status, obj) => { if (replied) return; replied = true; L.send(res, status, obj); };
  const q = L.query(req);
  /* d17.167 (shop, 22 Oct: "a test alert button, so we come to know it is working"): Admin -> HEALTH -> Watchman ->
     SEND TEST ALERT. Only for signed-in staff; it goes to the same number the real alerts go to. */
  if (q.get('test')) return reply(...(await testAlert(req)));
  const key = q.get('key') || req.headers['x-key'] || '';
  const KEY = L.env('WATCH_KEY') || L.env('SENDER_KEY');
  if (!KEY) return reply(501, { ok: false, error: 'SENDER_KEY is not set in Vercel' });
  if (!same(key, KEY)) return reply(403, { ok: false, error: 'wrong key' });
  /* the website answers within 45 seconds whatever happens (a hanging database must never look like "the website is down") */
  const guard = setTimeout(() => reply(200, { ok: true, partial: true, error: 'some checks took too long' }), 45000);
  try { reply(200, await look(req)); }
  catch (e) { reply(200, { ok: false, error: String((e && e.message) || e).slice(0, 120) }); }
  finally { clearTimeout(guard); }
};

async function testAlert(req) {
  const user = await L.staffUser(req);
  if (!user) return [401, { ok: false, error: 'Sign in to your shop account first (Admin -> Settings -> Your account).' }];
  if (L.tooMany('watchtest|' + user.email, 5, 10 * 60e3)) return [429, { ok: false, error: 'Too many tests -- wait 10 minutes.' }];
  if (!L.senderReady()) return [200, { ok: false, error: 'SENDER_URL / SENDER_KEY are not set in Vercel.' }];
  if (!L.env('SUPABASE_SERVICE_KEY')) return [200, { ok: false, error: 'SUPABASE_SERVICE_KEY is not set in Vercel, so the alert number cannot be read.' }];
  const shop = await limit(L.shopSettings(), 10000, {});
  const to = L.phone10(shop.alertWa) || L.phone10(shop.mgrWa) || L.phone10(shop.phone) || L.phone10(shop.wa);
  if (!to) return [200, { ok: false, error: 'No alert number: Settings -> Contact numbers -> Website problem alerts go to.' }];
  const w = await L.whatsapp(to, '✅ VISION GALLERY WEBSITE — watchman test (' + ist(Date.now()) + ').\nWebsite problem alerts reach this number. Nothing is wrong.');
  return [200, { ok: !!w.ok, to: '•••' + to.slice(-4), error: w.ok ? undefined : (w.error || 'not sent') }];
}

async function look(req) {
  const canDb = !!L.env('SUPABASE_SERVICE_KEY');
  const host = String(req.headers['x-forwarded-host'] || req.headers.host || 'visiongallery.me').split(',')[0].trim();
  const origin = L.env('SITE_URL') || ('https://' + host);
  const now = Date.now();

  /* 1. the shop's own pages and the database, all at once */
  const dbCheckP = (async () => {
    try { const r = await Promise.race([fetch(L.SB_URL + '/rest/v1/products?select=id&limit=1', { headers: { apikey: L.PUBLIC_KEY } }), new Promise((_, j) => setTimeout(() => j(new Error('no answer in 7 s')), 7000))]);
      return { name: 'Database (frames)', path: 'database', ok: r.ok, status: r.status }; } catch (e) { return { name: 'Database (frames)', path: 'database', ok: false, status: 0, why: e.message }; }
  })();
  const results = await Promise.all(PAGES.map(([name, path]) => probe(origin, path).then(r => Object.assign({ name, path }, r))));
  results.push(await dbCheckP);

  const loaded = canDb ? await limit(state(), 8000, null) : null;
  const S = loaded || {};
  S.down = S.down || {}; S.alerted = S.alerted || {}; S.told = S.told || {};
  const msgs = [], commits = [];   /* what is marked "told" only once the WhatsApp really went out */

  /* down twice in a row (10 minutes) before an alert, so a one-second blip never wakes anyone;
     a page that keeps going up and down is told about once an hour, not every 15 minutes */
  results.forEach(r => {
    const d = S.down[r.path];
    if (!r.ok) {
      if (!d) S.down[r.path] = { since: now, n: 1, status: r.status, name: r.name };
      else {
        d.n = (d.n || 1) + 1; d.status = r.status;
        if (d.n >= 2 && !d.told) {
          if (S.told[r.path] && now - S.told[r.path] < 3600e3) d.told = 'quiet';
          else {
            msgs.push('⚠️ ' + r.name + ' is NOT opening' + (r.status ? ' (error ' + r.status + ')' : ' (' + (r.why || 'no answer') + ')') + ' since ' + ist(d.since) + '.\n' + origin + (r.path.startsWith('/') ? r.path.split('?')[0] : ''));
            commits.push(() => { d.told = now; S.told[r.path] = now; });
          }
        }
      }
    } else if (d) {
      if (d.told && d.told !== 'quiet') msgs.push('✅ ' + (d.name || r.name) + ' is opening again (' + ist(now) + ').');
      delete S.down[r.path];
    }
  });
  Object.keys(S.told).forEach(p => { if (now - S.told[p] > 24 * 3600e3) delete S.told[p]; });

  /* 1b. d17.182: the backup (made by GitHub, not this computer) -- told once a day when it failed or is over 2 days old (d17.183: it runs every night) */
  if (loaded) {
    const bk = await limit(L.db('/rest/v1/shop_private?select=data&id=eq.__backup'), 8000, null);
    const last = bk && bk.ok && Array.isArray(bk.body) && bk.body[0] ? bk.body[0].data : null;
    if (last && last.at) {
      const age = now - (Date.parse(last.at) || now), bad = last.ok === false, old = age > 2 * 86400e3;
      if ((bad || old) && !(S.backupTold && now - S.backupTold < 24 * 3600e3)) {
        msgs.push('⚠️ NIGHTLY BACKUP ' + (bad ? 'did NOT finish (' + ist(last.at) + ')' + (last.note ? ': ' + String(last.note).slice(0, 80) : '') : 'is ' + Math.floor(age / 86400e3) + ' days old (last ' + ist(last.at) + ')') +
          '.\nGitHub → vg-backup → Actions shows why. Admin → HEALTH → Backup.');
        commits.push(() => { S.backupTold = now; });
      }
      if (!bad && !old) delete S.backupTold;
    }
  }

  /* 2. what customers' phones reported since the last look */
  let reports = [], repMsgs = 0;
  const prevSeen = S.lastSeen, prevAlerted = JSON.parse(JSON.stringify(S.alerted));
  if (loaded) {
    /* the last report's own time, exactly as the database wrote it (so it is never read twice);
       times in the future are ignored, so a wrong clock -- or a made-up report -- cannot stop the reading */
    const floor = new Date(now - 30 * 60e3).toISOString();
    const last = typeof S.lastSeen === 'string' && Date.parse(S.lastSeen) > now - 30 * 60e3 && Date.parse(S.lastSeen) < now + 60e3 ? S.lastSeen : floor;
    const until = new Date(now + 60e3).toISOString();
    const r = await limit(L.db('/rest/v1/site_health?select=page,kind,message,detail,created_at&created_at=gt.' + encodeURIComponent(last) + '&created_at=lt.' + encodeURIComponent(until) + '&order=created_at.asc&limit=500'), 8000, null);
    if (r && r.ok && Array.isArray(r.body)) {
      if (r.body.length) S.lastSeen = String(r.body[r.body.length - 1].created_at);
      reports = r.body.filter(x => !x.detail || x.detail.level !== 'info');
    }
    const day = ist(now).split(',')[0];
    if (!S.day || S.day.d !== day) S.day = { d: day, n: 0 };
    const groups = {};
    reports.forEach(x => {
      const k = code(x.page + '|' + x.kind + '|' + String(x.message || '').slice(0, 60));
      (groups[k] = groups[k] || { page: x.page, kind: x.kind, message: x.message, n: 0, devices: {} }).n++;
      if (x.detail && x.detail.device) groups[k].devices[String(x.detail.device).slice(0, 40)] = 1;
    });
    let told = 0, more = 0;
    Object.keys(groups).forEach(k => {
      const g0 = groups[k];
      const need = URGENT[g0.kind] ? 1 : 3;
      /* the same problem is told at most once in 6 hours; "3 times" means 3 within 30 minutes */
      const seen = S.alerted[k];
      if (seen && seen.at && now - seen.at < 6 * 3600e3) return;
      const fresh = seen && !seen.at && now - (seen.first || now) < 30 * 60e3;
      const tally = (fresh ? seen.n : 0) + g0.n, first = fresh ? seen.first : now;
      S.alerted[k] = { n: tally, first };
      if (tally < need) return;
      if (S.day.n + told >= DAY_MAX || told >= PER_LOOK) { more++; return; }
      told++;
      msgs.push('⚠️ ' + (LABEL[g0.kind] || String(g0.kind).slice(0, 30)) + ' — ' + (PAGE_NAME[g0.page] || String(g0.page).slice(0, 30)) + (tally > 1 ? ' (' + tally + ' times)' : '') + '\n' +
        String(g0.message || '').slice(0, 120) + (Object.keys(g0.devices).length ? '\nPhones: ' + Object.keys(g0.devices).slice(0, 3).join(', ') : '') + '\nAdmin → HEALTH has the details.');
      commits.push(() => { S.alerted[k] = { at: now, n: tally }; S.day.n++; });
    });
    repMsgs = told + more;
    if (more) msgs.push('…and ' + more + ' more problem' + (more === 1 ? '' : 's') + ' — Admin → HEALTH has them all.');
    /* forget old notes */
    Object.keys(S.alerted).forEach(k => { const a = S.alerted[k]; if (a.at ? now - a.at > 24 * 3600e3 : now - (a.first || 0) > 30 * 60e3) delete S.alerted[k]; });
  }

  /* 3. tell the alert number -- only when it really went out is the problem marked as told (else it is tried again in 5 minutes) */
  let sent = 0, to = '', why = '';
  if (msgs.length && L.senderReady()) {
    const shop = loaded ? await limit(L.shopSettings(), 8000, {}) : {};
    to = L.phone10(shop.alertWa) || L.phone10(shop.mgrWa) || L.phone10(shop.phone) || L.phone10(shop.wa);
    if (to) {
      const w = await L.whatsapp(to, ('VISION GALLERY WEBSITE\n\n' + msgs.join('\n\n')).slice(0, 1400));
      if (w.ok) { sent = msgs.length; commits.forEach(f => f()); } else why = w.error || 'not sent';
    } else why = 'no alert number';
  } else if (msgs.length) why = 'WhatsApp sender not set up';
  /* not sent: the same reports are read again at the next look, so the alert is not lost */
  if (!sent && repMsgs) { S.lastSeen = prevSeen; S.alerted = prevAlerted; }
  S.lastRun = now; S.lastOk = results.every(r => r.ok); S.pages = results.map(r => ({ name: r.name, ok: r.ok, status: r.status, ms: r.ms || 0 }));
  S.lastAlert = sent ? { at: now, n: sent } : (S.lastAlert || null);
  S.lastFail = why ? { at: now, why: String(why).slice(0, 80) } : null;
  if (loaded) await limit(note(S), 8000, null);
  return { ok: true, pages: S.pages, problems: reports.length, alerts: msgs.length, sent, to: to ? '•••' + to.slice(-3) : '', db: canDb, notes: !!loaded, error: why || undefined };
}
module.exports.PAGES = PAGES;

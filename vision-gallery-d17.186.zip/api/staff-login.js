/* Vision Gallery — Admin sign-in with NAME + PASSCODE only (d17.174, shop 23 Oct: "if I give the manager a role and a
   password, they type the name and the password and it has to open -- no e-mail every time")

   GET  /api/staff-login                 -> the names on the sign-in list (id, name, role -- never a passcode)
   POST /api/staff-login {who, pass}      -> right passcode: the shop account's sign-in is handed to this phone
                                             (the same account the Owner signs in to with the e-mail), so the frames,
                                             orders and settings load. Staff never see or type the shop e-mail.

   The passcodes are the ones in Admin -> Staff & Roles (kept in shop_private, which only the shop can read).
   Safety (every try is written down FIRST, as its own record, and only then counted -- so tries sent all at once
   cannot slip past the count):
     - 5 wrong passcodes from one phone in 15 minutes   -> that phone waits
     - 10 wrong passcodes for one name in 15 minutes    -> that name waits (from every phone)
     - 30 wrong passcodes for one name in a day         -> that name is stopped for the day (slow guessing);
       a NEW passcode for that name (Owner, Staff & Roles) starts its count again
     - when a wait starts, the alert number (Settings -> Contact numbers) gets a WhatsApp, at most once an hour
     - names whose passcode is the starting vg2026 or shorter than 4 cannot open Admin from a new phone
     - the passcodes are read only from the private table (shop_private), never from the public settings row
   Needs SUPABASE_SERVICE_KEY in Vercel (already set for My Orders). Optional SHOP_EMAIL: the shop account's e-mail
   (default visionviewoptic@gmail.com, or the only account there is). */
'use strict';
const crypto = require('crypto');
const L = require('./_lib');

const WIN = 15 * 60e3, LOCK = 15 * 60e3, IP_MAX = 5, WHO_MAX = 10, TELL_EVERY = 60 * 60e3, DAY = 24 * 3600e3, DAY_MAX = 30;
const STATE_ID = '__login', ROW = 'login:';

function same(a, b) {
  const x = crypto.createHash('sha256').update(String(a)).digest(), y = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(x, y) && String(a) === String(b);
}
const hash = s => crypto.createHash('sha1').update(String(s)).digest('hex').slice(0, 12);

async function readRow(path) {
  const r = await L.db(path);
  return (r.ok && Array.isArray(r.body) && r.body[0] && r.body[0].data) || null;
}
/* names for the sign-in list: private table first; the old public row only for the NAMES (never for checking) */
async function privateStaff() {
  const priv = await readRow('/rest/v1/shop_private?select=data&id=eq.shop');
  return priv && Array.isArray(priv.staff) && priv.staff.length ? priv.staff : null;
}
async function listForNames() {
  const priv = await privateStaff(); if (priv) return priv;
  const pub = await readRow('/rest/v1/products?select=data&id=eq.__shop');
  return pub && Array.isArray(pub.staff) && pub.staff.length ? pub.staff : null;
}
function usable(p) { const s = String((p && p.pass) || ''); return s.length >= 4 && s !== 'vg2026'; }

/* the "told the Owner" time (one WhatsApp an hour at most) */
async function loadTold() { try { const d = await readRow('/rest/v1/shop_private?select=data&id=eq.' + STATE_ID); return (d && d.toldAt) || 0; } catch (e) { return 0; } }
async function saveTold(t) {
  try { await L.db('/rest/v1/shop_private?on_conflict=id', { method: 'POST', headers: { Prefer: 'resolution=merge-duplicates,return=minimal' },
    body: JSON.stringify([{ id: STATE_ID, data: { toldAt: t }, updated_at: new Date().toISOString() }]) }); } catch (e) {}
}
/* one record per try: login:<name>:<phone>:<time>:<random> (name and phone as short hashes) */
async function addTry(id, passKey) {
  const r = await L.db('/rest/v1/shop_private', { method: 'POST', headers: { Prefer: 'return=minimal' },
    body: JSON.stringify([{ id, data: { p: passKey }, updated_at: new Date().toISOString() }]) });
  return r.ok;
}
async function dropTry(id) { try { await L.db('/rest/v1/shop_private?id=eq.' + encodeURIComponent(id), { method: 'DELETE' }); } catch (e) {} }
async function tries(pattern, sinceMs) {
  const r = await L.db('/rest/v1/shop_private?select=id,data,updated_at&id=like.' + encodeURIComponent(pattern) + '&updated_at=gt.' + encodeURIComponent(new Date(Date.now() - sinceMs).toISOString()) + '&limit=500');
  if (!r.ok || !Array.isArray(r.body)) return null;
  return r.body.map(x => ({ id: x.id, p: x.data && x.data.p, at: Date.parse(x.updated_at) || 0 }));
}
/* minutes until the count is back under the limit (the oldest tries age out first) */
function waitFor(list, max, win) {
  const t = list.map(x => x.at).sort((a, b) => a - b), idx = t.length - max;
  return Math.max(1, Math.ceil(((t[Math.max(0, idx)] || Date.now()) + win - Date.now()) / 60e3));
}

/* the shop account (the one the Owner signs in to with the e-mail) */
async function shopEmail() {
  const want = (L.env('SHOP_EMAIL') || 'visionviewoptic@gmail.com').toLowerCase();
  const r = await L.db('/auth/v1/admin/users?page=1&per_page=200');
  const list = r.ok && r.body ? (Array.isArray(r.body) ? r.body : (r.body.users || [])) : [];
  const withMail = list.filter(u => u && u.email);
  const hit = withMail.find(u => String(u.email).toLowerCase() === want);
  if (hit) return hit.email;
  return withMail.length === 1 ? withMail[0].email : '';
}
/* a fresh sign-in for that account, made here on the server: no e-mail is sent */
async function shopSession() {
  const email = await shopEmail();
  if (!email) return { error: 'The shop account was not found. Owner: sign in once with your e-mail.' };
  const g = await L.db('/auth/v1/admin/generate_link', { method: 'POST', body: JSON.stringify({ type: 'magiclink', email }) });
  if (!g.ok || !g.body) return { error: 'The shop account did not answer (' + g.status + '). Try again in a minute.' };
  const p = g.body.properties || g.body;
  const tries = [];
  if (p.hashed_token) tries.push({ type: p.verification_type || 'magiclink', token_hash: p.hashed_token });
  if (p.hashed_token && (p.verification_type || 'magiclink') !== 'magiclink') tries.push({ type: 'magiclink', token_hash: p.hashed_token });
  if (p.email_otp) tries.push({ type: 'email', email, token: p.email_otp });
  for (const t of tries) {
    const v = await L.db('/auth/v1/verify', { method: 'POST', body: JSON.stringify(t) });
    if (v.ok && v.body && v.body.access_token) return { session: v.body };
  }
  return { error: 'The shop account did not hand over a sign-in. Try again in a minute.' };
}

async function alert(shop, text) {
  try {
    const to = L.phone10(shop.alertWa) || L.phone10(shop.mgrWa) || L.phone10(shop.phone) || L.phone10(shop.wa);
    if (to && L.senderReady()) await L.whatsapp(to, text);
  } catch (e) {}
}

module.exports = async (req, res) => {
  if (!L.env('SUPABASE_SERVICE_KEY')) return L.send(res, 501, { ok: false, notSetUp: true, error: 'Passcode sign-in is not switched on yet. Owner: sign in with your e-mail.' });
  const ip = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim() || 'ip';

  if (req.method === 'GET') {
    if (L.tooMany('sll:' + ip, 60, 3600e3)) return L.send(res, 429, { ok: false });
    let staff = null; try { staff = await listForNames(); } catch (e) {}
    if (!staff) return L.send(res, 200, { ok: false, staff: [] });
    return L.send(res, 200, { ok: true, staff: staff.filter(p => p && p.id).map(p => ({ id: String(p.id), name: String(p.name || p.role || p.id), role: String(p.role || '') })) });
  }
  if (req.method !== 'POST') return L.send(res, 405, { ok: false });

  /* a quick brake inside this running copy, before the database is even asked */
  if (L.tooMany('slp:' + ip, 12, WIN)) return L.send(res, 429, { ok: false, locked: true, error: 'Too many tries. Wait 15 minutes, then try again.' });

  const b = await L.body(req);
  const who = String((b && b.who) || '').slice(0, 80), pass = String((b && b.pass) || '').slice(0, 200);
  if (!who || !pass) return L.send(res, 400, { ok: false, error: 'Pick your name and type your passcode.' });

  let staff = null; try { staff = await privateStaff(); } catch (e) {}
  if (!staff) return L.send(res, 503, { ok: false, error: 'Could not read the staff list. Check the internet and try again.' });

  const person = staff.find(p => p && String(p.id) === who);
  /* a name whose passcode is too simple cannot open Admin from a new phone (said before the passcode is even looked at) */
  if (person && !usable(person)) return L.send(res, 403, { ok: false, error: 'This name’s passcode is too simple to open Admin on a new phone. Owner: set a new passcode (at least 4 characters) in Staff & Roles.' });

  const now = Date.now(), ipKey = hash(ip), whoKey = person ? hash('w:' + who) : 'x';
  const passKey = person ? hash('p:' + String(person.pass)) : '';
  const myId = ROW + whoKey + ':' + ipKey + ':' + now + ':' + crypto.randomBytes(4).toString('hex');
  if (!(await addTry(myId, passKey))) return L.send(res, 503, { ok: false, error: 'Could not check the passcode just now. Try again in a minute.' });
  if (Math.random() < 0.1) { try { await L.db('/rest/v1/shop_private?id=like.' + encodeURIComponent(ROW + '*') + '&updated_at=lt.' + encodeURIComponent(new Date(now - DAY).toISOString()), { method: 'DELETE' }); } catch (e) {} }

  /* count the OTHER tries (wrong ones, and ones still being checked right now) */
  const ipList = await tries(ROW + '*:' + ipKey + ':*', WIN);
  const whoDay = person ? await tries(ROW + whoKey + ':*', DAY) : [];
  if (!ipList || !whoDay) { await dropTry(myId); return L.send(res, 503, { ok: false, error: 'Could not check the passcode just now. Try again in a minute.' }); }
  const others = l => l.filter(x => x.id !== myId);
  const ipN = others(ipList), dayN = others(whoDay).filter(x => x.p === passKey), whoN = dayN.filter(x => now - x.at < WIN);
  if (dayN.length >= DAY_MAX) { await dropTry(myId); return L.send(res, 429, { ok: false, locked: true, error: 'Too many wrong passcodes for this name today. The Owner can change this passcode in Staff & Roles; otherwise it opens again in about ' + Math.ceil(waitFor(dayN, DAY_MAX, DAY) / 60) + ' hours.' }); }
  if (ipN.length >= IP_MAX || whoN.length >= WHO_MAX) {
    await dropTry(myId);
    const m = Math.max(ipN.length >= IP_MAX ? waitFor(ipN, IP_MAX, WIN) : 0, whoN.length >= WHO_MAX ? waitFor(whoN, WHO_MAX, WIN) : 0);
    return L.send(res, 429, { ok: false, locked: true, error: 'Too many wrong passcodes. Wait ' + m + ' minute' + (m > 1 ? 's' : '') + ', then try again.' });
  }

  if (!person || !same(pass, person.pass)) {
    /* this try stays written down as a wrong one */
    let started = '';
    if (person && dayN.length + 1 >= DAY_MAX) started = 'day';
    else if (ipN.length + 1 >= IP_MAX) started = 'phone';
    else if (person && whoN.length + 1 >= WHO_MAX) started = 'name';
    const name = person ? String(person.name || person.role || who) : 'an unknown name';
    if (started) {
      const told = await loadTold();
      if (now - told > TELL_EVERY) {
        await saveTold(now);
        let shop = {}; try { shop = await L.shopSettings(); } catch (e) {}
        await alert(shop, started === 'day'
          ? '⚠️ VISION GALLERY ADMIN — ' + DAY_MAX + ' wrong passcodes for ' + name + ' today. Someone may be guessing. Sign-in for ' + name + ' is stopped for the rest of the day. Change that passcode in Admin → Staff & Roles.'
          : '⚠️ VISION GALLERY ADMIN — ' + (started === 'phone' ? IP_MAX : WHO_MAX) + ' wrong passcodes for ' + name +
            '. Admin sign-in for ' + (started === 'phone' ? 'that phone' : name) + ' is paused for 15 minutes. If this was not your staff, change the passcodes in Admin → Staff & Roles.');
      }
      if (started === 'day') return L.send(res, 429, { ok: false, locked: true, error: 'Too many wrong passcodes for this name today. The Owner can change this passcode in Staff & Roles.' });
      return L.send(res, 429, { ok: false, locked: true, error: 'Too many wrong passcodes. Wait 15 minutes, then try again.' });
    }
    const left = Math.min(IP_MAX - ipN.length - 1, person ? WHO_MAX - whoN.length - 1 : 99, person ? DAY_MAX - dayN.length - 1 : 99);
    return L.send(res, 401, { ok: false, error: 'Wrong passcode — try again.' + (left <= 2 ? ' (' + left + ' more ' + (left === 1 ? 'try' : 'tries') + ' before a wait)' : '') });
  }

  /* right passcode */
  let got;
  try { got = await shopSession(); } catch (e) { got = { error: 'The shop account did not answer. Try again in a minute.' }; }
  await dropTry(myId);       /* a right passcode is not a wrong try */
  if (got.session) { try { await L.db('/rest/v1/shop_private?id=like.' + encodeURIComponent(ROW + whoKey + ':' + ipKey + ':*'), { method: 'DELETE' }); } catch (e) {} }   /* this person's own slips on this phone are forgiven */
  if (!got.session) return L.send(res, 502, { ok: false, error: got.error });
  const s = got.session;
  return L.send(res, 200, { ok: true,
    session: { access_token: s.access_token, refresh_token: s.refresh_token, expires_in: s.expires_in, user: { id: s.user && s.user.id, email: s.user && s.user.email } },
    person: { id: String(person.id), name: String(person.name || person.role || person.id), role: String(person.role || '') } });
};

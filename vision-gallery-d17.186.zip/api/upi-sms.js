/* Vision Gallery — automatic "payment received, order confirmed" (d17.155, shop 19 Oct)

   Customers keep paying exactly as now: your Kotak UPI QR, the quoted amount.
   Kotak then sends you an SMS ("Received Rs.2800.00 ... from ...@ybl ... UPI Ref ...").
   A small SMS-forwarding app on your phone passes ONLY those messages here:

     POST https://visiongallery.me/api/upi-sms?key=<UPI_SMS_KEY>     (body: the SMS text, in any common form)

   Here we read the amount, the payer's UPI ID and the UPI Ref, find the order
   waiting for that amount, mark it Confirmed + Paid in the database, and send
   the customer a WhatsApp from your sender:
     "Hi Manish, we have received your payment of ₹2,800. Your order no. VG-1023 is confirmed."
   Which order: the one whose mobile number is inside the payer's UPI ID; else
   the one whose name matches; else the oldest order still waiting for that amount.
   A payment that matches no order goes to the manager on WhatsApp instead.
   The same UPI Ref is never counted twice.

   GET /api/upi-sms?check=1 -> { configured } */
'use strict';
const L = require('./_lib.js');
const P = require('../upi-parse.js');

const WAITING = ['New', 'Waiting for Prescription', 'Prescription Received', ''];

function textOf(b, q) {
  if (!b) b = {};
  const keys = ['text', 'message', 'msg', 'body', 'sms', 'content', 'key_text'];
  for (const k of keys) if (typeof b[k] === 'string' && b[k].trim()) return b[k];
  if (b.data && typeof b.data === 'object') for (const k of keys) if (typeof b.data[k] === 'string') return b.data[k];
  if (typeof b === 'string') return b;
  return q.get('text') || q.get('message') || q.get('msg') || '';
}
function words(s) { return String(s || '').toLowerCase().replace(/[^a-z ]/g, ' ').split(/\s+/).filter(w => w.length > 2); }

async function note(result) {
  /* the Health page reads when the last payment SMS came in (time and outcome only -- no amounts, no names) */
  try { await L.db('/rest/v1/products?on_conflict=id', { method: 'POST', headers: { Prefer: 'resolution=merge-duplicates,return=minimal' },
    body: JSON.stringify([{ id: '__upi', data: { lastSms: new Date().toISOString(), lastResult: result }, updated_at: new Date().toISOString() }]) }); } catch (e) {}
}

module.exports = async function (req, res) {
  const q = L.query(req);
  const ready = !!(L.env('SUPABASE_SERVICE_KEY') && L.env('UPI_SMS_KEY'));
  if (req.method === 'GET' && q.get('check')) return L.send(res, 200, { configured: ready, whatsapp: L.senderReady() });
  if (!ready) return L.send(res, 501, { ok: false, configured: false });
  const b = await L.body(req);
  const key = q.get('key') || req.headers['x-key'] || (b && b.key) || '';
  if (key !== L.env('UPI_SMS_KEY')) return L.send(res, 401, { ok: false, error: 'wrong key' });

  const sms = textOf(b, q);
  const pay = P.parse(sms);
  if (!pay.ok) { await note('ignored'); return L.send(res, 200, { ok: true, ignored: pay.why }); }

  /* the same payment twice (an app that forwards twice, a retry) is counted once */
  if (pay.ref) {
    const dup = await L.db('/rest/v1/orders?select=ref&payload->>upiRef=eq.' + encodeURIComponent(pay.ref) + '&limit=1');
    if (dup.ok && Array.isArray(dup.body) && dup.body.length) return L.send(res, 200, { ok: true, duplicate: dup.body[0].ref });
  }

  const since = new Date(Date.now() - 3 * 86400e3).toISOString();
  const r = await L.db('/rest/v1/orders?select=ref,created_at,status,total,phone,name,payload&created_at=gte.' + encodeURIComponent(since) + '&order=created_at.asc&limit=200');
  const all = (r.ok && Array.isArray(r.body)) ? r.body : [];
  const cands = all.filter(o => {
    const p = o.payload || {};
    if (p.upiRef || p.payStatus === 'Paid' || p.payStatus === 'Refunded') return false;
    if (WAITING.indexOf(o.status || '') < 0) return false;
    /* d17.158: an EXPRESS order expects its total with the extra charge (kept in the order's details) */
    const due = (p.express && Number(p.total) > 0) ? Number(p.total) : (Number(o.total) || Number(p.total) || 0);
    return Math.abs(due - pay.amount) < 0.5;
  });
  let pick = null, how = '';
  if (pay.phone) { pick = cands.find(o => L.phone10(o.phone) === pay.phone); if (pick) how = 'mobile number in the UPI ID'; }
  if (!pick && (pay.name || pay.vpa)) {
    const w = words(pay.name || pay.vpa.split('@')[0]);
    pick = cands.find(o => { const n = words(o.name); return n.length && w.some(x => n.indexOf(x) >= 0); });
    if (pick) how = 'name';
  }
  if (!pick && cands.length) { pick = cands[0]; how = cands.length > 1 ? 'oldest of ' + cands.length + ' orders waiting for this amount' : 'the only order waiting for this amount'; }

  const shop = await L.shopSettings();
  if (!pick) {
    const mgr = shop.mgrWa || shop.wa;
    if (mgr) await L.whatsapp(mgr, 'PAYMENT WITH NO ORDER\n\n' + L.rupees(pay.amount) + ' received by UPI' + (pay.vpa ? ' from ' + pay.vpa : '') + (pay.ref ? '\nUPI Ref ' + pay.ref : '') + '\n\nNo order is waiting for this amount. Please check and confirm by hand.');
    await note('no matching order');
    return L.send(res, 200, { ok: true, matched: false, amount: pay.amount });
  }

  const p = Object.assign({}, pick.payload || {}, { payStatus: 'Paid', paid: pay.amount, payMethod: 'UPI', upiRef: pay.ref || ('noref-' + Date.now()), upiFrom: pay.vpa || pay.name || '', upiAt: new Date().toISOString(), upiPaid: true, upiMatch: how });
  const upd = { payload: p };
  if ((pick.status || 'New') === 'New') upd.status = 'Confirmed';
  const w = await L.db('/rest/v1/orders?ref=eq.' + encodeURIComponent(pick.ref), { method: 'PATCH', headers: { Prefer: 'return=minimal' }, body: JSON.stringify(upd) });
  if (!w.ok) { await note('could not update the order'); return L.send(res, 502, { ok: false, error: 'could not update the order', status: w.status }); }

  const first = String(pick.name || '').trim().split(/\s+/)[0] || 'there';
  const msg = 'Hi ' + first + ', we have received your payment of ' + L.rupees(pay.amount) + '. Your order no. ' + pick.ref + ' is confirmed.' +
    (pick.status === 'Waiting for Prescription' ? ' We will start as soon as we have your prescription.' : '') + '\n\nThank you — Vision Gallery';
  const sent = await L.whatsapp(pick.phone, msg);
  await note(sent.ok ? 'confirmed and messaged' : 'confirmed, WhatsApp not sent');
  return L.send(res, 200, { ok: true, matched: pick.ref, how, whatsapp: sent.ok });
};

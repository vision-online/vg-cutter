/* Vision Gallery — SECOND OPINION on a try-on cut-out (d17.183, shop 25 Oct: "let Gemini also watch what the robot is doing")

   Admin sends two small pictures of one view of a frame: the ORIGINAL photo and the FINAL cut-out laid on plain green.
   Google's picture reader (the same Gemini key as the chat) compares them and says whether any part of the frame is missing
   from the cut-out, or anything is left in that is not the frame. It only gives its opinion -- it never changes a picture;
   staff compare and APPROVE as always.

   POST /api/cut-check  { orig: "data:image/jpeg;base64,...", cut: "data:image/jpeg;base64,...", view }   (signed-in staff)
        -> { ok, good, missing, extra }
   Needs GEMINI_KEY in Vercel (already there for the chat). */
'use strict';
const crypto = require('crypto');
const L = require('./_lib.js');

const MODELS = () => [L.env('GEMINI_MODEL'), 'gemini-flash-latest', 'gemini-2.5-flash', 'gemini-flash-lite-latest'].filter((m, i, a) => m && a.indexOf(m) === i);
const SEEN = new Map();
let DAY = '', COUNT = 0;
const VIEW = { front: 'the FRONT view (straight on)', angle: 'a 30-degree view (frame turned, one arm towards the camera)', angleR: 'a 30-degree view (frame turned, one arm towards the camera)' };

function prompt(view) {
  return 'You check cut-outs of eyeglass frames for an optical shop. Picture 1 is the ORIGINAL photo of ONE pair of eyeglasses, '
    + (VIEW[view] || 'one view') + '. Picture 2 is the CUT-OUT of the same glasses laid on plain GREEN: green means removed. '
    + 'Compare them carefully and report only clear, real problems: '
    + '(a) MISSING: a part of the frame that is in picture 1 but cut away in picture 2 -- a piece of rim, the top bar, the bridge, a nose pad, a hinge or end piece, part of an arm, or an arm hollowed out; '
    + '(b) LEFT IN: something in picture 2 that is not the frame -- the sheet or table, a shadow, a reflection outside the frame, a price tag or label hanging from the frame. '
    + 'IGNORE: the lenses (they must be removed, so green inside the rims is right), writing on the lenses, tiny differences of a few pixels, soft edges. '
    + 'Answer JSON only: {"good": true or false, "missing": "a few plain words, or empty", "extra": "a few plain words, or empty"}. '
    + 'Say where (left lens, right lens, top, bottom, bridge, arm). good is true only when nothing is missing and nothing is left in.';
}
function img(dataUrl) {
  const m = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(String(dataUrl || ''));
  if (!m) return null;
  const bytes = Math.floor(m[2].length * 3 / 4);
  if (bytes < 1000 || bytes > 1500000) return null;
  return { mime: m[1], b64: m[2] };
}
async function ask(view, a, b) {
  const body = JSON.stringify({ contents: [{ role: 'user', parts: [{ text: prompt(view) }, { inlineData: { mimeType: a.mime, data: a.b64 } }, { inlineData: { mimeType: b.mime, data: b.b64 } }] }],
    generationConfig: { temperature: 0, maxOutputTokens: 1024, responseMimeType: 'application/json' } });
  let last = 'no answer'; const t0 = Date.now();
  for (const m of MODELS()) {
    if (Date.now() - t0 > 30000) break;
    let r;
    try {
      r = await Promise.race([
        fetch('https://generativelanguage.googleapis.com/v1beta/models/' + encodeURIComponent(m) + ':generateContent', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-goog-api-key': L.env('GEMINI_KEY') }, body }),
        new Promise((_, j) => setTimeout(() => j(new Error('timeout')), 20000))]);
    } catch (e) { last = e.message; continue; }
    let j = null; try { j = await r.json(); } catch (e) {}
    if (r.status === 404 || (r.status === 400 && /not found|not supported/i.test(JSON.stringify(j || '')))) { last = 'model ' + m + ' not available'; continue; }
    if (!r.ok) return { ok: false, why: (j && j.error && j.error.message) || ('error ' + r.status) };
    const c = j && j.candidates && j.candidates[0];
    const text = c && c.content && Array.isArray(c.content.parts) ? c.content.parts.map(p => p.text || '').join('').trim() : '';
    let o = null; try { o = JSON.parse(text.replace(/^```(?:json)?\s*|\s*```$/g, '')); } catch (e) {}
    if (o && typeof o === 'object' && typeof o.good === 'boolean') {
      const clean = s => String(s || '').replace(/\b(?:gemini|google|ai|model)\b/gi, '').replace(/\s+/g, ' ').trim().slice(0, 160);
      const missing = clean(o.missing), extra = clean(o.extra);
      return { ok: true, good: o.good && !missing && !extra, missing, extra };
    }
    last = 'unreadable answer';
  }
  return { ok: false, why: last };
}

module.exports = async (req, res) => {
  const q = L.query(req);
  if (req.method === 'GET' && q.get('check')) return L.send(res, 200, { configured: !!L.env('GEMINI_KEY') });
  if (req.method !== 'POST') return L.send(res, 405, { ok: false });
  if (!L.env('GEMINI_KEY')) return L.send(res, 501, { ok: false, notSetUp: true });
  const who = await L.staffUser(req); if (!who) return L.send(res, 401, { ok: false, error: 'Sign in to Admin first.' });
  const ip = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim() || 'ip';
  if (L.tooMany('cc:' + ip, 200, 3600e3)) return L.send(res, 429, { ok: false, busy: true });
  const today = new Date().toISOString().slice(0, 10); if (today !== DAY) { DAY = today; COUNT = 0; }
  if (COUNT >= (Number(L.env('CUTCHECK_DAILY_MAX')) || 600)) return L.send(res, 429, { ok: false, busy: true, error: 'Enough checks for today.' });
  const b = await L.body(req);
  const a = img(b && b.orig), c = img(b && b.cut), view = String((b && b.view) || 'front').slice(0, 10);
  if (!a || !c) return L.send(res, 400, { ok: false, error: 'Two pictures are needed.' });
  const key = crypto.createHash('sha256').update(view + '|' + a.b64 + '|' + c.b64).digest('hex');
  if (SEEN.has(key)) return L.send(res, 200, Object.assign({ ok: true, cached: true }, SEEN.get(key)));
  COUNT++;
  const r = await ask(view, a, c);
  if (!r.ok) return L.send(res, 502, { ok: false, error: 'The picture reader did not answer. Try again in a minute.' });
  const out = { good: r.good, missing: r.missing, extra: r.extra };
  SEEN.set(key, out); if (SEEN.size > 300) SEEN.clear();
  return L.send(res, 200, Object.assign({ ok: true }, out));
};

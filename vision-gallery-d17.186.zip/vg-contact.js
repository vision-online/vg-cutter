/* Vision Gallery — the shop's contact numbers, from Admin -> Settings -> Contact numbers (d17.158, shop 20 Oct)

   "If WhatsApp blocks the number we must replace it instantly" -- so no page carries a number of its own any more.
   Every "WhatsApp us" / "Call us" button and every printed number on the website reads the two numbers saved in
   Admin, and a change there reaches every page within a minute, with no new upload.

   In a page:   <a data-vg="tel">          -> href becomes tel:+91...           (the customer care number)
                <span data-vg="phone">     -> text becomes "+91 98xxx xxxxx"     (the customer care number)
                <a data-vg="wa" data-vg-text="Hi...">  -> href becomes https://wa.me/91...?text=...   (the WhatsApp number)
                <span data-vg="waphone">   -> text becomes the WhatsApp number
                <span data-vg="email">, <a data-vg="mailto">  -> the shop's e-mail (Admin -> Shop details -> Email)
   In code:     VGContact.get() -> { wa:'9198...', phone:'+91 98...', tel:'+9198...', waDisplay:'+91 98...' }
                window event 'vg:contact' when the numbers arrive or change. */
(function (g) {
  'use strict';
  if (g.VGContact) return;
  var DEF = { url: 'https://oscpunukbyosckrmopeh.supabase.co', key: 'sb_publishable_WWAPQTu0lo-X51T4kDlgng_LR39PPkU' };
  /* used only until the first answer from the account ever arrives on this phone */
  var FIRST = { wa: '918657143412', phone: '+91 86571 43412' };
  var MAIL = 'visionviewoptic@gmail.com';          /* d17.170: the shop's e-mail when Admin -> Shop details -> Email is empty */
  var CK = 'vg_contact', FRESH_MS = 60 * 1000;

  function db() { try { var s = JSON.parse(localStorage.getItem('vg_sync') || 'null'); if (s && s.url && s.key) return s; } catch (e) {} return DEF; }
  function digits(s) { return String(s || '').replace(/\D/g, ''); }
  function full(s) {                       /* 10 digits -> 91 + 10 digits; 0 in front dropped */
    var d = digits(s); if (d.length === 11 && d[0] === '0') d = d.slice(1);
    if (d.length === 10) d = '91' + d;
    return d;
  }
  function pretty(d) {                     /* 919876543210 -> +91 98765 43210 */
    d = full(d); if (d.length === 12 && d.slice(0, 2) === '91') return '+91 ' + d.slice(2, 7) + ' ' + d.slice(7);
    return d ? '+' + d : '';
  }
  function fromShop(sh) {
    sh = sh || {};
    var phone = full(sh.phone), wa = full(sh.wa);
    if (sh.sameNumber && phone) wa = phone;          /* "use the same number for both" */
    if (!phone && wa) phone = wa;
    if (!wa && phone) wa = phone;
    if (!phone) return null;
    var em = String(sh.email || '').trim();
    return { wa: wa, phone: pretty(phone), tel: '+' + phone, waDisplay: pretty(wa), email: /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(em) ? em : MAIL };
  }
  var cur = (function () {
    try { var c = JSON.parse(localStorage.getItem(CK) || 'null'); if (c && c.wa && c.phone) return c; } catch (e) {}
    return fromShop(FIRST);
  })();

  function apply(root) {
    root = root || document;
    var c = cur; if (!c || !root.querySelectorAll) return;
    root.querySelectorAll('[data-vg="tel"]').forEach(function (a) { a.setAttribute('href', 'tel:' + c.tel); });
    root.querySelectorAll('[data-vg="phone"]').forEach(function (e) { e.textContent = c.phone; });
    root.querySelectorAll('[data-vg="waphone"]').forEach(function (e) { e.textContent = c.waDisplay; });
    root.querySelectorAll('[data-vg="email"]').forEach(function (e) { e.textContent = c.email || MAIL; });
    root.querySelectorAll('[data-vg="mailto"]').forEach(function (a) { a.setAttribute('href', 'mailto:' + (c.email || MAIL)); });
    root.querySelectorAll('[data-vg="wa"]').forEach(function (a) {
      var t = a.getAttribute('data-vg-text');
      a.setAttribute('href', 'https://wa.me/' + c.wa + (t ? '?text=' + encodeURIComponent(t) : ''));
    });
  }
  function set(c) {
    if (!c) return;
    var changed = !cur || cur.wa !== c.wa || cur.phone !== c.phone || cur.email !== c.email;
    cur = c;
    try { localStorage.setItem(CK, JSON.stringify(Object.assign({ at: Date.now() }, c))); } catch (e) {}
    apply();
    if (changed) { try { g.dispatchEvent(new CustomEvent('vg:contact', { detail: c })); } catch (e) {} }
  }
  function refresh() {
    try {
      var c = JSON.parse(localStorage.getItem(CK) || 'null');
      if (c && c.at && Date.now() - c.at < FRESH_MS) return Promise.resolve(cur);
    } catch (e) {}
    var d = db();
    try {
      return fetch(d.url + '/rest/v1/products?select=data&id=eq.__shop', { headers: { apikey: d.key } })
        .then(function (r) { return r.ok ? r.json() : []; })
        .then(function (rows) { var sh = rows && rows[0] && rows[0].data && rows[0].data.shop; var c = fromShop(sh); if (c) set(c); return cur; }, function () { return cur; });
    } catch (e) { return Promise.resolve(cur); }
  }

  g.VGContact = {
    get: function () { return cur; },
    apply: apply, refresh: refresh, fromShop: fromShop, pretty: pretty, full: full,
    waLink: function (text) { return 'https://wa.me/' + cur.wa + (text ? '?text=' + encodeURIComponent(text) : ''); }
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { apply(); refresh(); });
  else { apply(); refresh(); }
})(window);

/* VG LIVE TRY-ON (test) -- d17.58, shop 6 Oct.
   The camera stays on and the frame follows the face. When the head turns, the picture switches between the shop's
   REAL cut-outs: 0-~20 degrees the front cut-out, ~25-55 degrees the robot's 45-degree cut-out (with its fit points),
   with a 0.1-second fade so there is no jump. Nothing is invented: every angle shown is a studio photo of the frame.
   Only for the shop while testing: open the shop with ?live=1 (this tab only); ?live=0 ends it. */
(function (g) {
  'use strict';
  try { if (/[?&]live=1\b/.test(g.location.search)) g.sessionStorage.setItem('vg_live', '1'); if (/[?&]live=0\b/.test(g.location.search)) g.sessionStorage.setItem('vg_live', '0'); } catch (e) {}
  /* d17.59 (shop: "set the entire flow first"): LIVE VIDEO is offered on every try-on now; ?live=0 hides it in a tab */
  function enabled() { try { return g.sessionStorage.getItem('vg_live') !== '0'; } catch (e) { return true; } }
  var FRONT_MAX = 0.30, SIDE_MIN = 0.42, FADE_MS = 100, STEP_MS = 70;
  /* d17.101 (shop, 9 Oct: "forget 30 for now -- in the live view let the frame turn with the head 10-15 degrees each way,
     with the side going back to the hair; past that we don't follow"): up to MAX_TURN degrees the front turns with the
     head (near half / far half, face form) and the real arm runs from the hinge to the ear; past it the last good picture
     is held until the head comes back. The turn is read from the skull points (eye corners, forehead, chin). */
  /* d17.121 (shop, 10 Oct: "open the window 5 degrees more and check; then 5 more, step by step, toward 30-45 -- stop
     where the problems start"): step 1 of that plan -- the frame now follows the head up to 20 degrees each way */
  /* d17.133 (shop, 11 Oct: "try for 60 -- at least 55 -- and if it is not useful we come back to 45"): 60 degrees each way by
     default. The shop can choose the limit without a new build: open the site once with ?turn=45 (or any number 15-60) and
     this phone keeps that limit; ?turn=60 goes back. */
  var MAX_TURN = (function () { try { var m = /[?&]turn=(\d+)/.exec(g.location.search); if (m) g.localStorage.setItem('vg_max_turn', m[1]); var v = Number(g.localStorage.getItem('vg_max_turn')); if (v >= 15 && v <= 60) return v; } catch (e) {} return 60; })();
  function turnOf(face) {
    var d = (face.pose && isFinite(face.pose.yaw)) ? face.pose.yaw : Math.abs(face.yaw || 0) * 55;
    S.turnS = S.turnS == null ? d : S.turnS * 0.5 + d * 0.5;          /* steadied over a couple of pictures */
    return S.turnS < 2 ? 0 : S.turnS;
  }
  var S = { on: false, p: null, video: null, stream: null, cv: null, busy: false, last: 0, zone: '', prev: null, fadeAt: 0, cuts: {}, mirror: true };
  function load(src) { return new Promise(function (res, rej) { var i = new Image(); i.crossOrigin = 'anonymous'; i.onload = function () { res(i); }; i.onerror = rej; i.src = src; }); }
  function widthMM(p) { return (typeof g.frameWidthMM === 'function') ? g.frameWidthMM(p) : 140; }
  /* d17.63: a 45 cut-out is enough -- the page finds the fit points itself when the robot stored none (the robot rule's twin) */
  function has45(p) { return !!(p.tryOnAngleUrl || p.tryOnAngleRUrl); }   /* d17.144: the 90-degree photo is not used */
  async function prepare(p) {
    var c = {};
    var front = (typeof g.tryOnURL === 'function') ? g.tryOnURL(p) : p.tryOnUrl;
    /* d17.141 (shop: "the camera has to work very smoothly"): the frame's pictures are fetched all at once, not one by one */
    var none = function () { return null; };
    var got = await Promise.all([load(front), p.tryOnAngleUrl ? load(p.tryOnAngleUrl).catch(none) : null, p.tryOnAngleRUrl ? load(p.tryOnAngleRUrl).catch(none) : null]);
    c.frontImg = got[0]; c.front = g.VGOnFace.cutout(got[0], { alreadyCut: true, fullRim: /full/i.test(String(p.rim || '')) });
    if (got[1]) c.a = got[1]; if (got[2]) c.b = got[2];
    /* d17.65: the TEMPLE from the side (90) cut-out -- the real thick arm, to swing out when the head turns */
    /* d17.69: BOTH 90 photos when the shop took two (left temple, right temple) -- each side gets its own arm, logo the right way round */
    /* d17.89: the real arm for the front view, from the 30-degree cut-out */
    try { var A30 = c.a || c.b; c.realArm = (A30 && g.VGOnFace.realArmFrom30) ? g.VGOnFace.realArmFrom30(A30, c.front, widthMM(p)) : null; } catch (e) { c.realArm = null; }
    /* d17.120: both 30-degree photos -> each side gets its own arm (see armFor in onface.js) */
    /* d17.123: no usable 30-degree photo -> the side from the frame's own end piece, so a side is ALWAYS there */
    if (!c.realArm && c.b && c.a) { try { c.realArm = g.VGOnFace.realArmFrom30(c.b, c.front, widthMM(p)); } catch (e) {} }   /* the other 30-degree photo */
    S.armFrom = c.realArm ? 'robot 30-degree photo' : '';
    if (!c.realArm && g.VGOnFace.armFromFront) { c.realArm = g.VGOnFace.armFromFront(c.front, widthMM(p)); if (c.realArm) S.armFrom = 'frame colour'; }
    try { if (c.realArm && c.a && c.b) { var other = g.VGOnFace.realArmFrom30(c.b, c.front, widthMM(p)); if (other && other.side !== c.realArm.side) { c.realArm.pair = {}; c.realArm.pair[c.realArm.side] = c.realArm; c.realArm.pair[other.side] = other; } } } catch (e) {}
    /* d17.144 (shop, 15 Oct: "the 90 photo is not required"): the 90-degree side photo is no longer downloaded -- the arms
       come from the 30-degree photos, so the try-on starts a little sooner */
    c.temple = null;
    return c;
  }
  /* the temple out of the side cut-out: the front is the tall slab at one end; the arm is the long low strip after it */
  function templeStrip(img) {
    if (g.VG45 && g.VG45.templeStrip) return g.VG45.templeStrip(img);          /* d17.73: one arm reader for the whole site */
    var W = img.naturalWidth, H = img.naturalHeight, c = document.createElement('canvas'); c.width = W; c.height = H;
    var x = c.getContext('2d'); x.drawImage(img, 0, 0); var d = x.getImageData(0, 0, W, H).data;
    var top = new Int16Array(W), run = new Int16Array(W), hgt = new Int16Array(W), maxH = 0;
    for (var cx = 0; cx < W; cx++) { var t = -1, bt = -1, rl = 0; for (var y = 0; y < H; y++) { var on = d[(y * W + cx) * 4 + 3] > 100; if (on) { if (t < 0) t = y; bt = y; if (rl >= 0) rl++; } else if (t >= 0 && rl > 0) { rl = -rl; } }
      top[cx] = t; run[cx] = Math.abs(rl); hgt[cx] = t < 0 ? 0 : bt - t + 1; if (hgt[cx] > maxH) maxH = hgt[cx]; }
    if (maxH < 10) return null;
    /* the front slab is the tall block at ONE end (the first 30% or the last 30% of the width) */
    var tall = function (i) { return hgt[i] >= maxH * 0.6; };
    var leftTall = 0, rightTall = 0; for (var i = 0; i < Math.round(W * 0.3); i++) { if (tall(i)) leftTall++; if (tall(W - 1 - i)) rightTall++; }
    var dir = leftTall >= rightTall ? 1 : -1;                     /* +1: slab on the left, arm runs to the right */
    var e = dir > 0 ? 0 : W - 1; while (e >= 0 && e < W && tall(e)) e += dir;        /* first column past the slab */
    var a0 = dir > 0 ? e : 0, a1 = dir > 0 ? W : e + 1;
    /* the arm = the TOP run of each arm column (the second, lower arm of an opened frame is left out) */
    var cols = []; for (var k = a0; k < a1; k++) if (hgt[k] > 0 && run[k] > 0) cols.push(k);
    if (cols.length < 10) return null;
    /* d17.72 (VG-1019): the arm's thickness is read along its MIDDLE (the hinge end carries the nose pad and rims hanging
       below it), and every column is kept to that thickness (+60%), so a pad or the bent tip never makes the arm a block */
    var mid = cols.slice(Math.round(cols.length * 0.25), Math.max(Math.round(cols.length * 0.25) + 3, Math.round(cols.length * 0.65))).map(function (k) { return run[k]; }).sort(function (p, q) { return p - q; });
    var thick = mid.length ? mid[mid.length >> 1] : 0, lim = Math.max(3, Math.round(thick * 1.6));
    var rk = function (k) { return Math.min(run[k], lim); };
    var y0 = H, y1 = 0; cols.forEach(function (k) { if (top[k] < y0) y0 = top[k]; if (top[k] + rk(k) > y1) y1 = top[k] + rk(k); });
    var out = document.createElement('canvas'); out.width = cols[cols.length - 1] - cols[0] + 1; out.height = Math.max(2, y1 - y0); var ox = out.getContext('2d');
    cols.forEach(function (k) { ox.drawImage(c, k, top[k], 1, rk(k), k - cols[0], top[k] - y0, 1, rk(k)); });
    var hc = dir > 0 ? cols.slice(0, Math.max(3, Math.round(cols.length * 0.08))) : cols.slice(-Math.max(3, Math.round(cols.length * 0.08)));
    var ht = hc.map(function (k) { return top[k]; }).sort(function (p, q) { return p - q; });
    return { canvas: out, hingeFirst: dir > 0, slabH: maxH, thickPx: thick || out.height, lenPx: out.width, hingeYpx: (ht.length ? ht[ht.length >> 1] : y0) - y0 + (thick || 2) / 2 };
  }
  /* d17.65 THE HYBRID SIDE VIEW (shop: "the front sits on the nose -- add the side to it and let it move with me"):
     the front cut-out stays where the front engine put it (on the nose), and the REAL temple from the side photo swings
     out from the near hinge towards the ear as the head turns; the far temple stays hidden behind the head. */
  function drawTemple(canvas, dbg, face, p, temple) {
    var r = dbg && dbg.frameRect; if (!r || !temple) return;
    var yaw = face.yaw || 0, a = Math.abs(yaw); if (a < 0.12) return;
    var th = Math.min(35 * Math.PI / 180, a * (Math.PI / 4) / 0.9);                   /* d17.66 (shop): we show up to about 35 degrees, no further */
    var nearRight = yaw > 0;                                                             /* nose points left -> the near side is the right of the picture */
    var hx = r.cx + (nearRight ? 1 : -1) * r.w * 0.49, hy = r.cy - r.h * 0.30;          /* the hinge: outer top corner of the near rim */
    var mmppFront = (typeof g.frameWidthMM === 'function' ? (g.frameWidthMM(p) || 0) : 0) / r.w || (p.size && p.size.lens ? (2 * Number(p.size.lens) + Number(p.size.bridge || 18) + 11) / r.w : 135 / r.w);   /* d17.86: the same front width as the try-on */   /* mm per picture px of the frame */
    var templeMM = Number(p.size && p.size.temple) || 140;
    var lenPx = templeMM / mmppFront * Math.sin(th) * 0.92;                              /* foreshortened by the turn, a little inside the ear */
    /* d17.66 (shop): the temple goes back as far as the HAIR (the temple point at eye level), not all the way to the ear */
    var hairPt = nearRight ? (face.templeL || face.cheekL) : (face.templeR || face.cheekR);
    if (hairPt && hairPt.x != null) { var toHair = Math.abs(hairPt.x - hx) * 1.08; if (toHair > 10) lenPx = Math.min(lenPx, toHair); }
    var drop = (nearRight ? face.pupilL : face.pupilR); var dy = drop && drop.y != null ? (drop.y - hy) * 0.6 : r.h * 0.12;   /* down to the ear's top */
    var drawDir = nearRight ? 1 : -1;
    var pick = pickTemple(temple, drawDir); if (!pick) return;
    var thickPx = (pick.t.thickPx / pick.t.slabH) * r.h * 1.15;                         /* the arm's real thickness, from the side photo */
    var x = canvas.getContext('2d'); x.save(); x.translate(hx, hy); x.rotate(r.roll + Math.atan2(dy, lenPx) * (nearRight ? 1 : -1));
    x.globalAlpha = 0.96;
    if (g.VG45 && g.VG45.paintTemple) g.VG45.paintTemple(x, pick, drawDir, lenPx, thickPx, 0.8);   /* d17.73: true thickness, fades only over the last fifth */
    else paintTemple(x, pick, drawDir, lenPx, thickPx, 0.8);
    x.restore();
    S.lastTemple = { mirrored: pick.mirror, drawDir: drawDir };
  }
  /* the twins of VG45.pickTemple / paintTemple, for a page without try45.js */
  function pickTemple(temples, drawDir) {
    var list = Array.isArray(temples) ? temples.filter(Boolean) : (temples ? [temples] : []);
    if (!list.length) return null;
    for (var i = 0; i < list.length; i++) if ((list[i].hingeFirst ? 1 : -1) === drawDir) return { t: list[i], mirror: false };
    return { t: list[0], mirror: true };
  }
  function paintTemple(ctx, pick, drawDir, len, thick, fadeFrom) {
    var t = pick.t, photoDir = t.hingeFirst ? 1 : -1, cw = t.canvas.width, ch = t.canvas.height;
    var ky = Math.max(0.05, thick / Math.max(1, t.thickPx || ch));
    var tmp = document.createElement('canvas'); tmp.width = Math.max(2, Math.round(len)); tmp.height = Math.max(2, Math.round(ch * ky));
    var sw = Math.max(2, Math.round(cw * 0.62)), sx = photoDir > 0 ? 0 : cw - sw;
    var tx = tmp.getContext('2d'); tx.drawImage(t.canvas, sx, 0, sw, ch, 0, 0, tmp.width, tmp.height);
    var gr = photoDir > 0 ? tx.createLinearGradient(0, 0, tmp.width, 0) : tx.createLinearGradient(tmp.width, 0, 0, 0);
    gr.addColorStop(0, 'rgba(0,0,0,1)'); gr.addColorStop(fadeFrom, 'rgba(0,0,0,1)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
    tx.globalCompositeOperation = 'destination-in'; tx.fillStyle = gr; tx.fillRect(0, 0, tmp.width, tmp.height);
    if (pick.mirror) ctx.scale(-1, 1);
    var hy = (t.hingeYpx != null ? t.hingeYpx : (t.thickPx || ch) / 2) * ky;
    ctx.drawImage(tmp, photoDir > 0 ? 0 : -tmp.width, -hy);
  }

  /* one picture: the face in `src` (a canvas or image), the zone it is in, and the frame drawn on it */
  async function step(src, p, cuts, frontRef, given) {
    var face = given !== undefined ? given : await g.VGOnFace.findFace(src, { runs: 1 });
    if (!face || face.estimated) return { zone: 'none' };
    var turn = turnOf(face), nearRight = (face.yaw || 0) > 0;
    if (turn > MAX_TURN + 0.5 && S.lastOut) return { zone: 'hold', canvas: S.lastOut, face: face, turnDeg: turn };   /* d17.101: past the limit -- hold */
    var zone = 'front';                                                   /* d17.101: the turned front replaces the old side switch */
    var out = null;
    /* d17.64: THE FRAME'S SIZE ON A TURNED FACE comes from the same face seen STRAIGHT a moment ago (the front rule:
       iris = 12 mm), carried over by the face's length, which a turn does not shorten. Without it the side view guessed
       the scale from a half-turned iris and drew the frame far too big, off the nose. */
    /* d17.87: with the face locked, the turned views carry the LOCKED scale, not one picture's iris */
    if (zone === 'front' && S.perMMNow > 0) { S.frontFace = face; S.frontPerMM = S.perMMNow; }
    else if (zone === 'front' && face.irisUsed && face.irisPx > 0) { S.frontFace = face; S.frontPerMM = g.VG45 ? g.VG45.perMMFromFace(face) : 0; }
    var ref = frontRef ? Object.assign({}, frontRef) : {};
    if (S.frontFace && S.frontPerMM > 0) { ref.face = S.frontFace; ref.perMM = S.frontPerMM; }
    if (zone === 'side' && cuts.temple) {
      /* the hybrid: front on the nose + the real temple swinging out */
      var dbg = {}; var o2 = g.VGOnFace.compose(src, face, cuts.front, widthMM(p), { drawSyntheticArms: false, debug: dbg, perMM: S.perMMNow > 0 ? S.perMMNow : undefined });
      out = o2 && (o2.canvas || o2);
      if (out) try { drawTemple(out, dbg, face, p, cuts.temple); } catch (e) {}
    }
    if (!out && zone === 'side' && g.VG45) {
      var sizes = { lens: p.size && p.size.lens, bridge: p.size && p.size.bridge };
      var tries = [[cuts.a, p.tryOnAngleFit], [cuts.b, p.tryOnAngleRFit]];
      for (var i = 0; i < tries.length && !out; i++) {
        if (!tries[i][0]) continue;
        var r = g.VG45.fit45({ faceImg: src, face: face, cutImg: tries[i][0], fit: tries[i][1], frontRef: ref, sizes: sizes });
        if (r && r.canvas) out = r.canvas;
      }
      if (!out) zone = 'front';
    }
    if (!out) { var dbgF = {}; var o = g.VGOnFace.compose(src, face, cuts.front, widthMM(p), { drawSyntheticArms: false, perMM: S.perMMNow > 0 ? S.perMMNow : undefined,
      armsToHair: !!cuts.realArm, realArm: cuts.realArm || undefined, turnDeg: Math.min(turn, MAX_TURN), turnNearRight: nearRight, templeMM: Number(p.size && p.size.temple) || 140, debug: dbgF });
      out = o && (o.canvas || o); S.lastDbg = dbgF; }        /* d17.89: front view with the real arm; d17.101: turned with the head */
    if (out) S.lastOut = out;
    return { zone: zone, canvas: out, face: face, turnDeg: Math.min(turn, MAX_TURN) };
  }

  /* d17.87 THE FACE LOCK: measured over the first second (eyes open, straight on), then locked -- see VGOnFace.faceLock */
  /* d17.115 (shop, 10 Oct: "check the actual size -- this looks a little bigger, and the size keeps changing: 115-123, before
     131-139, 125-133, 120-128"): the live camera measured the face afresh every time, on a small picture at arm's length
     where the coloured part of the eye is only 6-8 dots across -- one dot off is 12-15% off in size. Now:
       1. the customer's own front photo (taken close, sharp) gives the measurement when there is one -- the SAME numbers
          as the photo try-on, every time, no waiting;
       2. the live camera still measures (on a 2x sharper picture) as a check: when it disagrees with the photo by more
          than 12% it is someone else in front of the camera, and the live measurement is used for them instead;
       3. no photo: measured live on the sharper picture, as before; within one visit the same measurement is kept. */
  function selfieLock() {
    try {
      var s = JSON.parse(g.localStorage.getItem('vg_selfie') || 'null'), f = s && s.face; if (!f || f.estimated) return null;
      var k = g.VGOnFace.faceLock({}); for (var i = 0; i < 15; i++) k.add(f, Date.now());
      return k.locked() ? k.lock() : null;
    } catch (e) { return null; }
  }
  function visitLock() {
    try { var L = JSON.parse(g.sessionStorage.getItem('vg_face_lock') || 'null'); return (L && L.from === 'live' && Date.now() - (Number(L.at) || 0) < 30 * 60 * 1000) ? L : null; } catch (e) { return null; }
  }
  function saveLock(from) {
    try { g.sessionStorage.setItem('vg_face_lock', JSON.stringify(Object.assign(S.lock.lock(), { at: Date.now(), from: from }))); } catch (e) {}
  }
  function lockStep(face) {
    if (!S.lock && g.VGOnFace.faceLock) {
      var pdK = (typeof g.knownPD === 'function') ? g.knownPD() : 0;
      S.lock = g.VGOnFace.faceLock({ pdMM: pdK }); S.lockFrom = 'live'; S.check = null; S.photoLock = null;
      if (!pdK) {                                           /* a typed PD is exact: it is always measured with */
        var SL = selfieLock(), VL = SL ? null : visitLock();
        if (SL && S.lock.restore(SL)) { S.lockFrom = 'photo'; S.photoLock = SL; S.check = g.VGOnFace.faceLock({}); S.lockShown = false; }
        else if (VL && S.lock.restore(VL)) { S.lockFrom = 'visit'; }
      }
    }
    if (!S.lock) { S.perMMNow = 0; return; }
    /* the check: is the face in front of the camera the one in the photo? */
    if (S.check && !S.check.locked() && face && !gateHint(face)) {
      S.check.add(face, Date.now());
      if (S.check.locked()) {
        var a = S.check.lock(), b = S.photoLock, d = (a && b && b.pd > 0) ? Math.abs(a.pd / b.pd - 1) : 0;
        S.checkDiff = +(d * 100).toFixed(1);
        if (d > 0.12) { S.lock.reset(); S.lock.restore(a); S.lockFrom = 'live (not the person in the photo)'; S.adviceFor = ''; }
      }
    }
    var was = S.lock.locked();
    /* d17.88 THE OVAL: measuring only counts while the face sits in the oval at a good distance, straight, eyes open */
    S.hint = was ? '' : gateHint(face);
    if (face && !S.hint) S.lock.add(face, Date.now());
    else if (face && !face.estimated) S.lock.add(Object.assign({}, face, { eyeOpen: 0 }), Date.now());   /* seen, not measured */
    S.perMMNow = face ? S.lock.perMM(face) : 0;
    if (!was && S.lock.locked()) {
      saveLock('live');
      S.adviceFor = '';
    }
    if (S.lock.locked() && face && S.p && S.cuts && S.cuts.front && S.adviceFor !== S.p.id) advise(face);
  }
  /* the size advice, ONCE per frame from the locked measurement -- it does not change while the customer moves.
     d17.88: in plain words, the customer's own frame size beside it, and their own glasses first when they gave them */
  function advise(face) {
    S.adviceFor = S.p.id; var el = document.getElementById('vgLiveFit'); if (!el) return;
    try {
      var r = (typeof g.glassesFit === 'function' && g.glassesFit(S.p)) || g.VGOnFace.fitReport(face, S.cuts.front, widthMM(S.p), { perMM: S.perMMNow });
      S.advice = r; el.hidden = !r; if (!r) return;
      var word = typeof g.fitWord === 'function' ? g.fitWord(r.status) : r.status;
      var mine = '', gl = typeof g.myGlasses === 'function' ? g.myGlasses() : null;
      if (gl) mine = 'Your size ' + gl.lens + '\u25a1' + gl.bridge;
      else if (r.faceMM && typeof g.vgYourSize === 'function') { var ys = g.vgYourSize(r.faceMM); if (ys) mine = 'Your size: ' + ys.text; }   /* d17.90: a range */
      el.textContent = word + (mine ? ' \u00b7 ' + mine : '') + (S.lockFrom === 'photo' ? ' (from your photo)' : '');
      if (S.armFrom === 'frame colour') el.textContent += ' \u00b7 side: frame colour';   /* d17.123: tells the shop this frame has no usable 30-degree photo */   /* d17.115: where the size comes from */
      el.className = 'vgl-fit ' + (/^GOOD/.test(r.status) ? 'ok' : 'chk');
    } catch (e) { el.hidden = true; }
  }
  /* what to tell the customer while measuring (empty = all good, measuring) */
  /* d17.114 (shop, 10 Oct: "nothing keeps the phone at ARM'S LENGTH, and the oval does nothing -- even when the face is not
     in the centre the video starts"): the frame comes on only when the face sits IN THE OVAL with the phone at arm's length
     (the face then fills about 13-27% of the picture's width); until then the camera shows the oval and one line saying
     what to do. Once measured, it stays on while the face stays roughly in place (looser limits, so a turn of the head does
     not switch it off); a face far off-centre or the phone pulled close brings the oval back. */
  /* d17.117 (shop, 10 Oct, live screenshot: "the picture is very small, the round is ugly and the frame does not come --
     with live video we don't need the round; it is needed only for the ear and temple points for the side"): no oval and
     no arm's-length rule any more. The face finder reads the temple and ear points anywhere in the picture; all it needs
     is BOTH SIDES OF THE HEAD IN THE PICTURE. So the frame comes on whenever the face is seen with both temples and both
     ear points inside the picture, at any normal selfie distance; otherwise one short line says what to do. */
  function placeHint(face, strict) {
    if (!face || face.estimated) return 'Look at the camera';
    var W = face.w || 0, frac = W ? (face.faceW || 0) / W : 0.4, m = W * 0.015;
    var xs = [face.templeR, face.templeL, face.cheekR, face.cheekL].filter(function (q) { return q && isFinite(q.x); }).map(function (q) { return q.x; });
    if (W && xs.length && (Math.min.apply(null, xs) < m || Math.max.apply(null, xs) > W - m)) return 'Move back a little \u2014 keep both sides of your head in view';
    if (frac > 0.9) return 'Move back a little \u2014 keep both sides of your head in view';
    if (frac && frac < (strict ? 0.14 : 0.10)) return 'Come a little closer';
    return '';
  }
  function gateHint(face) {
    var ph = placeHint(face, true); if (ph) return ph;
    if (Math.abs(face.yaw || 0) > 0.12) return 'Look straight at the camera';
    if (Math.abs(face.roll || 0) > 0.143) return 'Hold your head straight';   /* d17.98: full tilt now; 0.143 = the old 0.10 */
    if (face.eyeOpen != null && face.eyeOpen < 0.18) return 'Keep your eyes open';
    return '';
  }
  function lockLabel(zone) {
    var lbl = document.getElementById('vgLiveLbl'), ov = document.getElementById('vgLiveOval'), hint = document.getElementById('vgLiveHint');
    if (!S.lock) return;
    if (S.holdShown) return;                              /* d17.146: the big "Turn back a little" card stays while past the limit */
    var locked = S.lock.locked(), pct = Math.round(S.lock.progress() * 100);
    if (lbl && !locked) lbl.textContent = 'MEASURING YOUR FACE ' + pct + '%';
    /* d17.115: measured from the photo, but the face has not yet been in the oval at arm's length -- the oval stays up */
    if (locked && !S.placedOnce && ov) { ov.hidden = false; ov.className = 'vgl-oval'; setHint((S.gate && S.gate !== 'none' && S.gate !== 'measuring') ? S.gate : 'Look at the camera'); if (lbl) lbl.textContent = 'LOOK AT THE CAMERA'; S.ovDoneAt = 0; return; }
    if (ov) {
      if (!locked) { ov.hidden = false; ov.className = 'vgl-oval' + (S.hint ? '' : ' ok'); setHint(S.hint || ('Hold still \u2014 measuring ' + pct + '%')); S.ovDoneAt = 0; }
      else if (!ov.hidden) { if (!S.ovDoneAt) { S.ovDoneAt = Date.now(); ov.className = 'vgl-oval ok'; setHint('Measured'); } else if (Date.now() - S.ovDoneAt > 2400) ov.hidden = true; }
    }
  }
  function draw(res) {
    var cv = S.cv, x = cv.getContext('2d'), now = performance.now();
    if (!res.canvas) return;
    if (cv.width !== res.canvas.width || cv.height !== res.canvas.height) { cv.width = res.canvas.width; cv.height = res.canvas.height; }
    if (res.zone !== S.zone && S.zone && S.prev) S.fadeAt = now;           /* the view changed: fade from the last picture */
    S.zone = res.zone;
    x.save(); if (S.mirror) { x.translate(cv.width, 0); x.scale(-1, 1); }
    var k = S.fadeAt ? Math.min(1, (now - S.fadeAt) / FADE_MS) : 1;
    if (k < 1 && S.prev) { x.globalAlpha = 1; x.drawImage(S.prev, 0, 0, cv.width, cv.height); x.globalAlpha = k; }
    x.drawImage(res.canvas, 0, 0, cv.width, cv.height); x.restore();
    if (k >= 1) S.fadeAt = 0;
    var keep = document.createElement('canvas'); keep.width = cv.width; keep.height = cv.height; keep.getContext('2d').drawImage(res.canvas, 0, 0); S.prev = keep;
    var lbl = document.getElementById('vgLiveLbl'); if (lbl) lbl.textContent = res.zone === 'hold' ? 'TURN BACK A LITTLE' : (res.turnDeg >= 3 ? 'SIDE LOOK' : 'FRONT');
    var ovH = document.getElementById('vgLiveOval');
    if (res.zone === 'hold' && ovH) { ovH.hidden = false; setHint('turn back'); S.holdShown = true; }
    else if (S.holdShown && ovH) { ovH.hidden = true; S.holdShown = false; }
  }
  async function ensureMesh() {
    if (S.mesh) return S.mesh;
    if (typeof g.FaceMesh === 'undefined' && g.loadFaceMesh) { try { await g.loadFaceMesh(); } catch (e) {} }
    if (typeof g.FaceMesh === 'undefined') return null;
    var m = new g.FaceMesh({ locateFile: function (f) { return (g.FACEMESH_BASE || 'https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh@0.4/') + f; } });
    m.setOptions({ maxNumFaces: 1, refineLandmarks: true, minDetectionConfidence: 0.5, minTrackingConfidence: 0.5 });
    m.onResults(function (r) { S.lm = (r && r.multiFaceLandmarks && r.multiFaceLandmarks[0]) || null; });
    try { if (m.initialize) await m.initialize(); } catch (e) {}
    S.mesh = m;
    if (S.camProblem === 'net') { var blN = document.getElementById('vgLiveBlocked'); if (blN) blN.hidden = true; S.camProblem = ''; }   /* d17.146: it came after all */
    return m;
  }
  function drawRaw(f) {                                   /* no face yet: still show the camera, never a black screen */
    var cv = S.cv, x = cv.getContext('2d');
    if (cv.width !== f.width || cv.height !== f.height) { cv.width = f.width; cv.height = f.height; }
    x.save(); if (S.mirror) { x.translate(cv.width, 0); x.scale(-1, 1); } x.drawImage(f, 0, 0); x.restore();
  }
  async function loop() {
    if (!S.on) return;
    var now = performance.now();
    if (!S.busy && now - S.last >= STEP_MS && S.video.readyState >= 2 && S.video.videoWidth > 0) {
      S.busy = true; S.last = now;
      try {
        var f = S.frame || (S.frame = document.createElement('canvas'));
        /* d17.117 (shop: "the picture is very small"): many phones send the front camera sideways-wide (4:3 landscape), which
           showed as a thin strip in the middle of the screen. The middle of it is cut to an upright 3:4 picture, so the
           camera fills the screen's width and the face is big. */
        var vw = S.video.videoWidth, vh = S.video.videoHeight, cw = vw > vh ? Math.round(vh * 3 / 4) : vw, sx = Math.round((vw - cw) / 2);
        /* d17.126 (shop, 11 Oct: "when the camera opens, why is my face not in the centre?"): the phone's front camera sends a
           wide picture and only its middle part (upright 3:4) is shown -- with a 16:9 camera that is just 42% of the width, so
           a face a little to one side was cut off at the edge. Now the shown part FOLLOWS THE FACE: it slides smoothly so the
           face stays in the middle (and drifts back to the centre when no face is seen). */
        if (cw < vw) { var ccx = S.cropCx == null ? 0.5 : S.cropCx; sx = Math.max(0, Math.min(vw - cw, Math.round(ccx * vw - cw / 2))); }
        S.cropSx = sx;
        f.width = cw; f.height = vh; f.getContext('2d').drawImage(S.video, sx, 0, cw, vh, 0, 0, cw, vh); S.crop = { vw: vw, vh: vh, cw: cw };
        var face = null;
        if (S.mesh) {                                   /* d17.146: the face is followed (and measured) while the frame is still loading */
          var sm = S.small || (S.small = document.createElement('canvas')); var meas = !(S.lock && S.lock.locked()) || (S.check && !S.check.locked()), k = Math.min(1, (meas ? 960 : 480) / f.width); S.detW = Math.round(f.width * k);   /* d17.115: a 2x sharper picture while measuring */ sm.width = Math.round(f.width * k); sm.height = Math.round(f.height * k);
          sm.getContext('2d').drawImage(f, 0, 0, sm.width, sm.height);
          S.lm = null; await S.mesh.send({ image: sm });
          if (S.lm) face = g.VGOnFace.faceFromLandmarks(S.lm, f.width, f.height, false);
          if (cw < vw) {
            var nP = face && (face.noseSeat || face.bridge), nowC = performance.now();
            if (nP && isFinite(nP.x)) { var tgt = (sx + nP.x) / vw; if (S.cropCx == null) S.cropCx = tgt; else if (Math.abs(tgt - S.cropCx) * vw > 0.03 * cw) S.cropCx += (tgt - S.cropCx) * 0.3; S.noFaceAt = 0; }
            else { if (!S.noFaceAt) S.noFaceAt = nowC; if (nowC - S.noFaceAt > 1500 && S.cropCx != null) S.cropCx += (0.5 - S.cropCx) * 0.1; }
          }
          if (face && isFinite(face.roll)) { S.rollS = S.rollS == null ? face.roll : S.rollS * 0.6 + face.roll * 0.4; face.roll = S.rollS; }   /* d17.98: the tilt is read in full now -- on the moving camera it is steadied over a few pictures */
        }
        /* d17.139: how dark the picture is (once a second), and how long no face has been seen -> the tips card */
        if (now - (S.darkAt || 0) > 1000) { S.darkAt = now; try { var dk = S.dk || (S.dk = document.createElement('canvas')); dk.width = 16; dk.height = 16; var dx = dk.getContext('2d', { willReadFrequently: true }); dx.drawImage(f, 0, 0, 16, 16); var dd = dx.getImageData(0, 0, 16, 16).data, sum = 0; for (var di = 0; di < dd.length; di += 4) sum += dd[di] * 0.3 + dd[di + 1] * 0.59 + dd[di + 2] * 0.11; S.dark = sum / 256 < 55; } catch (e) {} }
        var frameReady = !!(S.cuts && S.cuts.front);
        if (face || !frameReady) S.noFaceSince = 0; else if (S.mesh && !S.noFaceSince) S.noFaceSince = now;
        lockStep(face);
        /* d17.146 (audit: a slow frame picture said "We can't see your face"): while this frame's picture is still coming,
           the camera shows and the card says the frame is loading -- or that it could not load */
        if (S.mesh && !frameReady) {
          drawRaw(f); var ovL = document.getElementById('vgLiveOval'), lbL = document.getElementById('vgLiveLbl');
          if (ovL) { ovL.hidden = false; setHint(S.frameFailed ? 'frame failed' : 'loading frame'); } if (lbL) lbL.textContent = S.frameFailed ? 'PICK ANOTHER FRAME' : 'LOADING\u2026';
          S.busy = false; if (S.on) requestAnimationFrame(loop); return;
        }
        /* d17.114: the frame only once the face is in the oval at arm's length (measuring), and while it stays in place */
        var locked = !!(S.lock && S.lock.locked()), place = face ? (locked ? placeHint(face, !S.placedOnce) : (S.hint || 'measuring')) : 'none';
        if (locked && face && !place) S.placedOnce = true;   /* d17.115: measured from the photo -- the frame still comes on only once the face is in the oval at arm's length */
        if (face && place){
          drawRaw(f);
          var ovP = document.getElementById('vgLiveOval'), hiP = document.getElementById('vgLiveHint'), lbP = document.getElementById('vgLiveLbl');
          if (locked){ if (ovP){ ovP.hidden = false; ovP.className = 'vgl-oval'; } setHint(place); if (lbP) lbP.textContent = 'LOOK AT THE CAMERA'; S.ovDoneAt = 0; }
          else { try { lockLabel('none'); } catch (e) {} }
          S.gate = place; S.busy = false; if (S.on) requestAnimationFrame(loop); return;
        }
        S.gate = '';
        var res = face ? await step(f, S.p, S.cuts, S.frontRef, face) : { zone: 'none' };
        if (res.zone === 'none' || !res.canvas) { drawRaw(f); try { lockLabel('none'); } catch (e) {} var lb = document.getElementById('vgLiveLbl'); if (lb && !S.camProblem) lb.textContent = S.mesh ? 'LOOK AT THE CAMERA' : 'STARTING\u2026';
          if (!S.mesh) { var ovS = document.getElementById('vgLiveOval'); if (ovS) { ovS.hidden = false; setHint('loading'); } }
          else if (!face && S.noFaceSince && now - S.noFaceSince > 1500) showTips(); }
        else { draw(res); lockLabel(res.zone); var note = document.getElementById('vgLiveNote'); if (note) { note.hidden = true;   /* d17.101: every frame turns with the head now */ } }
      } catch (e) {}
      S.busy = false;
    }
    requestAnimationFrame(loop);
  }
  /* d17.139 (shop, 14 Oct: "the try-on is a success -- now make the live video page up to the mark, a completely different
     look, and when the face cannot be made out GUIDE them properly, in big words"): a new full-screen page. The camera fills
     the screen; a big coaching card says in plain words what to do (with a picture), and turns into three simple tips when the
     face is not seen at all; a camera that will not start gets its own page with the steps for iPhone and Android and a
     "use a photo instead" way out; the frames, the size and the buttons sit on a light-blue sheet at the bottom. */
  var ICONS = {
    face: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><circle cx="9" cy="10" r=".6" fill="currentColor"/><circle cx="15" cy="10" r=".6" fill="currentColor"/><path d="M9 15c1.7 1.4 4.3 1.4 6 0"/></svg>',
    back: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="8" y="3" width="8" height="14" rx="2"/><path d="M12 21v-2M5 12H2m3 0-1.5-1.5M5 12l-1.5 1.5M19 12h3m-3 0 1.5-1.5M19 12l1.5 1.5"/></svg>',
    closer: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/><circle cx="12" cy="12" r="3"/></svg>',
    level: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 12h18"/><circle cx="12" cy="12" r="3"/><path d="M12 4v2M12 18v2"/></svg>',
    eye: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>',
    hold: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
    ok: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5 10 17 19 7"/></svg>',
    turn: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12a8 8 0 1 1-3-6.2"/><path d="M20 4v4h-4"/></svg>',
    phone: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="7" y="2" width="10" height="20" rx="2"/><path d="M11 18h2"/></svg>',
    arm: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12h18M7 8l-4 4 4 4M17 8l4 4-4 4"/></svg>',
    sun: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>',
    glasses: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="6.5" cy="14" r="3.5"/><circle cx="17.5" cy="14" r="3.5"/><path d="M10 13.5c1.2-1 2.8-1 4 0M3 13l1-5M21 13l-1-5"/></svg>',
    cam: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M23 7l-7 5 7 5V7z"/><rect x="1" y="5" width="15" height="14" rx="2"/></svg>',
    x: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>',
    share: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="M8.6 13.5l6.8 4M15.4 6.5l-6.8 4"/></svg>',
    save: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v12M7 10l5 5 5-5M5 21h14"/></svg>'
  };
  /* the raw hint -> what the customer reads: a big title, one short line, a picture */
  function coachText(h) {
    h = String(h || '');
    var m = /measuring (\d+)/i.exec(h);
    if (m) return { icon: 'hold', title: 'Hold still — measuring', sub: 'Just a second… ' + m[1] + '%', pct: +m[1], tone: 'go' };
    if (/measured/i.test(h)) return { icon: 'ok', title: '✓ Measured', sub: 'Now turn your head slowly to the left and right', tone: 'ok' };
    if (/move back/i.test(h)) return { icon: 'back', title: 'Move back a little', sub: 'Keep both ears inside the picture', tone: 'fix' };
    if (/closer/i.test(h)) return { icon: 'closer', title: 'Come a little closer', sub: 'Your face should fill the middle of the screen', tone: 'fix' };
    if (/straight at the camera/i.test(h)) return { icon: 'face', title: 'Look straight at the camera', sub: 'Keep still for a second so we can measure your face', tone: 'fix' };
    if (/head straight/i.test(h)) return { icon: 'level', title: 'Hold your head straight', sub: 'Don’t tilt it to one side', tone: 'fix' };
    if (/eyes open/i.test(h)) return { icon: 'eye', title: 'Keep your eyes open', sub: 'Look at the screen normally', tone: 'fix' };
    if (/turn back/i.test(h)) return { icon: 'turn', title: 'Turn back a little', sub: 'That’s as far as the side look goes', tone: 'fix' };
    if (/frame failed/i.test(h)) return { icon: 'glasses', title: 'This frame didn’t load', sub: 'Pick another frame below, or check your internet', tone: 'fix' };
    if (/loading frame/i.test(h)) return { icon: 'glasses', title: 'Loading the frame…', sub: 'One moment — keep looking at the camera', tone: 'go' };
    if (/loading/i.test(h)) return { icon: 'cam', title: 'Getting the try-on ready…', sub: 'Hold the phone at eye level, about an arm’s length away', tone: 'go' };
    if (/starting/i.test(h)) return { icon: 'cam', title: 'Starting your camera…', sub: 'Hold the phone at eye level, about an arm’s length away', tone: 'go' };
    return { icon: 'face', title: 'Look at the camera', sub: 'Hold the phone at eye level, about an arm’s length away', tone: 'fix' };
  }
  function setHint(h) {
    var t = coachText(h), ov = document.getElementById('vgLiveOval'); if (!ov) return;
    var hi = document.getElementById('vgLiveHint'), sb = document.getElementById('vgLiveSub'), ic = document.getElementById('vgLiveIcon'), bar = document.getElementById('vgLiveBar'), tips = document.getElementById('vgLiveTips');
    if (hi) hi.textContent = t.title; if (sb) sb.textContent = t.sub; if (ic) ic.innerHTML = ICONS[t.icon] || '';
    if (bar) { bar.hidden = t.pct == null; if (t.pct != null) bar.firstChild.style.width = Math.max(4, Math.min(100, t.pct)) + '%'; }
    if (tips) tips.hidden = true;
    ov.setAttribute('data-tone', t.tone || 'fix'); ov.classList.remove('tips');
  }
  /* no face for a while: the three simple tips, big */
  function showTips() {
    var ov = document.getElementById('vgLiveOval'); if (!ov) return;
    ov.hidden = false; ov.classList.add('tips'); ov.setAttribute('data-tone', 'fix');
    var hi = document.getElementById('vgLiveHint'), sb = document.getElementById('vgLiveSub'), ic = document.getElementById('vgLiveIcon'), bar = document.getElementById('vgLiveBar'), tips = document.getElementById('vgLiveTips');
    if (hi) hi.textContent = 'We can’t see your face — look at the camera'; if (sb) sb.textContent = ''; if (ic) ic.innerHTML = ICONS.face; if (bar) bar.hidden = true;
    if (tips) { tips.hidden = false;
      var rows = [['phone', 'Hold the phone at eye level'], ['arm', 'About an arm’s length away'], ['sun', S.dark ? 'Too dark — face a light or a window' : 'Face the light, not a window behind you'], ['glasses', 'Take off your own glasses']];
      tips.innerHTML = rows.map(function (r) { return '<li><i>' + ICONS[r[0]] + '</i><span>' + r[1] + '</span></li>'; }).join(''); }
  }
  /* d17.140 (shop, 14 Oct: "if the camera is live don't tell them to allow access -- only when it is not"): each camera
     problem gets its own page and its own words. "Allow the camera" ONLY when the customer (or the phone) said no to the
     camera; a camera in use by another app, no camera, an app's built-in browser that cannot open cameras, or a camera that
     never starts each say what is really wrong. */
  var CAM_PAGES = {
    denied: { t: 'Allow the camera', p: 'The live try-on needs your front camera. Nothing is recorded or uploaded.',
      steps: ['<b>iPhone:</b> tap <b>aA</b> in the address bar → <b>Website Settings</b> → <b>Camera</b> → <b>Allow</b>', '<b>Android:</b> tap the <b>lock</b> by the address → <b>Permissions</b> → <b>Camera</b> → <b>Allow</b>'], retry: true },
    busy: { t: 'Your camera is in use', p: 'You are on a call, or another app is using the camera.',
      steps: ['Finish the call or close that app', 'Then tap <b>TRY AGAIN</b>'], retry: true },
    none: { t: 'No front camera found', p: 'This phone did not give us a front camera to use.', steps: [], retry: true },
    inapp: { t: 'Open in your phone’s browser', p: 'The browser inside this app cannot open the camera.',
      steps: ['Tap <b>⋮</b> or <b>•••</b> at the top', 'Choose <b>Open in Chrome</b> (Android) or <b>Open in Safari</b> (iPhone)'], retry: false },
    net: { t: 'The try-on didn’t load', p: 'Your internet seems slow or off right now.',
      steps: ['Check your mobile data or Wi-Fi', 'Then tap <b>TRY AGAIN</b>'], retry: true },
    stuck: { t: 'The camera didn’t start', p: 'Sometimes the phone needs a second try.', steps: ['Tap <b>TRY AGAIN</b>', 'If it still stays dark, close the browser and open visiongallery.me again'], retry: true }
  };
  function inApp() { var u = navigator.userAgent || ''; return /FBAN|FBAV|Instagram|Line\/|WhatsApp|Snapchat|; ?wv\)/i.test(u); }
  function camKind(e) {
    var n = (e && e.name) || '';
    if (/NotAllowed|PermissionDenied|Security/.test(n)) return 'denied';
    if (/NotReadable|TrackStart|Abort/.test(n)) return 'busy';
    if (/NotFound|DevicesNotFound|Overconstrained/.test(n)) return 'none';
    if (/NotSupported|TypeError/.test(n)) return inApp() ? 'inapp' : 'none';
    return 'stuck';
  }
  function showCamProblem(kind) {
    var c = CAM_PAGES[kind] || CAM_PAGES.stuck, bl = document.getElementById('vgLiveBlocked'); if (!bl) return;
    document.getElementById('vgLiveBTitle').textContent = c.t; document.getElementById('vgLiveBText').textContent = c.p;
    var ol = document.getElementById('vgLiveBSteps'); ol.innerHTML = c.steps.map(function (x) { return '<li>' + x + '</li>'; }).join(''); ol.hidden = !c.steps.length;
    document.getElementById('vgLiveRetry').hidden = !c.retry;
    var phB = document.getElementById('vgLivePhoto'); if (phB) phB.hidden = (kind === 'net');   /* the photo way needs the same face finder */
    var ov = document.getElementById('vgLiveOval'); if (ov) ov.hidden = true;
    var lbl = document.getElementById('vgLiveLbl'); if (lbl) lbl.textContent = 'CAMERA OFF';
    S.camProblem = kind; bl.hidden = false;
    /* d17.153: Admin -> HEALTH. A call holding the camera is the customer's side (info); the face finder not loading is a site problem */
    try { if (g.VGHealth) g.VGHealth.report('tryon-' + kind, 'Live try-on: ' + c.t, { frame: S.p && S.p.id || '' }, kind === 'busy' ? 'info' : 'problem'); } catch (e) {}
  }
  function ui() {
    var box = document.getElementById('vgLive'); if (box) return box;
    box = document.createElement('div'); box.id = 'vgLive'; box.setAttribute('role', 'dialog'); box.setAttribute('aria-label', 'Live try-on');
    box.innerHTML =
      '<canvas id="vgLiveCv"></canvas><video id="vgLiveV" playsinline muted autoplay style="position:absolute;width:2px;height:2px;opacity:0;pointer-events:none;left:0;top:0"></video>' +
      '<div class="vgl-top"><img class="vgl-logo" src="logo-vg3.svg" alt="Vision Gallery"><span class="vgl-chip" id="vgLiveLbl">STARTING…</span><button type="button" class="vgl-x" id="vgLiveX" aria-label="Close">' + ICONS.x + '</button></div>' +
      '<div class="vgl-fit" id="vgLiveFit" hidden></div>' +
      '<div class="vgl-note" id="vgLiveNote" hidden></div>' +
      '<div class="vgl-oval" id="vgLiveOval" hidden role="status" aria-live="polite"><div class="vgl-ic" id="vgLiveIcon"></div><div class="vgl-tx"><b id="vgLiveHint">Look at the camera</b><span id="vgLiveSub"></span><div class="vgl-bar" id="vgLiveBar" hidden><i></i></div><ul class="vgl-tips" id="vgLiveTips" hidden></ul></div></div>' +
      '<div class="vgl-blocked" id="vgLiveBlocked" hidden><div class="vgl-card"><div class="vgl-ic big">' + ICONS.cam + '</div><h2 id="vgLiveBTitle">Allow the camera</h2><p id="vgLiveBText"></p>' +
        '<ol id="vgLiveBSteps"></ol>' +
        '<button type="button" class="vgl-go" id="vgLiveRetry">TRY AGAIN</button><button type="button" class="vgl-line" id="vgLivePhoto">USE A PHOTO INSTEAD</button><button type="button" class="vgl-plain" id="vgLiveX2">CLOSE</button></div></div>' +
      '<div class="vgl-sheet"><div class="vgl-name"><b id="vgLiveName"></b><span id="vgLivePrice"></span></div>' +
        '<div class="vgl-strip" id="vgLiveStrip"></div>' +
        '<div class="vgl-bot"><button type="button" class="vgl-add" id="vgLiveAdd">ADD TO BASKET</button><button type="button" class="vgl-ib" id="vgLiveShare" aria-label="Share">' + ICONS.share + '<small>SHARE</small></button><button type="button" class="vgl-ib" id="vgLiveShot" aria-label="Save photo">' + ICONS.save + '<small>SAVE</small></button></div></div>';
    var css = document.createElement('style');
    css.textContent =
      '#vgLive{position:fixed;inset:0;z-index:9500;background:#1741B3;color:#fff;font-family:Manrope,system-ui,sans-serif;overflow:hidden;--sheet:212px}#vgLive[hidden]{display:none}' +
      '#vgLive canvas#vgLiveCv{position:absolute;left:0;right:0;top:0;bottom:calc(var(--sheet) - 22px);width:100%;height:calc(100% - var(--sheet) + 22px);object-fit:cover;background:#06143E}' +
      '#vgLive .vgl-top{position:absolute;left:0;right:0;top:0;display:flex;align-items:center;gap:10px;padding:calc(10px + env(safe-area-inset-top)) 14px 22px;background:linear-gradient(rgba(6,20,62,.85),rgba(6,20,62,0))}' +
      '#vgLive .vgl-logo{height:40px;width:auto;margin-right:auto}' +
      '#vgLive .vgl-chip{font-size:.72rem;font-weight:800;letter-spacing:.12em;color:#C8FF1A;background:rgba(6,20,62,.7);border:1px solid rgba(200,255,26,.5);padding:6px 11px;border-radius:99px;white-space:nowrap}' +
      '#vgLive .vgl-x{width:46px;height:46px;border-radius:50%;border:1px solid rgba(255,255,255,.35);background:rgba(6,20,62,.7);color:#fff;display:flex;align-items:center;justify-content:center;padding:0}#vgLive .vgl-x svg{width:22px;height:22px}' +
      '#vgLive .vgl-fit{position:absolute;left:50%;transform:translateX(-50%);top:calc(74px + env(safe-area-inset-top));max-width:92vw;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:.8rem;font-weight:700;padding:7px 14px;border-radius:99px;background:rgba(6,20,62,.82)}#vgLive .vgl-fit.ok{color:#9EF0B6}#vgLive .vgl-fit.chk{color:#C8FF1A}#vgLive .vgl-fit[hidden]{display:none}' +
      '#vgLive .vgl-note{position:absolute;left:50%;transform:translateX(-50%);bottom:calc(var(--sheet) + 120px);background:rgba(6,20,62,.8);font-size:.8rem;padding:6px 12px;border-radius:14px}#vgLive .vgl-note[hidden]{display:none}' +
      '#vgLive .vgl-oval{position:absolute;left:14px;right:14px;bottom:calc(var(--sheet) + 12px);display:flex;gap:14px;align-items:flex-start;padding:16px 16px 16px 14px;border-radius:22px;background:rgba(6,20,62,.9);border:2px solid #C8FF1A;box-shadow:0 10px 30px rgba(0,0,0,.35);pointer-events:none}' +
      '#vgLive .vgl-oval[hidden]{display:none}#vgLive .vgl-oval[data-tone="go"]{border-color:#8EC0F7}#vgLive .vgl-oval[data-tone="ok"]{border-color:#9EF0B6}' +
      '#vgLive .vgl-ic{flex:0 0 56px;width:56px;height:56px;border-radius:50%;background:#C8FF1A;color:#0A1F4D;display:flex;align-items:center;justify-content:center}#vgLive .vgl-ic svg{width:32px;height:32px}' +
      '#vgLive .vgl-oval[data-tone="go"] .vgl-ic{background:#8EC0F7}#vgLive .vgl-oval[data-tone="ok"] .vgl-ic{background:#9EF0B6}' +
      '#vgLive .vgl-tx{flex:1;min-width:0;display:flex;flex-direction:column;gap:5px}#vgLive .vgl-tx b{font-family:Unbounded,Manrope,sans-serif;font-size:1.32rem;line-height:1.2;font-weight:700}#vgLive .vgl-tx span{font-size:1rem;line-height:1.35;color:#D6E6FF}' +
      '#vgLive .vgl-bar{height:8px;border-radius:8px;background:rgba(255,255,255,.18);overflow:hidden;margin-top:4px}#vgLive .vgl-bar i{display:block;height:100%;width:0;background:#C8FF1A;border-radius:8px;transition:width .2s}#vgLive .vgl-bar[hidden]{display:none}' +
      '#vgLive .vgl-tips{list-style:none;margin:6px 0 0;padding:0;display:flex;flex-direction:column;gap:10px}#vgLive .vgl-tips[hidden]{display:none}#vgLive .vgl-tips li{display:flex;align-items:center;gap:12px;font-size:1.05rem;font-weight:600}' +
      '#vgLive .vgl-tips i{flex:0 0 38px;width:38px;height:38px;border-radius:12px;background:rgba(142,192,247,.18);color:#C8FF1A;display:flex;align-items:center;justify-content:center}#vgLive .vgl-tips i svg{width:22px;height:22px}' +
      '#vgLive .vgl-oval.tips .vgl-ic{display:none}' +
      '#vgLive .vgl-sheet{position:absolute;left:0;right:0;bottom:0;height:var(--sheet);box-sizing:border-box;background:#8EC0F7;color:#0A1F4D;border-radius:22px 22px 0 0;padding:14px 14px calc(12px + env(safe-area-inset-bottom));display:flex;flex-direction:column;gap:10px;box-shadow:0 -8px 24px rgba(0,0,0,.25)}' +
      '#vgLive .vgl-name{display:flex;align-items:baseline;justify-content:space-between;gap:10px}#vgLive .vgl-name b{font-family:Unbounded,Manrope,sans-serif;font-size:1rem;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}#vgLive .vgl-name span{font-family:Unbounded,Manrope,sans-serif;font-weight:700;font-size:1.05rem;color:#0A2A8C;white-space:nowrap}' +
      '#vgLive .vgl-strip{display:flex;gap:10px;overflow-x:auto;padding:4px 2px 6px;flex:0 0 auto;scrollbar-width:none}#vgLive .vgl-strip::-webkit-scrollbar{display:none}' +
      '#vgLive .vgl-strip button{flex:0 0 auto;width:78px;height:58px;padding:0;border-radius:14px;border:2px solid transparent;background:#fff;overflow:hidden;box-shadow:0 2px 6px rgba(10,31,77,.15)}#vgLive .vgl-strip button.on{border:3px solid #0A1F4D;box-shadow:0 0 0 3px #C8FF1A}#vgLive .vgl-strip img{width:100%;height:100%;object-fit:contain;display:block}' +
      '#vgLive .vgl-bot{display:flex;gap:10px;align-items:stretch;margin-top:auto}#vgLive .vgl-add{flex:1;min-height:52px;border-radius:14px;border:0;background:#0A1F4D;color:#C8FF1A;font-family:inherit;font-weight:800;font-size:.95rem;letter-spacing:.06em}' +
      '#vgLive .vgl-ib{flex:0 0 64px;min-height:52px;border-radius:14px;border:2px solid #0A1F4D;background:transparent;color:#0A1F4D;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;padding:0;font-family:inherit}#vgLive .vgl-ib svg{width:20px;height:20px}#vgLive .vgl-ib small{font-size:.6rem;font-weight:800;letter-spacing:.08em}' +
      '#vgLive .vgl-top{z-index:4}#vgLive .vgl-blocked{position:absolute;inset:0;z-index:3;background:rgba(6,20,62,.96);display:flex;align-items:center;justify-content:center;padding:20px}#vgLive .vgl-blocked[hidden]{display:none}' +
      '#vgLive .vgl-card{width:100%;max-width:420px;display:flex;flex-direction:column;gap:12px;align-items:stretch;text-align:left}#vgLive .vgl-card .vgl-ic.big{width:72px;height:72px;flex:0 0 72px;align-self:center}#vgLive .vgl-card .vgl-ic.big svg{width:40px;height:40px}' +
      '#vgLive .vgl-card h2{margin:0;text-align:center;font-family:Unbounded,Manrope,sans-serif;font-size:1.6rem}#vgLive .vgl-card p{margin:0;text-align:center;font-size:1rem;color:#D6E6FF}' +
      '#vgLive .vgl-card ol{margin:4px 0;padding-left:22px;display:flex;flex-direction:column;gap:8px;font-size:1rem;line-height:1.4}' +
      '#vgLive .vgl-go{min-height:54px;border-radius:14px;border:0;background:#C8FF1A;color:#06143E;font-weight:800;font-size:1rem;letter-spacing:.06em;font-family:inherit}' +
      '#vgLive .vgl-line{min-height:50px;border-radius:14px;border:2px solid #8EC0F7;background:transparent;color:#fff;font-weight:800;font-size:.95rem;letter-spacing:.05em;font-family:inherit}#vgLive .vgl-plain{min-height:44px;border:0;background:transparent;color:#BFD1F0;font-weight:700;font-family:inherit}' +
      '@media (max-height:640px){#vgLive{--sheet:200px}#vgLive .vgl-tx b{font-size:1.15rem}}' +
      /* d17.146 (audit: turned sideways the camera shrank to a thin band): a short screen keeps only the buttons at the bottom */
      '@media (orientation:landscape) and (max-height:520px){#vgLive{--sheet:76px}#vgLive .vgl-strip,#vgLive .vgl-name{display:none}#vgLive .vgl-sheet{padding:10px 14px calc(8px + env(safe-area-inset-bottom));border-radius:16px 16px 0 0}' +
        '#vgLive .vgl-logo{height:30px}#vgLive .vgl-top{padding-top:calc(6px + env(safe-area-inset-top));padding-bottom:10px}#vgLive .vgl-oval{left:auto;right:12px;width:min(420px,46vw);padding:10px 12px}#vgLive .vgl-tx b{font-size:1rem}#vgLive .vgl-tx span{font-size:.85rem}#vgLive .vgl-ic{flex-basis:40px;width:40px;height:40px}#vgLive .vgl-ic svg{width:24px;height:24px}#vgLive .vgl-add{min-height:46px}#vgLive .vgl-ib{min-height:46px}}';
    document.head.appendChild(css); document.body.appendChild(box);
    box.querySelector('#vgLiveX').addEventListener('click', function () { close(); });
    box.querySelector('#vgLiveX2').addEventListener('click', function () { close(); });
    box.querySelector('#vgLiveRetry').addEventListener('click', function () { if (S.p) { var p = S.p; S.retrying = true; S.stuckTries = 0; open(p, S.openOpts); } });
    box.querySelector('#vgLivePhoto').addEventListener('click', function () { if (S.camProblem === 'net') { close(); return; } toPhoto(); });
    /* d17.146 (audit: the basket opened and closed again at once): the try-on's own Back step is finished first, THEN the
       basket opens (on the frame page its own "added" panel) */
    box.querySelector('#vgLiveAdd').addEventListener('click', function () { var p = S.p; if (!p) return; try { if (g.VGBasket && !g.VGBasket.has(p.id)) g.VGBasket.add(p); } catch (e) {}
      close(false, function () { try { if (g.vgAfterAdd) g.vgAfterAdd(p); else if (g.openBasket) g.openBasket(true); } catch (e) {} }); });
    box.querySelector('#vgLiveShare').addEventListener('click', async function () {
      if (!S.cv || S.cv.width <= 300) { alert('The camera picture is not showing yet.'); return; }
      try { var blob = await new Promise(function (r) { S.cv.toBlob(r, 'image/jpeg', 0.92); }); var file = new File([blob], 'vision-gallery-tryon.jpg', { type: 'image/jpeg' });
        if (navigator.canShare && navigator.canShare({ files: [file] })) { await navigator.share({ files: [file], title: 'Vision Gallery', text: (S.p && S.p.name || 'This frame') + ' on me — what do you think?' }); return; } } catch (e) {}
      try { var a = document.createElement('a'); a.href = S.cv.toDataURL('image/jpeg', 0.92); a.download = 'vision-gallery-tryon.jpg'; a.click(); } catch (e) {}
    });
    box.querySelector('#vgLiveStrip').addEventListener('click', function (e) { var b = e.target.closest('button[data-pid]'); if (!b) return; var pp = (g.allProducts ? g.allProducts() : []).find(function (x) { return x.id === b.dataset.pid; }); if (pp) switchTo(pp); });
    g.addEventListener('popstate', function () { if (S.selfBack) { S.selfBack = false; return; } if (S.on || !box.hidden) close(true); });   /* d17.146: our own Back step never closes a try-on opened again meanwhile */
    box.querySelector('#vgLiveShot').addEventListener('click', function () {
      if (!S.cv || S.cv.width <= 300) { alert('The camera picture is not showing yet. Wait for it, then save.'); return; }
      try { var a = document.createElement('a'); a.href = S.cv.toDataURL('image/jpeg', 0.92); a.download = 'vision-gallery-tryon.jpg'; a.click(); } catch (e) {} });
    return box;
  }
  function nameLine(p) {
    var n = document.getElementById('vgLiveName'), pr = document.getElementById('vgLivePrice'); if (!n) return;
    n.textContent = (p && (p.name || p.id)) || '';
    var price = Number(p && p.price) || 0; pr.textContent = price > 0 ? '₹' + price.toLocaleString('en-IN') : '';
  }
  function strip(p) {
    var el = document.getElementById('vgLiveStrip'); if (!el) return;
    var list = (g.allProducts ? g.allProducts() : []).filter(function (x) { return x && x.url && (g.tryOnURL ? g.tryOnURL(x) : x.tryOnUrl) && x.tryOnOk !== false; });
    var i = list.findIndex(function (x) { return x.id === p.id; }); if (i > 0) { list.splice(i, 1); list.unshift(p); }
    el.innerHTML = list.slice(0, 40).map(function (x) { return '<button type="button" data-pid="' + x.id + '"' + (x.id === p.id ? ' class="on"' : '') + ' title="' + (x.name || '') + '"><img src="' + (g.vgImg ? g.vgImg(x.url, 160) : x.url) + '" alt=""></button>'; }).join('');
  }
  async function switchTo(p) {
    var tok = S.switchTok = (S.switchTok || 0) + 1;      /* d17.146: two quick taps -- a slower first picture never replaces the second */
    S.p = p; S.zone = ''; S.prev = null; S.cuts = {}; S.adviceFor = ''; S.lastOut = null; S.frameFailed = false;   /* d17.87: same face, same lock; new frame, new advice */
    var el = document.getElementById('vgLiveStrip'); if (el) el.querySelectorAll('button').forEach(function (b) { b.classList.toggle('on', b.dataset.pid === p.id); });
    nameLine(p); var fe = document.getElementById('vgLiveFit'); if (fe) fe.hidden = true;
    var c = null; try { c = await prepare(p); } catch (e) { c = null; }
    if (tok !== S.switchTok || S.p !== p) return;
    S.cuts = c || {}; S.frameFailed = !(c && c.front);
    try { S.frontRef = g.VG45 && S.cuts.frontImg ? g.VG45.frontReference(S.cuts.frontImg, { lens: p.size && p.size.lens, bridge: p.size && p.size.bridge }, null) : null; } catch (e) { S.frontRef = null; }
  }
  async function open(p, opts) {
    if (!p || !g.VGOnFace) return;
    S.openOpts = opts || S.openOpts || null;
    if (!S.retrying) { try { history.pushState({ vgLive: 1 }, ''); } catch (e) {} }
    S.retrying = false;
    var box = ui(); box.hidden = false; var bl = document.getElementById('vgLiveBlocked'); if (bl) bl.hidden = true;
    try { (S.stream && S.stream.getTracks() || []).forEach(function (t) { t.stop(); }); } catch (e) {}
    nameLine(p); S.noFaceSince = 0; S.dark = false; S.darkAt = 0; S.cv = box.querySelector('#vgLiveCv'); S.video = box.querySelector('#vgLiveV'); S.p = p; S.zone = ''; S.prev = null; S.cuts = {}; S.frontFace = null; S.frontPerMM = 0; S.lastOut = null;
    S.cropCx = null; S.noFaceAt = 0; S.lock = null; S.check = null; S.photoLock = null; S.lockFrom = ''; S.checkDiff = null; S.placedOnce = false; S.perMMNow = 0; S.adviceFor = ''; S.hint = ''; S.ovDoneAt = 0; var ov0 = document.getElementById('vgLiveOval'); if (ov0) ov0.hidden = true; var fe = document.getElementById('vgLiveFit'); if (fe) fe.hidden = true;     /* d17.87: every live session measures afresh; d17.115: or takes the customer's own photo's measurement (see lockStep) */
    strip(p);
    var lbl = document.getElementById('vgLiveLbl'); lbl.textContent = 'STARTING\u2026';
    var ovI = document.getElementById('vgLiveOval'); if (ovI) { ovI.hidden = false; setHint('starting'); }
    S.camProblem = ''; S.frameFailed = false; S.switchTok = (S.switchTok || 0) + 1; clearTimeout(S.meshT);
    var my = S.session = (S.session || 0) + 1;           /* d17.146: a close (or a new open) while the camera starts ends THIS one */
    /* d17.141: the face finder and the frame start loading NOW, side by side with the camera (they used to wait for it) */
    var prepP = prepare(p).catch(function () { return {}; }), meshP = ensureMesh().catch(function () { return null; });
    try {
      if (!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia)) throw { name: 'NotSupported' };
      try { S.stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: { ideal: 720 }, height: { ideal: 960 } }, audio: false }); }
      catch (e1) {
        /* d17.140: a phone that cannot meet the asked size, or has no camera marked "front", gets one plain second try */
        if (/Overconstrained|NotFound|NotReadable|Abort/.test((e1 && e1.name) || '')) S.stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
        else throw e1;
      }
    }
    catch (e) {
      if (my !== S.session) return;                     /* closed meanwhile */
      /* d17.141 (shop, 14 Oct: "on Lenskart I never see all these messages -- show 'your camera is in use' only when someone is
         on a call; otherwise don't show anything"): ONLY a camera held by a call / another app gets a message. Anything else
         (refused, no camera, an app's own browser) shows nothing: the customer goes quietly to the one-photo try-on. */
      S.camError = (e && e.name) || 'blocked';
      if (camKind(e) === 'busy') { showCamProblem('busy'); return; }
      quietPhoto(); return;
    }
    if (my !== S.session || box.hidden) {               /* d17.146 (audit): closed while the camera was starting -- switch it off now */
      try { S.stream.getTracks().forEach(function (t) { t.stop(); }); } catch (e) {} return;
    }
    S.video.srcObject = S.stream;
    /* d17.146 (audit: a camera that opens but sends no picture never started the 6-second check, because play() never
       finished): the check starts first, play() is not waited for */
    armStuck(my);
    try { var pl = S.video.play(); if (pl && pl.catch) pl.catch(function () {}); } catch (e) {}
    /* a call that takes the camera while the try-on is open */
    try { var vt = S.stream.getVideoTracks()[0]; if (vt) vt.onended = function () { if (S.on) showCamProblem('busy'); }; } catch (e) {}
    S.on = true; S.rollS = null; S.turnS = null; S.lastOut = null; requestAnimationFrame(loop);                     /* the camera shows at once ... */
    lbl.textContent = 'LOADING\u2026';
    /* d17.146 (audit: if the face finder never loads, the page said "Starting your camera" for ever): after 15 seconds, or
       at once when it fails, a plain "The try-on didn't load -- check your internet" with TRY AGAIN */
    S.meshT = setTimeout(function () { if (my === S.session && S.on && !S.mesh) showCamProblem('net'); }, 15000);
    var tok0 = S.switchTok, c0 = await prepP;
    if (my !== S.session) return;
    if (tok0 === S.switchTok) { S.cuts = c0 || {}; S.frameFailed = !(c0 && c0.front);
      if (S.frameFailed) try { if (g.VGHealth) g.VGHealth.report('tryon-frame', 'The try-on picture of frame ' + (p && p.id || '') + ' did not load', { frame: p && p.id || '' }); } catch (e) {}
      try { S.frontRef = g.VG45 && S.cuts.frontImg ? g.VG45.frontReference(S.cuts.frontImg, { lens: p.size && p.size.lens, bridge: p.size && p.size.bridge }, null) : null; } catch (e) { S.frontRef = null; } }
    var m0 = await meshP;                                           /* ... and the frame joins as soon as the face finder is ready */
    if (my === S.session && S.on && !m0 && !S.mesh) { clearTimeout(S.meshT); showCamProblem('net'); }
  }
  /* d17.141: the camera opened but no picture arrives within 6 seconds: a track the phone has muted is a call holding the
     camera -> "in use"; otherwise one quiet second try, and then the one-photo try-on -- no message */
  function armStuck(my) {
    clearTimeout(S.stuckT); S.stuckT = setTimeout(function () {
      if (my !== S.session || !S.on || !S.video || (S.video.videoWidth > 0 && S.video.readyState >= 2)) { S.stuckTries = 0; return; }
      var t0 = null; try { t0 = S.stream.getVideoTracks()[0]; } catch (e) {}
      if (t0 && (t0.muted || t0.readyState === 'ended')) { showCamProblem('busy'); return; }
      if (!S.stuckTries) { S.stuckTries = 1; S.retrying = true; open(S.p, S.openOpts); } else { S.stuckTries = 0; quietPhoto(); }
    }, 6000);
  }
  /* no camera for the live try-on and no call to blame: quietly to the one-photo try-on, no message */
  function quietPhoto() { g.__vgNoCam = true; try { if (g.VGHealth) g.VGHealth.report('tryon-nocam', 'Live camera not available (' + (S.camError || 'no picture') + ') -- the customer was taken to the photo try-on', { frame: S.p && S.p.id || '' }, 'info'); } catch (e) {} toPhoto(); }   /* d17.146: the photo page then offers "use a photo" and does not try the camera again */
  /* to the one-photo try-on: the try-on's Back step is finished first (it used to be blanked, so one Back did nothing) */
  function toPhoto() {
    var o = S.openOpts, p = S.p;
    close(false, function () { try { if (o && o.onPhoto) o.onPhoto(p); else if (g.vgPhotoTryOn) g.vgPhotoTryOn(p); } catch (e) {} });
  }
  /* then(): run once the browser has finished stepping back out of the try-on (or at once if there was no step) */
  function close(fromBack, then) {
    clearTimeout(S.stuckT); clearTimeout(S.meshT); S.session = (S.session || 0) + 1; S.on = false;
    try { (S.stream && S.stream.getTracks() || []).forEach(function (t) { t.stop(); }); } catch (e) {} S.stream = null;
    var b = document.getElementById('vgLive'); if (b) b.hidden = true;
    var stepping = false;
    if (!fromBack) { try { if (history.state && history.state.vgLive) {
      stepping = true; g.__vgLiveBack = true; S.selfBack = true;   /* the page's own Back handler (and ours) leave this one alone */
      if (then) { var done = false, h = function () { if (done) return; done = true; g.removeEventListener('popstate', h); g.__vgLiveBack = false; setTimeout(then, 0); };
        g.addEventListener('popstate', h); setTimeout(h, 800); }
      else setTimeout(function () { g.__vgLiveBack = false; }, 800);
      history.back(); } } catch (e) {} }
    if (then && !stepping) then();
  }
  g.VGLive = { _S: S, camKind: camKind, showCamProblem: showCamProblem, coachText: coachText, setHint: setHint, showTips: showTips, lockStep: lockStep, enabled: enabled, open: open, close: close, step: step, prepare: prepare, has45: has45, lastTemple: function () { return S.lastTemple || null; }, MAX_TURN: MAX_TURN, turnOf: turnOf, FRONT_MAX: FRONT_MAX, SIDE_MIN: SIDE_MIN };
})(window);

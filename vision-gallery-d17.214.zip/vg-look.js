/* Vision Gallery — COLOUR AND SHAPE CHECK for the Details box in TO CHECK (d17.178, shop 24 Oct: "the robot says the colour
   wrong sometimes -- give me a proper option to check the colour and the shape")

   VGLook.measure(p) -> Promise<{ colour, colour2, alt, sure, why, shapeFamily, ratio, lenses } | null>
     COLOUR, measured properly:
       - only the frame itself: the robot's front cut-out says which pixels are frame; its edge, shiny spots and deep
         shadows are left out;
       - the shop light is taken out first: the white/grey sheet around the frame in the SAME photo is neutral, so whatever
         tint it has (yellow bulb, blue daylight) is removed from the frame's colour too;
       - the colour is named the way the eye sees colour (CIE Lab), from the shop's own colour list; the second-closest name
         is given too, and "sure" only when the best is clearly closer than the next;
       - tortoise (dark and light brown patches) and two-tone (top and bottom rim different) are recognised.
     SHAPE, measured: the lens openings in the cut-out (full-rim frames): how wide against how tall, and how square the
       corners are -> "angular" (square / rectangle / wayfarer / geometric) or "rounded" (round / oval / aviator / cat eye).
   Nothing here changes the frame or its photos; it only gives the Details box its suggestions. */
(function (g) {
  'use strict';
  if (g.VGLook) return;
  /* the shop's colour names (Admin's chips) with the colour each stands for */
  var PALETTE = [
    ['Black', 26, 26, 30], ['Navy', 30, 50, 92], ['Blue', 52, 96, 152], ['Gunmetal', 78, 82, 90], ['Grey', 140, 140, 148],
    ['Silver', 190, 193, 198], ['Gold', 168, 132, 52], ['Brown', 107, 74, 42], ['Tortoise', 126, 78, 36], ['Amber', 170, 98, 38],
    ['Red', 168, 48, 48], ['Burgundy', 112, 34, 48], ['Green', 52, 110, 70], ['Purple', 98, 62, 122], ['Pink', 196, 128, 148],
    ['White', 238, 240, 243], ['Light blue', 143, 179, 217], ['Light purple', 183, 156, 207], ['Light pink', 227, 180, 196],
    ['Light grey', 196, 198, 204], ['Light green', 157, 201, 168], ['Light brown', 184, 145, 106]
  ];
  function lin(c) { c /= 255; return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); }
  function lab(r, gg, b) {
    var R = lin(r), G = lin(gg), B = lin(b);
    var X = (R * 0.4124 + G * 0.3576 + B * 0.1805) / 0.95047, Y = R * 0.2126 + G * 0.7152 + B * 0.0722, Z = (R * 0.0193 + G * 0.1192 + B * 0.9505) / 1.08883;
    var f = function (t) { return t > 0.008856 ? Math.cbrt(t) : 7.787 * t + 16 / 116; };
    var fx = f(X), fy = f(Y), fz = f(Z);
    return [116 * fy - 16, 500 * (fx - fy), 200 * (fy - fz)];
  }
  var PAL = PALETTE.map(function (c) { return { n: c[0], lab: lab(c[1], c[2], c[3]) }; });
  function de(a, b) { return Math.sqrt((a[0] - b[0]) * (a[0] - b[0]) + (a[1] - b[1]) * (a[1] - b[1]) + (a[2] - b[2]) * (a[2] - b[2])); }
  function nearest(L) {
    var s = PAL.map(function (c) { return { n: c.n, d: de(L, c.lab) }; }).sort(function (x, y) { return x.d - y.d; });
    return s;
  }
  function median(a) { if (!a.length) return 0; var b = a.slice().sort(function (x, y) { return x - y; }); return b[b.length >> 1]; }
  function pct(a, q) { if (!a.length) return 0; var b = a.slice().sort(function (x, y) { return x - y; }); return b[Math.min(b.length - 1, Math.floor(q * b.length))]; }
  function hueName(h) { /* for the light / see-through colours */
    if (h < 20 || h >= 330) return 'pink'; if (h < 70) return 'brown'; if (h < 170) return 'green'; if (h < 260) return 'blue'; return 'purple';
  }
  function load(src) { return new Promise(function (res, rej) { var i = new Image(); i.crossOrigin = 'anonymous'; i.onload = function () { res(i); }; i.onerror = rej; i.src = src; }); }

  function analyse(cutImg, srcImg) {
    var W0 = cutImg.naturalWidth || cutImg.width, H0 = cutImg.naturalHeight || cutImg.height;
    var k = Math.min(1, 520 / Math.max(W0, H0)), W = Math.max(8, Math.round(W0 * k)), H = Math.max(8, Math.round(H0 * k)), N = W * H, i, j;
    var c = document.createElement('canvas'); c.width = W; c.height = H; var x = c.getContext('2d', { willReadFrequently: true });
    x.drawImage(cutImg, 0, 0, W, H); var cd = x.getImageData(0, 0, W, H).data;
    var sd = null;
    if (srcImg) { var c2 = document.createElement('canvas'); c2.width = W; c2.height = H; var x2 = c2.getContext('2d', { willReadFrequently: true }); x2.drawImage(srcImg, 0, 0, W, H); sd = x2.getImageData(0, 0, W, H).data; }
    /* the frame: solid pixels of the cut-out, two pixels in from its edge */
    var solid = new Uint8Array(N); for (i = 0; i < N; i++) solid[i] = cd[i * 4 + 3] > 230 ? 1 : 0;
    var core = new Uint8Array(N);
    for (var y = 2; y < H - 2; y++) for (var xx = 2; xx < W - 2; xx++) { var q = y * W + xx; if (!solid[q]) continue;
      if (solid[q - 2] && solid[q + 2] && solid[q - 2 * W] && solid[q + 2 * W] && solid[q - 1 - W] && solid[q + 1 + W]) core[q] = 1; }
    /* the light: the sheet around the frame in the same photo (outer band, where the cut-out is empty) */
    var gains = [1, 1, 1], lightFrom = 'none';
    if (sd) {
      var rs = [], gs = [], bs = [], band = Math.max(3, Math.round(Math.min(W, H) * 0.12));
      for (y = 0; y < H; y++) for (xx = 0; xx < W; xx++) {
        if (y >= band && y < H - band && xx >= band && xx < W - band) continue;
        i = y * W + xx; if (cd[i * 4 + 3] > 10) continue; j = i * 4;
        var lu = (sd[j] + sd[j + 1] + sd[j + 2]) / 765; if (lu < 0.45) continue;
        rs.push(sd[j]); gs.push(sd[j + 1]); bs.push(sd[j + 2]); }
      if (rs.length > 80) { var mr = median(rs), mg = median(gs), mb = median(bs), m = (mr + mg + mb) / 3;
        gains = [m / Math.max(1, mr), m / Math.max(1, mg), m / Math.max(1, mb)];
        /* never more than a mild correction: a strongly coloured sheet is not trusted */
        if (Math.max.apply(null, gains) / Math.min.apply(null, gains) < 1.6) lightFrom = 'sheet'; else gains = [1, 1, 1];
        /* d17.214 (second check of AUTO WHITE, 14 Nov): a photo the camera made white (d17.213) has its frame about 12% brighter
           than the grey photos this check was made on -- a silver or grey frame then read lighter ("Transparent blue" for a
           grey one), and the TO CHECK colour check said PLEASE CHECK where it used to be sure. Such a photo (its sheet white,
           which no grey photo's is) is read 0.89 as bright: on the shop's photos the colour then comes out as it did on the
           photo as taken (7 of 7). Every photo taken before AUTO WHITE is read exactly as before. */
        if (m >= 238) { gains = gains.map(function (v) { return v * 0.89; }); lightFrom += ' (white photo, read as taken)'; } }
    }
    var px = sd || cd, Ls = [], As = [], Bs = [], Ys = [], total = 0, shine = 0;
    var y0 = H, y1 = 0;
    for (i = 0; i < N; i++) if (core[i]) { y = (i / W) | 0; if (y < y0) y0 = y; if (y > y1) y1 = y; }
    /* shiny spots are not the frame's colour -- but only when they are SPOTS: a frame that is light all over (crystal,
       a clear lower rim) keeps its light pixels */
    var bright = [];
    for (i = 0; i < N; i++) {
      if (!core[i]) continue; j = i * 4; total++;
      var r = Math.min(255, px[j] * gains[0]), gg = Math.min(255, px[j + 1] * gains[1]), b = Math.min(255, px[j + 2] * gains[2]);
      var mx = Math.max(r, gg, b), mn = Math.min(r, gg, b);
      var L = lab(r, gg, b);
      if (mx > 228 && (mx - mn) < 30) { bright.push([L, (i / W) | 0]); continue; }
      Ls.push(L[0]); As.push(L[1]); Bs.push(L[2]); Ys.push((i / W) | 0);
    }
    if (bright.length > 0.15 * total) bright.forEach(function (q) { Ls.push(q[0][0]); As.push(q[0][1]); Bs.push(q[0][2]); Ys.push(q[1]); });
    else shine = bright.length;
    if (Ls.length < 120) return null;
    var med = [median(Ls), median(As), median(Bs)], chroma = Math.sqrt(med[1] * med[1] + med[2] * med[2]);
    var hue = (Math.atan2(med[2], med[1]) * 180 / Math.PI + 360) % 360;
    var out = { lightFrom: lightFrom, pixels: Ls.length, shine: shine / Math.max(1, total), lab: med.map(function (v) { return Math.round(v); }) };
    /* see-through / crystal: light and nearly colourless, or light with a soft tint */
    if (med[0] > 74 && chroma < 9) { out.colour = 'Transparent'; out.alt = 'White'; out.sure = med[0] < 88; out.why = 'very light, no colour'; }
    else if (med[0] > 70 && chroma < 22) { var hn = hueName(hue); out.colour = 'Transparent ' + hn; out.alt = 'Light ' + (hn === 'pink' ? 'pink' : hn === 'brown' ? 'brown' : hn); out.sure = false; out.why = 'light with a tint'; }
    else {
      /* tortoise: brown-ish, with dark and light patches mixed */
      var spread = pct(Ls, 0.85) - pct(Ls, 0.15);
      if (hue > 25 && hue < 85 && chroma > 12 && spread > 22 && med[0] < 60) { out.colour = 'Tortoise'; out.alt = 'Brown'; out.sure = spread > 30; out.why = 'brown with dark and light patches'; }
      else if (med[0] < 36 && chroma >= 5 && hue > 20 && hue < 95) { out.colour = 'Brown'; out.alt = 'Black'; out.sure = chroma >= 9; out.why = 'very dark, but brown'; }
      else if (med[0] < 36 && chroma >= 5 && hue > 200 && hue < 290) { out.colour = 'Navy'; out.alt = 'Black'; out.sure = chroma >= 9; out.why = 'very dark, but blue'; }
      else { var s = nearest(med); out.colour = s[0].n; out.alt = s[1].n; out.sure = s[0].d < 22 && (s[1].d - s[0].d) > 7; out.why = 'nearest: ' + s[0].n + ' (' + s[0].d.toFixed(0) + ') then ' + s[1].n + ' (' + s[1].d.toFixed(0) + ')'; }
    }
    /* two-tone: the top part of the frame and the bottom part clearly different */
    if (y1 > y0 + 6) {
      var mid = (y0 + y1) / 2, tL = [], tA = [], tB = [], bL = [], bA = [], bB = [];
      for (i = 0; i < Ls.length; i++) { if (Ys[i] < y0 + (y1 - y0) * 0.33) { tL.push(Ls[i]); tA.push(As[i]); tB.push(Bs[i]); } else if (Ys[i] > y0 + (y1 - y0) * 0.67) { bL.push(Ls[i]); bA.push(As[i]); bB.push(Bs[i]); } }
      if (tL.length > 60 && bL.length > 60) {
        var T = [median(tL), median(tA), median(tB)], Bt = [median(bL), median(bA), median(bB)];
        out.top = T.map(Math.round); out.bottom = Bt.map(Math.round);
        if (de(T, Bt) > 28 && out.colour !== 'Tortoise') {
          var tc = Math.sqrt(T[1] * T[1] + T[2] * T[2]), th = (Math.atan2(T[2], T[1]) * 180 / Math.PI + 360) % 360;
          var nt = (T[0] < 36 && tc >= 5 && th > 20 && th < 95) ? 'Brown' : (T[0] < 36 && tc >= 5 && th > 200 && th < 290) ? 'Navy' : nearest(T)[0].n, bc = Math.sqrt(Bt[1] * Bt[1] + Bt[2] * Bt[2]), nb;
          if (Bt[0] > 70 && bc < 9) nb = 'Transparent'; else if (Bt[0] > 70 && bc < 22) nb = 'Transparent ' + hueName((Math.atan2(Bt[2], Bt[1]) * 180 / Math.PI + 360) % 360); else nb = nearest(Bt)[0].n;
          if (nb !== nt) { out.colour = nt; out.colour2 = nb; out.why = 'top ' + nt + ', bottom ' + nb; }
        }
      }
    }
    /* SHAPE: the lens openings (closed holes in the cut-out) */
    var lab2 = new Int32Array(N), st = new Int32Array(N), Lb = 0, holes = [];
    for (i = 0; i < N; i++) {
      if (lab2[i] || solid[i]) continue; Lb++; var sp = 0, size = 0, edge = false, hx0 = W, hx1 = 0, hy0 = H, hy1 = 0; st[sp++] = i; lab2[i] = Lb;
      while (sp) { var qq = st[--sp], qx = qq % W, qy = (qq - qx) / W; size++;
        if (qx === 0 || qy === 0 || qx === W - 1 || qy === H - 1) edge = true;
        if (qx < hx0) hx0 = qx; if (qx > hx1) hx1 = qx; if (qy < hy0) hy0 = qy; if (qy > hy1) hy1 = qy;
        if (qx > 0 && !lab2[qq - 1] && !solid[qq - 1]) { lab2[qq - 1] = Lb; st[sp++] = qq - 1; }
        if (qx < W - 1 && !lab2[qq + 1] && !solid[qq + 1]) { lab2[qq + 1] = Lb; st[sp++] = qq + 1; }
        if (qy > 0 && !lab2[qq - W] && !solid[qq - W]) { lab2[qq - W] = Lb; st[sp++] = qq - W; }
        if (qy < H - 1 && !lab2[qq + W] && !solid[qq + W]) { lab2[qq + W] = Lb; st[sp++] = qq + W; } }
      if (!edge && size > N * 0.02) holes.push({ size: size, w: hx1 - hx0 + 1, h: hy1 - hy0 + 1 });
    }
    holes.sort(function (a, b) { return b.size - a.size; });
    if (holes.length >= 2 && holes[1].size > holes[0].size * 0.6) {
      var hs = holes.slice(0, 2), fill = (hs[0].size / (hs[0].w * hs[0].h) + hs[1].size / (hs[1].w * hs[1].h)) / 2, ratio = (hs[0].w / hs[0].h + hs[1].w / hs[1].h) / 2;
      out.fill = +fill.toFixed(3); out.ratio = +ratio.toFixed(2);
      out.shapeFamily = fill >= 0.86 ? 'angular' : fill <= 0.80 ? 'rounded' : '';
      out.lenses = 2;
    } else out.lenses = holes.length;
    return out;
  }
  var CACHE = new Map();
  function measure(p) {
    if (!p || !p.tryOnUrl) return Promise.resolve(null);
    var key = p.tryOnUrl + '|' + (p.tryOnSource || '');
    if (!CACHE.has(key)) CACHE.set(key, Promise.all([load(p.tryOnUrl), p.tryOnSource ? load(p.tryOnSource).catch(function () { return null; }) : Promise.resolve(null)])
      .then(function (a) { try { return analyse(a[0], a[1]); } catch (e) { return null; } }).catch(function () { return null; }));
    return CACHE.get(key);
  }
  var FAMILY = { 'square': 'angular', 'rectangle': 'angular', 'wayfarer': 'angular', 'geometric': 'angular', 'round': 'rounded', 'oval': 'rounded', 'aviator': 'rounded', 'cat eye': 'rounded', 'browline': '' };
  g.VGLook = { measure: measure, analyse: analyse, family: function (s) { return FAMILY[String(s || '').toLowerCase()] || ''; }, PALETTE: PALETTE, VERSION: 'd17.214' };
})(window);

/* VG LIVE TRY-ON (test) -- d17.58, shop 6 Oct.
   The camera stays on and the frame follows the face. When the head turns, the picture switches between the shop's
   REAL cut-outs: 0-~20 degrees the front cut-out, ~25-55 degrees the robot's 45-degree cut-out (with its fit points),
   with a 0.1-second fade so there is no jump. Nothing is invented: every angle shown is a studio photo of the frame.
   Only for the shop while testing: open the shop with ?live=1 (this tab only); ?live=0 ends it. */
(function (g) {
  'use strict';
  try { if (/[?&]live=1\b/.test(g.location.search)) g.sessionStorage.setItem('vg_live', '1'); if (/[?&]live=0\b/.test(g.location.search)) g.sessionStorage.removeItem('vg_live'); } catch (e) {}
  function enabled() { try { return g.sessionStorage.getItem('vg_live') === '1'; } catch (e) { return false; } }
  var FRONT_MAX = 0.30, SIDE_MIN = 0.42, FADE_MS = 100, STEP_MS = 70;
  var S = { on: false, p: null, video: null, stream: null, cv: null, busy: false, last: 0, zone: '', prev: null, fadeAt: 0, cuts: {}, mirror: true };
  function load(src) { return new Promise(function (res, rej) { var i = new Image(); i.crossOrigin = 'anonymous'; i.onload = function () { res(i); }; i.onerror = rej; i.src = src; }); }
  function widthMM(p) { return (typeof g.frameWidthMM === 'function') ? g.frameWidthMM(p) : 140; }
  function has45(p) { return (p.tryOnAngleUrl && p.tryOnAngleFit && p.tryOnAngleFit.bridge) || (p.tryOnAngleRUrl && p.tryOnAngleRFit && p.tryOnAngleRFit.bridge); }
  async function prepare(p) {
    var c = {};
    var front = (typeof g.tryOnURL === 'function') ? g.tryOnURL(p) : p.tryOnUrl;
    c.front = g.VGOnFace.cutout(await load(front), { alreadyCut: true });
    c.frontImg = await load(front);
    if (p.tryOnAngleUrl && p.tryOnAngleFit) try { c.a = await load(p.tryOnAngleUrl); } catch (e) {}
    if (p.tryOnAngleRUrl && p.tryOnAngleRFit) try { c.b = await load(p.tryOnAngleRUrl); } catch (e) {}
    return c;
  }
  /* one picture: the face in `src` (a canvas or image), the zone it is in, and the frame drawn on it */
  async function step(src, p, cuts, frontRef) {
    var face = await g.VGOnFace.findFace(src, { runs: 1 });
    if (!face || face.estimated) return { zone: 'none' };
    var a = Math.abs(face.yaw || 0), zone = a <= FRONT_MAX ? 'front' : (a >= SIDE_MIN && has45(p) ? 'side' : (S.zone || 'front'));
    var out = null;
    if (zone === 'side' && g.VG45) {
      var sizes = { lens: p.size && p.size.lens, bridge: p.size && p.size.bridge };
      var tries = [[cuts.a, p.tryOnAngleFit], [cuts.b, p.tryOnAngleRFit]];
      for (var i = 0; i < tries.length && !out; i++) {
        if (!tries[i][0] || !tries[i][1] || !tries[i][1].bridge) continue;
        var r = g.VG45.fit45({ faceImg: src, face: face, cutImg: tries[i][0], fit: tries[i][1], frontRef: frontRef || { face: null }, sizes: sizes });
        if (r && r.canvas) out = r.canvas;
      }
      if (!out) zone = 'front';
    }
    if (!out) { var o = g.VGOnFace.compose(src, face, cuts.front, widthMM(p), { drawSyntheticArms: false }); out = o && (o.canvas || o); }
    return { zone: zone, canvas: out, face: face };
  }
  function draw(res) {
    var cv = S.cv, x = cv.getContext('2d'), now = performance.now();
    if (!res.canvas) return;
    if (cv.width !== res.canvas.width || cv.height !== res.canvas.height) { cv.width = res.canvas.width; cv.height = res.canvas.height; }
    if (res.zone !== S.zone && S.zone && S.prev) S.fadeAt = now;           /* the view changed: fade from the last picture */
    S.zone = res.zone;
    x.save(); if (S.mirror) { x.translate(cv.width, 0); x.scale(-1, 1); }
    var k = S.fadeAt ? Math.min(1, (now - S.fadeAt) / FADE_MS) : 1;
    if (k < 1 && S.prev) { x.globalAlpha = 1; x.drawImage(S.prev, 0, 0, cv.width, cv.height); x.globalAlpha = k; }
    x.drawImage(res.canvas, 0, 0, cv.width, cv.height); x.restore();
    if (k >= 1) S.fadeAt = 0;
    var keep = document.createElement('canvas'); keep.width = cv.width; keep.height = cv.height; keep.getContext('2d').drawImage(res.canvas, 0, 0); S.prev = keep;
    var lbl = document.getElementById('vgLiveLbl'); if (lbl) lbl.textContent = res.zone === 'side' ? 'SIDE VIEW (45\u00b0)' : 'FRONT';
  }
  async function loop() {
    if (!S.on) return;
    var now = performance.now();
    if (!S.busy && now - S.last >= STEP_MS && S.video.readyState >= 2) {
      S.busy = true; S.last = now;
      try {
        var f = S.frame || (S.frame = document.createElement('canvas'));
        f.width = S.video.videoWidth; f.height = S.video.videoHeight; f.getContext('2d').drawImage(S.video, 0, 0);
        var res = await step(f, S.p, S.cuts, S.frontRef);
        if (res.zone === 'none') { var lb = document.getElementById('vgLiveLbl'); if (lb) lb.textContent = 'LOOK AT THE CAMERA'; }
        else draw(res);
      } catch (e) {}
      S.busy = false;
    }
    requestAnimationFrame(loop);
  }
  function ui() {
    var box = document.getElementById('vgLive'); if (box) return box;
    box = document.createElement('div'); box.id = 'vgLive';
    box.innerHTML = '<div class="vgl-top"><b>LIVE TRY-ON <small>(test)</small></b><span id="vgLiveLbl">STARTING\u2026</span><button type="button" id="vgLiveX">CLOSE</button></div>' +
      '<canvas id="vgLiveCv"></canvas><video id="vgLiveV" playsinline muted hidden></video>' +
      '<div class="vgl-bot"><small>Turn your head a little to the side to see the frame from the side.</small><button type="button" id="vgLiveShot">SAVE PHOTO</button></div>';
    var css = document.createElement('style');
    css.textContent = '#vgLive{position:fixed;inset:0;z-index:9500;background:#0C0B0A;color:#F4EFE6;display:flex;flex-direction:column}#vgLive[hidden]{display:none}' +
      '#vgLive .vgl-top,#vgLive .vgl-bot{display:flex;align-items:center;gap:10px;padding:10px 12px}#vgLive .vgl-top b{flex:1;letter-spacing:.08em}#vgLive .vgl-top span{color:#D9B26B;font-size:.75rem;letter-spacing:.1em}' +
      '#vgLive canvas{flex:1;min-height:0;width:100%;object-fit:contain}#vgLive button{min-height:44px;padding:0 14px;border-radius:10px;border:1px solid #2E2A25;background:#1C1A17;color:#F4EFE6;font-weight:700}' +
      '#vgLive #vgLiveShot{background:#D9B26B;color:#0C0B0A;border:0;margin-left:auto}#vgLive .vgl-bot small{color:#B3AA9C}';
    document.head.appendChild(css); document.body.appendChild(box);
    box.querySelector('#vgLiveX').addEventListener('click', close);
    box.querySelector('#vgLiveShot').addEventListener('click', function () { try { var a = document.createElement('a'); a.href = S.cv.toDataURL('image/jpeg', 0.92); a.download = 'vision-gallery-tryon.jpg'; a.click(); } catch (e) {} });
    return box;
  }
  async function open(p) {
    if (!p || !g.VGOnFace) return;
    var box = ui(); box.hidden = false; S.cv = box.querySelector('#vgLiveCv'); S.video = box.querySelector('#vgLiveV'); S.p = p; S.zone = ''; S.prev = null;
    try { if (g.loadFaceMesh) await g.loadFaceMesh(); } catch (e) {}
    S.cuts = await prepare(p);
    try { S.frontRef = g.VG45 ? g.VG45.frontReference(S.cuts.frontImg, { lens: p.size && p.size.lens, bridge: p.size && p.size.bridge }, null) : null; } catch (e) { S.frontRef = null; }
    try { S.stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: { ideal: 720 }, height: { ideal: 960 } }, audio: false }); }
    catch (e) { document.getElementById('vgLiveLbl').textContent = 'CAMERA NOT AVAILABLE'; return; }
    S.video.srcObject = S.stream; try { await S.video.play(); } catch (e) {}
    S.on = true; requestAnimationFrame(loop);
  }
  function close() { S.on = false; try { (S.stream && S.stream.getTracks() || []).forEach(function (t) { t.stop(); }); } catch (e) {} var b = document.getElementById('vgLive'); if (b) b.hidden = true; }
  g.VGLive = { enabled: enabled, open: open, close: close, step: step, prepare: prepare, has45: has45, FRONT_MAX: FRONT_MAX, SIDE_MIN: SIDE_MIN };
})(window);

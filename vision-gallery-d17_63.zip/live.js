/* VG LIVE TRY-ON (test) -- d17.58, shop 6 Oct.
   The camera stays on and the frame follows the face. When the head turns, the picture switches between the shop's
   REAL cut-outs: 0-~20 degrees the front cut-out, ~25-55 degrees the robot's 45-degree cut-out (with its fit points),
   with a 0.1-second fade so there is no jump. Nothing is invented: every angle shown is a studio photo of the frame.
   Only for the shop while testing: open the shop with ?live=1 (this tab only); ?live=0 ends it. */
(function (g) {
  'use strict';
  try { if (/[?&]live=1\b/.test(g.location.search)) g.sessionStorage.setItem('vg_live', '1'); if (/[?&]live=0\b/.test(g.location.search)) g.sessionStorage.setItem('vg_live', '0'); } catch (e) {}
  /* d17.59 (shop: "set the entire flow first"): LIVE VIDEO is offered on every try-on now; ?live=0 hides it in a tab */
  function enabled() { try { return g.sessionStorage.getItem('vg_live') !== '0'; } catch (e) { return true; } }
  var FRONT_MAX = 0.30, SIDE_MIN = 0.42, FADE_MS = 100, STEP_MS = 70;
  var S = { on: false, p: null, video: null, stream: null, cv: null, busy: false, last: 0, zone: '', prev: null, fadeAt: 0, cuts: {}, mirror: true };
  function load(src) { return new Promise(function (res, rej) { var i = new Image(); i.crossOrigin = 'anonymous'; i.onload = function () { res(i); }; i.onerror = rej; i.src = src; }); }
  function widthMM(p) { return (typeof g.frameWidthMM === 'function') ? g.frameWidthMM(p) : 140; }
  /* d17.63: a 45 cut-out is enough -- the page finds the fit points itself when the robot stored none (the robot rule's twin) */
  function has45(p) { return !!(p.tryOnAngleUrl || p.tryOnAngleRUrl); }
  async function prepare(p) {
    var c = {};
    var front = (typeof g.tryOnURL === 'function') ? g.tryOnURL(p) : p.tryOnUrl;
    c.front = g.VGOnFace.cutout(await load(front), { alreadyCut: true });
    c.frontImg = await load(front);
    if (p.tryOnAngleUrl) try { c.a = await load(p.tryOnAngleUrl); } catch (e) {}
    if (p.tryOnAngleRUrl) try { c.b = await load(p.tryOnAngleRUrl); } catch (e) {}
    return c;
  }
  /* one picture: the face in `src` (a canvas or image), the zone it is in, and the frame drawn on it */
  async function step(src, p, cuts, frontRef, given) {
    var face = given !== undefined ? given : await g.VGOnFace.findFace(src, { runs: 1 });
    if (!face || face.estimated) return { zone: 'none' };
    var a = Math.abs(face.yaw || 0), zone = a <= FRONT_MAX ? 'front' : (a >= SIDE_MIN && has45(p) ? 'side' : (S.zone || 'front'));
    var out = null;
    if (zone === 'side' && g.VG45) {
      var sizes = { lens: p.size && p.size.lens, bridge: p.size && p.size.bridge };
      var tries = [[cuts.a, p.tryOnAngleFit], [cuts.b, p.tryOnAngleRFit]];
      for (var i = 0; i < tries.length && !out; i++) {
        if (!tries[i][0]) continue;
        var r = g.VG45.fit45({ faceImg: src, face: face, cutImg: tries[i][0], fit: tries[i][1], frontRef: frontRef || { face: null }, sizes: sizes });
        if (r && r.canvas) out = r.canvas;
      }
      if (!out) zone = 'front';
    }
    if (!out) { var o = g.VGOnFace.compose(src, face, cuts.front, widthMM(p), { drawSyntheticArms: false }); out = o && (o.canvas || o); }
    return { zone: zone, canvas: out, face: face };
  }
  function draw(res) {
    var cv = S.cv, x = cv.getContext('2d'), now = performance.now();
    if (!res.canvas) return;
    if (cv.width !== res.canvas.width || cv.height !== res.canvas.height) { cv.width = res.canvas.width; cv.height = res.canvas.height; }
    if (res.zone !== S.zone && S.zone && S.prev) S.fadeAt = now;           /* the view changed: fade from the last picture */
    S.zone = res.zone;
    x.save(); if (S.mirror) { x.translate(cv.width, 0); x.scale(-1, 1); }
    var k = S.fadeAt ? Math.min(1, (now - S.fadeAt) / FADE_MS) : 1;
    if (k < 1 && S.prev) { x.globalAlpha = 1; x.drawImage(S.prev, 0, 0, cv.width, cv.height); x.globalAlpha = k; }
    x.drawImage(res.canvas, 0, 0, cv.width, cv.height); x.restore();
    if (k >= 1) S.fadeAt = 0;
    var keep = document.createElement('canvas'); keep.width = cv.width; keep.height = cv.height; keep.getContext('2d').drawImage(res.canvas, 0, 0); S.prev = keep;
    var lbl = document.getElementById('vgLiveLbl'); if (lbl) lbl.textContent = res.zone === 'side' ? 'SIDE VIEW (45\u00b0)' : 'FRONT';
  }
  async function ensureMesh() {
    if (S.mesh) return S.mesh;
    if (typeof g.FaceMesh === 'undefined' && g.loadFaceMesh) { try { await g.loadFaceMesh(); } catch (e) {} }
    if (typeof g.FaceMesh === 'undefined') return null;
    var m = new g.FaceMesh({ locateFile: function (f) { return (g.FACEMESH_BASE || 'https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh@0.4/') + f; } });
    m.setOptions({ maxNumFaces: 1, refineLandmarks: true, minDetectionConfidence: 0.5, minTrackingConfidence: 0.5 });
    m.onResults(function (r) { S.lm = (r && r.multiFaceLandmarks && r.multiFaceLandmarks[0]) || null; });
    try { if (m.initialize) await m.initialize(); } catch (e) {}
    S.mesh = m; return m;
  }
  function drawRaw(f) {                                   /* no face yet: still show the camera, never a black screen */
    var cv = S.cv, x = cv.getContext('2d');
    if (cv.width !== f.width || cv.height !== f.height) { cv.width = f.width; cv.height = f.height; }
    x.save(); if (S.mirror) { x.translate(cv.width, 0); x.scale(-1, 1); } x.drawImage(f, 0, 0); x.restore();
  }
  async function loop() {
    if (!S.on) return;
    var now = performance.now();
    if (!S.busy && now - S.last >= STEP_MS && S.video.readyState >= 2 && S.video.videoWidth > 0) {
      S.busy = true; S.last = now;
      try {
        var f = S.frame || (S.frame = document.createElement('canvas'));
        f.width = S.video.videoWidth; f.height = S.video.videoHeight; f.getContext('2d').drawImage(S.video, 0, 0);
        var face = null;
        if (S.mesh && S.cuts && S.cuts.front) {
          var sm = S.small || (S.small = document.createElement('canvas')); var k = Math.min(1, 480 / f.width); sm.width = Math.round(f.width * k); sm.height = Math.round(f.height * k);
          sm.getContext('2d').drawImage(f, 0, 0, sm.width, sm.height);
          S.lm = null; await S.mesh.send({ image: sm });
          if (S.lm) face = g.VGOnFace.faceFromLandmarks(S.lm, f.width, f.height, false);
        }
        var res = face ? await step(f, S.p, S.cuts, S.frontRef, face) : { zone: 'none' };
        if (res.zone === 'none' || !res.canvas) { drawRaw(f); var lb = document.getElementById('vgLiveLbl'); if (lb) lb.textContent = S.mesh ? 'LOOK AT THE CAMERA' : 'STARTING\u2026'; }
        else { draw(res); var note = document.getElementById('vgLiveNote'); if (note) { var turned = Math.abs(face.yaw || 0) >= SIDE_MIN && !has45(S.p); note.hidden = !turned; if (turned) note.textContent = 'Side view coming soon for this frame'; } }
      } catch (e) {}
      S.busy = false;
    }
    requestAnimationFrame(loop);
  }
  function ui() {
    var box = document.getElementById('vgLive'); if (box) return box;
    box = document.createElement('div'); box.id = 'vgLive';
    box.innerHTML = '<div class="vgl-top"><b>LIVE VIDEO TRY-ON</b><span id="vgLiveLbl">STARTING\u2026</span><button type="button" id="vgLiveX">CLOSE</button></div>' +
      '<canvas id="vgLiveCv"></canvas><video id="vgLiveV" playsinline muted autoplay style="position:absolute;width:2px;height:2px;opacity:0;pointer-events:none;left:0;top:0"></video>' +
      '<div class="vgl-note" id="vgLiveNote" hidden></div>' +
      '<div class="vgl-strip" id="vgLiveStrip"></div>' +
      '<div class="vgl-bot"><button type="button" id="vgLiveAdd">ADD TO BASKET</button><button type="button" id="vgLiveShare">SHARE</button><button type="button" id="vgLiveShot">SAVE PHOTO</button></div>';
    var css = document.createElement('style');
    css.textContent = '#vgLive{position:fixed;inset:0;z-index:9500;background:#0C0B0A;color:#F4EFE6;display:flex;flex-direction:column}#vgLive[hidden]{display:none}' +
      '#vgLive .vgl-top,#vgLive .vgl-bot{display:flex;align-items:center;gap:10px;padding:10px 12px}#vgLive .vgl-top b{flex:1;letter-spacing:.08em}#vgLive .vgl-top span{color:#D9B26B;font-size:.75rem;letter-spacing:.1em}' +
      '#vgLive canvas{flex:1;min-height:0;width:100%;object-fit:contain}#vgLive button{min-height:44px;padding:0 14px;border-radius:10px;border:1px solid #2E2A25;background:#1C1A17;color:#F4EFE6;font-weight:700}' +
      '#vgLive #vgLiveShot{background:#D9B26B;color:#0C0B0A;border:0}#vgLive .vgl-bot button{flex:1}' +
      '#vgLive .vgl-strip{display:flex;gap:8px;overflow-x:auto;padding:6px 10px;flex:0 0 auto}#vgLive .vgl-strip button{flex:0 0 auto;width:74px;height:56px;padding:0;border-radius:10px;border:2px solid #2E2A25;background:#fff;overflow:hidden}' +
      '#vgLive .vgl-strip button.on{border-color:#D9B26B}#vgLive .vgl-strip img{width:100%;height:100%;object-fit:cover;display:block}' +
      '#vgLive .vgl-note{position:absolute;left:50%;transform:translateX(-50%);bottom:150px;background:rgba(12,11,10,.75);color:#F4EFE6;font-size:.78rem;padding:6px 12px;border-radius:14px;white-space:nowrap}#vgLive .vgl-note[hidden]{display:none}';
    document.head.appendChild(css); document.body.appendChild(box);
    box.querySelector('#vgLiveX').addEventListener('click', close);
    box.querySelector('#vgLiveAdd').addEventListener('click', function () { if (!S.p) return; try { if (g.VGBasket && !g.VGBasket.has(S.p.id)) g.VGBasket.add(S.p); } catch (e) {} close(); try { if (g.openBasket) g.openBasket(true); } catch (e) {} });
    box.querySelector('#vgLiveShare').addEventListener('click', async function () {
      if (!S.cv || S.cv.width <= 300) { alert('The camera picture is not showing yet.'); return; }
      try { var blob = await new Promise(function (r) { S.cv.toBlob(r, 'image/jpeg', 0.92); }); var file = new File([blob], 'vision-gallery-tryon.jpg', { type: 'image/jpeg' });
        if (navigator.canShare && navigator.canShare({ files: [file] })) { await navigator.share({ files: [file], title: 'Vision Gallery', text: (S.p && S.p.name || 'This frame') + ' on me \u2014 what do you think?' }); return; } } catch (e) {}
      try { var a = document.createElement('a'); a.href = S.cv.toDataURL('image/jpeg', 0.92); a.download = 'vision-gallery-tryon.jpg'; a.click(); } catch (e) {}
    });
    box.querySelector('#vgLiveStrip').addEventListener('click', function (e) { var b = e.target.closest('button[data-pid]'); if (!b) return; var pp = (g.allProducts ? g.allProducts() : []).find(function (x) { return x.id === b.dataset.pid; }); if (pp) switchTo(pp); });
    g.addEventListener('popstate', function () { if (S.on) close(true); });
    box.querySelector('#vgLiveShot').addEventListener('click', function () {
      if (!S.cv || S.cv.width <= 300) { alert('The camera picture is not showing yet. Wait for it, then save.'); return; }
      try { var a = document.createElement('a'); a.href = S.cv.toDataURL('image/jpeg', 0.92); a.download = 'vision-gallery-tryon.jpg'; a.click(); } catch (e) {} });
    return box;
  }
  function strip(p) {
    var el = document.getElementById('vgLiveStrip'); if (!el) return;
    var list = (g.allProducts ? g.allProducts() : []).filter(function (x) { return x && x.url && (g.tryOnURL ? g.tryOnURL(x) : x.tryOnUrl) && x.tryOnOk !== false; });
    var i = list.findIndex(function (x) { return x.id === p.id; }); if (i > 0) { list.splice(i, 1); list.unshift(p); }
    el.innerHTML = list.slice(0, 40).map(function (x) { return '<button type="button" data-pid="' + x.id + '"' + (x.id === p.id ? ' class="on"' : '') + ' title="' + (x.name || '') + '"><img src="' + (g.vgImg ? g.vgImg(x.url, 160) : x.url) + '" alt=""></button>'; }).join('');
  }
  async function switchTo(p) {
    S.p = p; S.zone = ''; S.prev = null; S.cuts = {};
    var el = document.getElementById('vgLiveStrip'); if (el) el.querySelectorAll('button').forEach(function (b) { b.classList.toggle('on', b.dataset.pid === p.id); });
    try { S.cuts = await prepare(p); } catch (e) { S.cuts = {}; }
    try { S.frontRef = g.VG45 && S.cuts.frontImg ? g.VG45.frontReference(S.cuts.frontImg, { lens: p.size && p.size.lens, bridge: p.size && p.size.bridge }, null) : null; } catch (e) { S.frontRef = null; }
  }
  async function open(p) {
    if (!p || !g.VGOnFace) return;
    try { history.pushState({ vgLive: 1 }, ''); } catch (e) {}
    var box = ui(); box.hidden = false; S.cv = box.querySelector('#vgLiveCv'); S.video = box.querySelector('#vgLiveV'); S.p = p; S.zone = ''; S.prev = null; S.cuts = {};
    strip(p);
    var lbl = document.getElementById('vgLiveLbl'); lbl.textContent = 'STARTING CAMERA\u2026';
    try { S.stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: { ideal: 720 }, height: { ideal: 960 } }, audio: false }); }
    catch (e) {
      lbl.textContent = 'CAMERA BLOCKED';
      alert('The camera did not start: ' + ((e && e.name) || 'blocked') + '.\n\nAllow the camera for visiongallery.me: tap the lock icon in the address bar \u2192 Permissions \u2192 Camera \u2192 Allow, then tap LIVE VIDEO again.');
      return;
    }
    S.video.srcObject = S.stream; try { await S.video.play(); } catch (e) {}
    S.on = true; requestAnimationFrame(loop);                     /* the camera shows at once ... */
    lbl.textContent = 'LOADING\u2026';
    try { S.cuts = await prepare(p); } catch (e) { S.cuts = {}; }
    try { S.frontRef = g.VG45 && S.cuts.frontImg ? g.VG45.frontReference(S.cuts.frontImg, { lens: p.size && p.size.lens, bridge: p.size && p.size.bridge }, null) : null; } catch (e) { S.frontRef = null; }
    try { await ensureMesh(); } catch (e) {}                       /* ... and the frame joins as soon as the face finder is ready */
  }
  function close(fromBack) { if (!fromBack) { try { if (history.state && history.state.vgLive) history.back(); } catch (e) {} } S.on = false; try { (S.stream && S.stream.getTracks() || []).forEach(function (t) { t.stop(); }); } catch (e) {} var b = document.getElementById('vgLive'); if (b) b.hidden = true; }
  g.VGLive = { enabled: enabled, open: open, close: close, step: step, prepare: prepare, has45: has45, FRONT_MAX: FRONT_MAX, SIDE_MIN: SIDE_MIN };
})(window);

/* try45.js -- THE 45-DEGREE TRY-ON ENGINE (d17.23, 1 Oct 2026)

   What it does: puts the frame's own 45-degree cut-out (the robot's photographed near
   arm, the far arm already removed) on a customer's turned face, at the frame's true
   size. No drawn arms: the arm is the photographed one, faded out behind the ear.

   What it never does: touch the front try-on. This file stands on its own; nothing in
   onface.js or the front flow calls it. It reads the face the same way the front does
   (VGOnFace.findFace / faceFromLandmarks give the face object) and only adds placing.

   The pieces
     fitPointsFromImage(img)   where the bridge and the two lens openings are in a
                               cut-out (the same rule the robot uses; used when the
                               robot's own fit points are missing)
     frontReference(frontImg, sizes, frontFace)
                               true size from the FRONT cut-out and the face's own
                               scale from the FRONT photo, carried over to the turned view
     pickView(face, views)     which of the frame's two 45 views belongs to this turn
     fit45(o)                  the placing; returns {canvas, report} or {error, advice}
     headTurn(face)            for the guide: turn more / good / turn back

   Everything that depends on how a real face looks is a named constant below, so it
   can be tuned from the numbers the test page prints, not by guessing. */
(function (global) {
  'use strict';

  var VERSION = '2026-10-05 try45.5';

  /* THE HEAD-TURN WINDOW. yaw is the engine's own number: (distance nose-to-far-cheek minus
     nose-to-near-cheek) / face width, 0 square on, about 0.6 at most. 0.20 to 0.58 is a
     starting window around "halfway"; the test page prints the real number for each photo
     so it can be set from the six AI models. */
  /* d17.40: the window for a half turn (about 25 to 55 degrees) on the uncapped turn measure; it used to end at 0.58,
     so a real 45-degree turn (about 0.75) was refused as 'turned too far' */
  var YAW_MIN = 0.42, YAW_MAX = 0.92;
  var ROLL_MAX = 14 * Math.PI / 180;
  var IRIS_MM = 12.0;                 /* the same figure the front uses */
  var SEAT_DROP_MM = 2.0;             /* lens centre sits this far below the pupil line (the front's rule) */
  var FADE_START = 0.60;              /* the arm is full strength this far (as a share of eye-to-ear) ... */
  var FADE_END = 1.00;                /* ... and gone by the ear root, plus a little */
  var ASSUMED_LENS_H_RATIO = 0.78;    /* only when the front cut-out is missing: lens height / lens width */
  var ASSUMED_FACE_LEN_MM = 188;      /* only when no front photo is available: brow to chin */

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function isNum(v) { return typeof v === 'number' && isFinite(v); }

  /* ---------- fit points from a cut-out (the JavaScript twin of the robot's angle_anchors) ---------- */
  function alphaOf(img, maxSide) {
    var w0 = img.naturalWidth || img.width, h0 = img.naturalHeight || img.height;
    if (!w0 || !h0) return null;
    var k = Math.min(1, (maxSide || 640) / Math.max(w0, h0));
    var w = Math.max(1, Math.round(w0 * k)), h = Math.max(1, Math.round(h0 * k));
    var c = document.createElement('canvas'); c.width = w; c.height = h;
    var x = c.getContext('2d'); x.drawImage(img, 0, 0, w, h);
    var d = x.getImageData(0, 0, w, h).data, a = new Uint8Array(w * h);
    for (var i = 0, j = 3; i < a.length; i++, j += 4) a[i] = d[j] > 127 ? 1 : 0;
    return { a: a, w: w, h: h, k: k, w0: w0, h0: h0 };
  }

  function floodOutside(a, w, h) {
    var out = new Uint8Array(w * h), stack = [], i;
    function push(p) { if (!a[p] && !out[p]) { out[p] = 1; stack.push(p); } }
    for (i = 0; i < w; i++) { push(i); push((h - 1) * w + i); }
    for (i = 0; i < h; i++) { push(i * w); push(i * w + w - 1); }
    while (stack.length) {
      var p = stack.pop(), x = p % w, y = (p - x) / w;
      if (x > 0) push(p - 1); if (x < w - 1) push(p + 1);
      if (y > 0) push(p - w); if (y < h - 1) push(p + w);
    }
    return out;
  }

  function fitPointsFromImage(img) {
    try {
      var A = alphaOf(img, 640); if (!A) return null;
      var a = A.a, w = A.w, h = A.h, n = w * h, i;
      var solid = 0, fx0 = w, fy0 = h, fx1 = -1, fy1 = -1;
      for (i = 0; i < n; i++) if (a[i]) { solid++; var x = i % w, y = (i - x) / w; if (x < fx0) fx0 = x; if (x > fx1) fx1 = x; if (y < fy0) fy0 = y; if (y > fy1) fy1 = y; }
      if (solid < 200) return null;
      var out = floodOutside(a, w, h), lab = new Int32Array(n), comps = [], stack = [];
      for (i = 0; i < n; i++) {
        if (a[i] || out[i] || lab[i]) continue;
        var id = comps.length + 1, c = { area: 0, sx: 0, sy: 0, x0: w, x1: -1, y0: h, y1: -1 };
        lab[i] = id; stack.push(i);
        while (stack.length) {
          var p = stack.pop(), px = p % w, py = (p - px) / w;
          c.area++; c.sx += px; c.sy += py;
          if (px < c.x0) c.x0 = px; if (px > c.x1) c.x1 = px; if (py < c.y0) c.y0 = py; if (py > c.y1) c.y1 = py;
          var nb = [px > 0 ? p - 1 : -1, px < w - 1 ? p + 1 : -1, py > 0 ? p - w : -1, py < h - 1 ? p + w : -1];
          for (var q = 0; q < 4; q++) { var m = nb[q]; if (m >= 0 && !a[m] && !out[m] && !lab[m]) { lab[m] = id; stack.push(m); } }
        }
        comps.push(c);
      }
      var fh = fy1 - fy0 + 1, fw = fx1 - fx0 + 1;
      comps.sort(function (p, q) { return q.area - p.area; });
      var boxes = [];
      for (i = 0; i < Math.min(6, comps.length); i++) {
        var c2 = comps[i], bh = c2.y1 - c2.y0 + 1, bw = c2.x1 - c2.x0 + 1;
        if (bh < 0.25 * fh || c2.area < 0.015 * fh * fw || bw < 0.06 * fw) continue;       /* a lens, not a speck */
        boxes.push({ cx: c2.sx / c2.area, cy: c2.sy / c2.area, x0: c2.x0, x1: c2.x1, y0: c2.y0, y1: c2.y1, w: bw, h: bh, area: c2.area });
      }
      if (boxes.length < 2) return null;
      boxes = boxes.slice(0, 2);
      if (boxes[1].area < 0.12 * boxes[0].area) return null;                                /* the far lens is not really visible */
      if (Math.abs(boxes[0].cy - boxes[1].cy) > 0.35 * fh) return null;                    /* not two lenses side by side */
      var near = boxes[0], far = boxes[1];
      var left = near.cx < far.cx ? near : far, right = near.cx < far.cx ? far : near;
      var s = 1 / A.k;                                                                      /* back to the picture's own pixels */
      function sc(b) { return { cx: b.cx * s, cy: b.cy * s, w: b.w * s, h: b.h * s }; }
      return {
        w: A.w0, h: A.h0, frame: [fx0 * s, fy0 * s, fx1 * s, fy1 * s],
        bridge: [((left.x1 + right.x0) / 2) * s, ((left.cy + right.cy) / 2) * s],
        near: sc(near), far: sc(far), nearSide: near === left ? 'left' : 'right',
        lensHeightPx: near.h * s, lensLine: ((near.cy + far.cy) / 2) * s, source: 'page'
      };
    } catch (e) { return null; }
  }

  /* the robot writes its own fit points (in the cut-out's own pixels, with w and h); use them when they are sound */
  function usableFit(fit, img) {
    if (!fit || !fit.bridge || !fit.near || !fit.far || !isNum(fit.bridge[0])) return null;
    var w0 = img.naturalWidth || img.width, h0 = img.naturalHeight || img.height, k = (fit.w && w0) ? w0 / fit.w : 1;
    function sc(b) { return { cx: b.cx * k, cy: b.cy * k, w: b.w * k, h: b.h * k }; }
    return {
      w: w0, h: h0, frame: (fit.frame || [0, 0, w0, h0]).map(function (v) { return v * k; }),
      bridge: [fit.bridge[0] * k, fit.bridge[1] * k], near: sc(fit.near), far: sc(fit.far),
      nearSide: fit.nearSide, lensHeightPx: (fit.lensHeightPx || fit.near.h) * k, lensLine: (fit.lensLine || fit.bridge[1]) * k, source: 'robot'
    };
  }

  function fitFor(img, robotFit) { return usableFit(robotFit, img) || fitPointsFromImage(img); }

  /* ---------- scale: the face's own scale, and the frame's true size, both from the FRONT ---------- */
  function perMMFromFace(face) {                       /* pixels per millimetre on a square-on face: the front's own rule */
    if (!face) return 0;
    if (face.irisPx > 0) { var share = face.irisPx / (face.pd || 1); if (share > 0.10 && share < 0.40) return face.irisPx / IRIS_MM; }
    return face.pd > 0 ? face.pd / 63 : 0;
  }

  /* frontImg: the FRONT cut-out; sizes: {lens, bridge} as typed in admin (mm); frontFace: the face measured on the FRONT photo */
  function frontReference(frontImg, sizes, frontFace, frontRobotFit) {
    var ref = { face: frontFace || null, perMM: perMMFromFace(frontFace), mmppFront: 0, lensHpx: 0, source: [] };
    var fp = frontImg ? fitFor(frontImg, frontRobotFit) : null;
    if (fp && sizes && sizes.lens && isNum(+sizes.lens) && sizes.bridge != null) {
      var centres = Math.abs(fp.near.cx - fp.far.cx);                      /* lens centre to lens centre, in the cut-out's pixels */
      if (centres > 10) { ref.mmppFront = (Number(sizes.lens) + Number(sizes.bridge)) / centres; ref.lensHpx = (fp.near.h + fp.far.h) / 2; ref.source.push('front cut-out + typed lens/bridge'); }
    }
    return ref;
  }

  /* ---------- the guide: how turned is this head? ---------- */
  function headTurn(face) {
    if (!face) return { state: 'no-face', yaw: 0, text: 'I cannot see your face. Hold the phone at eye level.' };
    var y = face.yaw || 0, ay = Math.abs(y);
    if (ay < YAW_MIN) return { state: 'turn-more', yaw: y, text: 'Turn your head a little more, until you can see your ear in the picture\u2019s edge.' };
    if (ay > YAW_MAX) return { state: 'turn-less', yaw: y, text: 'That is too far \u2014 turn back a little so both eyes still show.' };
    return { state: 'ok', yaw: y, text: 'Good \u2014 hold it there.' };
  }

  var ADVICE = {
    'no-face': 'I could not find your face in that photo. Take it again at eye level with good light.',
    'turn-more': 'Your head is not turned enough for a side view. Turn your head about halfway and take it again.',
    'turn-less': 'Your head is turned too far. Turn back until both eyes still show, then take it again.',
    'no-ear': 'I could not see your ear on the near side. Tuck your hair back and take it again.',
    'no-view': 'This frame has no 45\u00b0 picture for that side yet.',
    'no-fit': 'This frame\u2019s 45\u00b0 picture cannot be placed (no lens openings found).',
    'tilted': 'Your head is tilted. Keep it level and take it again.'
  };

  function pickView(face, views) {
    if (!face || !views) return null;
    var want = (face.yaw || 0) > 0 ? 'right' : 'left';              /* the near eye is the image-right one when yaw > 0 */
    for (var i = 0; i < views.length; i++) if (views[i] && views[i].fit && views[i].fit.nearSide === want) return views[i];
    return null;
  }

  /* ---------- the placing ----------
     o = { faceImg, face, cutImg, fit, frontRef, sizes:{lens,bridge}, perMM (optional override) } */
  function fit45(o) {
    try {
      var face = o.face, fit = o.fit, cut = o.cutImg, notes = [];
      if (!face || !o.faceImg) return { error: 'no-face', advice: ADVICE['no-face'] };
      if (!cut || !fit) return { error: 'no-fit', advice: ADVICE['no-fit'] };
      var yaw = face.yaw || 0, ay = Math.abs(yaw);
      if (ay < YAW_MIN) return { error: 'turn-more', advice: ADVICE['turn-more'], report: { yaw: yaw } };
      if (ay > YAW_MAX) return { error: 'turn-less', advice: ADVICE['turn-less'], report: { yaw: yaw } };
      var roll = face.roll || 0;
      if (Math.abs(roll) > ROLL_MAX) return { error: 'tilted', advice: ADVICE.tilted, report: { yaw: yaw, roll: roll } };

      var nearIsRight = yaw > 0, sgn = nearIsRight ? 1 : -1;
      var pupilNear = nearIsRight ? face.pupilL : face.pupilR;           /* the engine names pupils by image side: pupilL is the image-RIGHT one */
      var earNear = nearIsRight ? face.templeL : face.templeR;
      if (!pupilNear) return { error: 'no-face', advice: ADVICE['no-face'] };
      if (!earNear) return { error: 'no-ear', advice: ADVICE['no-ear'] };
      var wantSide = nearIsRight ? 'right' : 'left';
      if (fit.nearSide !== wantSide) return { error: 'no-view', advice: ADVICE['no-view'], report: { needs: wantSide, has: fit.nearSide } };

      /* 1. pixels per millimetre ON THIS TURNED FACE */
      var ref = o.frontRef || {}, perMM = 0, perMMsrc = '';
      if (isNum(o.perMM) && o.perMM > 0) { perMM = o.perMM; perMMsrc = 'given'; }
      else if (ref.face && ref.perMM > 0 && ref.face.faceL > 0 && face.faceL > 0) {
        perMM = ref.perMM * (face.faceL / ref.face.faceL); perMMsrc = 'front photo scale x (face length turned / front)';   /* length is not shortened by a turn */
      } else if (face.irisUsed && face.irisPx > 0) {
        var th = Math.asin(clamp(ay / 0.85, 0, 0.95)); perMM = (face.irisPx / Math.max(0.6, Math.cos(th * 0.5))) / IRIS_MM; perMMsrc = 'iris, corrected for the turn (rough)';
        notes.push('no front photo: scale is rough');
      } else if (face.faceL > 0) { perMM = face.faceL / ASSUMED_FACE_LEN_MM; perMMsrc = 'face length, assumed 188 mm (rough)'; notes.push('no front photo: scale is rough'); }
      if (!(perMM > 0)) return { error: 'no-face', advice: ADVICE['no-face'] };

      /* 2. millimetres per pixel of THIS 45 cut-out, from the lens height (a turn does not change heights) */
      var mmpp = 0, mmppSrc = '';
      if (ref.mmppFront > 0 && ref.lensHpx > 0 && fit.near.h > 0) { mmpp = ref.lensHpx * ref.mmppFront / fit.near.h; mmppSrc = 'front cut-out lens height'; }
      else {
        var lensMM = Number(o.sizes && o.sizes.lens) || 52;
        mmpp = (ASSUMED_LENS_H_RATIO * lensMM) / fit.near.h; mmppSrc = 'assumed lens height (' + ASSUMED_LENS_H_RATIO + ' x lens width) (rough)'; notes.push('no front cut-out: frame size is rough');
      }
      var s = mmpp * perMM;                                         /* cut-out pixel -> picture pixel */

      /* 3. where: the bridge on the nose midline, the lens line a little below the pupil line (the front's rule) */
      var ax = face.noseAxisX || (face.noseSeat && face.noseSeat.x) || ((pupilNear.x + (nearIsRight ? face.pupilR : face.pupilL).x) / 2);
      var ayLine = pupilNear.y + (ax - pupilNear.x) * Math.tan(roll) + SEAT_DROP_MM * perMM;
      var W = (o.faceImg.naturalWidth || o.faceImg.width) || face.w, H = (o.faceImg.naturalHeight || o.faceImg.height) || face.h;     /* the picture's own size */

      var layer = document.createElement('canvas'); layer.width = W; layer.height = H;
      var lx = layer.getContext('2d'); lx.imageSmoothingEnabled = true; if ('imageSmoothingQuality' in lx) lx.imageSmoothingQuality = 'high';
      /* d17.41 (shop): ONLY THE FRONT AND THE STRAIGHT ARM. Beside the near lens, a 45 photo also shows the far arm seen
         through the glass and the arms' hanging ear tips; on a face those land on the cheek. So, in the cut-out: past the
         near lens's outer edge only the arm's own band (from the top of the lens to just above its middle, where hinges
         sit) is kept, and past the far lens's outer edge nothing (the far arm is behind the head). */
      var cutM = document.createElement('canvas'); cutM.width = fit.w; cutM.height = fit.h;
      var cm = cutM.getContext('2d'); cm.drawImage(cut, 0, 0, fit.w, fit.h);
      cm.globalCompositeOperation = 'destination-out';
      var nW = fit.near.w, nH = fit.near.h, fW = fit.far.w;
      var armRight = fit.near.cx > fit.far.cx;                       /* the near lens is on the right of the cut-out: its arm goes right */
      var bandTop = fit.near.cy - nH * 0.56, bandBot = fit.near.cy - nH * 0.04;
      /* find the arm itself: beside the near lens, the row where the straight arm runs (the median height of what the
         cut-out kept there); then keep only a slim band around it, so a diagonal piece near the hinge goes too */
      try {
        var armSide = fit.near.cx > fit.far.cx ? 1 : -1;
        var ax0 = armSide > 0 ? Math.round(fit.near.cx + nW / 2 + nW * 0.06) : Math.round(fit.near.cx - nW / 2 - nW * 0.06 - nW * 0.6);
        var aw = Math.round(nW * 0.6), ay0 = Math.max(0, Math.round(bandTop)), ah = Math.max(1, Math.round(bandBot - bandTop));
        ax0 = Math.max(0, Math.min(fit.w - 1, ax0)); aw = Math.max(1, Math.min(fit.w - ax0, aw)); ah = Math.min(fit.h - ay0, ah);
        if (aw > 4 && ah > 4) {
          var ad = cm.getImageData(ax0, ay0, aw, ah).data, ys = [];
          for (var cxx = 0; cxx < aw; cxx += 2) { var sy = 0, sn = 0; for (var cyy = 0; cyy < ah; cyy++) { if (ad[(cyy * aw + cxx) * 4 + 3] > 128) { sy += cyy; sn++; } } if (sn) ys.push(ay0 + sy / sn); }
          if (ys.length > aw / 6) {
            ys.sort(function (u, v) { return u - v; }); var armY = ys[ys.length >> 1], half = Math.max(4, nH * 0.07);
            bandTop = Math.max(bandTop, armY - half); bandBot = Math.min(bandBot, armY + half);
          }
        }
      } catch (e) {}
      if (armRight) {
        var xa = fit.near.cx + nW / 2 + nW * 0.04;
        cm.fillRect(xa, 0, fit.w - xa, Math.max(0, bandTop)); cm.fillRect(xa, bandBot, fit.w - xa, fit.h - bandBot);
        var xf = fit.far.cx - fW / 2 - fW * 0.12; if (xf > 0) cm.fillRect(0, 0, xf, fit.h);
      } else {
        var xb = fit.near.cx - nW / 2 - nW * 0.04;
        cm.fillRect(0, 0, xb, Math.max(0, bandTop)); cm.fillRect(0, bandBot, xb, fit.h - bandBot);
        var xg = fit.far.cx + fW / 2 + fW * 0.12; if (xg < fit.w) cm.fillRect(xg, 0, fit.w - xg, fit.h);
      }
      /* d17.49 (shop): ONLY THE NEAR ARM. Beside the near lens the 45 photo also shows the far arm's dark tip crossing
         at hinge height; on a face it looked like a black stub on the cheek. The near arm is the same colour as the
         frame's end piece beside it, so in the arm band only pixels of that colour stay. */
      var R0, G0, B0;
      try {
        cm.globalCompositeOperation = 'source-over';
        var armSide2 = fit.near.cx > fit.far.cx ? 1 : -1, edgeX = fit.near.cx + armSide2 * (nW / 2);
        var y0b = Math.max(0, Math.floor(bandTop)), hb = Math.max(1, Math.min(fit.h, Math.ceil(bandBot)) - y0b);
        /* the frame's own colour: the top rim of the near lens (no arm ever crosses it) */
        var refX0 = Math.max(0, Math.round(fit.near.cx - nW * 0.3)), refW = Math.max(2, Math.min(fit.w - refX0, Math.round(nW * 0.6)));
        var refY0 = Math.max(0, Math.round(fit.near.cy - nH * 0.54)), refH = Math.max(2, Math.min(fit.h - refY0, Math.round(nH * 0.16)));
        var rd = cm.getImageData(refX0, refY0, refW, refH).data, rs = [];
        for (var q = 0; q < rd.length; q += 4) if (rd[q + 3] > 160) rs.push([rd[q], rd[q + 1], rd[q + 2]]);
        if (rs.length > 8) {
          var med = function (k) { var a = rs.map(function (c) { return c[k]; }).sort(function (u, v) { return u - v; }); return a[a.length >> 1]; };
          R0 = med(0); G0 = med(1); B0 = med(2);
          var ax0 = armSide2 > 0 ? Math.round(edgeX + nW * 0.03) : 0, aw0 = armSide2 > 0 ? fit.w - ax0 : Math.round(edgeX - nW * 0.03);
          if (aw0 > 2) {
            var ad = cm.getImageData(ax0, y0b, aw0, hb), dd = ad.data;
            for (var q2 = 0; q2 < dd.length; q2 += 4) { if (dd[q2 + 3] < 8) continue;
              var dist = Math.abs(dd[q2] - R0) + Math.abs(dd[q2 + 1] - G0) + Math.abs(dd[q2 + 2] - B0);
              if (dist > 150) dd[q2 + 3] = 0; }                       /* a different colour beside the near lens: the far arm */
            cm.putImageData(ad, ax0, y0b);
          }
        }
      } catch (e) {}
      /* d17.50 (shop: "when they turn, the far temple is disturbing on the face"): the far temple is also seen THROUGH
         the lenses at 45 -- a dark line across the glass. Inside each lens opening only the nose pads (on the bridge
         side, lower part) are kept; everything else seen through the glass is cleared, so only the near temple shows. */
      try {
        cm.globalCompositeOperation = 'destination-out';
        [fit.near, fit.far].forEach(function (L) {
          if (!L || !L.w || !L.h) return;
          var bridgeSide = (fit.bridge[0] > L.cx) ? 1 : -1;
          var px0 = Math.round(bridgeSide > 0 ? L.cx + L.w * 0.12 : L.cx - L.w * 0.5), pw = Math.round(L.w * 0.38);
          var py0 = Math.round(L.cy - L.h * 0.12), ph = Math.round(L.h * 0.62);
          px0 = Math.max(0, Math.min(fit.w - 1, px0)); pw = Math.max(1, Math.min(fit.w - px0, pw));
          py0 = Math.max(0, Math.min(fit.h - 1, py0)); ph = Math.max(1, Math.min(fit.h - py0, ph));
          var pads = cm.getImageData(px0, py0, pw, ph);
          cm.beginPath(); cm.ellipse(L.cx, L.cy, L.w * 0.47, L.h * 0.47, 0, 0, Math.PI * 2); cm.fill();
          cm.putImageData(pads, px0, py0);
          /* and right under the rims, inside the lens box: anything NOT the frame's own colour (the far temple's dark
             tip runs along the top rim there) goes; the rim itself is the frame's colour and stays */
          if (typeof R0 === 'number') {
            var bx0 = Math.max(0, Math.round(L.cx - L.w / 2)), by0 = Math.max(0, Math.round(L.cy - L.h / 2));
            var bw = Math.max(1, Math.min(fit.w - bx0, Math.round(L.w))), bh = Math.max(1, Math.min(fit.h - by0, Math.round(L.h)));
            var bd = cm.getImageData(bx0, by0, bw, bh), bdd = bd.data;
            for (var yy = 0; yy < bh; yy++) for (var xx = 0; xx < bw; xx++) {
              var gx = bx0 + xx, gy = by0 + yy;
              if (gx >= px0 && gx < px0 + pw && gy >= py0 && gy < py0 + ph) continue;      /* the nose pads */
              var q3 = (yy * bw + xx) * 4; if (bdd[q3 + 3] < 8) continue;
              if (Math.abs(bdd[q3] - R0) + Math.abs(bdd[q3 + 1] - G0) + Math.abs(bdd[q3 + 2] - B0) > 150) bdd[q3 + 3] = 0;
            }
            cm.putImageData(bd, bx0, by0);
          }
        });
        cm.globalCompositeOperation = 'source-over';
      } catch (e) {}
      lx.save(); lx.translate(ax, ayLine); lx.rotate(roll); lx.scale(s, s); lx.translate(-fit.bridge[0], -fit.bridge[1]);
      lx.drawImage(cutM, 0, 0, fit.w, fit.h); lx.restore();

      /* 4. the near arm fades out before the ear; nothing is drawn beyond it */
      var dist = Math.abs(earNear.x - pupilNear.x);
      var f0 = pupilNear.x + sgn * FADE_START * dist, f1 = pupilNear.x + sgn * (FADE_END * dist + 0.04 * (face.faceW || dist));
      var mask = document.createElement('canvas'); mask.width = W; mask.height = H;
      var mx = mask.getContext('2d'), g = mx.createLinearGradient(f0, 0, f1, 0);
      g.addColorStop(0, 'rgba(0,0,0,1)'); g.addColorStop(1, 'rgba(0,0,0,0)');
      mx.fillStyle = g; mx.fillRect(0, 0, W, H);
      lx.globalCompositeOperation = 'destination-in'; lx.drawImage(mask, 0, 0);

      var out = document.createElement('canvas'); out.width = W; out.height = H;
      var ox = out.getContext('2d'); ox.imageSmoothingEnabled = true; if ('imageSmoothingQuality' in ox) ox.imageSmoothingQuality = 'high';
      ox.drawImage(o.faceImg, 0, 0, W, H); ox.drawImage(layer, 0, 0);

      /* how well does the near lens sit on the near pupil? (a check, not a correction) */
      var cr = Math.cos(roll), sr = Math.sin(roll), dxc = (fit.near.cx - fit.bridge[0]) * s, dyc = (fit.near.cy - fit.bridge[1]) * s;
      var lensX = ax + dxc * cr - dyc * sr, lensY = ayLine + dxc * sr + dyc * cr;
      var offX = lensX - pupilNear.x, offY = lensY - pupilNear.y;
      var report = {
        engine: VERSION, yaw: +yaw.toFixed(3), yawWindow: [YAW_MIN, YAW_MAX], rollDeg: +(roll * 180 / Math.PI).toFixed(1),
        nearSide: wantSide, fitSource: fit.source || '?', perMM: +perMM.toFixed(3), perMMsource: perMMsrc,
        mmPerCutPx: +mmpp.toFixed(4), mmPerCutPxSource: mmppSrc, scale: +s.toFixed(4),
        anchor: { x: Math.round(ax), y: Math.round(ayLine) },
        nearLensVsPupil: { dxPx: Math.round(offX), dyPx: Math.round(offY), dxMM: +(offX / perMM).toFixed(1), dyMM: +(offY / perMM).toFixed(1) },
        earRootDistPx: Math.round(dist), armFadePx: [Math.round(f0), Math.round(f1)], notes: notes
      };
      if (Math.abs(report.nearLensVsPupil.dxMM) > 14) report.notes.push('near lens is far from the near eye: frame size or head turn may be off');
      return { canvas: out, report: report };
    } catch (e) { return { error: 'failed', advice: 'Something went wrong placing the frame.', detail: String(e && e.message || e) }; }
  }

  global.VG45 = { VERSION: VERSION, YAW_MIN: YAW_MIN, YAW_MAX: YAW_MAX, fitPointsFromImage: fitPointsFromImage, usableFit: usableFit, fitFor: fitFor,
                  perMMFromFace: perMMFromFace, frontReference: frontReference, headTurn: headTurn, pickView: pickView, fit45: fit45, ADVICE: ADVICE };
})(typeof window !== 'undefined' ? window : this);

/* Vision Gallery — visitor analytics with PostHog (d17.155)

   Counts visits, which pages and frames people open, and where they stop in
   the checkout -- so the shop can see what customers actually do.
   - Off until a PostHog project key is saved in Admin -> Settings -> Visitor analytics.
   - Nothing a customer TYPES is recorded (names, phone numbers, prescriptions):
     inputs are masked, and nobody is identified by name.
   - Never runs inside the Admin HEALTH test. */
(function (g) {
  'use strict';
  if (g.__vgAnalytics) return; g.__vgAnalytics = 1;
  try { if (/[?&]vgtest=1\b/.test(location.search) || (g.top !== g && g.top.__VG_HEALTH_RUNNER)) return; } catch (e) {}
  var DEF = { url: 'https://oscpunukbyosckrmopeh.supabase.co', key: 'sb_publishable_WWAPQTu0lo-X51T4kDlgng_LR39PPkU' };
  function db() { try { var s = JSON.parse(localStorage.getItem('vg_sync') || 'null'); if (s && s.url && s.key) return s; } catch (e) {} return DEF; }
  var CK = 'vg_ph_cfg', MAX_AGE = 6 * 3600e3;

  function start(cfg) {
    if (!cfg || !/^phc_[A-Za-z0-9]+/.test(cfg.key || '') || g.posthog && g.posthog.__loaded) return;
    var host = cfg.host === 'eu' ? 'https://eu.i.posthog.com' : 'https://us.i.posthog.com';
    /* PostHog's standard loader */
    !function (t, e) { var o, n, p, r; e.__SV || (g.posthog = e, e._i = [], e.init = function (i, s, a) { function q(t, e) { var o = e.split('.'); 2 == o.length && (t = t[o[0]], e = o[1]), t[e] = function () { t.push([e].concat(Array.prototype.slice.call(arguments, 0))); }; } (p = t.createElement('script')).type = 'text/javascript', p.crossOrigin = 'anonymous', p.async = !0, p.src = s.api_host.replace('.i.posthog.com', '-assets.i.posthog.com') + '/static/array.js', (r = t.getElementsByTagName('script')[0]).parentNode.insertBefore(p, r); var u = e; for (void 0 !== a ? u = e[a] = [] : a = 'posthog', u.people = u.people || [], u.toString = function (t) { var e = 'posthog'; return 'posthog' !== a && (e += '.' + a), t || (e += ' (stub)'), e; }, u.people.toString = function () { return u.toString(1) + '.people (stub)'; }, o = 'capture identify alias people.set people.set_once set_config register register_once unregister opt_out_capturing has_opted_out_capturing opt_in_capturing reset isFeatureEnabled onFeatureFlags getFeatureFlag getFeatureFlagPayload reloadFeatureFlags group onSessionId'.split(' '), n = 0; n < o.length; n++) q(u, o[n]); e._i.push([i, s, a]); }, e.__SV = 1); }(document, g.posthog || []);
    g.posthog.init(cfg.key, {
      api_host: host,
      person_profiles: 'identified_only',          /* nobody is identified; visits are counted anonymously */
      capture_pageview: true, capture_pageleave: true, autocapture: true,
      mask_all_element_attributes: false, mask_all_text: false,
      session_recording: { maskAllInputs: true, maskTextSelector: '.rx, .order, input, textarea' },
      sanitize_properties: function (props) {      /* never keep a mobile number or e-mail that ended up in a page address */
        try { ['$current_url', '$pathname', '$referrer'].forEach(function (k) { if (props[k]) props[k] = String(props[k]).replace(/([?&](?:phone|mobile|email|ref)=)[^&#]*/gi, '$1x'); }); } catch (e) {}
        return props;
      }
    });
  }

  function cached() { try { var c = JSON.parse(localStorage.getItem(CK) || 'null'); if (c && Date.now() - c.at < MAX_AGE) return c; } catch (e) {} return null; }
  var c = cached();
  if (c) { start(c); return; }
  var d = db();
  try {
    fetch(d.url + '/rest/v1/products?select=data&id=eq.__shop', { headers: { apikey: d.key } }).then(function (r) { return r.ok ? r.json() : []; }).then(function (rows) {
      var sh = (rows && rows[0] && rows[0].data && rows[0].data.shop) || {};
      var cfg = { key: String(sh.posthogKey || '').trim(), host: sh.posthogHost === 'eu' ? 'eu' : 'us', at: Date.now() };
      try { localStorage.setItem(CK, JSON.stringify(cfg)); } catch (e) {}
      start(cfg);
    }, function () {});
  } catch (e) {}

  /* a few named moments, so the PostHog funnels read in plain words */
  g.vgTrack = function (name, props) { try { if (g.posthog && g.posthog.capture) g.posthog.capture(name, props || {}); } catch (e) {} };
})(window);

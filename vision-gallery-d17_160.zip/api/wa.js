/* Vision Gallery — WhatsApp relay for Admin (d17.155)

   Admin runs on the secure website (https). The WhatsApp sender on the Google
   Cloud computer has a plain http address, and a browser is not allowed to
   talk from https to http -- so messages sent from Admin never left. This
   function sits on the website itself: Admin talks to it (same site, allowed),
   and it passes the message on to the sender, server to server (allowed).
   The sender key stays here, never in the browser.

   GET  /api/wa?check=1   -> { configured }
   GET  /api/wa?health=1  -> the sender's own status (signed-in staff only)
   POST /api/wa           -> { phone, text, file?, filename?, mimetype? } (signed-in staff only) */
'use strict';
const L = require('./_lib.js');

module.exports = async function (req, res) {
  const q = L.query(req);
  if (req.method === 'GET' && q.get('check')) return L.send(res, 200, { configured: L.senderReady() });
  if (!L.senderReady()) return L.send(res, 501, { ok: false, configured: false, error: 'The WhatsApp sender is not set up on the website yet (SENDER_URL / SENDER_KEY in Vercel).' });
  const user = await L.staffUser(req);
  if (!user) return L.send(res, 401, { ok: false, error: 'Sign in to Admin first.' });

  if (req.method === 'GET' && q.get('health')) {
    const base = L.env('SENDER_URL').replace(/\/send\/?$/, '').replace(/\/+$/, '');
    for (const p of ['/health', '/status', '/']) {
      try {
        const r = await fetch(base + p, { headers: { Accept: 'application/json' } });
        const t = await r.text(); let j = null; try { j = JSON.parse(t); } catch (e) {}
        if (r.ok && j) return L.send(res, 200, { ok: true, ready: !!(j.ready || j.linked || /linked/i.test(String(j.status || ''))), me: j.me || j.number || j.phone || '', raw: j });
        if (r.ok && p === '/') return L.send(res, 200, { ok: true, ready: /\blinked\b/i.test(t) && !/not linked/i.test(t), me: ((/linked as\s*(\+?\d[\d ]{8,})/i.exec(t.replace(/<[^>]+>/g, ' ')) || [])[1] || '').replace(/\s/g, '') });
      } catch (e) { if (p === '/') return L.send(res, 502, { ok: false, error: 'The sender did not answer: ' + e.message }); }
    }
    return L.send(res, 502, { ok: false, error: 'The sender did not answer.' });
  }

  if (req.method !== 'POST') return L.send(res, 405, { ok: false, error: 'POST only' });
  const b = await L.body(req);
  if (!b || !b.phone || !(b.text || b.file)) return L.send(res, 400, { ok: false, error: 'phone and text are needed' });
  const extra = {}; if (b.file) { extra.file = b.file; extra.filename = b.filename || 'document.pdf'; extra.mimetype = b.mimetype || 'application/pdf'; }
  const r = await L.whatsapp(b.phone, String(b.text || ''), extra);
  return L.send(res, r.ok ? 200 : 502, r);
};

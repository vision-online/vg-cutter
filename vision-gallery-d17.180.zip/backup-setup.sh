#!/bin/bash
# Vision Gallery: switch on the WEEKLY BACKUP on this computer (d17.178, 24 Oct 2026)
# Every Sunday at 11 pm (India time) this computer:
#   1. asks the website for every record -- frames, orders, settings, the chat's approved answers (no photos)
#   2. saves them as one file in ~/vg-backups (vg-backup-YYYY-MM-DD.tar.gz) and keeps the last 8 weeks
#   3. tells the website (Admin -> HEALTH -> Weekly backup); if anything fails, or the disk has less than 1 GB free,
#      it WhatsApps the alert number instead.
# Nothing secret is in this file: it uses the key the watchman already keeps on this computer (~/vg-watch.conf).
echo "Vision Gallery weekly backup setup"
NODE=$(command -v node)
if [ -z "$NODE" ]; then echo "node is not on this computer -- tell your website support. Nothing changed."; exit 1; fi
if ! command -v crontab >/dev/null; then
  echo "Installing the timer (cron)..."
  sudo apt-get update -qq >/dev/null 2>&1; sudo apt-get install -y -qq cron >/dev/null 2>&1
  if ! command -v crontab >/dev/null; then echo "The timer (cron) could not be installed -- tell your website support. Nothing changed."; exit 1; fi
fi
umask 077
if [ -f "$HOME/vg-watch.conf" ]; then
  . "$HOME/vg-watch.conf"
  echo "Using the key the watchman already has."
else
  read -r -p "Paste the WhatsApp sender key (the same as SENDER_KEY in Vercel): " K
  read -r -p "Your mobile number for backup alerts (10 digits): " N
  N=$(printf '%s' "$N" | tr -cd '0-9'); N=${N: -10}
  if [ -z "$K" ] || [ ${#N} -ne 10 ]; then echo "Key or number missing. Nothing changed."; exit 1; fi
  printf 'K=%q\nN=%q\nNODE=%q\n' "$K" "91$N" "$NODE" > "$HOME/vg-backup.conf"
fi
C=$(curl -s -m 60 -o /dev/null -w '%{http_code}' -H "x-key: $K" "https://visiongallery.me/api/backup?tables=1")
if [ "$C" = "403" ]; then echo "WRONG KEY: the key is not the same as SENDER_KEY in Vercel. Nothing changed."; exit 1; fi
if [ "$C" != "200" ]; then echo "The website answered $C. 404 = upload the latest website zip first. 501 = SUPABASE_SERVICE_KEY is missing in Vercel. Nothing changed."; exit 1; fi
cat > "$HOME/vg-backup.sh" <<'EOS'
#!/bin/bash
# Vision Gallery weekly backup -- runs every Sunday night (crontab). Settings in ~/vg-watch.conf (or ~/vg-backup.conf)
umask 077                                    # the backups hold customer details: readable by this user only
export PATH="$PATH:/usr/local/bin:/usr/bin:/bin"
if [ -f "$HOME/vg-watch.conf" ]; then . "$HOME/vg-watch.conf"; elif [ -f "$HOME/vg-backup.conf" ]; then . "$HOME/vg-backup.conf"; fi   # the watchman's key first
[ -x "$NODE" ] || NODE=$(command -v node)
KQ=$("$NODE" -e 'process.stdout.write(encodeURIComponent(process.argv[1]))' "$K")
SITE="https://visiongallery.me"
D="$HOME/vg-backups"; mkdir -p "$D"
when() { TZ=Asia/Kolkata date '+%d %b %H:%M'; }
send() {
  local T="$1" Q B
  Q=$("$NODE" -e 'process.stdout.write(encodeURIComponent(process.argv[1]))' "$T")
  B=$("$NODE" -e 'process.stdout.write(JSON.stringify({phone:process.argv[1],number:process.argv[1],text:process.argv[2],message:process.argv[2]}))' "$N" "$T")
  curl -s -m 20 -X POST -H 'Content-Type: application/json' -H "x-key: $K" -d "$B" "http://localhost:3000/send?key=$KQ&phone=$N&to=$N&text=$Q" >/dev/null
}
report() {   # report <ok true|false> <file> <bytes> <kept> <freeMB> <note>
  local B
  B=$("$NODE" -e 'const a=process.argv;process.stdout.write(JSON.stringify({at:new Date().toISOString(),ok:a[1]==="true",file:a[2],bytes:+a[3]||0,kept:+a[4]||0,freeMB:+a[5]||0,note:a[6]||""}))' "$1" "$2" "$3" "$4" "$5" "$6")
  curl -s -m 30 -X POST -H 'Content-Type: application/json' -H "x-key: $K" -d "$B" "$SITE/api/backup?done=1" >/dev/null
}
FREE=$(df -Pm "$HOME" | awk 'NR==2{print $4}')
if [ "${FREE:-0}" -lt 1024 ]; then
  send "⚠️ VISION GALLERY BACKUP — the WhatsApp computer has only ${FREE} MB free, so this week's backup was NOT made ($(when)). Send this to your website support."
  report false "" 0 0 "$FREE" "less than 1 GB free"; exit 1
fi
T=$(mktemp -d)
fail() { send "⚠️ VISION GALLERY BACKUP — this week's backup did NOT finish ($1, $(when)). It tries again next Sunday; if this repeats, send this to your website support."; report false "" 0 0 "$FREE" "$1"; rm -rf "$T"; exit 1; }
for t in $(curl -s -m 60 -H "x-key: $K" "$SITE/api/backup?tables=1" | "$NODE" -e 'let s="";process.stdin.on("data",d=>s+=d).on("end",()=>{try{process.stdout.write(JSON.parse(s).tables.join(" "))}catch(e){}})'); do
  p=0
  while :; do
    C=$(curl -s -m 120 -o "$T/$t-$(printf '%04d' $p).json" -w '%{http_code}' -H "x-key: $K" "$SITE/api/backup?table=$t&page=$p")
    [ "$C" = "200" ] || fail "$t page $p answered $C"
    M=$("$NODE" -e 'try{const j=JSON.parse(require("fs").readFileSync(process.argv[1],"utf8"));process.stdout.write(j.ok?(j.more?"1":"0"):"x")}catch(e){process.stdout.write("x")}' "$T/$t-$(printf '%04d' $p).json")
    [ "$M" = "x" ] && fail "$t page $p unreadable"
    [ "$M" = "1" ] || break
    p=$((p+1)); [ $p -gt 2000 ] && break
  done
done
ls "$T"/*.json >/dev/null 2>&1 || fail "nothing was read"
F="$D/vg-backup-$(TZ=Asia/Kolkata date +%Y-%m-%d).tar.gz"
tar -czf "$F" -C "$T" . || fail "the file could not be written"
rm -rf "$T"
ls -1t "$D"/vg-backup-*.tar.gz 2>/dev/null | tail -n +9 | xargs -r rm -f
KEPT=$(ls -1 "$D"/vg-backup-*.tar.gz 2>/dev/null | wc -l)
BYTES=$(stat -c %s "$F")
FREE=$(df -Pm "$HOME" | awk 'NR==2{print $4}')
report true "$(basename "$F")" "$BYTES" "$KEPT" "$FREE" ""
echo "BACKUP-OK $(basename "$F") $BYTES bytes, $KEPT kept"
EOS
chmod 700 "$HOME/vg-backup.sh"
# Sunday 11 pm India time = Sunday 17:30 in the computer's own clock (UTC)
( crontab -l 2>/dev/null | grep -v 'vg-backup.sh'; echo "30 17 * * 0 /bin/bash $HOME/vg-backup.sh >/dev/null 2>&1" ) | crontab -
if ! crontab -l 2>/dev/null | grep -q 'vg-backup.sh'; then echo "The weekly timer could not be set -- tell your website support."; exit 1; fi
echo "Making the first backup now..."
OUT=$(/bin/bash "$HOME/vg-backup.sh" 2>&1 | tail -1)
case "$OUT" in
  BACKUP-OK*) echo "BACKUP-ON: $OUT. From now on every Sunday at 11 pm, the last 8 weeks kept in ~/vg-backups." ;;
  *) echo "The timer is set, but the first backup did not finish: $OUT -- tell your website support." ;;
esac

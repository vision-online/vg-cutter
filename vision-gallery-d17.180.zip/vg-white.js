/* Vision Gallery — WHITE BACKGROUND WITHOUT TOUCHING THE FRAME (d17.175, shop 24 Oct: "100% white, nothing to touch --
   go with this look, for all the frames, automatically")

   The frame is NOT cut out. Only the sheet behind it turns white:
     1. the light falling on the sheet is measured across the photo (the brightest nearby sheet, smoothed), so grey or
        uneven light still reads as "sheet";
     2. a pixel that is as bright as the sheet around it, and not coloured, is sheet -> white; anything darker or coloured
        is the frame and is left EXACTLY as photographed;
     3. only sheet that reaches the edge of the photo, or a big piece of it (the sheet seen through a lens), turns white --
        a small bright spot (shine on the rim) stays as it is;
     4. CRYSTAL / CLEAR FRAMES (d17.176, shop 24 Oct: "keep that also white -- it looks like a grey stone"): a frame that is
        hardly darker than the sheet is found by its OUTLINE (the fine edges a smooth sheet does not have); a thin band along
        that outline keeps the photo's own soft grey, everything else turns white -- so a clear frame shows as a clear frame
        on white. Only a photo where no frame outline can be found at all keeps its original (nothing to show).
   VGWhite.make(imageOrCanvas) -> { canvas, safe:true, stats } or { safe:false, reason, stats } */
(function (g) {
  'use strict';
  if (g.VGWhite) return;
  var T0 = 0.80, T1 = 0.93;          /* brightness against the sheet: below T0 = frame, above T1 = sheet */

  function boxBlur(src, w, h, r) {     /* separable box blur, edges clamped */
    if (r < 1) return src;
    var tmp = new Float32Array(w * h), out = new Float32Array(w * h), x, y, s, n = 2 * r + 1;
    for (y = 0; y < h; y++) { var row = y * w; s = 0;
      for (x = -r; x <= r; x++) s += src[row + Math.min(w - 1, Math.max(0, x))];
      for (x = 0; x < w; x++) { tmp[row + x] = s / n; s += src[row + Math.min(w - 1, x + r + 1)] - src[row + Math.max(0, x - r)]; } }
    for (x = 0; x < w; x++) { s = 0;
      for (y = -r; y <= r; y++) s += tmp[Math.min(h - 1, Math.max(0, y)) * w + x];
      for (y = 0; y < h; y++) { out[y * w + x] = s / n; s += tmp[Math.min(h - 1, y + r + 1) * w + x] - tmp[Math.max(0, y - r) * w + x]; } }
    return out;
  }
  function gauss(src, w, h, sigma) {   /* three box blurs ~ a Gaussian */
    var r = Math.max(1, Math.round(Math.sqrt(12 * sigma * sigma / 3 + 1) / 2));
    return boxBlur(boxBlur(boxBlur(src, w, h, r), w, h, r), w, h, r);
  }
  function maxFilter(src, w, h, size) {
    var r = (size - 1) >> 1, tmp = new Float32Array(w * h), out = new Float32Array(w * h), x, y, k, m;
    for (y = 0; y < h; y++) for (x = 0; x < w; x++) { m = 0;
      for (k = Math.max(0, x - r); k <= Math.min(w - 1, x + r); k++) if (src[y * w + k] > m) m = src[y * w + k];
      tmp[y * w + x] = m; }
    for (x = 0; x < w; x++) for (y = 0; y < h; y++) { m = 0;
      for (k = Math.max(0, y - r); k <= Math.min(h - 1, y + r); k++) if (tmp[k * w + x] > m) m = tmp[k * w + x];
      out[y * w + x] = m; }
    return out;
  }

  function make(img) {
    var W = img.naturalWidth || img.width, H = img.naturalHeight || img.height;
    if (!(W > 16 && H > 16)) return { safe: false, reason: 'no picture' };
    var c = document.createElement('canvas'); c.width = W; c.height = H;
    var x = c.getContext('2d', { willReadFrequently: true }); x.drawImage(img, 0, 0, W, H);
    var id = x.getImageData(0, 0, W, H), d = id.data, N = W * H, i, j;
    var lum = new Float32Array(N), sat = new Float32Array(N);
    for (i = 0, j = 0; i < N; i++, j += 4) {
      var r0 = d[j] / 255, g0 = d[j + 1] / 255, b0 = d[j + 2] / 255;
      lum[i] = (r0 + g0 + b0) / 3; sat[i] = Math.max(r0, g0, b0) - Math.min(r0, g0, b0);
    }
    /* 1. the light on the sheet, worked out small (about 400 px across) and spread back over the photo */
    var k = Math.max(1, Math.round(Math.max(W, H) / 400)), w = Math.max(8, Math.floor(W / k)), h = Math.max(8, Math.floor(H / k));
    var sc = document.createElement('canvas'); sc.width = w; sc.height = h;
    var sx = sc.getContext('2d', { willReadFrequently: true }); sx.imageSmoothingQuality = 'high'; sx.drawImage(c, 0, 0, w, h);
    var sd = sx.getImageData(0, 0, w, h).data, small = new Float32Array(w * h);
    for (i = 0, j = 0; i < w * h; i++, j += 4) small[i] = (sd[j] + sd[j + 1] + sd[j + 2]) / 765;
    var R = Math.max(3, Math.round(Math.min(w, h) * 0.04)) | 1;
    var bgS = gauss(maxFilter(small, w, h, R), w, h, R * 0.8);
    for (i = 0, j = 0; i < w * h; i++, j += 4) { var v = Math.round(Math.max(0.25, Math.min(1, bgS[i])) * 255); sd[j] = sd[j + 1] = sd[j + 2] = v; sd[j + 3] = 255; }
    sx.putImageData(new ImageData(sd, w, h), 0, 0);
    var bc = document.createElement('canvas'); bc.width = W; bc.height = H;
    var bx = bc.getContext('2d', { willReadFrequently: true }); bx.imageSmoothingEnabled = true; bx.imageSmoothingQuality = 'high'; bx.drawImage(sc, 0, 0, W, H);
    var bd = bx.getImageData(0, 0, W, H).data;

    /* 2. how much each pixel is sheet (0 = frame, 1 = sheet), and the safety numbers */
    var wt = new Float32Array(N), solid = 0, faint = 0;
    var lumS = boxBlur(boxBlur(lum, W, H, 1), W, H, 1);                     /* the camera's grain on the sheet is not frame */
    for (i = 0, j = 0; i < N; i++, j += 4) {
      var bg = Math.max(0.25, bd[j] / 255), rel = Math.max(lum[i], lumS[i]) / bg;
      var a = (lum[i] / bg < T0 || lum[i] < 0.40 || bg < 0.45) ? 0 : Math.min(1, Math.max(0, (rel - T0) / (T1 - T0)));   /* a dark pixel is frame, whatever is around it; the sheet is never darker than 45% grey */
      a *= Math.min(1, Math.max(0, 1 - (sat[i] - 0.10) / 0.10));        /* coloured = frame */
      wt[i] = a;
      if (rel < 0.70 || sat[i] > 0.20) solid++; else if (rel < 0.80) faint++;
    }
    var stats = { solid: solid / N, faint: faint / N, w: W, h: H };
    /* 4. a crystal / clear frame: protect its outline */
    stats.mode = stats.solid < 0.004 ? 'clear' : 'normal';
    if (stats.mode === 'clear') {
      var gr = new Float32Array(N);
      for (i = 0, j = 0; i < N; i++, j += 4) gr[i] = lum[i] / Math.max(0.25, bd[j] / 255);
      gr = boxBlur(boxBlur(gr, W, H, 1), W, H, 1);
      var edgeM = new Uint8Array(N), ecount = 0;
      for (var ey = 1; ey < H - 1; ey++) for (var ex = 1; ex < W - 1; ex++) { var q0 = ey * W + ex;
        var gx = (gr[q0 - W + 1] + 2 * gr[q0 + 1] + gr[q0 + W + 1]) - (gr[q0 - W - 1] + 2 * gr[q0 - 1] + gr[q0 + W - 1]);
        var gy = (gr[q0 + W - 1] + 2 * gr[q0 + W] + gr[q0 + W + 1]) - (gr[q0 - W - 1] + 2 * gr[q0 - W] + gr[q0 - W + 1]);
        if (Math.sqrt(gx * gx + gy * gy) > 0.12) edgeM[q0] = 1; }
      /* only real lines, not specks of grain */
      var elab = new Int32Array(N), est = new Int32Array(N), minE = Math.max(30, N * 0.00004), EL = 0;
      for (i = 0; i < N; i++) { if (!edgeM[i] || elab[i]) continue; EL++; var ep = 0, comp = []; est[ep++] = i; elab[i] = EL;
        while (ep) { var e0 = est[--ep], e0x = e0 % W; comp.push(e0);
          if (e0x > 0 && edgeM[e0 - 1] && !elab[e0 - 1]) { elab[e0 - 1] = EL; est[ep++] = e0 - 1; }
          if (e0x < W - 1 && edgeM[e0 + 1] && !elab[e0 + 1]) { elab[e0 + 1] = EL; est[ep++] = e0 + 1; }
          if (e0 >= W && edgeM[e0 - W] && !elab[e0 - W]) { elab[e0 - W] = EL; est[ep++] = e0 - W; }
          if (e0 < N - W && edgeM[e0 + W] && !elab[e0 + W]) { elab[e0 + W] = EL; est[ep++] = e0 + W; } }
        if (comp.length < minE) for (var ci = 0; ci < comp.length; ci++) edgeM[comp[ci]] = 0; else ecount += comp.length; }
      if (ecount < N * 0.0005) return { safe: false, reason: 'no frame outline found -- the original is kept', stats: stats };
      for (var di = 0; di < 2; di++) { var en = new Uint8Array(edgeM);
        for (i = 0; i < N; i++) { if (edgeM[i]) continue; var exx = i % W;
          if ((exx > 0 && edgeM[i - 1]) || (exx < W - 1 && edgeM[i + 1]) || (i >= W && edgeM[i - W]) || (i < N - W && edgeM[i + W])) en[i] = 1; }
        edgeM = en; }
      var prot = new Float32Array(N); for (i = 0; i < N; i++) prot[i] = edgeM[i];
      prot = boxBlur(boxBlur(prot, W, H, 1), W, H, 1);
      for (i = 0; i < N; i++) wt[i] *= 1 - Math.min(1, prot[i] * 1.6);
      stats.edges = ecount / N;
    }

    /* 3. only the sheet: pieces touching the photo's edge, or big pieces (the sheet through a lens) */
    var lab = new Int32Array(N), stack = new Int32Array(N), L = 0, keep = [false], big = N * 0.004;
    for (i = 0; i < N; i++) {
      if (lab[i] || wt[i] <= 0.5) continue;
      L++; var sp = 0, size = 0, edge = false; stack[sp++] = i; lab[i] = L;
      while (sp) { var q = stack[--sp], qx = q % W, qy = (q - qx) / W; size++;
        if (qx === 0 || qy === 0 || qx === W - 1 || qy === H - 1) edge = true;
        if (qx > 0 && !lab[q - 1] && wt[q - 1] > 0.5) { lab[q - 1] = L; stack[sp++] = q - 1; }
        if (qx < W - 1 && !lab[q + 1] && wt[q + 1] > 0.5) { lab[q + 1] = L; stack[sp++] = q + 1; }
        if (qy > 0 && !lab[q - W] && wt[q - W] > 0.5) { lab[q - W] = L; stack[sp++] = q - W; }
        if (qy < H - 1 && !lab[q + W] && wt[q + W] > 0.5) { lab[q + W] = L; stack[sp++] = q + W; } }
      keep[L] = edge || size > big;
    }
    var sheet = new Uint8Array(N);
    for (i = 0; i < N; i++) sheet[i] = keep[lab[i]] ? 1 : 0;
    for (var it = 0; it < 2; it++) {                                      /* reach the soft edge of the sheet (2 px) */
      var nx = new Uint8Array(sheet);
      for (var yy = 0; yy < H; yy++) for (var xx = 0; xx < W; xx++) { var p = yy * W + xx; if (sheet[p]) continue;
        if ((xx > 0 && sheet[p - 1]) || (xx < W - 1 && sheet[p + 1]) || (yy > 0 && sheet[p - W]) || (yy < H - 1 && sheet[p + W])) nx[p] = 1; }
      sheet = nx;
    }
    /* the ramp between T0 and T1 already gives a soft edge; a dark (frame) pixel has weight 0 and is never changed */
    for (i = 0, j = 0; i < N; i++, j += 4) {
      var f = sheet[i] ? Math.min(1, Math.max(0, (wt[i] - 0.1) / 0.6)) : 0; if (f <= 0) continue;   /* mostly-sheet = all white */
      d[j] = Math.round(d[j] * (1 - f) + 255 * f); d[j + 1] = Math.round(d[j + 1] * (1 - f) + 255 * f); d[j + 2] = Math.round(d[j + 2] * (1 - f) + 255 * f);
    }
    x.putImageData(id, 0, 0);
    return { canvas: c, safe: true, stats: stats };
  }
  g.VGWhite = { make: make, VERSION: 'd17.176' };
})(window);

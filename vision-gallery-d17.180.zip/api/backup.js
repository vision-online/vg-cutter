/* Vision Gallery — WEEKLY BACKUP (d17.178, shop 24 Oct: "weekly automatic backup of the frames, orders and settings")

   The WhatsApp computer (Google Cloud) runs ~/vg-backup.sh every Sunday night (set up once with backup-setup.sh). It reads
   everything from here, page by page, and keeps the last 8 weeks on its own disk. Photos are not in it (they stay in the
   photo storage); records only: frames, orders, settings (public and private), the chat's approved answers.
   Admin -> HEALTH shows the last backup and has DOWNLOAD BACKUP (a copy on the laptop).

   GET  /api/backup?table=<name>&page=<n>    -> { ok, rows:[...], more }     key = SENDER_KEY (the computer) or a signed-in staff token
   GET  /api/backup?tables=1                 -> { ok, tables:[...] }
   POST /api/backup?done=1  { at, file, bytes, kept, freeMB }   (the computer, key)  -> the result is kept for HEALTH
   GET  /api/backup?status=1                 -> { ok, last }                  (staff) */
'use strict';
const crypto = require('crypto');
const L = require('./_lib.js');

const TABLES = { products: 'id.asc', orders: 'created_at.asc,ref.asc', shop_private: 'id.asc', chat_learned: 'id.asc' };
const PAGE = 100;      /* small pages: a frame or order record can be large, and an answer must stay under 4.5 MB */
function same(a, b) { const x = crypto.createHash('sha256').update(String(a)).digest(), y = crypto.createHash('sha256').update(String(b)).digest(); return crypto.timingSafeEqual(x, y) && String(a) === String(b); }
const PASS_KEYS = /^(pass|passcode|password|pin)$/i;
function noPass(v) { if (Array.isArray(v)) return v.map(noPass); if (v && typeof v === 'object') { const o = {}; for (const k of Object.keys(v)) { if (!PASS_KEYS.test(k)) o[k] = noPass(v[k]); } return o; } return v; }
async function allowed(req, q) {
  const k = String(req.headers['x-key'] || '');                           /* header only: a key in the address ends up in logs */
  if (k && L.env('SENDER_KEY') && same(k, L.env('SENDER_KEY'))) return 'computer';
  const u = await L.staffUser(req); return u ? 'staff' : '';
}

module.exports = async (req, res) => {
  if (!L.env('SUPABASE_SERVICE_KEY')) return L.send(res, 501, { ok: false, notSetUp: true });
  const q = L.query(req);
  const who = await allowed(req, q);
  if (!who) return L.send(res, 403, { ok: false, error: 'not allowed' });

  if (req.method === 'POST' && q.get('done')) {
    if (who !== 'computer') return L.send(res, 403, { ok: false });
    const b = await L.body(req);
    const last = { at: String(b.at || new Date().toISOString()).slice(0, 40), file: String(b.file || '').slice(0, 80), bytes: Number(b.bytes) || 0,
      kept: Number(b.kept) || 0, freeMB: Number(b.freeMB) || 0, ok: b.ok === true || b.ok === 'true', note: String(b.note || '').slice(0, 200) };
    const r = await L.db('/rest/v1/shop_private?on_conflict=id', { method: 'POST', headers: { Prefer: 'resolution=merge-duplicates,return=minimal' },
      body: JSON.stringify([{ id: '__backup', data: last, updated_at: new Date().toISOString() }]) });
    return L.send(res, r.ok ? 200 : 502, { ok: r.ok });
  }
  if (req.method !== 'GET') return L.send(res, 405, { ok: false });
  if (q.get('tables')) return L.send(res, 200, { ok: true, tables: Object.keys(TABLES), page: PAGE });
  if (q.get('status')) {
    const r = await L.db('/rest/v1/shop_private?select=data,updated_at&id=eq.__backup');
    return L.send(res, 200, { ok: true, last: (r.ok && r.body && r.body[0] && r.body[0].data) || null });
  }
  const t = q.get('table'), page = Math.max(0, Math.floor(Number(q.get('page')) || 0));
  if (!TABLES[t]) return L.send(res, 400, { ok: false, error: 'unknown table' });
  if (L.tooMany('bk:' + (who === 'computer' ? 'pc' : String(req.headers['x-forwarded-for'] || 'ip')), 600, 3600e3)) return L.send(res, 429, { ok: false });
  let path = '/rest/v1/' + t + '?select=*&order=' + TABLES[t] + '&limit=' + (PAGE + 1) + '&offset=' + (page * PAGE);
  if (t === 'shop_private') path += '&id=not.like.login:*';                   /* the passcode-try notes are not worth keeping */
  const r = await L.db(path);
  if (!r.ok || !Array.isArray(r.body)) return L.send(res, 502, { ok: false, error: 'the database did not answer (' + r.status + ')' });
  const more = r.body.length > PAGE;
  let rows = r.body.slice(0, PAGE);
  if (t === 'shop_private' && who !== 'computer') rows = noPass(rows);            /* DOWNLOAD BACKUP on a laptop: no staff passcodes in the file */
  return L.send(res, 200, { ok: true, table: t, page, rows, more });
};
module.exports.TABLES = TABLES;

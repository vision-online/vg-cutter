/* Vision Gallery — AUTO TOUCH-UP of the robot's cut-outs (d17.183, shop 25 Oct: "my staff can look and compare, but they
   cannot do the editing -- it takes a lot of time. The robot has the original photo: let it do the final touch.")

   Exactly what staff do in FIX with PUT BACK and CLEAN, done by itself, with the same rules as their brushes:
     - the edit panel's own comparison of the ORIGINAL photo with the robot's cut finds the spots:
         pink = frame the robot cut away,  blue = background / glass the robot left in;
     - pink is put back FROM THE ORIGINAL PHOTO (the real frame, nothing drawn or invented);
     - blue is cleared, except anything that is clearly part of the frame's own body (it is never removed).
   The robot's own cut is kept, so ROBOT'S OWN puts it back in one tap. Staff still compare and APPROVE.
   VGTouch.run(cutImage, originalImage) -> { canvas, put, clean, pinkSpots, blueSpots } (same size as the cut) */
(function (g) {
  'use strict';
  if (g.VGTouch) return;
  const T_FRAME = 24, T_BG = 13;
  function frameAlpha(fm, i){             /* how solid this pixel should be if it were frame: 0 = background */
    const d = fm.diff[i], e = fm.edge[i];
    const a = Math.min(1, Math.max(0, (d - T_BG) / (T_FRAME - T_BG)));
    const ea = Math.min(1, Math.max(0, (e - 14) / 30));
    return Math.max(a, ea * 0.9);
  }
  function frameMap(src, cut){
    const W = cut.width, H = cut.height, n = W * H;
    let sd; try { const t2 = document.createElement('canvas'); t2.width = W; t2.height = H; const g = t2.getContext('2d'); g.drawImage(src, 0, 0, W, H); sd = g.getImageData(0, 0, W, H).data; } catch(e){ return null; }
    const cd = cut.getContext('2d').getImageData(0, 0, W, H).data;
    /* THE BACKGROUND, FROM THE PHOTO ITSELF (not from the cut-out, which may be wrong exactly where it needs fixing):
       the photo shrunk 8 times, a median that wipes out anything thin -- rims, arms, bars -- and grown back smoothly.
       What is left is the sheet, its shading and the floor. */
    const k8 = 8, sw = Math.max(8, Math.round(W / k8)), sh = Math.max(8, Math.round(H / k8));
    const sm = document.createElement('canvas'); sm.width = sw; sm.height = sh; const smx = sm.getContext('2d');
    smx.drawImage(src, 0, 0, sw, sh);
    const sp = smx.getImageData(0, 0, sw, sh), spd = sp.data, med = new Uint8ClampedArray(spd.length);
    const MR = Math.max(4, Math.round(Math.min(sw, sh) * 0.12)), buf = [];      /* wide enough to wipe out a thick bar too */
    for (let y = 0; y < sh; y++) for (let x = 0; x < sw; x++){
      for (let ch = 0; ch < 3; ch++){
        buf.length = 0;
        for (let dy = -MR; dy <= MR; dy++){ const yy = Math.min(sh - 1, Math.max(0, y + dy));
          for (let dx = -MR; dx <= MR; dx++){ const xx = Math.min(sw - 1, Math.max(0, x + dx)); buf.push(spd[(yy * sw + xx) * 4 + ch]); } }
        buf.sort((u, v) => u - v); med[(y * sw + x) * 4 + ch] = buf[buf.length >> 1];
      }
      med[(y * sw + x) * 4 + 3] = 255;
    }
    smx.putImageData(new ImageData(med, sw, sh), 0, 0);
    const big = document.createElement('canvas'); big.width = W; big.height = H; const bgx = big.getContext('2d');
    bgx.imageSmoothingEnabled = true; bgx.imageSmoothingQuality = 'high'; bgx.drawImage(sm, 0, 0, W, H);
    const bgd = bgx.getImageData(0, 0, W, H).data;
    const diff = new Float32Array(n), gray = new Float32Array(n);
    for (let i = 0; i < n; i++){ const j = i * 4;
      diff[i] = Math.max(Math.abs(sd[j] - bgd[j]), Math.abs(sd[j + 1] - bgd[j + 1]), Math.abs(sd[j + 2] - bgd[j + 2]));
      gray[i] = 0.299 * sd[j] + 0.587 * sd[j + 1] + 0.114 * sd[j + 2]; }
    const edge = new Float32Array(n);
    for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++){ const i = y * W + x; edge[i] = Math.abs(gray[i + 1] - gray[i - 1]) + Math.abs(gray[i + W] - gray[i - W]); }
    const a0 = new Uint8Array(n); for (let i = 0; i < n; i++) a0[i] = cd[i * 4 + 3];
    return { W, H, diff, edge, sd, a0, gray, bgd };
  }
  function mainBody(d, W, H){
    const n = W * H;
    const lab = new Int32Array(n), sizes = [0]; let best = 0, bestLab = 0, L = 0; const st = [];
    for (let s0 = 0; s0 < n; s0++){ if (lab[s0] || d[s0 * 4 + 3] <= 128) continue;
      L++; let sz = 0; st.push(s0); lab[s0] = L;
      while (st.length){ const i = st.pop(); sz++; const x = i % W;
        for (const k of [i - 1, i + 1, i - W, i + W]){ if (k < 0 || k >= n || lab[k] || d[k * 4 + 3] <= 128) continue; if (Math.abs((k % W) - x) > 1) continue; lab[k] = L; st.push(k); } }
      if (sz > best){ best = sz; bestLab = L; } }
    const m = new Uint8Array(n); for (let i = 0; i < n; i++) m[i] = lab[i] === bestLab ? 1 : 0;
    return m;
  }
  function marks(fm, cd){
    const W = fm.W, H = fm.H, n = W * H;
    /* near the frame that is kept: missing frame is only marked within reach of it (a far-off shadow is not frame) */
    const D = Math.max(5, Math.round(Math.min(W, H) * 0.025));
    const kept = new Uint8Array(n); for (let i = 0; i < n; i++) kept[i] = cd[i * 4 + 3] > 128 ? 1 : 0;
    const near = new Uint8Array(n), tmp = new Uint8Array(n);
    for (let y = 0; y < H; y++){ let last = -1e9; for (let x = 0; x < W; x++){ const i = y * W + x; if (kept[i]) last = x; tmp[i] = x - last <= D ? 1 : 0; }
      last = 1e9; for (let x = W - 1; x >= 0; x--){ const i = y * W + x; if (kept[i]) last = x; if (last - x <= D) tmp[i] = 1; } }
    for (let x = 0; x < W; x++){ let last = -1e9; for (let y = 0; y < H; y++){ const i = y * W + x; if (tmp[i]) last = y; near[i] = y - last <= D ? 1 : 0; }
      last = 1e9; for (let y = H - 1; y >= 0; y--){ const i = y * W + x; if (tmp[i]) last = y; if (last - y <= D) near[i] = 1; } }
    /* raw marks */
    const pk = new Uint8Array(n), bl = new Uint8Array(n);
    /* strong edges and the band around them: clear plastic lies between two edges, so it is not "background left in" */
    const E = Math.max(6, Math.round(Math.min(W, H) * 0.022));
    const se = new Uint8Array(n); for (let i = 0; i < n; i++) se[i] = fm.edge[i] > 26 ? 1 : 0;
    const nearE = new Uint8Array(n), t2 = new Uint8Array(n);
    for (let y = 0; y < H; y++){ let last = -1e9; for (let x = 0; x < W; x++){ const i = y * W + x; if (se[i]) last = x; t2[i] = x - last <= E ? 1 : 0; }
      last = 1e9; for (let x = W - 1; x >= 0; x--){ const i = y * W + x; if (se[i]) last = x; if (last - x <= E) t2[i] = 1; } }
    for (let x = 0; x < W; x++){ let last = -1e9; for (let y = 0; y < H; y++){ const i = y * W + x; if (t2[i]) last = y; nearE[i] = y - last <= E ? 1 : 0; }
      last = 1e9; for (let y = H - 1; y >= 0; y--){ const i = y * W + x; if (t2[i]) last = y; if (last - y <= E) nearE[i] = 1; } }
    /* BLUE is only for what is clearly NOT the frame: loose pieces apart from it, or half-kept fringe that looks like the
       sheet. Solid parts of the frame itself are never marked blue -- a clear rim looks like the sheet too. */
    const body = mainBody(cd, W, H);
    for (let i = 0; i < n; i++){
      const a = cd[i * 4 + 3], d = fm.diff[i];
      if (a < 40 && near[i] && d > T_FRAME + 6) pk[i] = 1;
      else if (a > 128 && d < T_FRAME + 6 && fm.edge[i] < 14 && !nearE[i] && (!body[i] || a < 230)) bl[i] = 1;
    }
    /* clean them: drop thin slivers along every edge (an opening) and specks smaller than a fingertip */
    const open2 = m => {
      const er = new Uint8Array(n), r = 2;
      for (let y = r; y < H - r; y++) for (let x = r; x < W - r; x++){ let all = 1; const i = y * W + x;
        for (let dy = -r; dy <= r && all; dy++) for (let dx = -r; dx <= r; dx++) if (!m[i + dy * W + dx]){ all = 0; break; }
        er[i] = all; }
      const o = new Uint8Array(n);
      for (let y = r; y < H - r; y++) for (let x = r; x < W - r; x++){ const i = y * W + x; if (!er[i]) continue;
        for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) o[i + dy * W + dx] = m[i + dy * W + dx]; }
      return o;
    };
    const keepBig = (m, min) => {
      const seen = new Uint8Array(n), st = [];
      for (let s0 = 0; s0 < n; s0++){ if (!m[s0] || seen[s0]) continue;
        const comp = []; st.push(s0); seen[s0] = 1;
        while (st.length){ const i = st.pop(); comp.push(i); const x = i % W;
          for (const k of [i - 1, i + 1, i - W, i + W]){ if (k < 0 || k >= n || seen[k] || !m[k]) continue; if (Math.abs((k % W) - x) > 1) continue; seen[k] = 1; st.push(k); } }
        if (comp.length < min) comp.forEach(i => { m[i] = 0; }); }
      return m;
    };
    const MIN = Math.max(60, Math.round(n * 0.0004));
    const pinkM = keepBig(open2(pk), MIN), blueM = keepBig(open2(bl), MIN);
    /* d17.142: a THIN rim cut away (a metal rim 3-6 px wide) does not survive the clean-up above, so it was never marked.
       It is marked too when it lies clear of the kept frame (more than 2 px away, so the soft fringe along every edge is
       not marked) and is a real piece, not a speck. */
    { const k2 = new Uint8Array(n), t3 = new Uint8Array(n), R2 = 2;
      for (let y = 0; y < H; y++){ let last = -1e9; for (let x = 0; x < W; x++){ const i = y * W + x; if (kept[i]) last = x; t3[i] = x - last <= R2 ? 1 : 0; }
        last = 1e9; for (let x = W - 1; x >= 0; x--){ const i = y * W + x; if (kept[i]) last = x; if (last - x <= R2) t3[i] = 1; } }
      for (let x = 0; x < W; x++){ let last = -1e9; for (let y = 0; y < H; y++){ const i = y * W + x; if (t3[i]) last = y; k2[i] = y - last <= R2 ? 1 : 0; }
        last = 1e9; for (let y = H - 1; y >= 0; y--){ const i = y * W + x; if (t3[i]) last = y; if (last - y <= R2) k2[i] = 1; } }
      const thin = new Uint8Array(n);
      for (let i = 0; i < n; i++) if (pk[i] && !k2[i]) thin[i] = 1;
      keepBig(thin, Math.max(30, Math.round(n * 0.00008)));
      for (let i = 0; i < n; i++) if (thin[i]){ pinkM[i] = 1; blueM[i] = 0; } }
    return { pinkM, blueM };
  }
  /* AUTOMATIC MODE ONLY: the sheet's colour taken from the background AROUND the frame (what is transparent in the cut and
     joined to the photo's edge), spread smoothly over the frame. The edit panel's own estimate is fooled by a thick dark
     area (a wide arm and bar side by side): it reads the arm itself as "background", so a hollowed arm was never marked. */
  function boxBlur(src, w, h, r){
    const tmp = new Float32Array(w * h), out = new Float32Array(w * h), n2 = 2 * r + 1;
    for (let y = 0; y < h; y++){ const row = y * w; let s0 = 0;
      for (let x = -r; x <= r; x++) s0 += src[row + Math.min(w - 1, Math.max(0, x))];
      for (let x = 0; x < w; x++){ tmp[row + x] = s0 / n2; s0 += src[row + Math.min(w - 1, x + r + 1)] - src[row + Math.max(0, x - r)]; } }
    for (let x = 0; x < w; x++){ let s0 = 0;
      for (let y = -r; y <= r; y++) s0 += tmp[Math.min(h - 1, Math.max(0, y)) * w + x];
      for (let y = 0; y < h; y++){ out[y * w + x] = s0 / n2; s0 += tmp[Math.min(h - 1, y + r + 1) * w + x] - tmp[Math.max(0, y - r) * w + x]; } }
    return out;
  }
  function outsideDiff(fm, cd){
    const W = fm.W, H = fm.H, n = W * H, open = new Uint8Array(n), st = [];
    /* the sheet's own colour, from the photo's border; the background is only what looks like it (a cut-away dark bar
       joined to the background through an open lens is NOT background) */
    const bord = [[], [], []];
    for (let i = 0; i < n; i++){ const x = i % W, y = (i - x) / W; if (x > 1 && y > 1 && x < W - 2 && y < H - 2) continue;
      if (cd[i * 4 + 3] < 40) for (let ch = 0; ch < 3; ch++) bord[ch].push(fm.sd[i * 4 + ch]); }
    if (bord[0].length < 20) return 0;
    const sheet = bord.map(a => { a.sort((u, v) => u - v); return a[a.length >> 1]; });
    const like = i => Math.max(Math.abs(fm.sd[i * 4] - sheet[0]), Math.abs(fm.sd[i * 4 + 1] - sheet[1]), Math.abs(fm.sd[i * 4 + 2] - sheet[2])) < 45;
    for (let i = 0; i < n; i++){ const x = i % W, y = (i - x) / W;
      if ((x === 0 || y === 0 || x === W - 1 || y === H - 1) && cd[i * 4 + 3] < 40 && like(i) && !open[i]){ open[i] = 1; st.push(i); } }
    while (st.length){ const i = st.pop(), x = i % W;
      for (const k of [i - 1, i + 1, i - W, i + W]){ if (k < 0 || k >= n || open[k] || cd[k * 4 + 3] >= 40 || !like(k)) continue; if (Math.abs((k % W) - x) > 1) continue; open[k] = 1; st.push(k); } }
    let cnt = 0; for (let i = 0; i < n; i++) cnt += open[i];
    if (cnt < n * 0.05) return 0;                                 /* hardly any background around: leave the panel's own estimate */
    const r = Math.max(6, Math.round(Math.max(W, H) * 0.02)), m = new Float32Array(n);
    for (let i = 0; i < n; i++) m[i] = open[i];
    let mb = m; for (let k = 0; k < 3; k++) mb = boxBlur(mb, W, H, r);
    let changed = 0;
    for (let ch = 0; ch < 3; ch++){
      let v = new Float32Array(n); for (let i = 0; i < n; i++) v[i] = open[i] ? fm.sd[i * 4 + ch] : 0;
      for (let k = 0; k < 3; k++) v = boxBlur(v, W, H, r);
      for (let i = 0; i < n; i++){ if (mb[i] < 0.02) continue;
        const bg = v[i] / mb[i], d = Math.abs(fm.sd[i * 4 + ch] - bg);
        if (d > fm.diff[i]){ fm.diff[i] = d; changed++; } }
    }
    return changed;
  }
  function spots(m, W, H){                /* how many separate places are marked */
    const n = W * H, seen = new Uint8Array(n), st = []; let c = 0;
    for (let s0 = 0; s0 < n; s0++){ if (!m[s0] || seen[s0]) continue; c++; st.push(s0); seen[s0] = 1;
      while (st.length){ const i = st.pop(), x = i % W;
        for (const k of [i - 1, i + 1, i - W, i + W]){ if (k < 0 || k >= n || seen[k] || !m[k]) continue; if (Math.abs((k % W) - x) > 1) continue; seen[k] = 1; st.push(k); } } }
    return c;
  }
  function run(cutImg, srcImg){
    const W = cutImg.naturalWidth || cutImg.width, H = cutImg.naturalHeight || cutImg.height;
    if (!(W > 16 && H > 16)) return null;
    const cut = document.createElement('canvas'); cut.width = W; cut.height = H;
    const cx = cut.getContext('2d', { willReadFrequently: true }); cx.drawImage(cutImg, 0, 0, W, H);
    const fm = frameMap(srcImg, cut); if (!fm) return null;
    const n = W * H;
    outsideDiff(fm, cx.getImageData(0, 0, W, H).data);
    /* AUTOMATIC = STRICTER than a person's brush: only what is clearly FRAME in the photo is put back -- darker than the
       sheet behind it, or clearly coloured. A pale patch (glare, the sheet, a white sticker) is never put back by itself;
       a person can still do that in FIX. */
    const frameLike = new Uint8Array(n);
    for (let i = 0, j = 0; i < n; i++, j += 4){
      const bgG = 0.299 * fm.bgd[j] + 0.587 * fm.bgd[j + 1] + 0.114 * fm.bgd[j + 2];
      const r = fm.sd[j], g2 = fm.sd[j + 1], b2 = fm.sd[j + 2], sat = (Math.max(r, g2, b2) - Math.min(r, g2, b2)) / 255;
      frameLike[i] = (fm.gray[i] < bgG - 18 || sat > 0.22) ? 1 : 0;
    }
    let put = 0, clean = 0, pinkSpots = 0, blueSpots = 0, passes = 0;
    /* a big piece cut away (the inside of a thick arm) is put back from its edges inwards: up to 6 rounds */
    for (let pass = 0; pass < 6; pass++){
      const img = cx.getImageData(0, 0, W, H), d = img.data;
      const mk = marks(fm, d);
      const body = mainBody(d, W, H);
      let p1 = 0, c1 = 0;
      for (let i = 0; i < n; i++){
        const j = i * 4;
        if (mk.pinkM[i]){                                        /* PUT BACK, from the original photo only */
          if (!frameLike[i]) continue;
          const want = Math.max(200, Math.round(frameAlpha(fm, i) * 255));
          if (want > d[j + 3]){ d[j] = fm.sd[j]; d[j + 1] = fm.sd[j + 1]; d[j + 2] = fm.sd[j + 2]; d[j + 3] = want; p1++; }
        } else if (pass === 0 && mk.blueM[i] && d[j + 3] > 0){   /* CLEAN once, with the brush's own protection of the frame */
          const dd2 = fm.diff[i], ee = fm.edge[i];
          const solidKept = fm.a0[i] >= 230 && (dd2 > 18 || ee > 20 || fm.gray[i] < 90);
          const protect = (dd2 > 45 || ee > 34 || solidKept) && body[i];
          if (!protect){ d[j + 3] = 0; c1++; }
        }
      }
      if (pass === 0){ pinkSpots = spots(mk.pinkM, W, H); blueSpots = spots(mk.blueM, W, H); }
      cx.putImageData(img, 0, 0);
      put += p1; clean += c1; passes = pass + 1;
      if (p1 < 20) break;
    }
    return { canvas: cut, put, clean, pinkSpots, blueSpots, passes };
  }
  function debugMarks(cutImg, srcImg){     /* for checks: the marks of the first look */
    const W = cutImg.naturalWidth || cutImg.width, H = cutImg.naturalHeight || cutImg.height;
    const cut = document.createElement('canvas'); cut.width = W; cut.height = H; const cx = cut.getContext('2d'); cx.drawImage(cutImg, 0, 0, W, H);
    const fm = frameMap(srcImg, cut); const d = cx.getImageData(0, 0, W, H).data; outsideDiff(fm, d); const mk = marks(fm, d);
    return { W, H, pink: mk.pinkM, blue: mk.blueM, diff: fm.diff };
  }
  g.VGTouch = { run, VERSION: 'd17.183', _marks: debugMarks };
})(window);

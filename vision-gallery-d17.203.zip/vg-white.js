/* Vision Gallery — WHITE BACKGROUND WITHOUT TOUCHING THE FRAME (d17.175, shop 24 Oct: "100% white, nothing to touch --
   go with this look, for all the frames, automatically")

   The frame is NOT cut out. Only the sheet behind it turns white:
     1. the light falling on the sheet is measured across the photo (the brightest nearby sheet, smoothed), so grey or
        uneven light still reads as "sheet";
     2. a pixel that is as bright as the sheet around it, and not coloured, is sheet -> white; anything darker or coloured
        is the frame and is left EXACTLY as photographed;
     3. only sheet that reaches the edge of the photo, or a big piece of it (the sheet seen through a lens), turns white --
        a small bright spot (shine on the rim) stays as it is;
     4. CRYSTAL / CLEAR FRAMES (d17.176, shop 24 Oct: "keep that also white -- it looks like a grey stone"): a frame that is
        hardly darker than the sheet is found by its OUTLINE (the fine edges a smooth sheet does not have); a thin band along
        that outline keeps the photo's own soft grey, everything else turns white -- so a clear frame shows as a clear frame
        on white. Only a photo where no frame outline can be found at all keeps its original (nothing to show).
   VGWhite.make(imageOrCanvas) -> { canvas, safe:true, stats } or { safe:false, reason, stats } */
(function (g) {
  'use strict';
  if (g.VGWhite) return;
  var T0 = 0.80, T1 = 0.93;          /* brightness against the sheet: below T0 = frame, above T1 = sheet */

  function boxBlur(src, w, h, r) {     /* separable box blur, edges clamped */
    if (r < 1) return src;
    var tmp = new Float32Array(w * h), out = new Float32Array(w * h), x, y, s, n = 2 * r + 1;
    for (y = 0; y < h; y++) { var row = y * w; s = 0;
      for (x = -r; x <= r; x++) s += src[row + Math.min(w - 1, Math.max(0, x))];
      for (x = 0; x < w; x++) { tmp[row + x] = s / n; s += src[row + Math.min(w - 1, x + r + 1)] - src[row + Math.max(0, x - r)]; } }
    for (x = 0; x < w; x++) { s = 0;
      for (y = -r; y <= r; y++) s += tmp[Math.min(h - 1, Math.max(0, y)) * w + x];
      for (y = 0; y < h; y++) { out[y * w + x] = s / n; s += tmp[Math.min(h - 1, y + r + 1) * w + x] - tmp[Math.max(0, y - r) * w + x]; } }
    return out;
  }
  /* distance from a mask in steps (two passes, O(N)); city = 4 neighbours (the same as growing the mask 1 px at a time),
     otherwise 8 neighbours. Capped at cap + 1. */
  function stepDist(mask, w, h, cap, city) {
    var n = w * h, d = new Uint16Array(n), C = Math.min(65000, cap + 1), x, y, i, v;
    for (i = 0; i < n; i++) d[i] = mask[i] ? 0 : C;
    for (y = 0; y < h; y++) for (x = 0; x < w; x++) { i = y * w + x; v = d[i]; if (!v) continue;
      if (x > 0 && d[i - 1] + 1 < v) v = d[i - 1] + 1;
      if (y > 0) { if (d[i - w] + 1 < v) v = d[i - w] + 1; if (!city) { if (x > 0 && d[i - w - 1] + 1 < v) v = d[i - w - 1] + 1; if (x < w - 1 && d[i - w + 1] + 1 < v) v = d[i - w + 1] + 1; } }
      d[i] = v; }
    for (y = h - 1; y >= 0; y--) for (x = w - 1; x >= 0; x--) { i = y * w + x; v = d[i]; if (!v) continue;
      if (x < w - 1 && d[i + 1] + 1 < v) v = d[i + 1] + 1;
      if (y < h - 1) { if (d[i + w] + 1 < v) v = d[i + w] + 1; if (!city) { if (x < w - 1 && d[i + w + 1] + 1 < v) v = d[i + w + 1] + 1; if (x > 0 && d[i + w - 1] + 1 < v) v = d[i + w - 1] + 1; } }
      d[i] = v; }
    return d;
  }
  /* d17.183: how sharply the photo changes at each wanted pixel of a box (x0, y0, cw x ch): each colour smoothed [1 2 3 2 1]
     across and down (two 3 x 3 box blurs), then Sobel; the strongest of the three colours. A small function of its own, so
     the browser can make it fast. */
  function edgeStrength(d, W, x0, y0, cw, ch, need, G, hb, sm) {
    var c, x, y, q, k = 1 / (81 * 255);
    for (c = 0; c < 3; c++) {
      for (y = 0; y < ch; y++) { var rb = ((y + y0) * W + x0) * 4 + c, ro = y * cw;
        for (x = 0; x < cw; x++) { var xm2 = x > 1 ? x - 2 : 0, xm1 = x > 0 ? x - 1 : 0, xp1 = x < cw - 1 ? x + 1 : cw - 1, xp2 = x < cw - 2 ? x + 2 : cw - 1;
          hb[ro + x] = d[rb + xm2 * 4] + 2 * d[rb + xm1 * 4] + 3 * d[rb + x * 4] + 2 * d[rb + xp1 * 4] + d[rb + xp2 * 4]; } }
      for (y = 0; y < ch; y++) { var ym2 = (y > 1 ? y - 2 : 0) * cw, ym1 = (y > 0 ? y - 1 : 0) * cw, yc = y * cw, yp1 = (y < ch - 1 ? y + 1 : ch - 1) * cw, yp2 = (y < ch - 2 ? y + 2 : ch - 1) * cw;
        for (x = 0; x < cw; x++) sm[yc + x] = (hb[ym2 + x] + 2 * hb[ym1 + x] + 3 * hb[yc + x] + 2 * hb[yp1 + x] + hb[yp2 + x]) * k; }
      for (y = 1; y < ch - 1; y++) for (x = 1; x < cw - 1; x++) { q = y * cw + x; if (!need[q]) continue;
        var gx = (sm[q - cw + 1] + 2 * sm[q + 1] + sm[q + cw + 1]) - (sm[q - cw - 1] + 2 * sm[q - 1] + sm[q + cw - 1]);
        var gy = (sm[q + cw - 1] + 2 * sm[q + cw] + sm[q + cw + 1]) - (sm[q - cw - 1] + 2 * sm[q - cw] + sm[q - cw + 1]);
        var gm = gx * gx + gy * gy, gq = (y + y0) * W + x + x0; if (gm > G[gq]) G[gq] = gm; } }
    for (y = 0; y < ch; y++) for (x = 0; x < cw; x++) { q = (y + y0) * W + x + x0; if (G[q]) G[q] = Math.sqrt(G[q]); }
  }
  function gauss(src, w, h, sigma) {   /* three box blurs ~ a Gaussian */
    var r = Math.max(1, Math.round(Math.sqrt(12 * sigma * sigma / 3 + 1) / 2));
    return boxBlur(boxBlur(boxBlur(src, w, h, r), w, h, r), w, h, r);
  }
  function maxFilter(src, w, h, size) {
    var r = (size - 1) >> 1, tmp = new Float32Array(w * h), out = new Float32Array(w * h), x, y, k, m;
    for (y = 0; y < h; y++) for (x = 0; x < w; x++) { m = 0;
      for (k = Math.max(0, x - r); k <= Math.min(w - 1, x + r); k++) if (src[y * w + k] > m) m = src[y * w + k];
      tmp[y * w + x] = m; }
    for (x = 0; x < w; x++) for (y = 0; y < h; y++) { m = 0;
      for (k = Math.max(0, y - r); k <= Math.min(h - 1, y + r); k++) if (tmp[k * w + x] > m) m = tmp[k * w + x];
      out[y * w + x] = m; }
    return out;
  }

  function make(img) {
    var W = img.naturalWidth || img.width, H = img.naturalHeight || img.height;
    if (!(W > 16 && H > 16)) return { safe: false, reason: 'no picture' };
    var c = document.createElement('canvas'); c.width = W; c.height = H;
    var x = c.getContext('2d', { willReadFrequently: true }); x.drawImage(img, 0, 0, W, H);
    var id = x.getImageData(0, 0, W, H), d = id.data, N = W * H, i, j;
    var lum = new Float32Array(N), sat = new Float32Array(N);
    for (i = 0, j = 0; i < N; i++, j += 4) {
      var r0 = d[j] / 255, g0 = d[j + 1] / 255, b0 = d[j + 2] / 255;
      lum[i] = (r0 + g0 + b0) / 3; sat[i] = Math.max(r0, g0, b0) - Math.min(r0, g0, b0);
    }
    /* 1. the light on the sheet, worked out small (about 400 px across) and spread back over the photo */
    var k = Math.max(1, Math.round(Math.max(W, H) / 400)), w = Math.max(8, Math.floor(W / k)), h = Math.max(8, Math.floor(H / k));
    var sc = document.createElement('canvas'); sc.width = w; sc.height = h;
    var sx = sc.getContext('2d', { willReadFrequently: true }); sx.imageSmoothingQuality = 'high'; sx.drawImage(c, 0, 0, w, h);
    var sd = sx.getImageData(0, 0, w, h).data, small = new Float32Array(w * h);
    for (i = 0, j = 0; i < w * h; i++, j += 4) small[i] = (sd[j] + sd[j + 1] + sd[j + 2]) / 765;
    var R = Math.max(3, Math.round(Math.min(w, h) * 0.04)) | 1;
    var bgS = gauss(maxFilter(small, w, h, R), w, h, R * 0.8);
    for (i = 0, j = 0; i < w * h; i++, j += 4) { var v = Math.round(Math.max(0.25, Math.min(1, bgS[i])) * 255); sd[j] = sd[j + 1] = sd[j + 2] = v; sd[j + 3] = 255; }
    sx.putImageData(new ImageData(sd, w, h), 0, 0);
    var bc = document.createElement('canvas'); bc.width = W; bc.height = H;
    var bx = bc.getContext('2d', { willReadFrequently: true }); bx.imageSmoothingEnabled = true; bx.imageSmoothingQuality = 'high'; bx.drawImage(sc, 0, 0, W, H);
    var bd = bx.getImageData(0, 0, W, H).data;

    /* 2. how much each pixel is sheet (0 = frame, 1 = sheet), and the safety numbers */
    var wt = new Float32Array(N), solid = 0, faint = 0;
    var lumS = boxBlur(boxBlur(lum, W, H, 1), W, H, 1);                     /* the camera's grain on the sheet is not frame */
    for (i = 0, j = 0; i < N; i++, j += 4) {
      var bg = Math.max(0.25, bd[j] / 255), rel = Math.max(lum[i], lumS[i]) / bg;
      var a = (lum[i] / bg < T0 || lum[i] < 0.40 || bg < 0.45) ? 0 : Math.min(1, Math.max(0, (rel - T0) / (T1 - T0)));   /* a dark pixel is frame, whatever is around it; the sheet is never darker than 45% grey */
      a *= Math.min(1, Math.max(0, 1 - (sat[i] - 0.10) / 0.10));        /* coloured = frame */
      wt[i] = a;
      if (rel < 0.70 || sat[i] > 0.20) solid++; else if (rel < 0.80) faint++;
    }
    var stats = { solid: solid / N, faint: faint / N, w: W, h: H };
    /* 2b. d17.183 PALE FRAMES KEEP THEIR RIM (shop, 25 Oct: the light purple Skechers cat-eye lost the top of its rim --
       those pixels are almost as bright as the sheet and only faintly coloured, so they read as "sheet").
       Kept as photographed only when ALL of these hold: next to the frame; the frame's own colour (measured from its solid
       part); a little more coloured than the sheet; a little DARKER than the sheet (the glow a camera spreads round a red
       or gold wire is as bright as the sheet, so it still turns white); outside the lens openings (inside, the frame's
       colour is only a reflection in the demo lens -- there just the frame's own 2 px edge); a band at least 3 px thick
       joined to the frame (no specks, no thin reflection lines). A black, grey, silver or many-coloured frame: nothing changes. */
    (function () {
      var hs = new Uint32Array(101), ns = 0;
      for (i = 0; i < N; i += 3) if (wt[i] > 0.95) { hs[Math.min(100, Math.round(sat[i] * 100))]++; ns++; }
      if (ns < 500) return;
      var acc = 0, sheetSat = 0.03; for (var b0 = 0; b0 <= 100; b0++) { acc += hs[b0]; if (acc >= ns * 0.9) { sheetSat = b0 / 100; break; } }
      var hueAt = function (q) { var jq = q * 4, R0 = d[jq], G0 = d[jq + 1], B0 = d[jq + 2], mx = Math.max(R0, G0, B0), mn = Math.min(R0, G0, B0), dl = mx - mn, hh = 0;   /* only where it is needed */
        if (dl > 0) { hh = mx === R0 ? ((G0 - B0) / dl) % 6 : mx === G0 ? (B0 - R0) / dl + 2 : (R0 - G0) / dl + 4; hh *= 60; if (hh < 0) hh += 360; }
        return hh; };
      /* the frame's colour: the coloured part of the frame itself */
      var core = new Uint8Array(N), cx0 = 0, cy0 = 0, cw = 0;
      for (i = 0; i < N; i++) if (wt[i] < 0.2) { core[i] = 1; if (sat[i] > 0.12) { var ang = hueAt(i) * Math.PI / 180; cx0 += Math.cos(ang) * sat[i]; cy0 += Math.sin(ang) * sat[i]; cw += sat[i]; } }
      if (cw < N * 0.002 * 0.15) return;                                  /* a black / grey / silver frame: no colour to follow */
      var fHue = Math.atan2(cy0, cx0) * 180 / Math.PI; if (fHue < 0) fHue += 360;
      if (Math.hypot(cx0, cy0) / cw < 0.6) return;                        /* many colours (tortoise, multicolour): leave it */
      var D = Math.max(4, Math.round(Math.max(W, H) / 120)), lo = sheetSat + 0.015;
      var cd = stepDist(core, W, H, D + 2, true), near = new Uint8Array(N), dd;
      for (i = 0; i < N; i++) if (cd[i] <= D) near[i] = 1;
      /* the camera spreads a strong colour a pixel or two onto the white sheet beside the frame (a pink glow round a red
         wire) -- that glow is as bright as the sheet. A real pale rim is a little darker than the sheet: only that is kept. */
      var rel = new Float32Array(N), hr = new Uint32Array(201), nr = 0;
      for (i = 0, j = 0; i < N; i++, j += 4) { rel[i] = lum[i] / Math.max(0.25, bd[j] / 255); if (near[i] && !core[i] && wt[i] > 0.95) { hr[Math.min(200, Math.round(rel[i] * 100))]++; nr++; } }
      var accR = 0, sheetRel = 0.97; if (nr > 200) for (b0 = 0; b0 <= 200; b0++) { accR += hr[b0]; if (accR >= nr * 0.5) { sheetRel = b0 / 100; break; } }
      var relHi = sheetRel - 0.05;
      var candR = new Uint8Array(N);
      for (i = 0; i < N; i++) { if (!near[i] || core[i] || wt[i] <= 0 || sat[i] <= lo || rel[i] >= relHi) continue;
        var dh = Math.abs(hueAt(i) - fHue); if (dh > 180) dh = 360 - dh; if (dh <= 28) candR[i] = 1; }
      /* inside a lens opening (sheet closed in by the rim -- the pale rim counts as rim here) the frame's colour is only a
         reflection in the demo lens: there just the frame's own edge (2 px) is kept. A pale piece that reaches the sheet
         outside the frame (sheet that reaches the photo's border) is kept whole. */
      var wall = function (q) { return core[q] || candR[q]; };
      var outside = new Uint8Array(N), st0 = [];
      for (i = 0; i < W; i++) { if (!wall(i)) { outside[i] = 1; st0.push(i); } var b1 = N - W + i; if (!wall(b1) && !outside[b1]) { outside[b1] = 1; st0.push(b1); } }
      for (i = 0; i < N; i += W) { if (!wall(i) && !outside[i]) { outside[i] = 1; st0.push(i); } var b2 = i + W - 1; if (!wall(b2) && !outside[b2]) { outside[b2] = 1; st0.push(b2); } }
      while (st0.length) { var q0 = st0.pop(), qx0 = q0 % W;
        if (qx0 > 0 && !wall(q0 - 1) && !outside[q0 - 1]) { outside[q0 - 1] = 1; st0.push(q0 - 1); }
        if (qx0 < W - 1 && !wall(q0 + 1) && !outside[q0 + 1]) { outside[q0 + 1] = 1; st0.push(q0 + 1); }
        if (q0 >= W && !wall(q0 - W) && !outside[q0 - W]) { outside[q0 - W] = 1; st0.push(q0 - W); }
        if (q0 < N - W && !wall(q0 + W) && !outside[q0 + W]) { outside[q0 + W] = 1; st0.push(q0 + W); } }
      var edge2 = new Uint8Array(N);
      for (i = 0; i < N; i++) if (cd[i] <= 2) edge2[i] = 1;
      /* a pale piece is allowed when it touches the outside sheet (then all of it), or within the frame's own 2 px edge */
      var cand0 = new Uint8Array(N), st1 = [];
      for (i = 0; i < N; i++) { if (!candR[i]) continue; var ox = i % W;
        if (edge2[i] || (ox > 0 && outside[i - 1]) || (ox < W - 1 && outside[i + 1]) || (i >= W && outside[i - W]) || (i < N - W && outside[i + W])) { cand0[i] = 1; if (!edge2[i]) st1.push(i); } }
      while (st1.length) { var q1 = st1.pop(), qx1 = q1 % W;
        if (qx1 > 0 && candR[q1 - 1] && !cand0[q1 - 1]) { cand0[q1 - 1] = 1; st1.push(q1 - 1); }
        if (qx1 < W - 1 && candR[q1 + 1] && !cand0[q1 + 1]) { cand0[q1 + 1] = 1; st1.push(q1 + 1); }
        if (q1 >= W && candR[q1 - W] && !cand0[q1 - W]) { cand0[q1 - W] = 1; st1.push(q1 - W); }
        if (q1 < N - W && candR[q1 + W] && !cand0[q1 + W]) { cand0[q1 + W] = 1; st1.push(q1 + W); } }
      /* specks and 1-2 px lines (grain, the frame's reflection line on a shiny sheet) are not rim: only a band at least
         3 px thick survives (opening: shrink by 1 px, grow back by 1 px inside the candidates) */
      var inner = new Uint8Array(N), cand = new Uint8Array(N);
      var ok0 = function (q) { return cand0[q] || core[q]; };
      for (i = 0; i < N; i++) { if (!cand0[i]) continue; var cx1 = i % W;
        if (cx1 > 0 && cx1 < W - 1 && i >= W && i < N - W && ok0(i - 1) && ok0(i + 1) && ok0(i - W) && ok0(i + W)) inner[i] = 1; }
      for (i = 0; i < N; i++) { if (!cand0[i]) continue; var cx3 = i % W;
        if (inner[i] || (cx3 > 0 && inner[i - 1]) || (cx3 < W - 1 && inner[i + 1]) || (i >= W && inner[i - W]) || (i < N - W && inner[i + W])) cand[i] = 1; }
      /* only what joins the frame */
      var keepP = new Uint8Array(N), st2 = [];
      for (i = 0; i < N; i++) { if (!cand[i]) continue; var ix2 = i % W;
        if ((ix2 > 0 && core[i - 1]) || (ix2 < W - 1 && core[i + 1]) || (i >= W && core[i - W]) || (i < N - W && core[i + W])) { keepP[i] = 1; st2.push(i); } }
      while (st2.length) { var q2 = st2.pop(), qx2 = q2 % W;
        if (qx2 > 0 && cand[q2 - 1] && !keepP[q2 - 1]) { keepP[q2 - 1] = 1; st2.push(q2 - 1); }
        if (qx2 < W - 1 && cand[q2 + 1] && !keepP[q2 + 1]) { keepP[q2 + 1] = 1; st2.push(q2 + 1); }
        if (q2 >= W && cand[q2 - W] && !keepP[q2 - W]) { keepP[q2 - W] = 1; st2.push(q2 - W); }
        if (q2 < N - W && cand[q2 + W] && !keepP[q2 + W]) { keepP[q2 + W] = 1; st2.push(q2 + W); } }
      var kept = 0;
      for (i = 0; i < N; i++) { if (!keepP[i]) continue; var pk = Math.min(1, Math.max(0, (sat[i] - lo) / 0.02), Math.max(0, (relHi - rel[i]) / 0.03)); wt[i] *= 1 - pk; if (pk >= 0.5) kept++; }
      stats.sheetSat = sheetSat; stats.frameHue = Math.round(fHue); stats.paleKept = kept / N; stats.sheetRel = sheetRel;

      /* 2c. d17.183 THE RIM UP TO ITS OWN OUTLINE (shop, 25 Oct: "still the upper rim is missing -- measure the thickness of
         the rim, so the robot can check it and make it like the original"). The top of a pale rim catches the light and can
         be as light as the sheet, but the frame's outline is still a sharp line in the photo. So: everything between that
         outline and the frame, on TOP of the rim, is rim -- kept exactly as photographed. Checks, so nothing else comes back:
           - it sits on a frame-coloured rim and is never thicker than that rim under it (RIM THICKNESS, column by column);
             a thin metal wire (under about 12 px) never gets anything added;
           - lens openings and plain-sheet gaps between frame parts are never touched;
           - a piece must contain some of the outline's own darker line (a camera's bright glow next to a frame has none);
           - the camera's soft fringe just outside the outline is trimmed off (3 px at most). */
      (function () {
        var Fm = new Uint8Array(N), nF = 0;
        for (i = 0; i < N; i++) if (wt[i] < 0.7) { Fm[i] = 1; nF++; }
        if (nF < N * 0.002) return;
        var fc = new Uint8Array(N);
        for (i = 0; i < N; i++) if (Fm[i] && sat[i] > 0.06) { var dq = Math.abs(hueAt(i) - fHue); if (dq > 180) dq = 360 - dq; if (dq <= 28) fc[i] = 1; }
        var BIG = 60000, Dmax = Math.max(6, Math.round(W / 50));
        /* distance from the frame (8 neighbours) */
        var dist = stepDist(Fm, W, H, 120, false);
        /* the photo's edges near the frame: each colour smoothed a little, then how sharply it changes (Sobel), the
           strongest of the three. Only in the frame's own box (far from the frame nothing is added anyway). */
        var bx0 = W, bx1 = -1, by0 = H, by1 = -1, xx, yy;
        for (yy = 0; yy < H; yy++) for (xx = 0; xx < W; xx++) if (Fm[yy * W + xx]) { if (xx < bx0) bx0 = xx; if (xx > bx1) bx1 = xx; if (yy < by0) by0 = yy; if (yy > by1) by1 = yy; }
        var mg = Dmax + 6; bx0 = Math.max(0, bx0 - mg); by0 = Math.max(0, by0 - mg); bx1 = Math.min(W - 1, bx1 + mg); by1 = Math.min(H - 1, by1 + mg);
        var cw2 = bx1 - bx0 + 1, chh = by1 - by0 + 1, G = new Float32Array(N), hb = new Float32Array(cw2 * chh), sm = new Float32Array(cw2 * chh), c3;
        var need = new Uint8Array(cw2 * chh);               /* near the frame, plus a sparse grid for the sheet's grain */
        for (yy = 1; yy < chh - 1; yy++) for (xx = 1; xx < cw2 - 1; xx++) { var dq0 = dist[(yy + by0) * W + xx + bx0];
          if (dq0 <= Dmax + 2 || (dq0 > 40 && !(xx & 3) && !(yy & 3))) need[yy * cw2 + xx] = 1; }
        edgeStrength(d, W, bx0, by0, cw2, chh, need, G, hb, sm);

        var hg = new Uint32Array(1001), ng = 0;
        for (yy = by0 + 1; yy < by1; yy++) for (xx = bx0 + 1; xx < bx1; xx++) { if (((xx - bx0) & 3) || ((yy - by0) & 3)) continue; i = yy * W + xx; if (dist[i] > 40) { hg[Math.min(1000, Math.round(G[i] * 1000))]++; ng++; } }
        var noiseG = 0.01; if (ng > 500) { var ag = 0; for (var bq = 0; bq <= 1000; bq++) { ag += hg[bq]; if (ag >= ng * 0.5) { noiseG = bq / 1000; break; } } }
        var Tg = Math.max(0.06, 8 * noiseG);
        var E0 = new Uint8Array(N), E = new Uint8Array(N);
        for (i = 0; i < N; i++) if (G[i] > Tg) E0[i] = 1;
        for (i = 0; i < N; i++) { if (E0[i]) { E[i] = 1; continue; } var ex0 = i % W;
          if ((ex0 > 0 && E0[i - 1]) || (ex0 < W - 1 && E0[i + 1]) || (i >= W && E0[i - W]) || (i < N - W && E0[i + W])) E[i] = 1; }
        /* the open sheet: reached from the photo's border without crossing the frame or an edge */
        var out = new Uint8Array(N), stk = [];
        var seed = function (q) { if (!Fm[q] && !E[q] && !out[q]) { out[q] = 1; stk.push(q); } };
        for (i = 0; i < W; i++) { seed(i); seed(N - W + i); } for (i = 0; i < N; i += W) { seed(i); seed(i + W - 1); }
        while (stk.length) { var q3 = stk.pop(), x3 = q3 % W;
          if (x3 > 0) seed(q3 - 1); if (x3 < W - 1) seed(q3 + 1); if (q3 >= W) seed(q3 - W); if (q3 < N - W) seed(q3 + W); }
        /* the sheet's own brightness next to the frame (for "is this plain sheet?" and "is this the outline's darker line?") */
        /* (worked out on a 4x smaller grid -- the sheet's brightness changes slowly) */
        var qw = Math.ceil(W / 4), qh = Math.ceil(H / 4), qn = qw * qh, sL = new Float32Array(qn), sM = new Float32Array(qn), tL = new Float32Array(qn), tM = new Float32Array(qn), satH = new Uint32Array(101), ns2 = 0;
        for (yy = 0; yy < H; yy++) for (xx = 0; xx < W; xx++) { i = yy * W + xx; if (!out[i]) continue; var qq = (yy >> 2) * qw + (xx >> 2);
          sL[qq] += lum[i]; sM[qq]++; if (!(i % 3)) { satH[Math.min(100, Math.round(sat[i] * 100))]++; ns2++; }
          if (dist[i] > 15 && dist[i] < 60) { tL[qq] += lum[i]; tM[qq]++; } }
        sL = boxBlur(sL, qw, qh, 4); sM = boxBlur(sM, qw, qh, 4); tL = boxBlur(tL, qw, qh, 5); tM = boxBlur(tM, qw, qh, 5);
        var cellOf = function (q) { var x9 = q % W, y9 = (q - x9) / W; return (y9 >> 2) * qw + (x9 >> 2); };
        var sheetAt = function (q) { var cq = cellOf(q); return sM[cq] > 1e-3 ? sL[cq] / sM[cq] : lum[q]; };
        var ssat = 0.03; if (ns2) { var as2 = 0; for (var b2 = 0; b2 <= 100; b2++) { as2 += satH[b2]; if (as2 >= ns2 * 0.5) { ssat = b2 / 100; break; } } }
        var plain = function (q) { return Math.abs(lum[q] - sheetAt(q)) < 0.03 && sat[q] < ssat + 0.02; };
        /* how grainy the sheet is next to the frame (a dull or dark photo is grainier) */
        var dv = new Uint32Array(201), ndv = 0;
        for (i = 0; i < N; i += 3) if (out[i] && dist[i] > 6 && dist[i] < 60) { dv[Math.min(200, Math.round(Math.abs(lum[i] - sheetAt(i)) * 1000))]++; ndv++; }
        var mad = 0.005; if (ndv > 200) { var adv = 0; for (var bv = 0; bv <= 200; bv++) { adv += dv[bv]; if (adv >= ndv * 0.5) { mad = bv / 1000; break; } } }
        var grain = Math.max(0.03, 3.5 * 1.48 * mad);
        /* at the outer border only something that is clearly frame stays: the outline's darker line, a bright highlight,
           or the frame's own colour; plain sheet (within the grain) is trimmed */
        var frameish = function (q) { var dl = lum[q] - sheetAt(q);
          if (dl < -grain || dl > 2 * grain) return true;
          if (sat[q] > ssat + 0.03) { var dq2 = Math.abs(hueAt(q) - fHue); if (dq2 > 180) dq2 = 360 - dq2; if (dq2 <= 28) return true; }
          return false; };
        var darkLine = function (q) { var cq = cellOf(q), l1 = tM[cq] > 1e-3 ? tL[cq] / tM[cq] : sheetAt(q); return lum[q] - l1 < -0.03; };
        /* lens openings: closed-in sheet that is big or reaches far from the frame */
        var lab = new Int32Array(N), nl = 0, lens = new Uint8Array(N), comp = [];
        for (i = 0; i < N; i++) { if (lab[i] || Fm[i] || E[i] || out[i]) continue;
          nl++; comp.length = 0; var deep = 0; lab[i] = nl; stk.push(i);
          while (stk.length) { var q4 = stk.pop(), x4 = q4 % W; comp.push(q4); if (dist[q4] > deep) deep = dist[q4];
            if (x4 > 0 && !lab[q4 - 1] && !Fm[q4 - 1] && !E[q4 - 1] && !out[q4 - 1]) { lab[q4 - 1] = nl; stk.push(q4 - 1); }
            if (x4 < W - 1 && !lab[q4 + 1] && !Fm[q4 + 1] && !E[q4 + 1] && !out[q4 + 1]) { lab[q4 + 1] = nl; stk.push(q4 + 1); }
            if (q4 >= W && !lab[q4 - W] && !Fm[q4 - W] && !E[q4 - W] && !out[q4 - W]) { lab[q4 - W] = nl; stk.push(q4 - W); }
            if (q4 < N - W && !lab[q4 + W] && !Fm[q4 + W] && !E[q4 + W] && !out[q4 + W]) { lab[q4 + W] = nl; stk.push(q4 + W); } }
          if (comp.length > N * 0.002 || deep > Dmax) for (var k1 = 0; k1 < comp.length; k1++) lens[comp[k1]] = 1; }   /* a small plain pocket is decided below (a gap between frame parts has no outline line in it) */
        var ldist = stepDist(lens, W, H, 6, true), lz = new Uint8Array(N);
        for (i = 0; i < N; i++) if (ldist[i] <= 4) lz[i] = 1;
        /* on TOP of a frame-coloured rim (within Dmax above it) -- never shadows under the frame */
        var cand = new Uint8Array(N);
        for (xx = 0; xx < W; xx++) { var gap = BIG;
          for (yy = H - 1; yy >= 0; yy--) { var p2 = yy * W + xx; if (fc[p2]) gap = 0; else gap++;
            if (gap <= Dmax && !Fm[p2] && !out[p2] && !lz[p2] && dist[p2] <= Dmax) cand[p2] = 1; } }
        /* RIM THICKNESS, column by column: the light top is never thicker than the rim under it; a thin wire gets nothing */
        var minRim = Math.max(8, Math.round(W / 110)), okc = new Uint8Array(N);
        for (xx = 0; xx < W; xx++) { yy = 0;
          while (yy < H) { if (!cand[yy * W + xx]) { yy++; continue; }
            var y0 = yy; while (yy < H && cand[yy * W + xx]) yy++;
            var r0 = 0; while (yy + r0 < H && Fm[(yy + r0) * W + xx]) r0++;
            if (r0 >= minRim && (yy - y0) <= Math.max(2, 0.9 * r0)) for (var y2 = y0; y2 < yy; y2++) okc[y2 * W + xx] = 1; } }
        /* the measurement wobbles column to column (a highlight, a speck): a gap of a few columns between kept columns of
           the same light top is closed, so the rim comes back whole, not in stripes */
        var gapMax = Math.max(9, Math.round(W / 70));
        for (yy = 0; yy < H; yy++) { var row = yy * W, last = -100;
          for (xx = 0; xx < W; xx++) { var pq = row + xx;
            if (okc[pq]) { if (xx - last > 1 && xx - last <= gapMax) { var allC = true; for (var xg = last + 1; xg < xx; xg++) if (!cand[row + xg]) { allC = false; break; }
                if (allC) for (xg = last + 1; xg < xx; xg++) okc[row + xg] = 1; } last = xx; }
            else if (!cand[pq]) last = -100; } }
        /* pieces joined to the frame, with some of the outline's darker line in them, mostly not plain sheet */
        var fill = new Uint8Array(N), lab2 = new Uint8Array(N), added = 0;
        for (i = 0; i < N; i++) { if (!okc[i] || lab2[i]) continue;
          comp.length = 0; var touch = false, ndk = 0, npl2 = 0; lab2[i] = 1; stk.push(i);
          while (stk.length) { var q5 = stk.pop(), x6 = q5 % W; comp.push(q5); if (darkLine(q5)) ndk++; if (plain(q5)) npl2++;
            if ((x6 > 0 && Fm[q5 - 1]) || (x6 < W - 1 && Fm[q5 + 1]) || (q5 >= W && Fm[q5 - W]) || (q5 < N - W && Fm[q5 + W])) touch = true;
            if (x6 > 0 && okc[q5 - 1] && !lab2[q5 - 1]) { lab2[q5 - 1] = 1; stk.push(q5 - 1); }
            if (x6 < W - 1 && okc[q5 + 1] && !lab2[q5 + 1]) { lab2[q5 + 1] = 1; stk.push(q5 + 1); }
            if (q5 >= W && okc[q5 - W] && !lab2[q5 - W]) { lab2[q5 - W] = 1; stk.push(q5 - W); }
            if (q5 < N - W && okc[q5 + W] && !lab2[q5 + W]) { lab2[q5 + W] = 1; stk.push(q5 + W); } }
          if (touch && ndk >= comp.length * 0.05 && npl2 <= comp.length * 0.6) for (var k2 = 0; k2 < comp.length; k2++) fill[comp[k2]] = 1; }
        /* trim the camera's soft fringe just outside the outline (4 px at most) */
        var fl = []; for (i = 0; i < N; i++) if (fill[i]) fl.push(i);
        var nb = function (q) { return out[q] || (!Fm[q] && !fill[q]); };
        for (var it3 = 0; it3 < 4; it3++) { var rm = [];
          for (var f1 = 0; f1 < fl.length; f1++) { i = fl[f1]; if (!fill[i] || frameish(i)) continue; var x7 = i % W;
            if ((x7 > 0 && nb(i - 1)) || (x7 < W - 1 && nb(i + 1)) || (i >= W && nb(i - W)) || (i < N - W && nb(i + W))) rm.push(i); }
          if (!rm.length) break; for (var k3 = 0; k3 < rm.length; k3++) fill[rm[k3]] = 0; }
        /* loose specks of sheet grain left on the outline: a pixel needs at least 2 of its 4 neighbours to be rim or frame */
        for (var it4 = 0; it4 < 2; it4++) { var rm2 = [];
          for (var f2 = 0; f2 < fl.length; f2++) { i = fl[f2]; if (!fill[i]) continue; var x8 = i % W, nn2 = 0;
            if (x8 > 0 && (fill[i - 1] || Fm[i - 1])) nn2++; if (x8 < W - 1 && (fill[i + 1] || Fm[i + 1])) nn2++;
            if (i >= W && (fill[i - W] || Fm[i - W])) nn2++; if (i < N - W && (fill[i + W] || Fm[i + W])) nn2++;
            if (nn2 < 2) rm2.push(i); }
          for (var k4 = 0; k4 < rm2.length; k4++) fill[rm2[k4]] = 0; }
        /* tiny leftover bits are not rim */
        var minPiece = Math.max(12, Math.round(W * W / 40000)), seen = new Uint8Array(N);
        for (var f3 = 0; f3 < fl.length; f3++) { var s0 = fl[f3]; if (!fill[s0] || seen[s0]) continue;
          comp.length = 0; seen[s0] = 1; stk.push(s0);
          while (stk.length) { var q6 = stk.pop(), x10 = q6 % W; comp.push(q6);
            if (x10 > 0 && fill[q6 - 1] && !seen[q6 - 1]) { seen[q6 - 1] = 1; stk.push(q6 - 1); }
            if (x10 < W - 1 && fill[q6 + 1] && !seen[q6 + 1]) { seen[q6 + 1] = 1; stk.push(q6 + 1); }
            if (q6 >= W && fill[q6 - W] && !seen[q6 - W]) { seen[q6 - W] = 1; stk.push(q6 - W); }
            if (q6 < N - W && fill[q6 + W] && !seen[q6 + W]) { seen[q6 + W] = 1; stk.push(q6 + W); } }
          if (comp.length < minPiece) for (var k5 = 0; k5 < comp.length; k5++) fill[comp[k5]] = 0; }
        if (g.__VGW_NOFILL) fill = new Uint8Array(N);                    /* tests: measure what the rim would be without this step */
        if (g.__VGW_DEBUG) g.__VGW_DEBUG = { W: W, H: H, out: out, E: E, cand: cand, okc: okc, fill: fill, lz: lz, Fm: Fm, fc: fc };
        for (i = 0; i < N; i++) if (fill[i]) { wt[i] = 0; added++; }
        stats.rimAdded = added / N; stats.rimTg = Math.round(Tg * 1000) / 1000; stats.rimGrain = Math.round(grain * 1000) / 1000;
        /* RIM CHECK -- the top rim measured column by column: in the PHOTO from its outline down to the lens opening, on the
           WHITE photo from its first frame pixel down to the same place. Saved with the white photo; Admin shows it, and a
           white photo whose rim is still clearly thinner than the photo is not used (the photo as taken is shown). */
        var cols = 0, thin = 0, sumP = 0, sumW = 0, sumLost = 0, minLen = Math.max(6, Math.round(W / 200));
        for (xx = 0; xx < W; xx += 2) {
          var yP = -1, yW = -1, yL = -1, hasC = false;
          for (yy = 0; yy < H; yy++) { var pz = yy * W + xx; if (!out[pz]) { yP = yy; break; } }
          if (yP < 0) continue;
          for (yy = yP; yy < H; yy++) { var pw = yy * W + xx; if (Fm[pw] || fill[pw]) { yW = yy; break; } }
          if (yW < 0 || yW - yP > Dmax * 2) continue;
          /* the outline itself: the first edge at least half as strong as the strongest one there (a camera's soft glow
             next to a thin wire is a weak edge and does not count) */
          var gmax = 0; for (yy = yP; yy <= Math.min(H - 1, yW + 3); yy++) if (G[yy * W + xx] > gmax) gmax = G[yy * W + xx];
          for (yy = yP; yy <= Math.min(H - 1, yW + 3); yy++) if (G[yy * W + xx] >= gmax * 0.5) { yP = yy; break; }
          for (yy = yW; yy < H; yy++) { var pl = yy * W + xx; if (fc[pl]) hasC = true;
            if (!Fm[pl] && !fill[pl]) { var run = 0; while (yy + run < H && !Fm[(yy + run) * W + xx] && !fill[(yy + run) * W + xx] && run < 4) run++; if (run >= 4) { yL = yy; break; } } }
          if (yL < 0 || !hasC) continue;
          var tP = yL - yP, tW = yL - yW; if (tP < minLen || tP > H * 0.25) continue;
          cols++; sumP += tP; sumW += tW; if (tW < tP * 0.85 - 2) { thin++; sumLost += tP - tW; } }
        stats.rimCheck = cols >= 10 ? { photoPx: Math.round(sumP / cols), whitePx: Math.round(sumW / cols), thinPct: Math.round(100 * thin / cols), lostPx: thin ? Math.round(sumLost / thin) : 0, cols: cols, w: W } : null;
      })();
    })();
    /* 4. a crystal / clear frame: protect its outline */
    stats.mode = stats.solid < 0.004 ? 'clear' : 'normal';
    if (stats.mode === 'clear') {
      var gr = new Float32Array(N);
      for (i = 0, j = 0; i < N; i++, j += 4) gr[i] = lum[i] / Math.max(0.25, bd[j] / 255);
      gr = boxBlur(boxBlur(gr, W, H, 1), W, H, 1);
      var edgeM = new Uint8Array(N), ecount = 0;
      for (var ey = 1; ey < H - 1; ey++) for (var ex = 1; ex < W - 1; ex++) { var q0 = ey * W + ex;
        var gx = (gr[q0 - W + 1] + 2 * gr[q0 + 1] + gr[q0 + W + 1]) - (gr[q0 - W - 1] + 2 * gr[q0 - 1] + gr[q0 + W - 1]);
        var gy = (gr[q0 + W - 1] + 2 * gr[q0 + W] + gr[q0 + W + 1]) - (gr[q0 - W - 1] + 2 * gr[q0 - W] + gr[q0 - W + 1]);
        if (Math.sqrt(gx * gx + gy * gy) > 0.12) edgeM[q0] = 1; }
      /* only real lines, not specks of grain */
      var elab = new Int32Array(N), est = new Int32Array(N), minE = Math.max(30, N * 0.00004), EL = 0;
      for (i = 0; i < N; i++) { if (!edgeM[i] || elab[i]) continue; EL++; var ep = 0, comp = []; est[ep++] = i; elab[i] = EL;
        while (ep) { var e0 = est[--ep], e0x = e0 % W; comp.push(e0);
          if (e0x > 0 && edgeM[e0 - 1] && !elab[e0 - 1]) { elab[e0 - 1] = EL; est[ep++] = e0 - 1; }
          if (e0x < W - 1 && edgeM[e0 + 1] && !elab[e0 + 1]) { elab[e0 + 1] = EL; est[ep++] = e0 + 1; }
          if (e0 >= W && edgeM[e0 - W] && !elab[e0 - W]) { elab[e0 - W] = EL; est[ep++] = e0 - W; }
          if (e0 < N - W && edgeM[e0 + W] && !elab[e0 + W]) { elab[e0 + W] = EL; est[ep++] = e0 + W; } }
        if (comp.length < minE) for (var ci = 0; ci < comp.length; ci++) edgeM[comp[ci]] = 0; else ecount += comp.length; }
      if (ecount < N * 0.0005) return { safe: false, reason: 'no frame outline found -- the original is kept', stats: stats };
      for (var di = 0; di < 2; di++) { var en = new Uint8Array(edgeM);
        for (i = 0; i < N; i++) { if (edgeM[i]) continue; var exx = i % W;
          if ((exx > 0 && edgeM[i - 1]) || (exx < W - 1 && edgeM[i + 1]) || (i >= W && edgeM[i - W]) || (i < N - W && edgeM[i + W])) en[i] = 1; }
        edgeM = en; }
      var prot = new Float32Array(N); for (i = 0; i < N; i++) prot[i] = edgeM[i];
      prot = boxBlur(boxBlur(prot, W, H, 1), W, H, 1);
      for (i = 0; i < N; i++) wt[i] *= 1 - Math.min(1, prot[i] * 1.6);
      stats.edges = ecount / N;
    }

    /* 3. only the sheet: pieces touching the photo's edge, or big pieces (the sheet through a lens) */
    var lab = new Int32Array(N), stack = new Int32Array(N), L = 0, keep = [false], edgeOf = [false], big = N * 0.004;
    for (i = 0; i < N; i++) {
      if (lab[i] || wt[i] <= 0.5) continue;
      L++; var sp = 0, size = 0, edge = false; stack[sp++] = i; lab[i] = L;
      while (sp) { var q = stack[--sp], qx = q % W, qy = (q - qx) / W; size++;
        if (qx === 0 || qy === 0 || qx === W - 1 || qy === H - 1) edge = true;
        if (qx > 0 && !lab[q - 1] && wt[q - 1] > 0.5) { lab[q - 1] = L; stack[sp++] = q - 1; }
        if (qx < W - 1 && !lab[q + 1] && wt[q + 1] > 0.5) { lab[q + 1] = L; stack[sp++] = q + 1; }
        if (qy > 0 && !lab[q - W] && wt[q - W] > 0.5) { lab[q - W] = L; stack[sp++] = q - W; }
        if (qy < H - 1 && !lab[q + W] && wt[q + W] > 0.5) { lab[q + W] = L; stack[sp++] = q + W; } }
      keep[L] = edge || size > big; edgeOf[L] = edge;
    }
    var sheet = new Uint8Array(N);
    for (i = 0; i < N; i++) sheet[i] = keep[lab[i]] ? 1 : 0;
    /* 3b. d17.183 DEMO LENS TEXT OFF (shop, 25 Oct: "the name on the demo has to be wiped out"). Anything printed or stuck
       on the demo lens -- the brand name, a logo, size numbers -- is a small mark floating inside a lens opening: all
       around it is the sheet seen through that lens, and it touches neither the frame nor the sheet outside the frame.
       Those marks turn white with the lens. An arm or a nose pad seen through the lens is joined to the frame, and a
       big piece (a sticker, a far arm) is never touched. */
    var wipe = new Uint8Array(N), labT = new Int32Array(N), nT = 0, wipedPx = 0, wipedMarks = 0;
    var maxMark = N * 0.003, maxSide = Math.max(W, H) * 0.08, compT = [];
    var floatPass = function () {                 /* marks with only lens all around them (wiped marks count as lens) */
      labT = new Int32Array(N);
      for (i = 0; i < N; i++) {
        if (sheet[i] || wipe[i] || labT[i]) continue;
        nT++; compT.length = 0; var ok = true, sizeT = 0, mx0 = W, mx1 = 0, my0 = H, my1 = 0; labT[i] = nT; stack[0] = i; var spT = 1;
        while (spT) { var qT = stack[--spT], xT = qT % W, yT = (qT - xT) / W; compT.push(qT); sizeT++;
          if (xT < mx0) mx0 = xT; if (xT > mx1) mx1 = xT; if (yT < my0) my0 = yT; if (yT > my1) my1 = yT;
          if (xT === 0 || yT === 0 || xT === W - 1 || yT === H - 1) ok = false;
          for (var dyT = -1; dyT <= 1; dyT++) for (var dxT = -1; dxT <= 1; dxT++) { if (!dxT && !dyT) continue;
            var xn = xT + dxT, yn = yT + dyT; if (xn < 0 || yn < 0 || xn >= W || yn >= H) continue; var qn = yn * W + xn;
            if (sheet[qn]) { if (edgeOf[lab[qn]]) ok = false; }
            else if (!wipe[qn] && !labT[qn]) { labT[qn] = nT; stack[spT++] = qn; } } }
        if (ok && sizeT <= maxMark && (mx1 - mx0) <= maxSide && (my1 - my0) <= maxSide) { wipedMarks++; wipedPx += sizeT; for (var kT = 0; kT < compT.length; kT++) wipe[compT[kT]] = 1; }
      }
    };
    floatPass();
    /* ... and thin marks that only lean on the frame: printing that runs into an arm seen through the lens, the grey haze
       a demo lens leaves near the rim. Thin = gone when the frame is shrunk by a few px (an arm, a rim or a pad is thicker
       and is never touched); it must not reach the sheet outside the frame, and only a small part of its outline may touch
       the thick frame. */
    (function () {
      var kept = new Uint8Array(N); for (i = 0; i < N; i++) kept[i] = sheet[i] ? 0 : 1;
      var rT = Math.max(2, Math.round(W / 400)), dK = stepDist(sheet, W, H, rT + 2, true), core = new Uint8Array(N);
      for (i = 0; i < N; i++) if (kept[i] && dK[i] > rT) core[i] = 1;
      var dC = stepDist(core, W, H, rT + 3, true), thick = new Uint8Array(N), thin = new Uint8Array(N);
      for (i = 0; i < N; i++) { if (dC[i] <= rT + 1) thick[i] = 1; if (kept[i] && !thick[i]) thin[i] = 1; }
      var nearOut = new Uint8Array(N);
      for (i = 0; i < N; i++) if (sheet[i] && edgeOf[lab[i]]) nearOut[i] = 1;
      var dO = stepDist(nearOut, W, H, 4, true);
      var seen = new Uint8Array(N), cmp = [];
      for (i = 0; i < N; i++) {
        if (!thin[i] || seen[i] || wipe[i]) continue;
        cmp.length = 0; seen[i] = 1; stack[0] = i; var sp2 = 1, ok2 = true, ax0 = W, ax1 = 0, ay0 = H, ay1 = 0, ring = 0, touchT = 0;
        while (sp2) { var q2 = stack[--sp2], x2 = q2 % W, y2 = (q2 - x2) / W; cmp.push(q2);
          if (x2 < ax0) ax0 = x2; if (x2 > ax1) ax1 = x2; if (y2 < ay0) ay0 = y2; if (y2 > ay1) ay1 = y2;
          if (x2 === 0 || y2 === 0 || x2 === W - 1 || y2 === H - 1 || dO[q2] <= 2) ok2 = false;
          for (var dy2 = -1; dy2 <= 1; dy2++) for (var dx2 = -1; dx2 <= 1; dx2++) { if (!dx2 && !dy2) continue;
            var xn2 = x2 + dx2, yn2 = y2 + dy2; if (xn2 < 0 || yn2 < 0 || xn2 >= W || yn2 >= H) continue; var qn2 = yn2 * W + xn2;
            if (thin[qn2]) { if (!seen[qn2]) { seen[qn2] = 1; stack[sp2++] = qn2; } }
            else if (dx2 === 0 || dy2 === 0) { ring++; if (thick[qn2] && kept[qn2]) touchT++; } } }
        if (ok2 && cmp.length <= maxMark && (ax1 - ax0) <= maxSide * 1.5 && (ay1 - ay0) <= maxSide * 1.5 && touchT <= ring * 0.25) {
          wipedMarks++; wipedPx += cmp.length; for (var k2 = 0; k2 < cmp.length; k2++) wipe[cmp[k2]] = 1; }
      }
    })();
    floatPass();                                  /* what was left floating once the thin printing went (the bold bits of letters) */
    if (wipedMarks) { for (var itw = 0; itw < 2; itw++) { var nw = new Uint8Array(wipe);        /* and their soft edge */
        for (i = 0; i < N; i++) { if (wipe[i]) continue; var xw = i % W;
          if ((xw > 0 && wipe[i - 1]) || (xw < W - 1 && wipe[i + 1]) || (i >= W && wipe[i - W]) || (i < N - W && wipe[i + W])) nw[i] = 1; }
        wipe = nw; } }
    stats.textMarks = wipedMarks; stats.textWiped = wipedPx / N;
    for (var it = 0; it < 2; it++) {                                      /* reach the soft edge of the sheet (2 px) */
      var nx = new Uint8Array(sheet);
      for (var yy = 0; yy < H; yy++) for (var xx = 0; xx < W; xx++) { var p = yy * W + xx; if (sheet[p]) continue;
        if ((xx > 0 && sheet[p - 1]) || (xx < W - 1 && sheet[p + 1]) || (yy > 0 && sheet[p - W]) || (yy < H - 1 && sheet[p + W])) nx[p] = 1; }
      sheet = nx;
    }
    /* the ramp between T0 and T1 already gives a soft edge; a dark (frame) pixel has weight 0 and is never changed */
    var shw = new Uint8Array(N);                 /* d17.184: how much of each pixel turned white (0-255) -- the try-on AI test clears the lenses with it */
    for (i = 0, j = 0; i < N; i++, j += 4) {
      var f = wipe[i] ? 1 : sheet[i] ? Math.min(1, Math.max(0, (wt[i] - 0.1) / 0.6)) : 0; if (f <= 0) continue;   /* mostly-sheet = all white; demo-lens text = white */
      shw[i] = Math.round(f * 255);
      d[j] = Math.round(d[j] * (1 - f) + 255 * f); d[j + 1] = Math.round(d[j + 1] * (1 - f) + 255 * f); d[j + 2] = Math.round(d[j + 2] * (1 - f) + 255 * f);
    }
    x.putImageData(id, 0, 0);
    return { canvas: c, safe: true, stats: stats, whiteMap: shw, w: W, h: H };
  }
  g.VGWhite = { make: make, VERSION: 'd17.184' };
})(window);

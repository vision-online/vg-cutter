/* Vision Gallery — "On a model · 30°" pictures (d17.175, shop 24 Oct: "it's a fixed model, we have the entire measurement --
   every frame has to sit on the same model the same way, every time"; "for the 30° we work on the side only").

   The model turned 30° wears the frame the SAME way the live camera try-on draws it on a turned head:
     - the FRONT cut-out (the good front, checked in TO CHECK) turned with the head,
     - the ARM from the robot's 30° picture (only the side part of that picture is used),
     - the model's face points are fixed numbers (measured once, Admin -> AI models), never detected again,
     - the size comes from the model's straight-on photo (its own measurement), carried to the turned photo.
   So the seat depends only on the frame's size and its front picture: same model + same frame = same picture, always.
   The front part of the 30° picture is no longer used here (the old way built the model picture from it, and a robot
   mistake on that front showed on the model).

   VGModel30.shot({ models, mid, view:'left45'|'right45', base:'models/', frontUrl, angleUrl, angleRUrl, widthMM, fullRim,
                    templeMM, only:'angle'|'angleR' })  -> Promise<dataURL|null>
   VGModel30.viewFor(...same, only) -> Promise<'left45'|'right45'|null>  (the model view that shows that 30° picture's arm) */
(function (g) {
  'use strict';
  if (g.VGModel30) return;
  var IMGS = new Map();
  function load(s) {
    if (IMGS.size > 40) IMGS.clear();                                  /* only what this visit needs */
    if (!IMGS.has(s)) IMGS.set(s, new Promise(function (res, rej) { var i = new Image(); i.crossOrigin = 'anonymous'; i.onload = function () { res(i); }; i.onerror = function (e) { IMGS.delete(s); rej(e); }; i.src = s; }));
    return IMGS.get(s);
  }
  function toLM(a) { return a.map(function (q) { return { x: q[0], y: q[1], z: q[2] || 0 }; }); }
  function none() { return null; }

  /* the arms from the 30° pictures, measured against the front (each side its own arm when both pictures are there) */
  async function arms(o, front) {
    var w = Number(o.widthMM) || 140, V = g.VGOnFace, out = {};
    var imgs = await Promise.all([o.angleUrl ? load(o.angleUrl).catch(none) : null, o.angleRUrl ? load(o.angleRUrl).catch(none) : null]);
    [['angle', imgs[0]], ['angleR', imgs[1]]].forEach(function (q) {
      if (!q[1]) return; try { var a = V.realArmFrom30(q[1], front, w); if (a && a.canvas) out[q[0]] = a; } catch (e) {}
    });
    return out;
  }
  function pairOf(list) {
    var A = list[0]; if (!A) return null;
    var P = {}; list.forEach(function (a) { if (a && P[a.side] == null) P[a.side] = a; });
    var r = Object.assign({}, A); if (Object.keys(P).length > 1) r.pair = P;
    return r;
  }

  async function prepare(o) {
    var V = g.VGOnFace, M = o.models; if (!V || !M || !o.mid || !M[o.mid]) return null;
    var base = o.base || 'models/', fr = M[o.mid].views && M[o.mid].views.front;
    if (!fr || !fr.found || !Array.isArray(fr.all) || !o.frontUrl) return null;
    var got = await Promise.all([load(base + o.mid + '/front.webp'), load(o.frontUrl)]);
    var frontFace = V.faceFromLandmarks(toLM(fr.all), got[0].naturalWidth, got[0].naturalHeight, false);
    var front = V.cutout(got[1], { alreadyCut: true, fullRim: !!o.fullRim });
    if (!frontFace || !front) return null;
    var A = await arms(o, front);
    return { frontFace: frontFace, front: front, A: A };
  }

  /* which turned model photo shows the arm of this 30° picture on its near side */
  function nearRightOf(M, mid, view, base) {
    var rec = M[mid].views && M[mid].views[view];
    if (!rec || !rec.found || !Array.isArray(rec.all)) return Promise.resolve(null);
    return load((base || 'models/') + mid + '/' + view + '.webp').then(function (img) {
      var f = g.VGOnFace.faceFromLandmarks(toLM(rec.all), img.naturalWidth, img.naturalHeight, false);
      return f ? { img: img, face: f, nearRight: (f.yaw || 0) > 0 } : null;
    }).catch(none);
  }

  async function shot(o) {
    try {
      var V = g.VGOnFace, M = o.models; if (!V || !V.compose || !M || !M[o.mid]) return null;
      var pre = await prepare(o); if (!pre) return null;
      var t = await nearRightOf(M, o.mid, o.view, o.base); if (!t) return null;
      var list;
      if (o.only) { list = pre.A[o.only] ? [pre.A[o.only]] : []; }
      else {
        /* the arm whose side matches the near side first (the left picture's arm on its side, the right picture's on its) */
        var want = t.nearRight ? 1 : -1, all = [pre.A.angle, pre.A.angleR].filter(Boolean);
        list = all.filter(function (a) { return a.side === want; }).concat(all.filter(function (a) { return a.side !== want; }));
      }
      var realArm = pairOf(list);
      if (!realArm && !o.only && V.armFromFront) { try { realArm = V.armFromFront(pre.front, Number(o.widthMM) || 140); } catch (e) { realArm = null; } }
      if (o.only && !realArm) return null;
      var scale = 0; try { scale = (g.VG45 && g.VG45.perMMFromFace) ? g.VG45.perMMFromFace(pre.frontFace) : 0; } catch (e) { scale = 0; }
      var perMM = (scale > 0 && pre.frontFace.faceL > 0 && t.face.faceL > 0) ? scale * (t.face.faceL / pre.frontFace.faceL) : undefined;
      var turn = (t.face.pose && isFinite(t.face.pose.yaw)) ? Math.abs(t.face.pose.yaw) : Math.abs(t.face.yaw || 0) * 55;
      var res = V.compose(t.img, t.face, pre.front, Number(o.widthMM) || 140, { drawSyntheticArms: false, armsToHair: !!realArm,
        realArm: realArm || undefined, turnDeg: Math.min(turn, 60), turnNearRight: t.nearRight, templeMM: Number(o.templeMM) || 140, perMM: perMM });
      var c = res && (res.canvas || res);
      return (c && c.toDataURL) ? c.toDataURL('image/jpeg', 0.88) : null;
    } catch (e) { return null; }
  }

  /* Admin: the model view for ONE 30° picture (its arm on the near side) */
  async function viewFor(o) {
    try {
      var V = g.VGOnFace, M = o.models; if (!V || !M || !M[o.mid]) return null;
      var pre = await prepare(o); if (!pre) return null;
      var a = pre.A[o.only]; if (!a) return null;
      for (var v of ['left45', 'right45']) { var t = await nearRightOf(M, o.mid, v, o.base); if (t && (t.nearRight ? 1 : -1) === a.side) return v; }
      return null;
    } catch (e) { return null; }
  }
  g.VGModel30 = { shot: shot, viewFor: viewFor, VERSION: 'd17.175' };
})(window);

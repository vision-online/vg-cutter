/* d17.140 TRY-ON KIT (shop, 14 Oct: "when we swipe back on the phone, it must only go back from the try-on -- not out to
   the other page"). The live try-on now opens IN PLACE on the frame page too (it used to jump to the home page first, so the
   phone's back-swipe took the customer away from the frame). These are the few helpers the live try-on needs; each one is
   only set when the page does not already have its own (the home page keeps its own versions). */
(function (g) {
  'use strict';
  /* the face finder, fetched the first time the try-on opens (two servers, the one that answers is remembered) */
  if (typeof g.loadFaceMesh !== 'function') {
    var LOAD = null;
    g.loadFaceMesh = function () {
      if (g.FaceMesh) return Promise.resolve();
      if (LOAD) return LOAD;
      var SOURCES = ['https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh@0.4/', 'https://unpkg.com/@mediapipe/face_mesh@0.4/'];
      var one = function (i) { return new Promise(function (res, rej) {
        var sc = document.createElement('script'); sc.src = SOURCES[i] + 'face_mesh.js'; sc.crossOrigin = 'anonymous';
        var tm = setTimeout(function () { sc.onload = sc.onerror = null; rej(new Error('timeout')); }, 12000);
        sc.onload = function () { clearTimeout(tm); g.FACEMESH_BASE = SOURCES[i]; res(); };
        sc.onerror = function () { clearTimeout(tm); rej(new Error('failed')); };
        document.head.appendChild(sc); }); };
      LOAD = one(0).catch(function () { return one(1); }).catch(function (err) { LOAD = null; throw err; });
      return LOAD;
    };
  }
  /* the frame's front width in mm -- the same rule as the home page */
  if (typeof g.frameWidthMM !== 'function') {
    var robotFrontMM = function (p) {
      var s = (p && p.size) || {}, n = (p && p.tryOnNumbers) || {}, L = Number(s.lens) || 0, B = Number(s.bridge) || 0, fw = Number(n.frontWidthPx) || 0, pg = Number(n.pupilGapPx) || 0;
      if (!L || !B || !fw || !pg) return 0; var mm = (L + B) * fw / pg;
      return (mm >= 2 * L + B + 4 && mm <= 2 * L + B + 22) ? Math.round(mm * 10) / 10 : 0;
    };
    g.frameWidthMM = function (p) {
      var total = Number(p.size && p.size.total) || 0, L0 = Number(p.size && p.size.lens) || 0, B0 = Number(p.size && p.size.bridge) || 0;
      var sane = !(L0 && B0) || (total >= 2 * L0 + B0 + 4 && total <= 2 * L0 + B0 + 20);
      if (total >= 100 && total <= 175 && sane) return total;
      var P = g.VG_PROFILES || {}, key = String(p.profile || p.name || '').toLowerCase();
      for (var k in P) if (key.indexOf(k) !== -1) return P[k].widthMM;
      var rf = robotFrontMM(p); if (rf) return rf;
      if (p.size && p.size.lens && p.size.bridge) return Number(p.size.lens) * 2 + Number(p.size.bridge) + 11;
      return String(p.cat || '').toLowerCase() === 'kids' ? 128 : 140;
    };
  }
  /* size groups and fit words -- the same as the home page */
  var NAMES = ['Extra Narrow', 'Narrow', 'Medium', 'Wide', 'Extra Wide'], EDGES = [129.5, 133.5, 137.5, 141.5];
  var strict = function (w) { w = Number(w) || 0; var i = 0; while (i < EDGES.length && w > EDGES[i]) i++; return NAMES[i]; };
  if (typeof g.vgYourSize !== 'function') g.vgYourSize = function (faceMM) {
    var f = Number(faceMM) || 0; if (!f) return null; var lo = Math.round(f - 4), hi = Math.round(f + 4), a = strict(lo + 0.5), z = strict(hi - 0.5);
    return { lo: lo, hi: hi, names: a === z ? a : a + ' to ' + z, text: lo + '–' + hi + ' mm' };
  };
  var WORDS = { 'GOOD FIT': 'Perfect fit', 'GOOD / CHECK FIT': 'Good fit', 'MAY BE WIDE': 'A little wide', 'MAY BE NARROW': 'A little narrow' };
  if (typeof g.fitWord !== 'function') g.fitWord = function (s) { return WORDS[s] || s || ''; };
  if (typeof g.myGlasses !== 'function') g.myGlasses = function () {
    try { var x = JSON.parse(g.localStorage.getItem('vg_my_glasses') || 'null'), L = Number(x && x.lens), B = Number(x && x.bridge);
      return (L >= 38 && L <= 62 && B >= 12 && B <= 26) ? { lens: L, bridge: B, temple: Number(x.temple) || 0 } : null; } catch (e) { return null; }
  };
  if (typeof g.glassesFit !== 'function') g.glassesFit = function (p) {
    var gl = g.myGlasses(), s = (p && p.size) || {}, L = Number(s.lens) || 0, B = Number(s.bridge) || 0; if (!gl || !L || !B) return null;
    var d = (L + B) - (gl.lens + gl.bridge);
    return { status: Math.abs(d) <= 2 ? 'GOOD FIT' : Math.abs(d) <= 4 ? 'GOOD / CHECK FIT' : d > 0 ? 'MAY BE WIDE' : 'MAY BE NARROW', fromGlasses: true, diff: d };
  };
  if (typeof g.knownPD !== 'function') g.knownPD = function () {
    try { var t = parseFloat(g.localStorage.getItem('vg_pd_known') || '0'); if (t >= 40 && t <= 82) return t;
      var rx = JSON.parse(g.localStorage.getItem('vg_rx_draft') || 'null'); if (!rx) return 0;
      var r = parseFloat((rx.od && rx.od.pd) || 0), l = parseFloat((rx.os && rx.os.pd) || 0), total = 0;
      if (r > 20 && l > 20) total = r + l; else if (r > 40 && r < 82) total = r; else if (l > 40 && l < 82) total = l;
      return (total >= 40 && total <= 82) ? total : 0; } catch (e) { return 0; }
  };
  /* the frames the strip shows: what this page has loaded */
  if (typeof g.allProducts !== 'function') g.allProducts = function () {
    return ((g.VG_CONFIG && g.VG_CONFIG.products) || []).filter(function (p) { return p && p.url && p.stock !== false && !(p.qty !== '' && p.qty !== undefined && p.qty !== null && Number(p.qty) <= 0); });
  };
})(window);

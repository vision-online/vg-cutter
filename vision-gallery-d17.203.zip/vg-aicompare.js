/* d17.183 ROBOT vs AI -- white photos side by side, for the shop to judge (shop, 25 Oct: "AI also looking good -- I want to see
   10 to 15 frames with AI and with robot in the admin page, so we come to know which works nicely; and the AI must clean the
   demo lens white and wipe the name on it").

   ROBOT = our white maker (vg-white.js, as Admin makes the shop's white photos now: sheet white, frame untouched, the rim up to
   its own outline, the demo-lens printing wiped).
   AI    = the free AI picture reader of the frame's shape (BiRefNet -- the same one the cut-out robot uses, MIT licence). It
   decides what is frame and what is background; the lenses are cleaned by the robot's rule (on its own the AI leaves them grey
   and keeps the printing). Its frame masks are made on GitHub by the "AI test" job and listed in the setting "aicompare".
   Nothing here changes the shop: it is a test page. Staff tap which one looks better; the votes are kept ("aivotes").

   d17.184 TRY-ON (shop, 25 Oct: "the 30 left / 30 right side -- robot did a lot of mistakes for the side also -- and the try-on
   front: is the AI the same as our robot or far better? test 10, 15, 50 frames, then I keep the better one ON").
   On its own the AI cannot make a try-on picture: it keeps the lenses solid (the sheet seen through them) and the arms behind
   the glass -- that is the robot's job, and the robot already starts from this same AI. So the test is
   ROBOT              = the try-on picture on the website now (front, 30° left, 30° right), and
   ROBOT + AI CLEAN-UP = the same picture with whatever the AI sees as NOT frame taken away (a table reflection, a shadow, a
                        smudge). The AI's frame is grown by a few px first, so the robot's own soft edge, rims and lenses stay.
   The AI's masks of the robot's own source crops are made by the same "AI test" job (setting "aicompare", list "tryon"). */
(function (g) {
  'use strict';
  var CSS = [
    '.aic{position:fixed;inset:0;z-index:9400;background:#F3F6FB;overflow:auto;font:500 .9rem/1.45 Inter,system-ui,sans-serif;color:#0F1E3D}',
    '.aic-top{position:sticky;top:0;z-index:2;background:#0F1E3D;color:#fff;padding:10px 14px;display:flex;align-items:center;justify-content:space-between;gap:10px}',
    '.aic-top b{font-size:1rem}.aic-top button{background:#fff;color:#0F1E3D;border:0;border-radius:8px;padding:8px 12px;font-weight:800;font-size:.75rem}',
    '.aic-in{max-width:1100px;margin:0 auto;padding:12px}',
    '.aic-note{background:#fff;border:1px solid #DCE3EE;border-radius:12px;padding:10px 12px;margin-bottom:10px}',
    '.aic-sum{display:flex;flex-wrap:wrap;gap:6px;margin:8px 0 0}.aic-sum span{background:#EEF2F8;border-radius:999px;padding:4px 10px;font-weight:700;font-size:.8rem}',
    '.aic-sum span.r{background:#E6EDFB;color:#1F55C8}.aic-sum span.a{background:#F3E8FF;color:#7E22CE}',
    '.aic-item{background:#fff;border:1px solid #DCE3EE;border-radius:12px;padding:10px;margin-bottom:10px}',
    '.aic-item h4{margin:0 0 8px;font-size:.9rem}.aic-item h4 small{font-weight:600;color:#5B6B86}',
    '.aic-row{display:grid;grid-template-columns:repeat(3,1fr);gap:6px}',
    '.aic-row figure{margin:0;background:#fff;border:1px solid #E3E8F1;border-radius:8px;overflow:hidden}',
    '.aic-row img{display:block;width:100%;aspect-ratio:16/9;object-fit:contain;background:#fff;cursor:zoom-in}',
    '.aic-row figcaption{font-size:.68rem;font-weight:800;text-align:center;padding:3px 2px;color:#334}',
    '.aic-row .wait{display:flex;align-items:center;justify-content:center;aspect-ratio:16/9;color:#8A97AD;font-size:.75rem}',
    '.aic-facts{font-size:.74rem;color:#5B6B86;margin:6px 0 0}',
    '.aic-vote{display:flex;gap:6px;margin-top:8px;flex-wrap:wrap}.aic-vote button{flex:1;min-width:90px;border:1px solid #C9D3E3;background:#fff;border-radius:8px;padding:8px 6px;font-weight:800;font-size:.72rem;color:#0F1E3D}',
    '.aic-vote button.on.r{background:#1F55C8;border-color:#1F55C8;color:#fff}.aic-vote button.on.s{background:#0F1E3D;border-color:#0F1E3D;color:#fff}.aic-vote button.on.a{background:#7E22CE;border-color:#7E22CE;color:#fff}',
    '.aic-alone{font-size:.68rem;margin-top:4px;text-align:center}.aic-alone button{border:0;background:none;color:#1F55C8;font-weight:700;text-decoration:underline;font-size:.68rem;padding:2px}',
    '.aic-big{position:fixed;inset:0;z-index:9600;background:rgba(15,30,61,.92);display:flex;align-items:center;justify-content:center;padding:10px}',
    '.aic-big img{max-width:100%;max-height:100%;background:#fff;border-radius:6px}',
    '.aic-big b{position:absolute;top:10px;left:12px;color:#fff;font-size:.85rem}',
    '.aic-tabs{display:flex;gap:6px;padding:8px 12px 0;max-width:1100px;margin:0 auto}.aic-tabs button{flex:1;border:1px solid #C9D3E3;background:#fff;border-radius:999px;padding:8px 6px;font-weight:800;font-size:.75rem;color:#0F1E3D}',
    '.aic-tabs button.on{background:#0F1E3D;border-color:#0F1E3D;color:#fff}',
    '.aic-row.t{grid-template-columns:1fr 1fr}.aic-row.t img{aspect-ratio:3/1;background:#DEB092}.aic-row.t .wait{aspect-ratio:3/1;background:#EBD3C2}',
    '.aic-big.t img{background:#DEB092}',
    '.aic-chg{display:inline-block;border-radius:999px;padding:1px 8px;font-size:.7rem;font-weight:800;background:#EEF2F8;color:#334;margin-left:4px}.aic-chg.big{background:#FDE8E8;color:#B42318}',
    '@media (max-width:560px){.aic-row{grid-template-columns:1fr 1fr}.aic-row figure:first-child{grid-column:1/-1}.aic-row.t{grid-template-columns:1fr}.aic-row.t figure:first-child{grid-column:auto}}'
  ].join('\n');
  var NAMES = { front: 'FRONT', angle: '30° LEFT', 'angle-right': '30° RIGHT' };
  var S = { data: null, votes: {}, made: {}, busy: false, alone: {}, tab: 'white', tmade: {}, tshow: {} };
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function $(id) { return document.getElementById(id); }
  function key(it) { return it.id + '|' + it.view; }
  function tkey(it) { return 'T|' + it.id + '|' + it.view; }          /* try-on votes, kept apart from the white-photo votes */
  function tlist() { var l = ((S.data && S.data.tryon) || []).slice();
    return l.sort(function (a, b) { return (Number(b.removed) || 0) - (Number(a.removed) || 0); }); }   /* the biggest change first */
  function addCss() { if ($('aicCss')) return; var st = document.createElement('style'); st.id = 'aicCss'; st.textContent = CSS; document.head.appendChild(st); }
  async function pic(url) {
    var r = await fetch(url, { cache: 'reload' }); if (!r.ok) throw new Error('picture ' + r.status);
    return await createImageBitmap(await r.blob());
  }
  /* AI = the AI's frame mask over the ROBOT's picture: where the AI sees background it is white; everything else is the
     robot's picture (frame untouched, lenses white, printing wiped). "AI alone" = the mask over the photo itself. */
  function compose(photo, mask, robotCanvas, alone) {
    var W = photo.width, H = photo.height, c = document.createElement('canvas'); c.width = W; c.height = H;
    var x = c.getContext('2d', { willReadFrequently: true });
    x.drawImage(alone ? photo : robotCanvas, 0, 0, W, H);
    var id = x.getImageData(0, 0, W, H), d = id.data;
    var mc = document.createElement('canvas'); mc.width = W; mc.height = H; var mx = mc.getContext('2d', { willReadFrequently: true });
    mx.imageSmoothingEnabled = true; mx.drawImage(mask, 0, 0, W, H);
    var m = mx.getImageData(0, 0, W, H).data, kept = 0, took = 0, rk = null, j;
    /* "how much of the frame": only inside the box the AI's frame fills (a stand or a cup at the photo's edge is not frame) */
    var bx0 = W, bx1 = -1, by0 = H, by1 = -1;
    for (j = 0; j < m.length; j += 4) if (m[j] > 127) { var pp = j >> 2, px = pp % W, py = (pp - px) / W; if (px < bx0) bx0 = px; if (px > bx1) bx1 = px; if (py < by0) by0 = py; if (py > by1) by1 = py; }
    var mgx = Math.round(W * 0.02), mgy = Math.round(H * 0.02); bx0 -= mgx; bx1 += mgx; by0 -= mgy; by1 += mgy;
    if (!alone) { rk = robotCanvas.getContext('2d', { willReadFrequently: true }).getImageData(0, 0, W, H).data; }
    for (j = 0; j < d.length; j += 4) {
      var a = m[j] / 255;
      if (rk) { var isKept = rk[j] + rk[j + 1] + rk[j + 2] < 750, q = j >> 2, qx = q % W, qy = (q - qx) / W;
        if (isKept && qx >= bx0 && qx <= bx1 && qy >= by0 && qy <= by1) { kept++; if (a < 0.5) took++; } }
      d[j] = d[j] * a + 255 * (1 - a); d[j + 1] = d[j + 1] * a + 255 * (1 - a); d[j + 2] = d[j + 2] * a + 255 * (1 - a);
    }
    x.putImageData(id, 0, 0);
    return { canvas: c, tookPct: kept ? Math.round(1000 * took / kept) / 10 : 0 };
  }
  /* d17.184: kept as files in memory (not text), at most 1400 px across, so 50 frames stay light on a phone */
  function jpg(c) {
    return new Promise(function (res) {
      var k = Math.min(1, 1400 / c.width), o = c;
      if (k < 1) { o = document.createElement('canvas'); o.width = Math.round(c.width * k); o.height = Math.round(c.height * k);
        var x = o.getContext('2d'); x.imageSmoothingQuality = 'high'; x.drawImage(c, 0, 0, o.width, o.height); }
      if (o.toBlob) o.toBlob(function (b) { res(b ? URL.createObjectURL(b) : o.toDataURL('image/jpeg', 0.9)); }, 'image/jpeg', 0.9); else res(o.toDataURL('image/jpeg', 0.9));
    });
  }
  async function makeOne(it) {
    var k = key(it); if (S.made[k] && S.made[k].ok) return S.made[k];
    var out = { ok: false };
    try {
      var photo = await pic(it.photo), mask = await pic(it.mask);
      var pc = document.createElement('canvas'); pc.width = photo.width; pc.height = photo.height; pc.getContext('2d').drawImage(photo, 0, 0);
      var res = g.VGWhite ? g.VGWhite.make(photo) : { safe: false };
      var robot = res.safe ? res.canvas : pc;
      var ai = compose(photo, mask, robot, false), aiAlone = compose(photo, mask, robot, true);
      out = { ok: true, photo: await jpg(pc), robot: await jpg(robot), ai: await jpg(ai.canvas), aiAlone: await jpg(aiAlone.canvas), tookPct: ai.tookPct,
        robotSafe: !!res.safe, rim: res.stats && res.stats.rimCheck, text: res.stats ? res.stats.textMarks || 0 : 0 };
      try { photo.close && photo.close(); mask.close && mask.close(); } catch (e) {}
    } catch (e) { out = { ok: false, error: e.message || String(e) }; }
    S.made[k] = out;
    return out;
  }
  /* the AI's frame grown by r px (a square window, as the test job measured it): the robot's soft edge is never cut */
  function grow(m, W, H, r) {
    var t = new Uint8ClampedArray(W * H), o = new Uint8ClampedArray(W * H), x, y, k, v;
    for (y = 0; y < H; y++) for (x = 0; x < W; x++) { v = 0; for (k = Math.max(0, x - r); k <= Math.min(W - 1, x + r); k++) if (m[y * W + k] > v) v = m[y * W + k]; t[y * W + x] = v; }
    for (x = 0; x < W; x++) for (y = 0; y < H; y++) { v = 0; for (k = Math.max(0, y - r); k <= Math.min(H - 1, y + r); k++) if (t[k * W + x] > v) v = t[k * W + x]; o[y * W + x] = v; }
    return o;
  }
  /* ROBOT + AI CLEAN-UP = the robot's try-on picture x the AI's (grown) frame. "changes" = the robot's picture with what goes
     painted red; "alone" = the AI by itself (its mask over the robot's source crop: solid lenses, arms behind the glass). */
  function composeTry(robot, src, mask, r) {
    var W = robot.width, H = robot.height, N = W * H, i, j;
    var cv = function () { var c = document.createElement('canvas'); c.width = W; c.height = H; return c; };
    var rd = (function () { var c = cv(), x = c.getContext('2d', { willReadFrequently: true }); x.drawImage(robot, 0, 0); return x.getImageData(0, 0, W, H); })();
    var md = (function () { var c = cv(), x = c.getContext('2d', { willReadFrequently: true }); x.imageSmoothingEnabled = true; x.drawImage(mask, 0, 0, W, H); return x.getImageData(0, 0, W, H).data; })();
    var sd = (function () { var c = cv(), x = c.getContext('2d', { willReadFrequently: true }); x.drawImage(src, 0, 0, W, H); return x.getImageData(0, 0, W, H).data; })();
    var m = new Uint8ClampedArray(N); for (i = 0; i < N; i++) m[i] = md[i * 4];
    var gm = grow(m, W, H, Math.max(1, Math.round(r || 3)));
    var R = rd.data, clean = new ImageData(W, H), chg = new ImageData(W, H), alone = new ImageData(W, H), solid = 0, gone = 0;
    for (i = 0, j = 0; i < N; i++, j += 4) {
      var a = R[j + 3] / 255, gg = Math.min(1, gm[i] / 255 * 1.5), na = a * gg;
      clean.data[j] = chg.data[j] = R[j]; clean.data[j + 1] = chg.data[j + 1] = R[j + 1]; clean.data[j + 2] = chg.data[j + 2] = R[j + 2];
      clean.data[j + 3] = Math.round(na * 255); chg.data[j + 3] = R[j + 3];
      if (a > 0.5) { solid++; if (na <= 0.5) gone++; }
      if (a > 0.08 && a - na > 0.2) { chg.data[j] = 230; chg.data[j + 1] = 20; chg.data[j + 2] = 20; chg.data[j + 3] = 255; }
      alone.data[j] = sd[j]; alone.data[j + 1] = sd[j + 1]; alone.data[j + 2] = sd[j + 2]; alone.data[j + 3] = m[i];
    }
    var can_ = function (d) { var c = cv(); c.getContext('2d').putImageData(d, 0, 0); return c; };
    return { robot: can_(rd), clean: can_(clean), changes: can_(chg), alone: can_(alone), removedPct: solid ? Math.round(10000 * gone / solid) / 100 : 0 };
  }
  /* kept as small pictures (900 px across at most), as files in memory rather than text: 50 frames x 3 views stay light on a phone */
  var TILE = 900;
  function small(c) {
    return new Promise(function (res) {
      var k = Math.min(1, TILE / c.width), o = c;
      if (k < 1) { o = document.createElement('canvas'); o.width = Math.round(c.width * k); o.height = Math.round(c.height * k);
        var x = o.getContext('2d'); x.imageSmoothingQuality = 'high'; x.drawImage(c, 0, 0, o.width, o.height); }
      if (o.toBlob) o.toBlob(function (b) { res(b ? URL.createObjectURL(b) : o.toDataURL('image/png')); }, 'image/png'); else res(o.toDataURL('image/png'));
    });
  }
  async function makeTry(it) {
    var k = tkey(it); if (S.tmade[k] && S.tmade[k].ok) return S.tmade[k];
    var out = { ok: false };
    try {
      var robot = await pic(it.robot), src = await pic(it.source), mask = await pic(it.mask);
      if (robot.width !== src.width || robot.height !== src.height) throw new Error('the source picture is not the same size as the try-on picture');
      var r = composeTry(robot, src, mask, it.grow);
      out = { ok: true, robot: await small(r.robot), clean: await small(r.clean), changes: await small(r.changes), alone: await small(r.alone), removedPct: r.removedPct };
      try { robot.close && robot.close(); src.close && src.close(); mask.close && mask.close(); } catch (e) {}
    } catch (e) { out = { ok: false, error: e.message || String(e) }; }
    S.tmade[k] = out;
    return out;
  }
  function counts() {
    var c = { robot: 0, ai: 0, same: 0, none: 0 }, items = (S.data && S.data.items) || [];
    items.forEach(function (it) { var v = (S.votes[key(it)] || {}).v; if (c[v] !== undefined) c[v]++; else c.none++; });
    return c;
  }
  function tcounts() {
    var c = { robot: 0, ai: 0, same: 0, none: 0 };
    tlist().forEach(function (it) { var v = (S.votes[tkey(it)] || {}).v; if (c[v] !== undefined) c[v]++; else c.none++; });
    return c;
  }
  function tryHtml(it, i) {
    var k = tkey(it), m = S.tmade[k], v = (S.votes[k] || {}).v, show = S.tshow[k] || '';
    var pc = m && m.ok ? m.removedPct : Number(it.removed) || 0;
    var tile = function (src, cap, which) { return '<figure>' + (src ? '<img src="' + src + '" alt="' + esc(cap) + '" data-aictbig="' + i + '" data-aicwhich="' + which + '">' : '<div class="wait">' + (m && !m.ok ? 'could not open' : 'making…') + '</div>') + '<figcaption>' + esc(cap) + '</figcaption></figure>'; };
    var left = show === 'changes' ? tile(m && m.changes, 'ROBOT — red = what the AI takes away', 'changes') : tile(m && m.robot, 'ROBOT (now)', 'robot');
    var right = show === 'alone' ? tile(m && m.alone, 'AI BY ITSELF (lenses solid)', 'alone') : tile(m && m.clean, 'ROBOT + AI CLEAN-UP', 'clean');
    var may = typeof can !== 'function' || can('tocheck.edit') || can('products.edit');
    return '<div class="aic-item" data-aict="' + i + '"><h4>' + esc(it.name || it.id) + ' <small>· ' + esc(NAMES[it.view] || it.view) + '</small>' +
      '<span class="aic-chg' + (pc >= 0.5 ? ' big' : '') + '">' + (pc > 0 ? 'AI takes away ' + pc + '%' : 'no change — the same') + '</span></h4>' +
      '<div class="aic-row t">' + left + right + '</div>' +
      (m && m.ok ? '<div class="aic-alone"><button type="button" data-aictshow="changes" data-i="' + i + '">' + (show === 'changes' ? 'show the robot’s picture' : 'show what the AI takes away (red)') + '</button> · ' +
        '<button type="button" data-aictshow="alone" data-i="' + i + '">' + (show === 'alone' ? 'show robot + AI clean-up' : 'show the AI by itself') + '</button></div>' : (m && !m.ok ? '<p class="aic-facts">' + esc(m.error) + '</p>' : '')) +
      (may ? '<div class="aic-vote"><button type="button" class="r' + (v === 'robot' ? ' on' : '') + '" data-aictvote="robot" data-i="' + i + '">ROBOT BETTER</button>' +
        '<button type="button" class="s' + (v === 'same' ? ' on' : '') + '" data-aictvote="same" data-i="' + i + '">SAME</button>' +
        '<button type="button" class="a' + (v === 'ai' ? ' on' : '') + '" data-aictvote="ai" data-i="' + i + '">AI CLEAN-UP BETTER</button></div>' : '') + '</div>';
  }
  function drawTry(box) {
    var d = S.data, items = tlist();
    if (!items.length) {
      box.innerHTML = '<div class="aic-note"><b>No try-on AI pictures yet.</b><p>To make them (free): GitHub → <b>vg-cutter</b> → <b>Actions</b> → <b>AI test</b> → <b>Run workflow</b> → in “What to test” pick <b>both</b> or <b>tryon</b> → Run workflow. It takes the newest frames that have try-on pictures. When it shows a green tick, open this page again.</p></div>';
      return;
    }
    var c = tcounts(), done = items.filter(function (it) { return S.tmade[tkey(it)]; }).length, changed = items.filter(function (it) { return (Number(it.removed) || 0) > 0; }).length;
    box.innerHTML = '<div class="aic-note"><b>' + items.length + ' try-on pictures · ' + changed + ' with a change · made ' + esc(d.tryMade ? new Date(d.tryMade).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' }) : '') + '</b>' +
      (d.partial ? '<p style="margin:4px 0 0;color:#B54708"><b>The AI test is still running on GitHub</b> — open this page again later for the rest.</p>' : '') +
      '<p style="margin:4px 0 0"><b>ROBOT</b> = the try-on picture on the website now. <b>ROBOT + AI CLEAN-UP</b> = the same picture, with whatever the free AI sees as <i>not frame</i> taken away (a table reflection, a shadow, a smudge) — the rims and lenses stay as the robot made them. On a skin colour, like on a face. The biggest changes are at the top. Nothing here changes the shop.</p>' +
      '<div class="aic-sum"><span class="r">Robot better: ' + c.robot + '</span><span>Same: ' + c.same + '</span><span class="a">AI clean-up better: ' + c.ai + '</span><span>Not judged: ' + c.none + '</span>' +
      (done < items.length ? '<span>Making ' + (done + 1) + ' of ' + items.length + '…</span>' : '') + '</div></div>' +
      items.map(tryHtml).join('') + '<p id="aicSay" class="aic-facts"></p>';
  }
  function itemHtml(it, i) {
    var k = key(it), m = S.made[k], v = (S.votes[k] || {}).v, alone = !!S.alone[k];
    var tile = function (src, cap, which) { return '<figure>' + (src ? '<img src="' + src + '" alt="' + esc(cap) + '" data-aicbig="' + i + '" data-aicwhich="' + which + '">' : '<div class="wait">' + (m && !m.ok ? 'could not open' : 'making…') + '</div>') + '<figcaption>' + esc(cap) + '</figcaption></figure>'; };
    var may = typeof can !== 'function' || can('tocheck.edit') || can('products.edit');
    return '<div class="aic-item" data-aici="' + i + '"><h4>' + esc(it.name || it.id) + ' <small>· ' + esc(NAMES[it.view] || it.view) + '</small></h4>' +
      '<div class="aic-row">' + tile(m && m.photo, 'PHOTO', 'photo') + tile(m && m.robot, 'ROBOT', 'robot') + tile(m && (alone ? m.aiAlone : m.ai), alone ? 'AI ALONE' : 'AI', 'ai') + '</div>' +
      (m && m.ok ? '<div class="aic-alone"><button type="button" data-aicalone="' + i + '">' + (alone ? 'show AI with the lenses cleaned' : 'show what the AI does alone') + '</button></div>' +
        '<p class="aic-facts">Robot: ' + (m.robotSafe ? (m.rim ? 'top rim ' + m.rim.photoPx + ' px in the photo, ' + m.rim.whitePx + ' px on white' : 'white made') + (m.text ? ' · demo printing wiped' : '') : 'kept the photo as taken') +
        ' · AI took away ' + m.tookPct + '% of what the robot kept around the frame (a shadow — or a part of the frame: look at the picture)</p>' : (m && !m.ok ? '<p class="aic-facts">' + esc(m.error) + '</p>' : '')) +
      (may ? '<div class="aic-vote"><button type="button" class="r' + (v === 'robot' ? ' on' : '') + '" data-aicvote="robot" data-i="' + i + '">ROBOT BETTER</button>' +
        '<button type="button" class="s' + (v === 'same' ? ' on' : '') + '" data-aicvote="same" data-i="' + i + '">SAME</button>' +
        '<button type="button" class="a' + (v === 'ai' ? ' on' : '') + '" data-aicvote="ai" data-i="' + i + '">AI BETTER</button></div>' : '') + '</div>';
  }
  function draw() {
    var box = $('aicBody'); if (!box) return;
    var tabs = $('aicTabs'), title = $('aicTitle');
    if (tabs) tabs.innerHTML = '<button type="button" data-aictab="white" class="' + (S.tab === 'white' ? 'on' : '') + '">WHITE PHOTOS</button><button type="button" data-aictab="tryon" class="' + (S.tab === 'tryon' ? 'on' : '') + '">TRY-ON (front · 30° left · 30° right)</button>';
    if (title) title.textContent = S.tab === 'tryon' ? 'ROBOT vs AI — try-on' : 'ROBOT vs AI — white photos';
    if (S.tab === 'tryon') { drawTry(box); return; }
    var d = S.data, items = (d && d.items) || [];
    if (!items.length) {
      box.innerHTML = '<div class="aic-note"><b>No AI pictures yet.</b><p>To make them (about 10 minutes, free): GitHub → <b>vg-cutter</b> → <b>Actions</b> → <b>AI test</b> → <b>Run workflow</b> → Run workflow. It takes the newest 15 frames. When it shows a green tick, open this page again.</p></div>';
      return;
    }
    var c = counts(), done = items.filter(function (it) { var m = S.made[key(it)]; return m; }).length;
    box.innerHTML = '<div class="aic-note"><b>' + items.length + ' pictures · AI pictures made ' + esc(d.made ? new Date(d.made).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' }) : '') + '</b>' +
      (d.partial ? '<p style="margin:4px 0 0;color:#B54708"><b>The AI test is still running on GitHub</b> — open this page again later for the rest.</p>' : '') +
      '<p style="margin:4px 0 0"><b>ROBOT</b> = our white maker. <b>AI</b> = the free AI decides what is frame; the lenses are cleaned and the demo name wiped by the robot’s rule. Tap a picture to see it big, then tap which looks better. Nothing here changes the shop.</p>' +
      '<div class="aic-sum"><span class="r">Robot better: ' + c.robot + '</span><span>Same: ' + c.same + '</span><span class="a">AI better: ' + c.ai + '</span><span>Not judged: ' + c.none + '</span>' +
      (done < items.length ? '<span>Making ' + (done + 1) + ' of ' + items.length + '…</span>' : '') + '</div></div>' +
      items.map(itemHtml).join('') + '<p id="aicSay" class="aic-facts"></p>';
  }
  async function loadVotes() { try { S.votes = (await g.VGSync.fetchSetting('aivotes')) || {}; if (S.votes.votes) S.votes = S.votes.votes; } catch (e) { S.votes = S.votes || {}; } }
  async function open() {
    addCss();
    var el = $('aic'); if (el) el.remove();
    el = document.createElement('div'); el.id = 'aic'; el.className = 'aic'; el.setAttribute('role', 'dialog');
    el.innerHTML = '<div class="aic-top"><b id="aicTitle">ROBOT vs AI — white photos</b><button type="button" data-aicclose="1">CLOSE</button></div><div class="aic-tabs" id="aicTabs"></div><div class="aic-in" id="aicBody"><div class="aic-note">Loading…</div></div>';
    document.body.appendChild(el);
    try { S.data = g.VGSync && g.VGSync.fetchSetting ? await g.VGSync.fetchSetting('aicompare') : null; } catch (e) { S.data = null; }
    await loadVotes();
    draw();
    pump();
  }
  /* makes the pictures one by one in the background: the open tab first, then the other */
  async function pump() {
    if (S.busy) return; S.busy = true;
    try {
      for (;;) {
        if (!$('aic')) break;
        var w = ((S.data && S.data.items) || []).filter(function (it) { return !S.made[key(it)]; })[0];
        var t = tlist().filter(function (it) { return !S.tmade[tkey(it)]; })[0];
        var first = S.tab === 'tryon' ? (t ? ['t', t] : w ? ['w', w] : null) : (w ? ['w', w] : t ? ['t', t] : null);
        if (!first) break;
        if (first[0] === 'w') await makeOne(first[1]); else await makeTry(first[1]);
        draw(); await new Promise(function (r) { setTimeout(r, 30); });
      }
    } finally { S.busy = false; }
  }
  async function vote(i, v, tryon) {
    var it = tryon ? tlist()[i] : S.data.items[i]; if (!it) return;
    var k = tryon ? tkey(it) : key(it), by = (typeof ME !== 'undefined' && ME && (ME.name || ME.role)) || 'staff';
    var say = $('aicSay');
    try {
      var fresh = (await g.VGSync.fetchSetting('aivotes')) || {}; if (fresh.votes) fresh = fresh.votes;
      fresh[k] = { v: v, by: by, at: new Date().toISOString() };
      var r = await g.VGSync.saveSetting('aivotes', fresh); if (!r || !r.ok) throw new Error('not saved');
      S.votes = fresh;
    } catch (e) { if (say) say.textContent = 'Not saved — check the internet and tap again.'; return; }
    draw();
  }
  document.addEventListener('click', function (e) {
    var t = e.target && e.target.closest ? e.target.closest('[data-aicopen],[data-aicclose],[data-aicvote],[data-aicbig],[data-aicalone],[data-aictab],[data-aictvote],[data-aictshow],[data-aictbig]') : null; if (!t) return;
    if (t.dataset.aictab) { S.tab = t.dataset.aictab === 'tryon' ? 'tryon' : 'white'; draw(); var bx = $('aic'); if (bx) bx.scrollTop = 0; pump(); return; }
    if (t.dataset.aictvote) { vote(Number(t.dataset.i), t.dataset.aictvote, true); return; }
    if (t.dataset.aictshow) { var ti = tlist()[Number(t.dataset.i)]; if (ti) { var tk = tkey(ti); S.tshow[tk] = S.tshow[tk] === t.dataset.aictshow ? '' : t.dataset.aictshow; draw(); } return; }
    if (t.dataset.aictbig) {
      var tt = tlist()[Number(t.dataset.aictbig)], tm = tt && S.tmade[tkey(tt)]; if (!tm || !tm.ok) return;
      var wh = t.dataset.aicwhich, caps = { robot: 'ROBOT (now)', clean: 'ROBOT + AI CLEAN-UP', changes: 'ROBOT — red = what the AI takes away', alone: 'AI BY ITSELF' };
      var bg = document.createElement('div'); bg.className = 'aic-big t'; bg.innerHTML = '<b>' + esc((tt.name || tt.id) + ' · ' + (NAMES[tt.view] || tt.view) + ' · ' + (caps[wh] || wh)) + ' — tap to close</b><img src="' + tm[wh] + '" alt="">';
      bg.addEventListener('click', function () { bg.remove(); }); document.body.appendChild(bg); return; }
    if (t.dataset.aicopen) { e.preventDefault(); open(); return; }
    if (t.dataset.aicclose) { var el = $('aic'); if (el) el.remove(); return; }
    if (t.dataset.aicvote) { vote(Number(t.dataset.i), t.dataset.aicvote); return; }
    if (t.dataset.aicalone) { var it0 = S.data.items[Number(t.dataset.aicalone)]; if (it0) { S.alone[key(it0)] = !S.alone[key(it0)]; draw(); } return; }
    if (t.dataset.aicbig) {
      var it = S.data.items[Number(t.dataset.aicbig)], m = it && S.made[key(it)]; if (!m) return;
      var which = t.dataset.aicwhich, src = which === 'photo' ? m.photo : which === 'robot' ? m.robot : (S.alone[key(it)] ? m.aiAlone : m.ai);
      var big = document.createElement('div'); big.className = 'aic-big'; big.innerHTML = '<b>' + esc((it.name || it.id) + ' · ' + (NAMES[it.view] || it.view) + ' · ' + (which === 'ai' && S.alone[key(it)] ? 'AI ALONE' : which.toUpperCase())) + ' — tap to close</b><img src="' + src + '" alt="">';
      big.addEventListener('click', function () { big.remove(); }); document.body.appendChild(big); }
  });
  g.VGAICompare = { open: open, compose: compose, composeTry: composeTry, state: function () { return S; }, VERSION: 'd17.184' };
})(window);

/* Vision Gallery — the app on a phone (d17.173, shop 22 Oct: "make it an app for mobile, for customers and for Admin;
   a laptop opens the desktop site, a phone opens the app")

   - The website IS the app: the same pages, in their own icon and full screen. A change on the website shows in the app
     at once -- nothing to update.
   - Two apps: "Vision Gallery" (the shop, manifest.json) and "VG Admin" (Admin only, manifest-admin.json).
   - A laptop keeps using the website as now; the install buttons show only on phones and tablets.
   - Android: INSTALL puts the app on the phone (Chrome's own install). iPhone: Apple allows no other way than
     Share -> Add to Home Screen, so the steps are shown.
   - When installed and opened from the icon, the install buttons hide themselves.
   - sw.js: shows the shop's "no internet" page when a page cannot open; nothing else is kept on the phone.

   In a page:  <a data-vg-app href="#">Get the app</a>   (data-vg-app="admin" on the Admin button) */
(function (g) {
  'use strict';
  if (g.VGInstall) return;
  var deferred = null, IS_ADMIN = /\/admin(\.html)?$/.test(location.pathname);

  function standalone() { try { return g.matchMedia('(display-mode: standalone)').matches || g.navigator.standalone === true || document.referrer.indexOf('android-app://') === 0; } catch (e) { return false; } }
  function phone() { try { return g.matchMedia('(pointer: coarse)').matches && Math.min(screen.width, screen.height) <= 900; } catch (e) { return false; } }
  function ios() { var u = navigator.userAgent || ''; return /iPhone|iPad|iPod/i.test(u) || (/Macintosh/.test(u) && 'ontouchend' in document); }
  function inApp() { var u = navigator.userAgent || ''; return /FBAN|FBAV|Instagram|Line\/|WhatsApp|wv\)/i.test(u); }

  /* the helper for the "no internet" page -- registered after the page has opened, never in its way */
  function register() {
    if (!('serviceWorker' in navigator)) return;
    try { if (/[?&]vgtest=1\b/.test(location.search)) return; } catch (e) {}
    /* next to the page: on the live site that is /sw.js for every page (/, /admin, /product ...) */
    var go = function () { navigator.serviceWorker.register(new URL('sw.js', location.href).href).catch(function () {}); };
    if (document.readyState === 'complete') setTimeout(go, 1500); else g.addEventListener('load', function () { setTimeout(go, 1500); }, { once: true });
  }

  g.addEventListener('beforeinstallprompt', function (e) { e.preventDefault(); deferred = e; paint(); });
  g.addEventListener('appinstalled', function () { deferred = null; try { localStorage.setItem('vg_app_installed', IS_ADMIN ? 'admin' : 'shop'); } catch (e) {} paint(); });

  function paint() {
    var show = phone() && !standalone();
    [].forEach.call(document.querySelectorAll('[data-vg-app]'), function (a) { a.hidden = !show; if (!show) a.style.display = 'none'; else a.style.display = ''; });
  }

  function css() {
    if (document.getElementById('vgAppCss')) return;
    var s = document.createElement('style'); s.id = 'vgAppCss';
    s.textContent = '#vgAppBox{position:fixed;inset:0;z-index:9000;background:rgba(6,20,62,.6);display:flex;align-items:flex-end;justify-content:center;font-family:Manrope,system-ui,sans-serif}' +
      '#vgAppBox[hidden]{display:none}#vgAppBox .ab{width:100%;max-width:480px;background:#fff;color:#0F1E3D;border-radius:18px 18px 0 0;padding:20px 18px calc(18px + env(safe-area-inset-bottom,0px));box-shadow:0 -10px 40px rgba(0,0,0,.25)}' +
      '#vgAppBox .ah{display:flex;gap:12px;align-items:center;margin-bottom:12px}#vgAppBox .ah img{width:56px;height:56px;border-radius:14px;background:#EAF1FF;object-fit:contain}' +
      '#vgAppBox .ah b{display:block;font-size:1.08rem}#vgAppBox .ah small{color:#5A6987;font-size:.82rem}' +
      '#vgAppBox ol{margin:6px 0 14px;padding-left:22px;font-size:.95rem;line-height:1.6}#vgAppBox ol b{color:#1741B3}' +
      '#vgAppBox p{margin:4px 0 14px;font-size:.92rem;color:#24324F;line-height:1.5}' +
      '#vgAppBox .ago{display:block;width:100%;padding:15px;border:0;border-radius:12px;background:#C8FF1A;color:#06143E;font-weight:800;font-size:.95rem;letter-spacing:.06em;margin-bottom:10px}' +
      '#vgAppBox .ax{display:block;width:100%;padding:13px;border:1.5px solid #D8E1F0;border-radius:12px;background:#fff;color:#0F1E3D;font-weight:700;font-size:.9rem}';
    document.head.appendChild(s);
  }
  function open(which) {
    css();
    var admin = which === 'admin' || IS_ADMIN;
    var name = admin ? 'VG Admin' : 'Vision Gallery', icon = admin ? '/images/icon-admin-192.png' : '/images/icon-192.png';
    var box = document.getElementById('vgAppBox');
    if (!box) { box = document.createElement('div'); box.id = 'vgAppBox'; box.setAttribute('role', 'dialog'); box.setAttribute('aria-modal', 'true'); document.body.appendChild(box);
      box.addEventListener('click', function (e) { if (e.target === box || (e.target.closest && e.target.closest('.ax'))) box.hidden = true;
        if (e.target.closest && e.target.closest('.ago') && deferred) { var d = deferred; deferred = null; box.hidden = true; d.prompt(); try { d.userChoice.then(function () { paint(); }); } catch (er) {} } }); }
    var body;
    if (deferred) body = '<p>Put <b>' + name + '</b> on your phone, like an app: its own icon, full screen, always up to date.</p><button type="button" class="ago">INSTALL THE APP</button>';
    else if (ios() && inApp()) body = '<p>Open this page in <b>Safari</b> first (tap &middot;&middot;&middot; &rarr; <b>Open in Safari</b>), then:</p><ol><li>Tap <b>Share</b> (the square with the arrow)</li><li>Tap <b>Add to Home Screen</b></li><li>Tap <b>Add</b></li></ol>';
    else if (ios()) body = '<ol><li>Tap <b>Share</b> at the bottom of Safari (the square with the arrow)</li><li>Scroll and tap <b>Add to Home Screen</b></li><li>Tap <b>Add</b> &mdash; ' + name + ' is now on your home screen</li></ol>';
    else if (inApp()) body = '<p>Open this page in <b>Chrome</b> first (tap &#8942; &rarr; <b>Open in Chrome</b>), then tap <b>Get the app</b> again.</p>';
    else body = '<ol><li>Tap <b>&#8942;</b> at the top-right of Chrome</li><li>Tap <b>Install app</b> (or <b>Add to Home screen</b>)</li><li>Tap <b>Install</b> &mdash; ' + name + ' is now on your phone</li></ol>';
    box.innerHTML = '<div class="ab"><div class="ah"><img src="' + icon + '" alt=""><span><b>' + name + ' app</b><small>' + (admin ? 'For Vision Gallery staff' : 'Frames, Try On, 1+1 offers and your orders') + '</small></span></div>' + body + '<button type="button" class="ax">' + (deferred ? 'NOT NOW' : 'CLOSE') + '</button></div>';
    box.hidden = false;
  }
  document.addEventListener('click', function (e) {
    var a = e.target.closest && e.target.closest('[data-vg-app]'); if (!a) return;
    e.preventDefault(); open(a.getAttribute('data-vg-app'));
  });

  g.VGInstall = { open: open, standalone: standalone, phone: phone, ready: function () { return !!deferred; } };
  register();
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', paint); else paint();
})(window);

/* =====================================================================
   VISION GALLERY — CHAT ASSISTANT (d17.158, shop 20 Oct: "train the chat properly")

   How a question is answered, in order:
   1. answers the shop's staff APPROVED in Admin -> CHATBOT (learned from earlier questions)
   2. the shop's own answer list (chat-brain.js) -- offers, branches, timings, warranty, returns, Try On ...
      prices, branches and numbers are filled in live from Admin -> Settings, never typed into an answer
   3. what is on the shelves right now (frames by colour, shape, type)
   4. anything else: smart answers (/api/chat) with the shop's facts -- and the question waits in
      Admin -> CHATBOT -> TO APPROVE so staff can make it part of the list
   If none of that can answer: WhatsApp us / Call us buttons. The chat never ends in a dead end.
   ===================================================================== */
(function () {
  'use strict';
  if (window.VGChat) return;

  const CFG = window.VG_CONFIG || {};
  const NAME = (CFG.shop && CFG.shop.shopName) || 'Vision Gallery';
  const BR = window.VGBrain;
  const DEF = { url: 'https://oscpunukbyosckrmopeh.supabase.co', key: 'sb_publishable_WWAPQTu0lo-X51T4kDlgng_LR39PPkU' };
  function db() { try { const s = JSON.parse(localStorage.getItem('vg_sync') || 'null'); if (s && s.url && s.key) return s; } catch (e) {} return DEF; }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }
  function money(n) { return '₹' + Number(n || 0).toLocaleString('en-IN'); }

  /* ---------- what the chat knows, loaded once when it opens ---------- */
  /* answers the shop used to ship with -- replaced by the trained list, so they are skipped */
  const OLD_DEFAULT = /goregaon|10am to 9pm|10am – 9pm|free home trial|home trial|6 stores|six stores|frames start around|₹900 added|prepar(ation)? time depends/i;
  let BAG = null, FACTS = null, LEARNED = [], OWN = [], CHAT_ON = null;
  const HISTORY = [];
  async function getJSON(path) {
    const d = db();
    const r = await fetch(d.url + path, { headers: { apikey: d.key } });
    return r.ok ? r.json() : null;
  }
  async function loadAll() {
    const jobs = [];
    jobs.push(getJSON('/rest/v1/products?select=data&id=eq.__shop').then(rows => {
      BAG = (rows && rows[0] && rows[0].data) || {};
      FACTS = BR ? BR.facts(BAG) : null;
      /* answers the shop added itself in Admin -> CHATBOT (keywords + answer) */
      OWN = (Array.isArray(BAG.chatbot) ? BAG.chatbot : []).filter(e => e && e.q && e.a && !OLD_DEFAULT.test(e.a));
    }).catch(() => { BAG = {}; FACTS = BR ? BR.facts({}) : null; }));
    jobs.push(getJSON('/rest/v1/chat_learned?select=q,a,qkey&status=eq.approved&order=asks.desc&limit=500')
      .then(rows => { LEARNED = Array.isArray(rows) ? rows : []; }).catch(() => {}));
    jobs.push(fetch('/api/chat?check=1', { cache: 'no-store' }).then(r => r.ok ? r.json() : null)
      .then(j => { CHAT_ON = !!(j && j.configured); }).catch(() => { CHAT_ON = false; }));
    await Promise.all(jobs);
  }
  let LOADING = null;
  function ready() { return LOADING || (LOADING = loadAll()); }

  /* ---------- frames on the shelves ---------- */
  function catalogue() {
    const list = (window.VG_CONFIG && window.VG_CONFIG.products) || [];
    return list.filter(p => p && p.name && p.stock !== false &&
      !(p.qty !== '' && p.qty !== undefined && p.qty !== null && Number(p.qty) <= 0));
  }
  const CAT_WORDS = {
    sunglass: 'sunglasses', sunglasses: 'sunglasses', shades: 'sunglasses', goggle: 'sunglasses', goggles: 'sunglasses',
    frame: 'frames', frames: 'frames', spectacle: 'frames', spectacles: 'frames', specs: 'frames', eyeglasses: 'frames', chashma: 'frames', chasma: 'frames',
    kid: 'kids', kids: 'kids', child: 'kids', children: 'kids',
    branded: 'branded', brand: 'branded'
  };
  const KNOWN_COLOURS = ['black', 'brown', 'blue', 'gold', 'silver', 'grey', 'gray', 'green', 'red', 'pink', 'purple', 'white',
    'tortoise', 'tortoiseshell', 'rose', 'beige', 'maroon', 'orange', 'yellow', 'transparent', 'clear', 'gunmetal', 'bronze', 'navy', 'olive', 'tan'];
  const KNOWN_SHAPES = ['round', 'square', 'rectangle', 'rectangular', 'oval', 'aviator', 'pilot', 'cat eye', 'cateye', 'wayfarer', 'geometric', 'hexagonal', 'butterfly'];
  function oneOnly() { return !(BAG && BAG.shop && BAG.shop.sellSingle === true); }
  function frameLink(p) {
    const bits = [p.colour, p.shape].filter(Boolean).join(', ');
    const price = !oneOnly() && Number(p.price) > 0 ? ' — ' + money(p.price) : '';
    return '<a href="product.html?id=' + encodeURIComponent(p.id || '') + '">' + esc(p.name) + '</a>' + price + (bits ? ' (' + esc(bits) + ')' : '');
  }
  /* only for clear stock questions: "black round frames", "show me sunglasses", "frames under 2000" */
  function fromCatalogue(q) {
    const list = catalogue(); if (!list.length) return null;
    const lower = ' ' + q.toLowerCase().replace(/[^a-z0-9\s₹]/g, ' ') + ' ';
    const words = lower.split(/\s+/).filter(Boolean);
    let cat = null; words.forEach(w => { if (CAT_WORDS[w] && !cat) cat = CAT_WORDS[w]; });
    const askedColour = KNOWN_COLOURS.find(c => lower.indexOf(' ' + c + ' ') !== -1) || null;
    const askedShape = KNOWN_SHAPES.find(sh => lower.indexOf(' ' + sh + ' ') !== -1) || null;
    let m = q.match(/(?:under|below|less than|upto|up to|within|max|budget of|around|about)\s*(?:rs\.?|inr|₹)?\s*([0-9][0-9,]*)\s*(k)?/i);
    const budget = m ? Number(String(m[1]).replace(/,/g, '')) * (m[2] ? 1000 : 1) : null;
    const wantsShow = /\b(show|suggest|recommend|have|any|options?|available|looking for|dikhao|hai kya)\b/.test(lower);
    /* a question about which colour/shape SUITS someone is advice, not stock */
    if (/\b(suit|suits|look good|looks good|achha|accha|skin|face)\b/.test(lower) && !cat) return null;
    if (!askedColour && !askedShape && !budget && !(cat && wantsShow)) return null;
    let hits = list.slice();
    if (cat && cat !== 'frames') hits = hits.filter(p => p.cat === cat);
    if (cat === 'frames') hits = hits.filter(p => !p.cat || p.cat === 'frames' || p.cat === 'branded');
    if (askedColour) hits = hits.filter(p => (p.colour || '').toLowerCase().indexOf(askedColour) >= 0 || (p.colour2 || '').toLowerCase().indexOf(askedColour) >= 0);
    if (askedShape) hits = hits.filter(p => (p.shape || '').toLowerCase().indexOf(askedShape.replace('rectangular', 'rectangle')) >= 0);
    const what = [askedColour, askedShape, cat ? cat.replace('-', ' ') : 'frames'].filter(Boolean).join(' ');
    let head = '';
    if (budget) {
      if (oneOnly()) {
        const from = FACTS && FACTS.sv[0] ? FACTS.sv[0].price : 1500;
        if (budget < from) return 'Every frame comes with our 1+1 offer — two complete pairs (frame + lenses) from ' + money(from) + '. That’s our lowest price.';
        head = 'Every frame comes with our 1+1 offer — two complete pairs from ' + money(from) + '. ';
      } else hits = hits.filter(p => Number(p.price) > 0 && Number(p.price) <= budget);
    }
    if (!hits.length) return 'I don’t have ' + esc(what) + ' listed online right now — we have many more in our shops. WhatsApp us and we’ll send you options. {contact}';
    const show = hits.slice(0, 4);
    return head + (head ? 'Some ' : 'Here are some ') + esc(what) + ' on the website:<br>' + show.map(p => '• ' + frameLink(p)).join('<br>') +
      (hits.length > show.length ? '<br>Plus ' + (hits.length - show.length) + ' more — use the search on the shop page.' : '') +
      '<br><br>Tap a frame, then TRY ON to see it on your face.';
  }

  /* the shop's own extra answers from Admin (keywords + answer) */
  function fromOwn(q) {
    const STOP = { the: 1, a: 1, an: 1, is: 1, are: 1, do: 1, does: 1, i: 1, you: 1, we: 1, my: 1, me: 1, to: 1, of: 1, in: 1, on: 1, for: 1, and: 1, or: 1, can: 1, it: 1, what: 1, how: 1, when: 1, where: 1, with: 1, have: 1, has: 1, be: 1, at: 1, your: 1 };
    const words = q.toLowerCase().replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter(w => w.length > 2 && !STOP[w]);
    if (!words.length) return null;
    let best = null, bestScore = 0;
    OWN.forEach(e => {
      const keys = String(e.q).toLowerCase().split(/\s+/); let s = 0;
      words.forEach(w => { if (keys.some(k => k === w || (k.length > 3 && w.length > 3 && (k.startsWith(w) || w.startsWith(k))))) s += 2; });
      if (s > bestScore) { bestScore = s; best = e; }
    });
    return bestScore >= 4 || (bestScore >= 2 && words.length <= 2) ? best.a : null;
  }

  /* ---------- answering ---------- */
  function format(text) {
    /* plain text from the list or the smart answers -> safe HTML; frame names become links */
    let h = esc(text).replace(/\*\*(.+?)\*\*/g, '<b>$1</b>').replace(/\n/g, '<br>');
    const names = catalogue().filter(p => p.name && String(p.name).length >= 4).sort((a, b) => String(b.name).length - String(a.name).length);
    const done = {};
    names.forEach(p => {
      const n = esc(p.name); if (done[n.toLowerCase()]) return;
      const i = h.indexOf(n); if (i < 0) return;
      done[n.toLowerCase()] = 1;
      h = h.slice(0, i) + '<a href="product.html?id=' + encodeURIComponent(p.id || '') + '">' + n + '</a>' + h.slice(i + n.length);
    });
    return h;
  }
  async function smart(q) {
    try {
      const r = await fetch('/api/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ q, history: HISTORY.slice(-6) }) });
      const j = await r.json().catch(() => null);
      if (r.ok && j && j.ok && j.answer) return { text: j.answer, contact: !!j.contact };
    } catch (e) {}
    return null;
  }
  const FALLBACK = 'I’ll get our team to help you with that. WhatsApp us or call our customer care — we’re available 10am to 10pm, every day.';

  async function answerFor(q) {
    await ready();
    /* 1. approved learned answers */
    if (BR) { const L = LEARNED.find(x => x.a && BR.sameQuestion(q, x.q)); if (L) return { html: format(L.a), via: 'learned' }; }
    /* 2. the trained list (and the shop's own extra answers) */
    if (BR && FACTS) {
      const m = BR.match(q);
      if (m) return { html: format(BR.fill(m.e.a, FACTS)), contact: !!m.e.contact, via: 'list:' + m.e.id };
    }
    const own = fromOwn(q); if (own) return { html: format(own), via: 'own' };
    /* 3. stock */
    let cat = null; try { cat = fromCatalogue(q); } catch (e) {}
    if (cat) return { html: cat.replace(' {contact}', ''), contact: /\{contact\}/.test(cat), via: 'stock' };
    /* 4. smart answers */
    if (CHAT_ON) { const s = await smart(q); if (s) return { html: format(s.text), contact: s.contact, via: 'smart' }; }
    return { html: esc(FALLBACK), contact: true, via: 'fallback' };
  }

  /* ---------- Styles ---------- */
  const css = `
  .vgc-btn{position:fixed;right:20px;bottom:20px;z-index:400;width:58px;height:58px;border-radius:50%;
    background:#2350C8;border:2.5px solid #FFFFFF;cursor:pointer;display:flex;align-items:center;justify-content:center;
    box-shadow:0 0 0 2.5px #C8FF1A,0 0 14px rgba(200,255,26,.65),0 6px 18px rgba(0,0,0,.35);transition:transform .2s ease,background .2s ease;}   /* d17.171: white inside, neon outside (shop, 22 Oct: option B) */
  .vgc-btn:hover{transform:scale(1.06);background:#C8FF1A;}
  .vgc-btn svg{width:27px;height:27px;color:#fff;}
  .vgc-btn:hover svg{color:#06143E;}
  .vgc-btn .vgc-dot{position:absolute;top:2px;right:2px;width:13px;height:13px;border-radius:50%;
    background:#C8FF1A;border:2px solid #fff;}
  .vgc-btn.open .vgc-dot{display:none;}

  .vgc-panel{position:fixed;right:20px;bottom:88px;z-index:400;width:370px;max-width:calc(100vw - 32px);
    height:520px;max-height:calc(100vh - 130px);max-height:calc(100dvh - 130px);background:#fff;border:1px solid #C9D6EA;
    box-shadow:0 16px 50px rgba(10,10,10,.22);display:none;flex-direction:column;overflow:hidden;}
  .vgc-panel.on{display:flex;}

  .vgc-head{background:#2350C8;color:#fff;padding:15px 18px;display:flex;align-items:center;gap:11px;flex-shrink:0;}
  .vgc-head .vgc-av{width:34px;height:34px;border-radius:50%;background:#C8FF1A;display:flex;
    align-items:center;justify-content:center;flex-shrink:0;}
  .vgc-head .vgc-av svg{width:19px;height:19px;color:#06143E;}
  .vgc-head b{font-family:'Unbounded','Manrope',sans-serif;font-size:.86rem;font-weight:600;letter-spacing:.04em;display:block;}
  .vgc-head small{font-size:.71rem;color:#8ED9A8;display:flex;align-items:center;gap:5px;}
  .vgc-head small::before{content:"";width:6px;height:6px;border-radius:50%;background:#25D366;}
  .vgc-head .vgc-x{margin-left:auto;background:none;border:none;color:#B5B0A5;cursor:pointer;
    font-size:1.4rem;line-height:1;padding:0 2px;}
  .vgc-head .vgc-x:hover{color:#fff;}

  .vgc-body{flex:1;overflow-y:auto;padding:18px;background:#EEF2F8;}
  .vgc-msg{margin-bottom:13px;display:flex;}
  .vgc-msg.bot{justify-content:flex-start;}
  .vgc-msg.you{justify-content:flex-end;}
  .vgc-bub{max-width:83%;padding:11px 14px;font-size:.87rem;line-height:1.6;}
  .vgc-msg.bot .vgc-bub{background:#fff;border:1px solid #C9D6EA;color:#1A1A1A;}
  .vgc-msg.you .vgc-bub{background:#2350C8;color:#fff;}
  .vgc-bub a{color:#0B3FA8;text-decoration:underline;}
  .vgc-msg.you .vgc-bub a{color:#C8FF1A;}

  .vgc-chips{display:flex;flex-wrap:wrap;gap:7px;padding:0 18px 14px;background:#EEF2F8;}
  .vgc-chip{background:#fff;border:1px solid #C9D6EA;padding:7px 12px;font-size:.76rem;cursor:pointer;
    font-family:inherit;color:#1A1A1A;transition:border-color .2s ease,background .2s ease;}
  .vgc-chip:hover{border-color:#C8FF1A;background:#F7FBFF;}

  .vgc-foot{border-top:1px solid #C9D6EA;padding:11px;display:flex;gap:8px;background:#fff;flex-shrink:0;}
  .vgc-foot input{flex:1;padding:11px 13px;border:1px solid #C9D6EA;font-family:inherit;font-size:.86rem;
    color:#1A1A1A;}
  .vgc-foot input:focus{outline:none;border-color:#C8FF1A;}
  /* d17.157 (shop, 20 Oct: "where we type is blue, the writing is not clear -- keep it white"): the site's own blue box style
     no longer reaches the chat -- white box, dark writing, grey hint */
  .vgc-panel .vgc-foot input{background:#fff !important;background-color:#fff !important;color:#06143E !important;-webkit-text-fill-color:#06143E;caret-color:#06143E;border:1px solid #C9D6EA !important;}
  .vgc-panel .vgc-foot input::placeholder{color:#6B7A99 !important;-webkit-text-fill-color:#6B7A99;opacity:1;}
  .vgc-panel .vgc-foot input:focus{border-color:#0B3FA8 !important;}
  .vgc-send{background:#C8FF1A;border:none;width:42px;cursor:pointer;display:flex;align-items:center;
    justify-content:center;flex-shrink:0;}
  .vgc-send:hover{background:#B5EB00;}
  .vgc-send svg{width:19px;height:19px;color:#06143E;}

  .vgc-typing{display:flex;gap:4px;padding:13px 15px;}
  .vgc-typing i{width:6px;height:6px;border-radius:50%;background:#C9C4B8;animation:vgcBounce 1.2s infinite;}
  .vgc-typing i:nth-child(2){animation-delay:.15s;}
  .vgc-typing i:nth-child(3){animation-delay:.3s;}
  @keyframes vgcBounce{0%,60%,100%{transform:translateY(0);opacity:.5;}30%{transform:translateY(-5px);opacity:1;}}

  @media (max-width:480px){
    .vgc-panel{right:12px;left:12px;width:auto;bottom:82px;height:calc(100vh - 120px);height:calc(100dvh - 102px);max-height:calc(100dvh - 102px);}
    .vgc-btn{right:14px;bottom:14px;}
  }
  @media (prefers-reduced-motion:reduce){.vgc-typing i{animation:none;}}
  `;

  /* ---------- Markup ---------- */
  const style = document.createElement('style');
  style.textContent = css + `
  .vgc-acts{display:flex;gap:8px;flex-wrap:wrap;margin:-4px 0 13px 0;}
  .vgc-acts a{display:inline-flex;align-items:center;gap:6px;padding:9px 13px;font-size:.78rem;font-weight:800;letter-spacing:.04em;text-decoration:none;border:1px solid #C9D6EA;background:#fff;color:#06143E;}
  .vgc-acts a.wa{background:#25D366;border-color:#25D366;color:#fff;}
  .vgc-acts svg{width:16px;height:16px;}`;
  document.head.appendChild(style);

  const btn = document.createElement('button');
  btn.className = 'vgc-btn';
  btn.setAttribute('aria-label', 'Chat with us');
  btn.innerHTML = `<span class="vgc-dot"></span>
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7">
      <path d="M21 11.5a8.4 8.4 0 01-9 8.4 9.3 9.3 0 01-2.9-.4L3 21l1.6-4.6A8.2 8.2 0 013 11.5 8.4 8.4 0 0112 3a8.4 8.4 0 019 8.5z"/>
      <path d="M8.5 11h.01M12 11h.01M15.5 11h.01"/></svg>`;

  const panel = document.createElement('div');
  panel.className = 'vgc-panel';
  panel.innerHTML = `
    <div class="vgc-head">
      <div class="vgc-av"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <rect x="2" y="9" width="8" height="6.5" rx="3"/><rect x="14" y="9" width="8" height="6.5" rx="3"/><path d="M10 12h4"/></svg></div>
      <div><b>${esc(NAME)} Assistant</b><small>Usually replies instantly</small></div>
      <button class="vgc-x" aria-label="Close chat">&times;</button>
    </div>
    <div class="vgc-body" id="vgcBody"></div>
    <div class="vgc-chips" id="vgcChips"></div>
    <div class="vgc-foot">
      <input type="text" id="vgcInput" placeholder="Ask us anything…" aria-label="Your message" maxlength="400">
      <button class="vgc-send" id="vgcSend" aria-label="Send"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 12l16-8-6 8 6 8-16-8z"/></svg></button>
    </div>`;

  document.body.appendChild(btn);
  document.body.appendChild(panel);

  const body = panel.querySelector('#vgcBody');
  const chips = panel.querySelector('#vgcChips');
  const input = panel.querySelector('#vgcInput');
  const CHIPS = ['Current offers', 'Store timings', 'Free eye test', 'Which frame suits me?', 'Where is my order?'];

  function bubble(html, who) {
    const m = document.createElement('div');
    m.className = 'vgc-msg ' + who;
    m.innerHTML = `<div class="vgc-bub">${html}</div>`;
    body.appendChild(m);
    body.scrollTop = body.scrollHeight;
    return m;
  }
  function contactRow() {
    const c = (window.VGContact && window.VGContact.get()) || null;
    const wa = c ? 'https://wa.me/' + c.wa + '?text=' + encodeURIComponent('Hi ' + NAME + ', I have a question: ') : '#';
    const tel = c ? 'tel:' + c.tel : '#';
    const row = document.createElement('div');
    row.className = 'vgc-acts';
    row.innerHTML = `<a class="wa" href="${esc(wa)}" target="_blank" rel="noopener"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 20l1.3-4A8 8 0 1 1 8 19z"/></svg>WHATSAPP US</a>
      <a class="call" href="${esc(tel)}"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6.6 3.5l3 3-1.8 2.3a12 12 0 0 0 7.4 7.4l2.3-1.8 3 3-2.2 2.6C11 19.5 4.5 13 3.9 5.7z"/></svg>CALL US</a>`;
    body.appendChild(row);
    body.scrollTop = body.scrollHeight;
  }
  function typing() {
    const m = document.createElement('div');
    m.className = 'vgc-msg bot';
    m.innerHTML = `<div class="vgc-bub vgc-typing"><i></i><i></i><i></i></div>`;
    body.appendChild(m);
    body.scrollTop = body.scrollHeight;
    return m;
  }

  let BUSY = false;
  async function reply(q) {
    BUSY = true;
    const t = typing();
    const started = Date.now();
    let a;
    try { a = await answerFor(q); } catch (e) { a = { html: esc(FALLBACK), contact: true, via: 'error' }; }
    const wait = 450 - (Date.now() - started);
    if (wait > 0) await new Promise(r => setTimeout(r, wait));
    t.remove();
    const m = bubble(a.html, 'bot'); m.dataset.via = a.via;
    if (a.contact) contactRow();
    HISTORY.push({ who: 'bot', text: m.textContent.slice(0, 600) });
    try { if (window.vgTrack) window.vgTrack('chat_question', { via: String(a.via).split(':')[0] }); } catch (e) {}
    BUSY = false;
  }

  function send(text) {
    const q = String(text || input.value).trim().slice(0, 400);
    if (!q || BUSY) return;
    bubble(esc(q), 'you');
    HISTORY.push({ who: 'you', text: q });
    input.value = '';
    chips.innerHTML = '';
    reply(q);
  }

  panel.querySelector('#vgcSend').addEventListener('click', () => send());
  input.addEventListener('keydown', e => { if (e.key === 'Enter') send(); });
  chips.addEventListener('click', e => { const c = e.target.closest('.vgc-chip'); if (c) send(c.textContent); });

  let started = false;
  function openChat() {
    panel.classList.add('on');
    btn.classList.add('open');
    ready();
    if (!started) {
      started = true;
      bubble(`Hello! 👋 I'm the ${esc(NAME)} assistant. Ask me about our 1+1 offer, frames, eye tests, Try On, delivery or your order.`, 'bot');
      chips.innerHTML = CHIPS.map(c => `<button class="vgc-chip">${esc(c)}</button>`).join('');
    }
    setTimeout(() => input.focus(), 120);
  }
  function closeChat() {
    panel.classList.remove('on');
    btn.classList.remove('open');
  }

  btn.addEventListener('click', () => panel.classList.contains('on') ? closeChat() : openChat());
  panel.querySelector('.vgc-x').addEventListener('click', closeChat);
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeChat(); });

  /* let other code open it: window.VGChat.open(); tests read VGChat.answerFor */
  window.VGChat = { open: openChat, close: closeChat, answerFor: answerFor, ready: ready };
})();

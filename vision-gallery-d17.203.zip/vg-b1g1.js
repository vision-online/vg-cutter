/* d17.200 (shop 29 Oct): the light sweep on the home page mirror box. Where the light has passed, the next couple shows.
   One sweep every 4.8 s, worked out from the clock (never drifts). Nothing runs while the box is off the screen or the
   tab is hidden; phones set to "reduce motion" just keep the first couple, no sweep. */
(function () {
  var PERIOD = 4800, WIPE = 1800, K = Math.tan(20 * Math.PI / 180);
  var reduce = !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);
  var boxes = [], seen = true, t0 = 0, timer = 0, raf = 0;
  function ease(p) { return p < .5 ? 2 * p * p : 1 - Math.pow(-2 * p + 2, 2) / 2; }
  function clip(im, v) { im.style.clipPath = v; im.style.webkitClipPath = v; }
  function render(t) {
    var cyc = Math.floor(t / PERIOD), ph = t - cyc * PERIOD, sweeping = ph < WIPE && !reduce;
    boxes.forEach(function (s) {
      var n = s.n, cur = reduce ? 0 : ((cyc % n) + n) % n, prev = (cur - 1 + n) % n, W = s.box.clientWidth, H = s.box.clientHeight, bw = s.shine.offsetWidth;
      var L = sweeping ? -0.9 * W + ease(ph / WIPE) * 2.1 * W : -9999;
      s.shine.style.transform = 'translateX(' + L.toFixed(1) + 'px) skewX(-20deg)';
      var pr = s.box.getBoundingClientRect();
      s.sets.forEach(function (set) {
        var r = set.getBoundingClientRect(), bx = r.left - pr.left, by = r.top - pr.top, bh = r.height, imgs = set.children;
        var x = function (y) { return (L + bw / 2 - K * (y - H / 2) - bx).toFixed(1); };
        for (var i = 0; i < imgs.length; i++) {
          var im = imgs[i];
          if (i === cur) { im.style.opacity = 1; im.style.zIndex = 2; clip(im, sweeping ? 'polygon(-4px -4px,' + x(by) + 'px -4px,' + x(by + bh) + 'px ' + (bh + 4) + 'px,-4px ' + (bh + 4) + 'px)' : 'none'); }
          else if (i === prev && sweeping) { im.style.opacity = 1; im.style.zIndex = 1; clip(im, 'none'); }
          else { im.style.opacity = 0; im.style.zIndex = 0; clip(im, 'none'); }
        }
      });
      var shown = sweeping && ease(ph / WIPE) < .5 ? prev : cur;
      s.dots.forEach(function (d, i) { d.classList.toggle('on', i === shown); });
    });
    return sweeping;
  }
  function tick(now) { raf = 0; if (!seen || document.hidden) return; var t = now - t0;
    if (render(t)) raf = requestAnimationFrame(tick); else timer = setTimeout(function () { raf = requestAnimationFrame(tick); }, Math.max(16, PERIOD - (t % PERIOD) - 8)); }
  function wake() { clearTimeout(timer); if (!raf && seen && !document.hidden && !reduce) raf = requestAnimationFrame(tick); }
  function start() {
    document.querySelectorAll('.b1').forEach(function (box) {
      var shine = box.querySelector('.b1-shine'), sets = [].slice.call(box.querySelectorAll('.b1-set'));
      if (!shine || !sets.length) return;
      boxes.push({ box: box, shine: shine, sets: sets, n: sets[0].children.length, dots: [].slice.call(box.querySelectorAll('.b1-dots i')) });
    });
    if (!boxes.length) return;
    window.VGB1 = { renderAt: render, PERIOD: PERIOD, WIPE: WIPE };
    t0 = performance.now() - WIPE - 200; render(WIPE + 200);
    if (reduce || window.VGB1_MANUAL) return;
    if ('IntersectionObserver' in window) new IntersectionObserver(function (es) { seen = es[0].isIntersecting; if (seen) wake(); }).observe(boxes[0].box);
    document.addEventListener('visibilitychange', wake); wake();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();

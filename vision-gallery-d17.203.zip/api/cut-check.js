/* Vision Gallery — SECOND OPINION on a try-on cut-out (d17.183, shop 25 Oct: "let Gemini also watch what the robot is doing")

   Admin sends two small pictures of one view of a frame: the ORIGINAL photo and the FINAL cut-out laid on plain green.
   Google's picture reader (the same Gemini key as the chat) compares them and says whether any part of the frame is missing
   from the cut-out, or anything is left in that is not the frame. It only gives its opinion -- it never changes a picture.
   d17.191: its "good" is one of the checks AUTO-LIVE needs (with the rim, the inside of the lenses, the arms, the colour).

   POST /api/cut-check  { orig: "data:image/jpeg;base64,...", cut: "data:image/jpeg;base64,...", view }   (signed-in staff)
        -> { ok, good, missing, extra }
   Needs GEMINI_KEY in Vercel (already there for the chat). */
'use strict';
const crypto = require('crypto');
const L = require('./_lib.js');

const MODELS = () => [L.env('GEMINI_MODEL'), 'gemini-flash-latest', 'gemini-2.5-flash', 'gemini-flash-lite-latest'].filter((m, i, a) => m && a.indexOf(m) === i);
const SEEN = new Map();
let DAY = '', COUNT = 0;
const VIEW = { front: 'the FRONT view (straight on)', angle: 'a 30-degree view (frame turned, one arm towards the camera)', angleR: 'a 30-degree view (frame turned, one arm towards the camera)' };

/* d17.191 (shop 27 Oct: "the picture reader checks the rim, and inside the demo area too"): on the FRONT the inside of
   the lenses must be clear -- anything left in the glass is reported; a rim thinner or broken against the photo is missing.
   A rimless or half-rim frame keeps a light tint and a thin edge line on its lenses on purpose. */
function prompt(view, kind) {
  const front = view === 'front', clearRim = kind === 'rimless' || kind === 'half';
  return 'You check cut-outs of eyeglass frames for an optical shop. Picture 1 is the ORIGINAL photo of ONE pair of eyeglasses, '
    + (VIEW[view] || 'one view') + '. Picture 2 is the CUT-OUT of the same glasses laid on plain GREEN: green means removed. '
    + 'Compare them carefully and report only clear, real problems: '
    + '(a) MISSING: a part of the frame that is in picture 1 but cut away in picture 2 -- a piece of rim, a rim clearly thinner than in picture 1, the top bar, the bridge, a nose pad, a hinge or end piece, part of an arm, or an arm hollowed out; '
    + '(b) LEFT IN: something in picture 2 that is not the frame -- the sheet or table, a shadow, a reflection outside the frame, a price tag or label hanging from the frame'
    + (front ? '; and INSIDE THE LENSES: anything left in the glass area -- glass that was not removed, printing or a logo on the lens, an arm or hinge seen through the glass, a reflection. The nose pads (and their small metal arms) belong to the frame and must stay. ' : '. ')
    /* d17.197 (shop 28 Oct: "on the front the arms are removed for the try-on -- why is it red?"): the arms are taken off the
       FRONT cut-out on purpose, and the far arm off a 30-degree cut-out; the reader was reporting them as missing */
    + (front ? 'THE ARMS ARE REMOVED ON PURPOSE on this FRONT cut-out: the try-on draws its own arms, so the two arms (temples) are cut away from the end pieces back. Arms missing in picture 2 is RIGHT -- never report the arms as missing. The end pieces (where an arm joins the front) and the hinges on the front must stay. '
             : 'On this 30-degree cut-out the FAR arm (the one going away behind the frame) is removed on purpose, apart from its first few millimetres behind the hinge -- that is right, never report it. The NEAR arm (towards the camera) must be whole. ')
    + (front && clearRim ? 'This is a ' + (kind === 'half' ? 'half-rim' : 'rimless') + ' frame: its lenses are meant to show a very light even tint and a thin light edge line along the lens shape -- that is right, not a problem; only report things left on top of that. ' : '')
    + 'IGNORE: ' + (front ? 'green inside the rims (that is right), the arms (removed on purpose), ' : 'the lenses (they must be removed, so green inside the rims is right), writing on the lenses, ') + 'tiny differences of a few pixels, soft edges. '
    + 'Answer JSON only: {"good": true or false, "missing": "a few plain words, or empty", "extra": "a few plain words, or empty"}. '
    + 'Say where (left lens, right lens, inside the left lens, inside the right lens, top, bottom, bridge, arm). good is true only when nothing is missing and nothing is left in.';
}
function img(dataUrl) {
  const m = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(String(dataUrl || ''));
  if (!m) return null;
  const bytes = Math.floor(m[2].length * 3 / 4);
  if (bytes < 1000 || bytes > 1500000) return null;
  return { mime: m[1], b64: m[2] };
}
async function ask(view, a, b, kind) {
  const body = JSON.stringify({ contents: [{ role: 'user', parts: [{ text: prompt(view, kind) }, { inlineData: { mimeType: a.mime, data: a.b64 } }, { inlineData: { mimeType: b.mime, data: b.b64 } }] }],
    generationConfig: { temperature: 0, maxOutputTokens: 1024, responseMimeType: 'application/json' } });
  let last = 'no answer'; const t0 = Date.now();
  for (const m of MODELS()) {
    if (Date.now() - t0 > 30000) break;
    let r;
    try {
      r = await Promise.race([
        fetch('https://generativelanguage.googleapis.com/v1beta/models/' + encodeURIComponent(m) + ':generateContent', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-goog-api-key': L.env('GEMINI_KEY') }, body }),
        new Promise((_, j) => setTimeout(() => j(new Error('timeout')), 20000))]);
    } catch (e) { last = e.message; continue; }
    let j = null; try { j = await r.json(); } catch (e) {}
    if (r.status === 404 || (r.status === 400 && /not found|not supported/i.test(JSON.stringify(j || '')))) { last = 'model ' + m + ' not available'; continue; }
    if (!r.ok) return { ok: false, why: (j && j.error && j.error.message) || ('error ' + r.status) };
    const c = j && j.candidates && j.candidates[0];
    const text = c && c.content && Array.isArray(c.content.parts) ? c.content.parts.map(p => p.text || '').join('').trim() : '';
    let o = null; try { o = JSON.parse(text.replace(/^```(?:json)?\s*|\s*```$/g, '')); } catch (e) {}
    if (o && typeof o === 'object' && typeof o.good === 'boolean') {
      const clean = s => String(s || '').replace(/\b(?:gemini|google|ai|model)\b/gi, '').replace(/\s+/g, ' ').trim().slice(0, 160);
      const missing = clean(o.missing), extra = clean(o.extra);
      return { ok: true, good: o.good && !missing && !extra, missing, extra };
    }
    last = 'unreadable answer';
  }
  return { ok: false, why: last };
}

module.exports = async (req, res) => {
  const q = L.query(req);
  if (req.method === 'GET' && q.get('check')) return L.send(res, 200, { configured: !!L.env('GEMINI_KEY') });
  if (req.method !== 'POST') return L.send(res, 405, { ok: false });
  if (!L.env('GEMINI_KEY')) return L.send(res, 501, { ok: false, notSetUp: true });
  const who = await L.staffUser(req); if (!who) return L.send(res, 401, { ok: false, error: 'Sign in to Admin first.' });
  const ip = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim() || 'ip';
  const b = await L.body(req);
  const a = img(b && b.orig), c = img(b && b.cut), view = String((b && b.view) || 'front').slice(0, 10);
  const kind = ['full', 'half', 'rimless'].indexOf(String(b && b.kind)) >= 0 ? String(b.kind) : 'full';
  if (!a || !c) return L.send(res, 400, { ok: false, error: 'Two pictures are needed.' });
  const key = crypto.createHash('sha256').update(view + '|' + kind + '|' + a.b64 + '|' + c.b64).digest('hex');
  /* d17.191: the same two pictures asked again get the saved answer -- not counted against the limits */
  if (SEEN.has(key)) return L.send(res, 200, Object.assign({ ok: true, cached: true }, SEEN.get(key)));
  if (L.tooMany('cc:' + ip, 200, 3600e3)) return L.send(res, 429, { ok: false, busy: true });
  const today = new Date().toISOString().slice(0, 10); if (today !== DAY) { DAY = today; COUNT = 0; }
  if (COUNT >= (Number(L.env('CUTCHECK_DAILY_MAX')) || 600)) return L.send(res, 429, { ok: false, busy: true, error: 'Enough checks for today.' });
  COUNT++;
  const r = await ask(view, a, c, kind);
  if (!r.ok) return L.send(res, 502, { ok: false, error: 'The picture reader did not answer. Try again in a minute.' });
  const out = { good: r.good, missing: r.missing, extra: r.extra };
  SEEN.set(key, out); if (SEEN.size > 300) SEEN.clear();
  return L.send(res, 200, Object.assign({ ok: true }, out));
};

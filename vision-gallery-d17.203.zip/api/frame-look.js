/* Vision Gallery — SECOND OPINION on a frame's colour and shape (d17.178, shop 24 Oct)

   Admin's Details box (TO CHECK) asks here with the frame's FRONT photo. Google's picture reader (the same Gemini key as the
   chat) names the main colour, a second colour for two-tone frames, and the shape -- always from the shop's own lists.
   Admin then shows it next to the robot's answer and its own colour measurement: when they agree it is marked green
   ("sure"), when they do not it is marked red ("please check"). Staff always confirm; nothing here is saved by itself.

   POST /api/frame-look  { url }   (signed-in staff only: Bearer token)  ->  { ok, colour, colour2, shape }
   GET  /api/frame-look?check=1                                         ->  { configured }
   Needs GEMINI_KEY in Vercel (already there for the chat). */
'use strict';
const L = require('./_lib.js');

const COLOURS = ['Black', 'Navy', 'Blue', 'Gunmetal', 'Grey', 'Silver', 'Gold', 'Brown', 'Tortoise', 'Amber', 'Red', 'Burgundy', 'Green', 'Purple', 'Pink', 'White',
  'Transparent', 'Transparent blue', 'Transparent purple', 'Transparent grey', 'Transparent brown', 'Transparent pink', 'Transparent green',
  'Light blue', 'Light purple', 'Light pink', 'Light grey', 'Light green', 'Light brown'];
const SHAPES = ['Square', 'Rectangle', 'Round', 'Oval', 'Cat eye', 'Aviator', 'Wayfarer', 'Geometric', 'Browline'];
const MODELS = () => [L.env('GEMINI_MODEL'), 'gemini-flash-latest', 'gemini-2.5-flash', 'gemini-flash-lite-latest'].filter((m, i, a) => m && a.indexOf(m) === i);
const SEEN = new Map();
let DAY = '', COUNT = 0;
const pick = (v, list) => { const s = String(v || '').trim().toLowerCase(); return list.find(x => x.toLowerCase() === s) || ''; };

/* a smaller copy of a Cloudinary photo (enough to judge colour and shape, quick to send) */
function smaller(url) { return /res\.cloudinary\.com\/[^/]+\/image\/upload\//.test(url) ? url.replace('/image/upload/', '/image/upload/w_900,c_limit/') : url; }

const PROMPT = 'This is a shop photo of ONE pair of eyeglass frames lying on a plain sheet. Look ONLY at the frame itself '
  + '(ignore the lenses, any sticker, price tag or printing on the lens, the background and shadows; shiny reflections are not a colour). '
  + 'Answer with JSON only: {"colour": "...", "colour2": "...", "shape": "..."}. '
  + '"colour" = the main colour of the frame front (for a two-tone frame, the colour of the TOP of the rim). '
  + '"colour2" = the second colour ONLY if the frame clearly has two colours (for example a different lower rim); otherwise "". '
  + 'A dark brown and black mottled pattern is "Tortoise". A see-through frame is "Transparent" (or "Transparent blue" etc. if tinted). '
  + '"shape" = the shape of the lens openings. Choose colour and colour2 ONLY from: ' + COLOURS.join(', ') + '. Choose shape ONLY from: ' + SHAPES.join(', ') + '.';

async function ask(b64, mime) {
  const body = JSON.stringify({ contents: [{ role: 'user', parts: [{ text: PROMPT }, { inlineData: { mimeType: mime, data: b64 } }] }],
    generationConfig: { temperature: 0, maxOutputTokens: 1024, responseMimeType: 'application/json' } });
  let last = 'no answer'; const t0 = Date.now();
  for (const m of MODELS()) {
    if (Date.now() - t0 > 30000) break;                                /* stay well inside the function's time */
    let r;
    try {
      r = await Promise.race([
        fetch('https://generativelanguage.googleapis.com/v1beta/models/' + encodeURIComponent(m) + ':generateContent', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-goog-api-key': L.env('GEMINI_KEY') }, body }),
        new Promise((_, j) => setTimeout(() => j(new Error('timeout')), 15000))]);
    } catch (e) { last = e.message; continue; }
    let j = null; try { j = await r.json(); } catch (e) {}
    if (r.status === 404 || (r.status === 400 && /not found|not supported/i.test(JSON.stringify(j || '')))) { last = 'model ' + m + ' not available'; continue; }
    if (!r.ok) return { ok: false, why: (j && j.error && j.error.message) || ('error ' + r.status) };
    const c = j && j.candidates && j.candidates[0];
    const text = c && c.content && Array.isArray(c.content.parts) ? c.content.parts.map(p => p.text || '').join('').trim() : '';
    let o = null; try { o = JSON.parse(text.replace(/^```(?:json)?\s*|\s*```$/g, '')); } catch (e) {}
    if (o && typeof o === 'object') return { ok: true, colour: pick(o.colour, COLOURS), colour2: pick(o.colour2, COLOURS), shape: pick(o.shape, SHAPES), model: m };
    last = 'unreadable answer';
  }
  return { ok: false, why: last };
}

module.exports = async (req, res) => {
  const q = L.query(req);
  if (req.method === 'GET' && q.get('check')) return L.send(res, 200, { configured: !!L.env('GEMINI_KEY') });
  if (req.method !== 'POST') return L.send(res, 405, { ok: false });
  if (!L.env('GEMINI_KEY')) return L.send(res, 501, { ok: false, notSetUp: true });
  const who = await L.staffUser(req); if (!who) return L.send(res, 401, { ok: false, error: 'Sign in to Admin first.' });
  const ip = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim() || 'ip';
  if (L.tooMany('fl:' + ip, 120, 3600e3)) return L.send(res, 429, { ok: false, busy: true });
  const today = new Date().toISOString().slice(0, 10); if (today !== DAY) { DAY = today; COUNT = 0; }
  if (COUNT >= (Number(L.env('LOOK_DAILY_MAX')) || 600)) return L.send(res, 429, { ok: false, busy: true, error: 'Enough checks for today.' });
  const b = await L.body(req), url = String((b && b.url) || '');
  if (!/^https:\/\/res\.cloudinary\.com\//.test(url)) return L.send(res, 400, { ok: false, error: 'Only the shop’s own photos can be checked.' });
  if (SEEN.has(url)) return L.send(res, 200, Object.assign({ ok: true, cached: true }, SEEN.get(url)));
  let img;
  try {
    const r = await Promise.race([fetch(smaller(url)), new Promise((_, j) => setTimeout(() => j(new Error('timeout')), 12000))]);
    if (!r.ok) return L.send(res, 502, { ok: false, error: 'The photo could not be read (' + r.status + ').' });
    const buf = Buffer.from(await r.arrayBuffer()); if (buf.length > 6e6) return L.send(res, 413, { ok: false, error: 'Photo too big.' });
    img = { b64: buf.toString('base64'), mime: (r.headers.get('content-type') || 'image/jpeg').split(';')[0] };
  } catch (e) { return L.send(res, 502, { ok: false, error: 'The photo could not be read.' }); }
  COUNT++;
  const a = await ask(img.b64, /^image\//.test(img.mime) ? img.mime : 'image/jpeg');
  if (!a.ok) return L.send(res, 502, { ok: false, error: 'The picture reader did not answer. Try again in a minute.' });
  const out = { colour: a.colour, colour2: a.colour2, shape: a.shape };
  SEEN.set(url, out); if (SEEN.size > 500) SEEN.clear();
  return L.send(res, 200, Object.assign({ ok: true }, out));
};
module.exports.COLOURS = COLOURS; module.exports.SHAPES = SHAPES;

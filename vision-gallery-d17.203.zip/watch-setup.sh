#!/bin/bash
# Vision Gallery: switch on the 5-minute website watchman on this computer (d17.166, 22 Oct 2026)
# Every 5 minutes this computer:
#  1. opens https://visiongallery.me/api/watch -- the website then checks its own pages and the problems customers'
#     phones reported, and WhatsApps the alert number (Admin -> Settings -> Contact numbers);
#  2. opens the home page itself -- if the website does not answer at all (twice in a row), this computer sends the
#     alert straight from the WhatsApp sender, and "answering again" when it is back.
# Nothing secret is in this file: the key is typed in once and kept only on this computer (~/vg-watch.conf).
echo "Vision Gallery watchman setup"
NODE=$(command -v node)
if [ -z "$NODE" ]; then echo "node is not on this computer -- tell your website support. Nothing changed."; exit 1; fi
if ! command -v crontab >/dev/null; then
  echo "Installing the timer (cron)..."
  sudo apt-get update -qq >/dev/null 2>&1; sudo apt-get install -y -qq cron >/dev/null 2>&1
  if ! command -v crontab >/dev/null; then echo "The timer (cron) could not be installed -- tell your website support. Nothing changed."; exit 1; fi
fi
read -r -p "Paste the WhatsApp sender key (the same as SENDER_KEY in Vercel): " K
read -r -p "Your mobile number for alerts if the whole website is down (10 digits): " N
N=$(printf '%s' "$N" | tr -cd '0-9'); N=${N: -10}
if [ ${#N} -ne 10 ]; then echo "Please type a 10-digit mobile number. Nothing changed."; exit 1; fi
if [ -z "$K" ]; then echo "The key is empty. Nothing changed."; exit 1; fi
umask 077
KQ=$("$NODE" -e 'process.stdout.write(encodeURIComponent(process.argv[1]))' "$K")
R=$(curl -s -m 90 -w '\n%{http_code}' "https://visiongallery.me/api/watch?key=$KQ"); C=$(printf '%s' "$R" | tail -n 1)
if [ "$C" = "403" ]; then echo "WRONG KEY: the key is not the same as SENDER_KEY in Vercel. Nothing changed -- paste the line again with the right key."; exit 1; fi
printf 'K=%q\nN=%q\nNODE=%q\n' "$K" "91$N" "$NODE" > "$HOME/vg-watch.conf"
cat > "$HOME/vg-watch.sh" <<'EOS'
#!/bin/bash
# Vision Gallery watchman -- runs every 5 minutes (crontab). Settings in ~/vg-watch.conf
export PATH="$PATH:/usr/local/bin:/usr/bin:/bin"
. "$HOME/vg-watch.conf"
[ -x "$NODE" ] || NODE=$(command -v node)
KQ=$("$NODE" -e 'process.stdout.write(encodeURIComponent(process.argv[1]))' "$K")
when() { TZ=Asia/Kolkata date '+%d %b %H:%M'; }
send() {
  local T="$1" Q B
  Q=$("$NODE" -e 'process.stdout.write(encodeURIComponent(process.argv[1]))' "$T")
  B=$("$NODE" -e 'process.stdout.write(JSON.stringify({phone:process.argv[1],number:process.argv[1],text:process.argv[2],message:process.argv[2]}))' "$N" "$T")
  curl -s -m 20 -X POST -H 'Content-Type: application/json' -H "x-key: $K" -d "$B" "http://localhost:3000/send?key=$KQ&phone=$N&to=$N&text=$Q" >/dev/null
}
# down = no answer at all (000) or a server failure (5xx, except 501 "not set up"). 403 / 404 / 501 mean it answered.
isdown() { case "$1" in 000) return 0 ;; 501) return 1 ;; 5??) return 0 ;; *) return 1 ;; esac; }
# track <state file> <answer code> <message when down> <message when back>: tells once after 2 bad looks, and once when back
track() {
  local S="$1" C="$2" n
  if isdown "$C"; then
    n=$(( $(cat "$S" 2>/dev/null || echo 0) + 1 )); echo "$n" > "$S"
    if [ "$n" -eq 2 ]; then send "$3 (error $C) -- checked twice, 5 minutes apart ($(when))."; fi
  elif [ -f "$S" ]; then
    if [ "$(cat "$S")" -ge 2 ]; then send "$4 ($(when))."; fi
    rm -f "$S"
  fi
}
A=$(curl -s -m 90 -o /dev/null -w '%{http_code}' "https://visiongallery.me/api/watch?key=$KQ")
H=$(curl -s -m 30 -o /dev/null -w '%{http_code}' -A 'VG-watchman' "https://visiongallery.me/")
track "$HOME/.vg-watch.down" "$H" "⚠️ visiongallery.me is NOT answering. Customers cannot open the website. Check vercel.com, or send this to your website support" "✅ visiongallery.me is answering again"
if ! isdown "$H"; then
  track "$HOME/.vg-watch.api" "$A" "⚠️ visiongallery.me opens, but its server part is failing (My Orders, chat and these alerts may not work). Check vercel.com, or send this to your website support" "✅ The website's server part is working again"
fi
EOS
chmod 700 "$HOME/vg-watch.sh"
( crontab -l 2>/dev/null | grep -v 'vg-watch.sh'; echo "*/5 * * * * /bin/bash $HOME/vg-watch.sh" ) | crontab -
if ! crontab -l 2>/dev/null | grep -q 'vg-watch.sh'; then echo "The 5-minute timer could not be set -- tell your website support."; exit 1; fi
if [ "$C" = "200" ]; then echo "WATCH-OK: the watchman looks at the website every 5 minutes from now on."
  if printf '%s' "$R" | grep -q '"notes":false'; then echo "BUT: SUPABASE_SERVICE_KEY is not working in Vercel yet -- until it is added (and the site redeployed) only a fully-down website is alerted."; fi
else echo "Switched on, but the website answered $C. 404 = upload the latest website zip first. 501 = SENDER_KEY is missing in Vercel. 000 = no answer (check the internet / the website)."; fi

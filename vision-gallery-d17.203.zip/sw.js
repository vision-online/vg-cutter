/* Vision Gallery app helper (d17.173, shop 22 Oct: "make it an app for mobile -- customers and Admin").
   It does ONE thing: when a page cannot be opened because the phone has no internet, it shows the shop's
   "no internet" page instead of the browser's error. Everything else goes to the website exactly as before --
   nothing is stored on the phone, so a new upload is always seen at once. */
var KEEP = 'vg-offline-1', PAGE = new URL('offline.html', self.location).href;
self.addEventListener('install', function (e) {
  e.waitUntil(caches.open(KEEP).then(function (c) { return c.add(new Request(PAGE, { cache: 'reload' })); }).catch(function () {}));
  self.skipWaiting();
});
self.addEventListener('activate', function (e) {
  e.waitUntil(caches.keys().then(function (ks) { return Promise.all(ks.filter(function (k) { return k !== KEEP; }).map(function (k) { return caches.delete(k); })); })
    .then(function () { return self.clients.claim(); }));
});
self.addEventListener('fetch', function (e) {
  if (e.request.mode !== 'navigate' || e.request.method !== 'GET') return;          /* pictures, programs, data: untouched */
  e.respondWith(fetch(e.request).catch(function () { return caches.match(PAGE).then(function (r) { return r || Response.error(); }); }));
});

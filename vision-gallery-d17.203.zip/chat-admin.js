/* Vision Gallery Admin — CHATBOT: answers waiting for approval (d17.158, shop 20 Oct)

   "Staff only approve them -- staff must not have to write the answer again."
   Every question the shop's own list could not answer was answered by the smart answers and waits here with that
   answer already written. APPROVE (one tap) -> from then on the chat answers it from the shop's own list.
   EDIT the words first if needed. REJECT -> never used, never asked again.
   Questions about one customer's order, number or power never arrive here. */
(function (g) {
  'use strict';
  var DEF = { url: 'https://oscpunukbyosckrmopeh.supabase.co', key: 'sb_publishable_WWAPQTu0lo-X51T4kDlgng_LR39PPkU' };
  function cfg() { try { var s = JSON.parse(localStorage.getItem('vg_sync') || 'null'); if (s && s.url && s.key) return s; } catch (e) {} return DEF; }
  function isJwt(k) { return /^eyJ/.test(String(k || '')); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function $(id) { return document.getElementById(id); }
  function allowed(p) { try { return typeof can === 'function' ? can(p) : true; } catch (e) { return true; } }
  function me() { try { return (typeof ME !== 'undefined' && ME && ME.name) || 'staff'; } catch (e) { return 'staff'; } }
  function say(t) { try { if (typeof toast === 'function') toast(t); } catch (e) {} }

  async function sb(path, opts) {
    opts = opts || {}; var c = cfg();
    var h = { apikey: c.key, 'Content-Type': 'application/json' };
    var t = null; try { t = g.VGAuth ? await g.VGAuth.token() : null; } catch (e) {}
    if (t) h.Authorization = 'Bearer ' + t; else if (isJwt(c.key)) h.Authorization = 'Bearer ' + c.key;
    if (opts.prefer) h.Prefer = opts.prefer;
    var r = await fetch(c.url + path, { method: opts.method || 'GET', headers: h, body: opts.body, cache: 'no-store' });
    var b = null; try { b = await r.json(); } catch (e) {}
    return { ok: r.ok, status: r.status, body: b };
  }

  var S = { rows: [], state: '', smart: null, open: {} };

  function mount() {
    var panel = $('panel-chatbot'); if (!panel || $('chatLearn')) return;
    var box = document.createElement('div');
    box.id = 'chatLearn';
    box.innerHTML = '<style>' +
      '#chatLearn .cl-card{border:1px solid var(--line,#D8DEE8);background:#fff;padding:14px;margin:0 0 12px}' +
      '#chatLearn .cl-q{font-weight:800;font-size:1rem;margin:0 0 4px;color:#06143E}' +
      '#chatLearn .cl-meta{font-size:.76rem;color:#5A6987;margin:0 0 8px}' +
      '#chatLearn textarea{width:100%;min-height:96px;font:inherit;font-size:.9rem;padding:10px;border:1px solid #C9D6EA;background:#fff;color:#06143E;box-sizing:border-box}' +
      '#chatLearn .cl-acts{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px}' +
      '#chatLearn .cl-warn{display:inline-block;background:#FEF0C7;color:#7A4A00;font-size:.74rem;font-weight:700;padding:3px 8px;margin:0 0 8px}' +
      '#chatLearn .cl-state{padding:12px 14px;margin:0 0 12px;font-size:.88rem;border-left:4px solid #0B3FA8;background:#EEF4FF;color:#06143E}' +
      '#chatLearn .cl-state.warn{border-left-color:#B54708;background:#FFF6E5}' +
      '#chatLearn .cl-a{white-space:pre-wrap;font-size:.88rem;color:#1A1A1A;margin:4px 0 0}' +
      '#chatLearn .cl-count{display:inline-block;min-width:22px;text-align:center;background:#06143E;color:#C8FF1A;font-weight:800;border-radius:11px;padding:1px 7px;margin-left:6px;font-size:.78rem}' +
      '</style>' +
      '<div class="notice"><b>Your chat assistant already knows your shop.</b> Offers and prices (always the ones in Settings), your branches and timings, free eye test, ' +
      'warranty, 7-day return, the 30-day progressive guarantee, ready times, delivery, payment, Try On and My Orders. ' +
      'Questions it could not answer from that are answered by the smart answers and wait below: <b>APPROVE</b> and the chat answers them itself from then on.</div>' +
      '<div id="clState"></div>' +
      '<div class="card"><div class="card-head"><h2>To approve <span class="cl-count" id="clPendN">0</span></h2><small>Most-asked first. The answer is already written &mdash; check it, change a word if needed, approve.</small></div>' +
      '<div class="card-body" id="clPending"><p class="hint">Loading&hellip;</p></div></div>' +
      '<div class="card"><div class="card-head"><h2>Approved answers <span class="cl-count" id="clAppN">0</span></h2><small>The chat answers these itself. Edit or remove any time.</small></div>' +
      '<div class="card-body" id="clApproved"><p class="hint">Loading&hellip;</p></div></div>';
    panel.insertBefore(box, panel.firstChild);
    box.addEventListener('click', onClick);
  }

  function badge(n) {
    var b = $('chatBadge'); if (!b) return;
    b.textContent = n; b.hidden = !n;
  }

  async function load() {
    mount();
    var r;
    try { r = await sb('/rest/v1/chat_learned?select=id,q,a,status,asks,updated_at,by&status=in.(pending,approved)&order=asks.desc,updated_at.desc&limit=300'); }
    catch (e) { S.state = 'offline'; render(); return; }
    if (r.status === 404 || (r.body && r.body.code === 'PGRST205')) { S.state = 'setup'; S.rows = []; }
    else if (!r.ok) { S.state = 'error:' + ((r.body && (r.body.message || r.body.hint)) || r.status); S.rows = []; }
    else { S.state = 'ok'; S.rows = Array.isArray(r.body) ? r.body : []; }
    try { var c = await fetch('/api/chat?check=1', { cache: 'no-store' }); S.smart = c.ok ? !!(await c.json()).configured : false; } catch (e) { S.smart = false; }
    render();
  }

  function render() {
    mount();
    var st = $('clState'); if (!st) return;
    var msgs = [];
    if (S.state === 'setup') msgs.push('<div class="cl-state warn"><b>One-time setup needed.</b> Open <b>HEALTH</b> &rarr; &ldquo;One-time database setup&rdquo; &rarr; COPY THE SETUP &rarr; run it in Supabase. Then come back here.</div>');
    else if (/^error/.test(S.state)) msgs.push('<div class="cl-state warn">Could not read the answers: ' + esc(S.state.slice(6)) + '</div>');
    else if (S.state === 'offline') msgs.push('<div class="cl-state warn">No internet &mdash; try again in a moment.</div>');
    if (S.smart === false) msgs.push('<div class="cl-state warn"><b>Smart answers are not switched on yet.</b> The chat still answers everything in its own list; other questions get your WhatsApp / Call buttons. ' +
      'To switch them on, add <b>GEMINI_KEY</b> in Vercel &rarr; Settings &rarr; Environment Variables (see the setup steps).</div>');
    else if (S.smart === true) msgs.push('<div class="cl-state">Smart answers are <b>on</b>.</div>');
    st.innerHTML = msgs.join('');

    var pend = S.rows.filter(function (x) { return x.status === 'pending'; });
    var app = S.rows.filter(function (x) { return x.status === 'approved'; });
    $('clPendN').textContent = pend.length; $('clAppN').textContent = app.length; badge(pend.length);
    var canEdit = allowed('chatbot.edit'), canDel = allowed('chatbot.delete');
    $('clPending').innerHTML = pend.length ? pend.map(function (x) {
      var price = /₹|\brs\.?\s?\d|\binr\b/i.test(x.a);
      return '<div class="cl-card" data-id="' + esc(x.id) + '">' +
        '<p class="cl-q">&ldquo;' + esc(x.q) + '&rdquo;</p>' +
        '<p class="cl-meta">Asked ' + (Number(x.asks) || 1) + (Number(x.asks) === 1 ? ' time' : ' times') + '</p>' +
        (price ? '<span class="cl-warn">Has a price in it &mdash; check it matches Settings</span>' : '') +
        '<textarea class="cl-text"' + (canEdit ? '' : ' disabled') + '>' + esc(x.a) + '</textarea>' +
        '<div class="cl-acts">' + (canEdit ? '<button type="button" class="btn btn-gold btn-sm" data-cl="approve">APPROVE</button>' : '') +
        (canDel ? '<button type="button" class="btn btn-line btn-sm" data-cl="reject">REJECT</button>' : '') + '</div></div>';
    }).join('') : '<p class="hint">' + (S.state === 'ok' ? 'Nothing waiting. New questions appear here as customers ask them.' : '&mdash;') + '</p>';
    $('clApproved').innerHTML = app.length ? app.map(function (x) {
      var open = S.open[x.id];
      return '<div class="cl-card" data-id="' + esc(x.id) + '">' +
        '<p class="cl-q">&ldquo;' + esc(x.q) + '&rdquo;</p>' +
        '<p class="cl-meta">Asked ' + (Number(x.asks) || 1) + (Number(x.asks) === 1 ? ' time' : ' times') + (x.by ? ' &middot; approved by ' + esc(x.by) : '') + '</p>' +
        (open ? '<textarea class="cl-text">' + esc(x.a) + '</textarea>' : '<p class="cl-a">' + esc(x.a) + '</p>') +
        '<div class="cl-acts">' + (canEdit ? (open ? '<button type="button" class="btn btn-gold btn-sm" data-cl="save">SAVE</button>' : '<button type="button" class="btn btn-line btn-sm" data-cl="edit">EDIT</button>') : '') +
        (canDel ? '<button type="button" class="btn btn-danger btn-sm" data-cl="remove">REMOVE</button>' : '') + '</div></div>';
    }).join('') : '<p class="hint">' + (S.state === 'ok' ? 'None yet.' : '&mdash;') + '</p>';
  }

  async function patch(id, data) {
    data.updated_at = new Date().toISOString();
    return sb('/rest/v1/chat_learned?id=eq.' + encodeURIComponent(id), { method: 'PATCH', prefer: 'return=minimal', body: JSON.stringify(data) });
  }
  async function onClick(e) {
    var b = e.target.closest('[data-cl]'); if (!b) return;
    var card = b.closest('.cl-card'), id = card && card.getAttribute('data-id'); if (!id) return;
    var row = S.rows.find(function (x) { return String(x.id) === id; }); if (!row) return;
    var act = b.getAttribute('data-cl'), ta = card.querySelector('.cl-text');
    if (act === 'edit') { S.open[id] = 1; render(); return; }
    if ((act === 'approve' || act === 'save') && !allowed('chatbot.edit')) return;
    if ((act === 'reject' || act === 'remove') && !allowed('chatbot.delete')) return;
    var text = ta ? ta.value.trim() : row.a;
    if ((act === 'approve' || act === 'save') && !text) { alert('The answer is empty.'); return; }
    if (act === 'remove' && !confirm('Remove this answer? The chat will stop using it.')) return;
    b.disabled = true;
    var data = act === 'approve' ? { status: 'approved', a: text, by: me() }
      : act === 'save' ? { a: text, by: me() }
      : { status: 'rejected' };
    var r = await patch(id, data).catch(function () { return { ok: false }; });
    if (!r.ok) { b.disabled = false; alert('Could not save — check the internet and try again.'); return; }
    Object.assign(row, data); delete S.open[id];
    if (data.status === 'rejected') S.rows = S.rows.filter(function (x) { return x !== row; });
    render();
    say(act === 'approve' ? 'Approved — the chat answers this itself now' : act === 'save' ? 'Saved' : act === 'reject' ? 'Rejected' : 'Removed');
  }

  g.VGChatAdmin = { load: load, render: render, state: function () { return S; } };
  /* refresh when CHATBOT opens, and every few minutes for the badge */
  document.addEventListener('click', function (e) { if (e.target.closest && e.target.closest('.tab[data-tab="chatbot"]')) load(); });
  function first() { if (g.VGAuth && g.VGAuth.signedIn && g.VGAuth.signedIn()) load(); }
  setTimeout(first, 2500); setInterval(first, 5 * 60 * 1000);
})(window);

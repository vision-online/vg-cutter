/* Vision Gallery Admin — VISITORS (d17.165, shop 22 Oct)

   "Three buttons: the visitors, the recordings, and where they come from (WhatsApp, Meta ad...)" -- they open the
   shop's PostHog pages; nothing extra runs on the website for customers.
   "Make a link": WhatsApp messages carry no "came from", so each place gets its own link
   (visiongallery.me/?utm_source=whatsapp ...) and PostHog counts the visits per place. */
(function (g) {
  'use strict';
  function $(id) { return document.getElementById(id); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function set() { try { return typeof SET !== 'undefined' ? SET : {}; } catch (e) { return {}; } }
  function say(t) { try { if (typeof toast === 'function') toast(t); } catch (e) {} }

  var SOURCES = [
    { id: 'whatsapp', name: 'WhatsApp', medium: 'messaging', hint: 'WhatsApp messages, status and broadcast lists' },
    { id: 'meta', name: 'Meta ad', medium: 'paid_social', hint: 'paid ads on Facebook / Instagram' },
    { id: 'instagram', name: 'Instagram', medium: 'social', hint: 'Instagram bio, posts and stories' },
    { id: 'facebook', name: 'Facebook', medium: 'social', hint: 'Facebook page and posts' },
    { id: 'google', name: 'Google', medium: 'local', hint: 'your Google Business profile' },
    { id: 'youtube', name: 'YouTube', medium: 'social', hint: 'YouTube videos and channel' },
    { id: 'qr', name: 'Shop QR / poster', medium: 'offline', hint: 'a QR code printed in the shop or on a bill' }
  ];
  var PAGES = [
    { v: '', name: 'Home page' },
    { v: 'order.html', name: 'Checkout (choose lenses)' },
    { v: 'prescription.html', name: 'Eye test / prescription' },
    { v: 'account.html', name: 'My Orders' }
  ];

  function base() {
    var S = set(), host = S.posthogHost === 'eu' ? 'https://eu.posthog.com' : 'https://us.posthog.com';
    var id = String(S.posthogProject || '').replace(/\D/g, '');
    return id ? host + '/project/' + id : host;
  }
  function site() { return /^https?:\/\/(localhost|127\.)/.test(location.origin) ? 'https://visiongallery.me' : location.origin; }
  function slug(s) { return String(s || '').toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40); }
  function makeLink() {
    var src = SOURCES.find(function (x) { return x.id === ($('vzSrc') && $('vzSrc').value); }) || SOURCES[0];
    var page = ($('vzPage') && $('vzPage').value) || '';
    var camp = slug($('vzCamp') && $('vzCamp').value);
    var q = 'utm_source=' + src.id + '&utm_medium=' + src.medium + (camp ? '&utm_campaign=' + camp : '');
    return site() + '/' + page + '?' + q;
  }

  function mount() {
    if ($('vzBtn')) return;
    var view = document.querySelector('header .hdr-right a[href="index.html"]');
    if (!view) return;
    var b = document.createElement('button');
    b.type = 'button'; b.id = 'vzBtn'; b.className = 'btn btn-ghost-light btn-sm'; b.textContent = 'VISITORS';
    view.parentNode.insertBefore(b, view);
    var m = document.createElement('div');
    m.id = 'vzModal'; m.hidden = true;
    m.innerHTML = '<style>' +
      '#vzModal{position:fixed;inset:0;z-index:600;background:rgba(6,20,62,.55);display:flex;align-items:flex-start;justify-content:center;overflow:auto;padding:24px 12px}' +
      '#vzModal[hidden]{display:none}' +
      '#vzModal .vz-box{background:#fff;color:#06143E;width:100%;max-width:520px;border-radius:14px;padding:18px 16px 20px;box-shadow:0 20px 60px rgba(0,0,0,.3)}' +
      '#vzModal h3{margin:0 0 4px;font-size:1.15rem}#vzModal .vz-sub{margin:0 0 14px;color:#5A6987;font-size:.84rem}' +
      '#vzModal .vz-go{display:flex;align-items:center;gap:12px;width:100%;box-sizing:border-box;text-decoration:none;color:#06143E;border:1px solid #D8DEE8;border-radius:12px;padding:12px 14px;margin:0 0 10px;background:#F7FAFF}' +
      '#vzModal .vz-go>span>b{display:block;font-size:.98rem;letter-spacing:.04em}#vzModal .vz-go small b{font-weight:700}#vzModal .vz-go small{display:block;color:#5A6987;font-size:.78rem;margin-top:2px}' +
      '#vzModal .vz-go i{font-style:normal;font-size:1.5rem;width:30px;text-align:center}' +
      '#vzModal .vz-sec{border-top:1px dashed #D8DEE8;margin-top:16px;padding-top:14px}' +
      '#vzModal label{display:block;font-size:.76rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:#5A6987;margin:10px 0 4px}' +
      '#vzModal select,#vzModal input{width:100%;box-sizing:border-box;font:inherit;font-size:.95rem;padding:10px;border:1px solid #C9D6EA;border-radius:8px;background:#fff;color:#06143E}' +
      '#vzModal .vz-link{margin:12px 0 0;padding:10px 12px;border-radius:8px;background:#EEF4FF;font:600 .86rem ui-monospace,Menlo,Consolas,monospace;word-break:break-all;color:#0B3FA8}' +
      '#vzModal .vz-acts{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px}#vzModal .vz-close{float:right;border:0;background:none;font-size:1.6rem;line-height:1;color:#5A6987;cursor:pointer}' +
      '#vzModal .vz-warn{background:#FFF6E5;border-left:4px solid #B54708;padding:10px 12px;font-size:.86rem;margin:0 0 12px}' +
      '</style><div class="vz-box" role="dialog" aria-modal="true" aria-label="Visitors">' +
      '<button type="button" class="vz-close" data-vz="close" aria-label="Close">&times;</button>' +
      '<h3>Visitors</h3><p class="vz-sub">Opens your PostHog. Sign in there once with your Google account.</p>' +
      '<div id="vzWarn"></div>' +
      '<a class="vz-go" id="vzWeb" target="_blank" rel="noopener"><i>&#128202;</i><span><b>VISITORS</b><small>How many came today / this week, top pages and frames, phone or computer, city</small></span></a>' +
      '<a class="vz-go" id="vzRec" target="_blank" rel="noopener"><i>&#9654;&#65039;</i><span><b>RECORDINGS</b><small>Watch each visit: where they scrolled, which frame, Try On, where they left (typed details hidden)</small></span></a>' +
      '<a class="vz-go" id="vzFrom" target="_blank" rel="noopener"><i>&#129517;</i><span><b>WHERE FROM</b><small>WhatsApp, Meta ad, Instagram, Google&hellip; &mdash; scroll to <b>Channels</b> and <b>UTM source</b></small></span></a>' +
      '<div class="vz-sec"><h3>Make a link</h3><p class="vz-sub">Use a different link in each place, so PostHog can tell you how many came from each. Customers see your normal page.</p>' +
      '<label for="vzSrc">Where will you post it?</label><select id="vzSrc">' + SOURCES.map(function (s) { return '<option value="' + s.id + '">' + esc(s.name) + ' &mdash; ' + esc(s.hint) + '</option>'; }).join('') + '</select>' +
      '<label for="vzPage">Which page should it open?</label><select id="vzPage">' + PAGES.map(function (p) { return '<option value="' + p.v + '">' + esc(p.name) + '</option>'; }).join('') + '</select>' +
      '<label for="vzCamp">Name of this ad or message (optional)</label><input id="vzCamp" type="text" maxlength="40" placeholder="e.g. 1+1 offer Diwali" autocomplete="off">' +
      '<div class="vz-link" id="vzLink"></div>' +
      '<div class="vz-acts"><button type="button" class="btn btn-gold btn-sm" data-vz="copy">COPY LINK</button>' +
      '<a class="btn btn-wa btn-sm" id="vzShare" target="_blank" rel="noopener">SHARE ON WHATSAPP</a></div>' +
      '<p class="vz-sub" id="vzSays" style="margin-top:10px"></p></div></div>';
    document.body.appendChild(m);
    b.addEventListener('click', open);
    m.addEventListener('click', function (e) {
      if (e.target === m || (e.target.closest && e.target.closest('[data-vz="close"]'))) { m.hidden = true; return; }
      if (e.target.closest && e.target.closest('[data-vz="copy"]')) copy(makeLink());
    });
    m.addEventListener('input', paint); m.addEventListener('change', paint);
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') m.hidden = true; });
  }
  function paint() {
    var link = makeLink(), src = SOURCES.find(function (x) { return x.id === $('vzSrc').value; }) || SOURCES[0];
    $('vzLink').textContent = link;
    $('vzShare').href = 'https://wa.me/?text=' + encodeURIComponent(link);
    var camp = slug($('vzCamp').value);
    $('vzSays').innerHTML = 'In PostHog these visits show as <b>' + esc(src.id) + '</b>' + (camp ? ', campaign <b>' + esc(camp) + '</b>' : '') + '.';
  }
  function open() {
    var S = set(), B = base();
    $('vzWeb').href = B + '/web'; $('vzRec').href = B + '/replay'; $('vzFrom').href = B + '/web';
    $('vzWarn').innerHTML = !S.posthogKey ? '<div class="vz-warn">Visitor counting is switched off. Settings &rarr; Visitor analytics: paste your PostHog key (phc_&hellip;) and SAVE.</div>'
      : (!S.posthogProject ? '<div class="vz-warn">Tip: add your PostHog project number in Settings &rarr; Visitor analytics, so these buttons open your project directly.</div>' : '');
    paint();
    $('vzModal').hidden = false;
  }
  function copy(t) {
    var done = function () { say('Link copied'); var c = document.querySelector('[data-vz="copy"]'); if (c) { c.textContent = 'COPIED ✓'; setTimeout(function () { c.textContent = 'COPY LINK'; }, 1800); } };
    try { if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(t).then(done, fb); return; } } catch (e) {}
    fb();
    function fb() { var ta = document.createElement('textarea'); ta.value = t; ta.style.position = 'fixed'; ta.style.opacity = '0'; document.body.appendChild(ta); ta.select(); try { document.execCommand('copy'); } catch (e) {} ta.remove(); done(); }
  }

  g.VGVisitors = { mount: mount, open: open, makeLink: makeLink, base: base };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mount); else mount();
})(window);

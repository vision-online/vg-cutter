/* =====================================================================
   Vision Gallery — "on a face" image generator

   Glasses photographed on a white background do not sell. A customer
   cannot tell how big a frame is, how it sits, or whether it suits
   anyone. Every large eyewear site shows the frame being worn, and
   that is most of why their listings convert better.

   Photographing every frame on a model is not realistic when you carry
   25,000 of them. So instead: photograph the frame once on white, and
   composite it onto a small set of model faces automatically.

   The face photos are yours. Staff, or customers who have given
   written permission. Do not use pictures taken from another
   company's website - that is their property, and a competitor will
   notice.
   ===================================================================== */

(function (global) {
  'use strict';

  /* ---- cut the frame out of a white-background photo -------------- */

  function cutout(img, opts){
    /* ALREADY CUT OUT (d16.30). When the picture arrives with a
       transparent background -- a PNG cut in Colab by RMBG-2.0 or
       BiRefNet -- there is nothing to decide and nothing to touch. It
       is copied straight through: no flood, no lens pass, no trim. The
       shop's rule, finally exact: the frame is the photograph. */
    if (opts && opts.alreadyCut){
      const t0 = document.createElement('canvas'); t0.width = img.naturalWidth || img.width; t0.height = img.naturalHeight || img.height;
      const x0 = t0.getContext('2d'); x0.drawImage(img, 0, 0);
      /* trim the fully clear border so the frame fills the canvas, and find the two lens openings for placement */
      const d0 = x0.getImageData(0, 0, t0.width, t0.height), q0 = d0.data;
      let x1 = t0.width, x2 = -1, y1 = t0.height, y2 = -1;
      for (let i = 3, n = 0; i < q0.length; i += 4, n++){
        if (q0[i] < 16) continue;
        const px = n % t0.width, py = (n - px) / t0.width;
        if (px < x1) x1 = px; if (px > x2) x2 = px; if (py < y1) y1 = py; if (py > y2) y2 = py;
      }
      if (x2 < x1 || y2 < y1) return null;
      const W2 = x2 - x1 + 1, H2 = y2 - y1 + 1;
      const c2 = document.createElement('canvas'); c2.width = W2; c2.height = H2;
      c2.getContext('2d').drawImage(t0, x1, y1, W2, H2, 0, 0, W2, H2);
      /* the lens openings are the clear regions INSIDE the frame: flood the clear pixels from the border, what is left and clear is a lens */
      const d2 = c2.getContext('2d').getImageData(0, 0, W2, H2), q2 = d2.data, N2 = W2 * H2;
      const outside = new Uint8Array(N2), st2 = [];
      for (let x = 0; x < W2; x++){ st2.push(x); st2.push((H2-1)*W2 + x); }
      for (let y = 0; y < H2; y++){ st2.push(y*W2); st2.push(y*W2 + W2-1); }
      /* a supra / rimless demo carries the shop's light tint (about 17%): it is lens, so up to ~23% counts as clear here
         (3 Oct 2026; at 16 a tinted demo was never found and its lenses were guessed) */
      const CLR = 60;
      while (st2.length){ const i = st2.pop(); if (outside[i] || q2[i*4+3] >= CLR) continue; outside[i] = 1;
        const px = i % W2, py = (i - px) / W2;
        if (px > 0) st2.push(i-1); if (px < W2-1) st2.push(i+1); if (py > 0) st2.push(i-W2); if (py < H2-1) st2.push(i+W2); }
      const seen2 = new Uint8Array(N2), found = [];
      for (let s0 = 0; s0 < N2; s0++){
        if (seen2[s0] || outside[s0] || q2[s0*4+3] >= CLR) continue;
        const st3 = [s0]; seen2[s0] = 1; let cnt = 0, ax1 = W2, ax2 = 0, ay1 = H2, ay2 = 0; const rowsMin = new Map(), rowsMax = new Map(), colsMin = new Map(), colsMax = new Map();
        while (st3.length){ const i = st3.pop(); cnt++;
          const px = i % W2, py = (i - px) / W2;
          if (!rowsMin.has(py) || px < rowsMin.get(py)) rowsMin.set(py, px); if (!rowsMax.has(py) || px > rowsMax.get(py)) rowsMax.set(py, px);
          if (!colsMin.has(px) || py < colsMin.get(px)) colsMin.set(px, py); if (!colsMax.has(px) || py > colsMax.get(px)) colsMax.set(px, py);
          if (px < ax1) ax1 = px; if (px > ax2) ax2 = px; if (py < ay1) ay1 = py; if (py > ay2) ay2 = py;
          const nbs = []; if (px > 0) nbs.push(i-1); if (px < W2-1) nbs.push(i+1); if (py > 0) nbs.push(i-W2); if (py < H2-1) nbs.push(i+W2);
          for (const nq of nbs){ if (!seen2[nq] && !outside[nq] && q2[nq*4+3] < CLR){ seen2[nq] = 1; st3.push(nq); } } }
        if (cnt > N2 * 0.01) found.push({ x:(ax1+ax2)/2/W2, y:(ay1+ay2)/2/H2, w:(ax2-ax1+1)/W2, h:(ay2-ay1+1)/H2, cx:(ax1+ax2)/2/W2, cy:(ay1+ay2)/2/H2, _rowsMin: rowsMin, _rowsMax: rowsMax, _colsMin: colsMin, _colsMax: colsMax, _px: [ax1, ax2, ay1, ay2] });
      }
      found.sort((a,b) => b.w*b.h - a.w*a.h);
      /* d17.89 THE HINGES, measured: the height of the end pieces at the frame's two outer edges (fraction of the picture) */
      const hingeY = (xa, xb) => { let sy = 0, n = 0; for (let x = xa; x <= xb; x++) for (let y = 0; y < H2; y++) if (q2[(y * W2 + x) * 4 + 3] > 110){ sy += y; n++; } return n ? sy / n / H2 : null; };
      /* and how TALL the hinge piece is there (the arm continues from it at exactly that height) */
      const hingeH = (xa, xb) => { const hs = []; for (let x = xa; x <= xb; x++){ let n = 0; for (let y = 0; y < H2; y++) if (q2[(y * W2 + x) * 4 + 3] > 110) n++; if (n) hs.push(n); } hs.sort((a, b) => a - b); return hs.length ? hs[hs.length >> 1] / H2 : null; };
      const eW = Math.max(2, Math.round(W2 * 0.025));
      /* and the hinge piece's exact TOP and BOTTOM edges there (the arm's own top and bottom edges continue from these) */
      const hingeTB = (xa, xb) => { const ts = [], bs = []; for (let x = xa; x <= xb; x++){ let t = -1, b = -1; for (let y = 0; y < H2; y++) if (q2[(y * W2 + x) * 4 + 3] > 110){ if (t < 0) t = y; b = y; } if (t >= 0){ ts.push(t); bs.push(b); } }
        ts.sort((a, b) => a - b); bs.sort((a, b) => a - b); return ts.length ? [ts[Math.floor(ts.length * 0.1)] / H2, (bs[bs.length >> 1] + 1) / H2] : null; };   /* top: the corner's highest point */
      const tbL = hingeTB(0, eW), tbR = hingeTB(W2 - 1 - eW, W2 - 1);
      c2.hinges = { yL: hingeY(0, eW), yR: hingeY(W2 - 1 - eW, W2 - 1), hL: hingeH(0, eW), hR: hingeH(W2 - 1 - eW, W2 - 1), tbL, tbR };
      /* d17.89 ARM PIECES SEEN THROUGH THE LENS (shop, 8 Oct: "why the black dot on the hinge side in the demo?"): in the studio
         photo the opened arms show through the demo just inside the rim, next to each hinge. Worn, they run back along the
         head and are never seen through the lens. On a FULL-RIM frame anything inside a lens on its HINGE half is cleared --
         the nose pads, on the other half, stay; supra and rimless frames (their hinge is mounted on the lens) are left alone. */
      if (opts.fullRim && found.length >= 2){
        const two = found.slice(0, 2).sort((a, b) => a.x - b.x);
        let cleared = 0;
        /* SAFETY: how far each pixel is from the frame's OUTER edge (the clear background around it), and how thick the rim
           is (measured at the middle of each lens's outer side). Nothing within the rim's own thickness is ever cleared, so
           the rim can never be eaten -- only what sits INSIDE the rim, in the lens. */
        const dist = new Float32Array(N2);
        /* distance from the outside; the picture's own edge counts as outside too (a rim touching the edge of the picture) */
        const chamfer = isOut => {
          for (let y = 0; y < H2; y++) for (let x = 0; x < W2; x++){ const i = y * W2 + x; dist[i] = isOut(i, x, y) ? 0 : ((x === 0 || y === 0 || x === W2 - 1 || y === H2 - 1) ? 1 : 1e9); }
          for (let y = 0; y < H2; y++) for (let x = 0; x < W2; x++){ const i = y * W2 + x; let v = dist[i];
            if (x > 0) v = Math.min(v, dist[i - 1] + 1); if (y > 0){ v = Math.min(v, dist[i - W2] + 1); if (x > 0) v = Math.min(v, dist[i - W2 - 1] + 1.414); if (x < W2 - 1) v = Math.min(v, dist[i - W2 + 1] + 1.414); } dist[i] = v; }
          for (let y = H2 - 1; y >= 0; y--) for (let x = W2 - 1; x >= 0; x--){ const i = y * W2 + x; let v = dist[i];
            if (x < W2 - 1) v = Math.min(v, dist[i + 1] + 1); if (y < H2 - 1){ v = Math.min(v, dist[i + W2] + 1); if (x < W2 - 1) v = Math.min(v, dist[i + W2 + 1] + 1.414); if (x > 0) v = Math.min(v, dist[i + W2 - 1] + 1.414); } dist[i] = v; }
        };
        chamfer(i => outside[i]);
        const rimT = two.map((L, li) => { const [ax1, ax2, ay1, ay2] = L._px, Hl = ay2 - ay1 + 1, v = [];
          for (let y = Math.round(ay1 + 0.4 * Hl); y <= Math.round(ay1 + 0.6 * Hl); y++){ const xo = li === 0 ? L._rowsMin.get(y) : L._rowsMax.get(y); if (xo != null){ const xr = xo + (li === 0 ? -1 : 1); if (xr >= 0 && xr < W2) v.push(dist[y * W2 + xr]); } }
          v.sort((a, b) => a - b); return v.length ? v[v.length >> 1] : 1e9; });
        /* again, with the END PIECES counted as outside too (everything beyond each lens's rim, towards the hinge): the rim
           where the hinge joins it is then measured as rim, not as something deep inside the frame */
        const xL = two[0]._px[0] - rimT[0] - 1, xR = two[1]._px[1] + rimT[1] + 1;
        if (isFinite(xL) && isFinite(xR)) chamfer((i, x) => outside[i] || x < xL || x > xR);
        const notRim = (j, li) => dist[(j - 3) >> 2] > rimT[li] + Math.max(3, rimT[li] * 0.15) + 2;      /* j = alpha index; a margin beyond the rim */
        two.forEach((L, li) => {
          /* the inside of the lens = the convex outline of its clear opening (bridges over the dent the arm piece makes) */
          const pts = []; L._rowsMin.forEach((x, y) => pts.push([x, y])); L._rowsMax.forEach((x, y) => pts.push([x, y]));
          pts.sort((p, q) => p[0] - q[0] || p[1] - q[1]);
          const cr = (o, a, b) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
          const lo = [], up = [];
          for (const p of pts){ while (lo.length >= 2 && cr(lo[lo.length - 2], lo[lo.length - 1], p) <= 0) lo.pop(); lo.push(p); }
          for (let i = pts.length - 1; i >= 0; i--){ const p = pts[i]; while (up.length >= 2 && cr(up[up.length - 2], up[up.length - 1], p) <= 0) up.pop(); up.push(p); }
          const hull = lo.slice(0, -1).concat(up.slice(0, -1));
          const [ax1, ax2, ay1, ay2] = L._px, mid = (ax1 + ax2) / 2, outerLeft = li === 0;
          for (let y = ay1 + 2; y <= ay2 - 2; y++){
            /* the hull's span on this row */
            let xa = Infinity, xb = -Infinity;
            for (let k = 0; k < hull.length; k++){ const p = hull[k], q = hull[(k + 1) % hull.length];
              if ((p[1] <= y && q[1] >= y) || (q[1] <= y && p[1] >= y)){ const X = p[1] === q[1] ? Math.min(p[0], q[0]) : p[0] + (y - p[1]) * (q[0] - p[0]) / (q[1] - p[1]);
                const X2 = p[1] === q[1] ? Math.max(p[0], q[0]) : X; if (X < xa) xa = X; if (X2 > xb) xb = X2; } }
            if (!isFinite(xa)) continue;
            const from = outerLeft ? Math.ceil(xa + 2) : Math.ceil(mid + (ax2 - ax1) * 0.06), to = outerLeft ? Math.floor(mid - (ax2 - ax1) * 0.06) : Math.floor(xb - 2);
            for (let x = from; x <= to; x++){ const j = (y * W2 + x) * 4 + 3; if (q2[j] >= CLR && notRim(j, li)){ q2[j] = 0; cleared++; } }
          }
        });
        /* 2nd look (thick acetate rims): an arm piece pressed against the rim fills in the lens's OUTER TOP corner, where the
           outline alone cannot tell it from the rim. The lens's straight edges (top, outer side, bottom) are measured, and
           the top-outer corner compared with the bottom-outer corner: a corner filled in at the top but not at the bottom
           is an arm piece. A round lens rounds both corners alike, so it is never touched. */
        const fitLine = pts => { const n = pts.length; if (n < 6) return null; let sx = 0, sy = 0, sxx = 0, sxy = 0; pts.forEach(([u, v]) => { sx += u; sy += v; sxx += u * u; sxy += u * v; });
          const den = n * sxx - sx * sx; if (!den) return null; const b = (n * sxy - sx * sy) / den; return { a: (sy - b * sx) / n, b }; };
        two.forEach((L, li) => {
          const [ax1, ax2, ay1, ay2] = L._px, Wl = ax2 - ax1 + 1, Hl = ay2 - ay1 + 1, out = li === 0 ? -1 : 1;
          const sidePts = [], topPts = [], botPts = [];
          for (let y = Math.round(ay1 + 0.38 * Hl); y <= Math.round(ay1 + 0.72 * Hl); y++){ const v = out < 0 ? L._rowsMin.get(y) : L._rowsMax.get(y); if (v != null) sidePts.push([y, v]); }
          for (let x = Math.round(ax1 + 0.3 * Wl); x <= Math.round(ax1 + 0.7 * Wl); x++){ const t = L._colsMin.get(x), b = L._colsMax.get(x); if (t != null) topPts.push([x, t]); if (b != null) botPts.push([x, b]); }
          const SL = fitLine(sidePts), TL = fitLine(topPts), BL = fitLine(botPts); if (!SL || !TL || !BL) return;
          const sideX = y => SL.a + SL.b * y, topY = x => TL.a + TL.b * x, botY = x => BL.a + BL.b * x;
          /* the corner's fill, row by row: how far in from the outer edge line the clear lens starts */
          const fill = y => { const v = out < 0 ? L._rowsMin.get(y) : L._rowsMax.get(y); return v == null ? null : Math.max(0, out < 0 ? v - sideX(y) : sideX(y) - v); };
          const D = Math.round(0.5 * Hl), prof = { t: [], b: [] };
          for (let d = 1; d <= D; d++){
            const yt = Math.round(topY(sideX(ay1)) + d), yb = Math.round(botY(sideX(ay2)) - d);
            prof.t[d] = { y: yt, e: fill(yt) }; prof.b[d] = { y: yb, e: fill(yb) };
          }
          /* the top corner may be filled as much as the bottom corner (its template), plus a small margin */
          const cut = []; let excess = 0;
          for (let d = 2; d <= D; d++){
            const T = prof.t[d], B = prof.b[d]; if (!T || T.e == null || !B || B.e == null) continue;
            const allow = B.e * 1.15 + 3;
            if (T.e > allow){ excess += T.e - allow;
              const sx = sideX(T.y);
              for (let k = Math.ceil(allow); k < T.e; k++){ const x = Math.round(sx - out * k); if (x >= 0 && x < W2){ const jj = (T.y * W2 + x) * 4 + 3; if (q2[jj] >= CLR && notRim(jj, li)) cut.push(jj); } } }
          }
          (c2.armCornerInfo = c2.armCornerInfo || []).push({ lens: li, excess: Math.round(excess), px: cut.length, rimT: +rimT[li].toFixed(1), W: Wl, H: Hl });
          if (excess > 0.0025 * Wl * Hl && cut.length){ cut.forEach(jj => { q2[jj] = 0; }); cleared += cut.length; }
        });
        if (cleared){ c2.getContext('2d').putImageData(d2, 0, 0); c2.armsInLensCleared = cleared; }
      }
      found.forEach(L => { delete L._rowsMin; delete L._rowsMax; delete L._colsMin; delete L._colsMax; delete L._px; delete L._corner; });
      if (found.length >= 2){ c2.lenses = found.slice(0,2).sort((a,b)=>a.x-b.x); }
      else { c2.lensesEstimated = true; c2.lenses = [{x:0.27,y:0.5,w:0.36,h:0.7},{x:0.73,y:0.5,w:0.36,h:0.7}]; }
      c2.alreadyCut = true;
      return c2;
    }
    opts = opts || {};
    const maxW = 1400;
    const s = Math.min(1, maxW / img.naturalWidth);
    const W = Math.round(img.naturalWidth * s), H = Math.round(img.naturalHeight * s);
    const c = document.createElement('canvas'); c.width = W; c.height = H;
    const x = c.getContext('2d');
    x.drawImage(img, 0, 0, W, H);
    const d = x.getImageData(0, 0, W, H);
    const p = d.data;

    // Background is the light surround. Flood from the edges so a dark
    // background object doesn't get mistaken for part of the frame.
    const thresh = opts.threshold || 150;
    /* SIMPLE MODE (d16.30, the shop's rule, 13 Sep): the sheet becomes
       transparent -- behind the frame and seen through the lenses --
       the front is cut corner to corner so no arm reaches the face,
       and the arm seen through the lens is covered (row-span, bounded
       by the opening itself); the sheet's own shadow strip under the
       rim counts as sheet. Nothing else. The rim is the photograph,
       pixel for pixel. What that means for the photo: it
       must be shot level at lens height so the arms hide behind the
       front, on a flat sheet with no shadow line. The full set of
       rules is still here behind {simple:false}. */
    const simple = opts.simple !== false;

    /* MEASURE THE BACKGROUND INSTEAD OF ASSUMING IT.

       The flood removed anything brighter than a fixed 150. That is
       right for a frame on white, and wrong for a crystal frame on
       grey: measured across the rim of a TOPTIME crystal on a 181 grey
       sheet, the rim reads 170, 153, 159, 139, 114, 100, 112, 121,
       133, 144, 166 -- every value BELOW the background, so the rim is
       perfectly distinguishable, and the fixed threshold threw away
       everything from 153 upward. Only 8.8% of the frame survived.

       When the border of the picture is genuinely uniform -- a proper
       sheet, not a shop counter -- the background colour can be
       measured and only pixels close to it removed. That keeps a
       crystal rim at 166 while still clearing a sheet at 181.

       Guarded: if the border is NOT uniform, this falls back to the
       fixed threshold. A previous attempt at background matching was
       reverted for swallowing half a frame; it had no uniformity test
       and too loose a tolerance. Both are here now. */
    let bgLum = -1;
    const bgTol = opts.bgTolerance == null ? 9 : opts.bgTolerance;
    {
      const edge = [];
      const step = Math.max(1, Math.round(W / 200));
      for (let i = 0; i < W; i += step){
        for (const yy of [1, H-2]){
          const i4 = ((yy*W)+i)*4;
          edge.push(p[i4]*0.299 + p[i4+1]*0.587 + p[i4+2]*0.114);
        }
      }
      for (let j = 0; j < H; j += step){
        for (const xx of [1, W-2]){
          const i4 = ((j*W)+xx)*4;
          edge.push(p[i4]*0.299 + p[i4+1]*0.587 + p[i4+2]*0.114);
        }
      }
      if (edge.length > 20){
        edge.sort((a,b)=>a-b);
        const med = edge[edge.length>>1];
        const lo  = edge[Math.floor(edge.length*0.05)];
        const hi  = edge[Math.floor(edge.length*0.95)];
        /* uniform enough to trust, and pale enough to be a backdrop.
           OPT-IN since d16.11: on by default it ate the bottom rim of a
           blue frame on the shop's counter photo (a shiny rim catching
           light sits within a few levels of the sheet and was removed
           with it). The rim must never be touched, so the fixed rule is
           the default again; pass {matchBackground:true} to use this. */
        if (opts.matchBackground === true && hi - lo <= 14 && med >= thresh - 40) bgLum = med;
      }
    }

    /* GREEN SHEET (d16.30). A grey sheet asks the cutter to tell grey
       sheet from grey shadow from grey highlight, and it never quite
       can: every wrong cut this month was a grey-on-grey call. A
       chroma-key green sheet ends that argument -- background is
       green, frame is not; a highlight is white, a shadow is dark
       green, and both are still decided correctly by HUE. No frame is
       chroma-key green. The lens shows green through the glass, so it
       becomes clear without any row-span or sliver logic at all.
       Detected from the border ring: if the border is green, every
       pale/background test below becomes an is-green test. Grey sheets
       keep working exactly as before. */
    let greenSheet = false;
    {
      let n = 0, hit = 0;
      const step = Math.max(1, Math.round(W / 200));
      const test = q => { const i4 = q*4, r0=p[i4], g0=p[i4+1], b0=p[i4+2]; n++; if (g0 > 70 && g0 > r0*1.25 && g0 > b0*1.25) hit++; };
      for (let i = 0; i < W; i += step){ test(i + W); test((H-2)*W + i); }
      for (let j = 0; j < H; j += step){ test(j*W + 1); test(j*W + W-2); }
      greenSheet = n > 20 && hit / n >= 0.85;
    }
    /* ANY BACKGROUND THAT CHANGES SLOWLY (d16.30). The shop's photo had
       a grey wall behind and a white table under the frame, with soft
       shadows on the table -- three different greys, and the old rule
       refused it. The background is now found by GROWING from the
       border: a neighbour joins the background when its colour is
       within 12 levels of the pixel it grew from (a sheet, a wall, a
       shadow all change slowly), it is neutral (chroma <= 30) and it is
       not dark (a floor of 90, or 70 below the border's own brightness).
       A rim is a sharp step of far more than 12 levels, so the growth
       stops at it. The dark floor is what keeps a black frame's own
       smooth surface from being walked into. */
    let bgFloor = 90;
    {
      const ring = [];
      const step = Math.max(1, Math.round(W / 200));
      const grab = q => { const i4 = q*4; ring.push(p[i4]*0.299 + p[i4+1]*0.587 + p[i4+2]*0.114); };
      for (let i = 0; i < W; i += step){ grab(i + W); grab((H-2)*W + i); }
      for (let j = 0; j < H; j += step){ grab(j*W + 1); grab(j*W + W-2); }
      if (ring.length > 20){ ring.sort((a,b)=>a-b); bgFloor = Math.max(90, ring[ring.length>>1] - 70); }
    }
    const GROW = opts.growStep == null ? 12 : opts.growStep;
    /* can this pixel be background at all? EITHER chroma-key green by
       hue OR light and neutral -- always both (d16.30). The shop shot a
       folded frame on a green cloth with a grey piece tucked behind the
       front: green outside, grey through the lenses. Green-only refused
       it; grey-only refused it. Both count now, in any photo, whether or
       not the border is green. (The growth rule still stops at a rim.) */
    const isGreen = (r0, g0, b0) => { const m = Math.max(r0, b0); return g0 > 40 && g0 - m > Math.max(18, 0.22 * g0); };
    const isSheet = (r0, g0, b0) => {
      if (isGreen(r0, g0, b0)) return true;
      const lum = (r0*0.299 + g0*0.587 + b0*0.114);
      const chroma = Math.max(r0,g0,b0) - Math.min(r0,g0,b0);
      return chroma <= 30 && lum >= bgFloor;
    };
    const bg = new Uint8Array(W * H);
    const stack = [];
    for (let i = 0; i < W; i++){ stack.push(i); stack.push((H-1)*W + i); }
    for (let j = 0; j < H; j++){ stack.push(j*W); stack.push(j*W + W-1); }
    const visited = new Uint8Array(W * H);
    const near = (a, b) => {
      if (isGreen(p[a*4], p[a*4+1], p[a*4+2]) || isGreen(p[b*4], p[b*4+1], p[b*4+2])) return true;   /* green needs no step test; and green may meet the grey piece */
      return Math.abs(p[a*4] - p[b*4]) <= GROW && Math.abs(p[a*4+1] - p[b*4+1]) <= GROW && Math.abs(p[a*4+2] - p[b*4+2]) <= GROW;
    };
    while (stack.length){
      const q = stack.pop();
      if (visited[q]) continue;
      visited[q] = 1;
      const i4 = q*4;
      if (!isSheet(p[i4], p[i4+1], p[i4+2])) continue;
      bg[q] = 1;
      const px = q % W, py = (q - px) / W;
      if (px > 0   && !visited[q-1] && near(q, q-1)) stack.push(q-1);
      if (px < W-1 && !visited[q+1] && near(q, q+1)) stack.push(q+1);
      if (py > 0   && !visited[q-W] && near(q, q-W)) stack.push(q-W);
      if (py < H-1 && !visited[q+W] && near(q, q+W)) stack.push(q+W);
    }
    /* CLOSING (d16.30): a highlight streak along a rim can sit within
       the sheet's tolerance and be flooded away, leaving a thin notch
       cut into the rim. Dilate the frame mask by 4px and erode it back;
       anything the flood took that lies inside that closed shape is
       given back to the frame. It only ever moves pixels from sheet to
       frame, never the other way, so the rim cannot lose by it. */
    {
      const R = 4, N = W*H;
      const fr = new Uint8Array(N); for (let q = 0; q < N; q++) fr[q] = bg[q] ? 0 : 1;
      const pass = (inp, val) => {
        const t1 = new Uint8Array(N), t2 = new Uint8Array(N);
        for (let y = 0; y < H; y++){ const row = y*W; let cnt = 0; for (let x = -R; x < W; x++){ if (x + R < W && inp[row + x + R] === val) cnt++; if (x - R - 1 >= 0 && inp[row + x - R - 1] === val) cnt--; if (x >= 0) t1[row + x] = cnt > 0 ? 1 : 0; } }
        for (let x = 0; x < W; x++){ let cnt = 0; for (let y = -R; y < H; y++){ if (y + R < H && t1[(y + R)*W + x]) cnt++; if (y - R - 1 >= 0 && t1[(y - R - 1)*W + x]) cnt--; if (y >= 0) t2[y*W + x] = cnt > 0 ? 1 : 0; } }
        return t2;
      };
      const dil = pass(fr, 1), nea = pass(dil, 0);
      for (let q = 0; q < N; q++){ if (bg[q] && dil[q] && !nea[q]) bg[q] = 0; }
    }
    for (let q = 0; q < W*H; q++) if (bg[q]) p[q*4+3] = 0;

    /* The lenses.

       Everything the flood could not reach stayed fully opaque --
       including the pale area inside each rim, which is the white of
       the sheet the frame was photographed on, not the lens. Pasted
       onto a face that reads as two solid white panels where the eyes
       should be. Real glasses are see-through.

       So: find the light regions that are enclosed by the frame --
       reachable from neither edge -- and make them mostly transparent
       instead of removing them. A little is left behind on purpose,
       because a lens is not invisible; it catches light. Sunglasses
       are dark, fall under the threshold, and are untouched. */
    const lenses = [];
    const lensAlpha = opts.lensAlpha == null ? 5 : opts.lensAlpha;
    const lensThresh = opts.lensThreshold || 168;
    const seen = new Uint8Array(W * H);
    const pieces = [];
    const smallPieces = [];   /* pale patches too small to be a lens on their own -- see below */
    for (let start = 0; start < W*H; start++){
      if (seen[start] || bg[start]) continue;
      const i0 = start*4;
      const lum0 = (p[i0]*0.299 + p[i0+1]*0.587 + p[i0+2]*0.114);
      if (!(isGreen(p[i0], p[i0+1], p[i0+2]) || (lum0 >= Math.max(115, bgFloor) && (Math.max(p[i0],p[i0+1],p[i0+2]) - Math.min(p[i0],p[i0+1],p[i0+2])) <= 30))) continue;

      /* Walk the whole enclosed pale region before deciding. A small
         one is a highlight on the plastic; a big one is a lens. */
      const region = [];
      const st = [start];
      seen[start] = 1;
      let touchesEdge = false;
      while (st.length){
        const q = st.pop();
        region.push(q);
        const px = q % W, py = (q - px) / W;
        if (px === 0 || py === 0 || px === W-1 || py === H-1) touchesEdge = true;
        const near = [];
        if (px > 0)   near.push(q-1);
        if (px < W-1) near.push(q+1);
        if (py > 0)   near.push(q-W);
        if (py < H-1) near.push(q+W);
        for (let n = 0; n < near.length; n++){
          const r = near[n];
          if (seen[r] || bg[r]) continue;
          const i4 = r*4;
          const lum = (p[i4]*0.299 + p[i4+1]*0.587 + p[i4+2]*0.114);
          if (!(isGreen(p[i4], p[i4+1], p[i4+2]) || (lum >= Math.max(115, bgFloor) && (Math.max(p[i4],p[i4+1],p[i4+2]) - Math.min(p[i4],p[i4+1],p[i4+2])) <= 30))) continue;
          seen[r] = 1; st.push(r);
        }
      }
      if (touchesEdge) continue;
      if (region.length < (W*H) * 0.004){
        /* Too small to be a lens -- but not necessarily part of the
           frame either.

           Beside the moulded nose pads, and around the hinges, the
           white sheet shows through small gaps. Those patches are
           enclosed, so the flood from the edges cannot reach them, and
           they were left FULLY OPAQUE: solid white wedges that landed
           on the customer's nose. Measured on the Fusion-X: two
           patches of 337 and 144 pixels, rgb(245,245,245).

           A gap shows the sheet, so it is as bright and as colourless
           as the background. A gold hinge detail is also a small
           enclosed bright region, but it is warm -- rgb(225,202,174),
           colour difference around 50. That difference is what tells
           them apart, so the gold survives and the gaps go. */
        let sr = 0, sg = 0, sb = 0;
        for (let n = 0; n < region.length; n++){
          const i4 = region[n]*4; sr += p[i4]; sg += p[i4+1]; sb += p[i4+2];
        }
        const rn = region.length;
        const mr = sr/rn, mg = sg/rn, mb = sb/rn;
        const mLum = mr*0.299 + mg*0.587 + mb*0.114;
        const mChroma = Math.max(mr,mg,mb) - Math.min(mr,mg,mb);
        if (mLum >= (opts.gapLum || 232) && mChroma <= (opts.gapChroma || 12)){
          for (let n = 0; n < region.length; n++) p[region[n]*4+3] = 0;
          continue;
        }
        /* Not a gap. It may still be a SLIVER OF THE LENS: with the
           frame standing and the arm seen through the glass, the arm
           cuts a thin wedge of sheet off the top corner of the opening
           (the Visibilla cat-eye, 12 Sep: a grey strip above a purple
           bar inside each lens). Kept aside; if it sits inside an
           opening's box it is joined to that opening below, and the
           row span then covers the arm between them. */
        if (mChroma <= 26 && region.length >= 12){
          let aMinX = W, aMaxX = 0, aMinY = H, aMaxY = 0;
          for (let n = 0; n < region.length; n++){
            const q = region[n], px = q % W, py = (q - px) / W;
            if (px < aMinX) aMinX = px; if (px > aMaxX) aMaxX = px;
            if (py < aMinY) aMinY = py; if (py > aMaxY) aMaxY = py;
          }
          smallPieces.push({ region, minX:aMinX, maxX:aMaxX, minY:aMinY, maxY:aMaxY });
        }
        continue;
      }
      /* Not decided yet. A lens opening can arrive here in PIECES: when
         the frame stands on the sheet with its arms open straight back,
         the arm is seen THROUGH the lens and cuts the pale opening in
         two (measured on an Ocelot front: the right opening came as
         13,287 px above the arm and 57,601 px below it, the left as one
         piece of 87,225). Taking "the two biggest" then pairs the left
         lens with the LOWER HALF of the right one -- the right lens is
         placed low, its width reads small, and the arm stays dark over
         the customer's eye. So every big enclosed pale region is
         collected first, and pieces that sit in the same columns are
         joined into one opening below. */
      let rMinX = W, rMaxX = 0, rMinY = H, rMaxY = 0;
      for (let n = 0; n < region.length; n++){
        const q = region[n], px = q % W, py = (q - px) / W;
        if (px < rMinX) rMinX = px;
        if (px > rMaxX) rMaxX = px;
        if (py < rMinY) rMinY = py;
        if (py > rMaxY) rMaxY = py;
      }
      pieces.push({ region, minX:rMinX, maxX:rMaxX, minY:rMinY, maxY:rMaxY });
    }

    /* Join pieces of one opening. Two pieces belong to the same lens
       when their column ranges overlap by most of the narrower one;
       the left and right lenses never share columns, and the small
       sheet-gap patches were handled above and are not in this list. */
    const groups = [];
    for (const pc of pieces.sort((a,b)=>b.region.length-a.region.length)){
      let home = null;
      for (const g of groups){
        const ov = Math.min(g.maxX, pc.maxX) - Math.max(g.minX, pc.minX);
        const narrow = Math.min(g.maxX - g.minX, pc.maxX - pc.minX) + 1;
        if (ov > 0 && ov / narrow >= 0.5){ home = g; break; }
      }
      if (home){
        home.parts.push(pc);
        home.minX = Math.min(home.minX, pc.minX); home.maxX = Math.max(home.maxX, pc.maxX);
        home.minY = Math.min(home.minY, pc.minY); home.maxY = Math.max(home.maxY, pc.maxY);
      } else groups.push({ parts:[pc], minX:pc.minX, maxX:pc.maxX, minY:pc.minY, maxY:pc.maxY });
    }
    /* Slivers join the opening whose box they sit in (a small margin
       allows for the sliver reaching the rim's inner edge). */
    for (const sp of (simple ? [] : smallPieces)){
      for (const g of groups){
        const mx = (g.maxX - g.minX) * 0.08, my = (g.maxY - g.minY) * 0.08;
        if (sp.minX >= g.minX - mx && sp.maxX <= g.maxX + mx && sp.minY >= g.minY - my && sp.maxY <= g.maxY + my){
          g.parts.push(sp);
          g.minX = Math.min(g.minX, sp.minX); g.maxX = Math.max(g.maxX, sp.maxX);
          g.minY = Math.min(g.minY, sp.minY); g.maxY = Math.max(g.maxY, sp.maxY);
          break;
        }
      }
    }

    for (const g of groups){
      const region = [];
      for (const pc of g.parts) for (let n = 0; n < pc.region.length; n++) region.push(pc.region[n]);
      let sx = 0, sy = 0;
      const rMinX = g.minX, rMaxX = g.maxX, rMinY = g.minY, rMaxY = g.maxY;
      for (let n = 0; n < region.length; n++){
        const q = region[n];
        p[q*4+3] = lensAlpha;
        const px = q % W, py = (q - px) / W;
        sx += px; sy += py;
      }
      /* Everything inside the lens opening goes behind the glass.

         For each row, the opening's own leftmost and rightmost pixels
         mark where the rim's inner edge is on that line; everything
         between them is inside the lens. A temple folded behind the
         lens sits in that span, so it is covered -- even though it
         touches the rim at the hinge and is therefore not an enclosed
         hole.

         This uses only the opening's own extremes, so it can never
         reach past the rim's inner edge. The squared-off oval it
         replaces was fitted to the lens BOX, and a real opening has
         rounded corners, so at the lower inner corner beside the nose
         it painted straight over the rim: the rim measured 27px in the
         photograph and 2px in the cut-out, tapering to a point.

         A lens opening is convex, so a row-by-row span is exactly its
         shape and nothing more. */
      /* the row-span cover stays on in simple mode (shop, 13 Sep, cat-eye with pink arms):
         the arm seen through the lens must not sit between the eyes. The span uses only the
         opening's own extreme pixels on each row, so it can never reach the rim. */
      {
        const bw = rMaxX - rMinX + 1, bh = rMaxY - rMinY + 1;
        if (bw > 2 && bh > 2 && bw * bh < 4000000){
          const rowMin = new Int32Array(bh).fill(-1);
          const rowMax = new Int32Array(bh).fill(-1);
          for (let n = 0; n < region.length; n++){
            const q = region[n], px = q % W, py = (q - px) / W;
            const ry = py - rMinY;
            if (rowMin[ry] < 0 || px < rowMin[ry]) rowMin[ry] = px;
            if (px > rowMax[ry]) rowMax[ry] = px;
          }

          /* A CONVEX HULL FILL WAS TRIED HERE AND REVERTED.

             The aim was to cover a folded temple that touches the rim:
             on those rows the light area only begins after the arm, so
             a plain span misses it and the arm shows as a grey curve
             inside the lens at the top corner.

             Pulling each boundary out to its hull did not cover the arm
             either, and it thinned the rim: 34px became 30, 41 became
             33. The rim must never be touched, so this is out. Anything
             that replaces it has to be measured against BOTH the rim
             thickness and the corner, not just one. */
          for (let ry = 0; ry < bh; ry++){
            if (rowMin[ry] < 0) continue;
            const y = ry + rMinY;
            for (let px = rowMin[ry]; px <= rowMax[ry]; px++){
              const q = y * W + px;
              if (p[q*4+3] > lensAlpha) p[q*4+3] = lensAlpha;
            }
          }
        }
      }

      /* Remember where this lens sits. An optician centres the lens on
         the pupil; to do the same here we have to know where the
         lenses are in the picture, not just where the frame is. */
      lenses.push({ cx: sx / region.length, cy: sy / region.length,
                    w: rMaxX - rMinX, h: rMaxY - rMinY, area: region.length,
                    minX:rMinX, maxX:rMaxX, minY:rMinY, maxY:rMaxY, region });
    }

    /* (d16.30) The 'one lens teaches the other' rule from d16.29 is
       gone: on the tortoise VG-1003 the mirrored outline landed on the
       bridge corner and painted rim away. The rim is never touched. */

    /* THE FRAME'S OWN SHADOW ON THE SHEET (d16.25).

       A frame standing on the sheet casts a grey strip on the sheet
       just under its bottom rim. Measured on the Ocelot, straight
       below the rim: luminance 99, 87, 78, 139, then the sheet at 190
       -- a contact shadow about six pixels deep, far below the 150
       threshold, so it survived the flood whole. Pasted on a face it
       is a dark line under the frame, as if the frame were resting on
       the cheek. That is the line the shop saw.

       Removed here under five guards, so the rim is never touched:
         1. only for a DARK frame (median rim luminance under 60) --
            grey, silver, gunmetal and crystal rims are near the
            shadow's luminance and are left alone entirely
         2. only neutral pixels (chroma <= 10) at least 50 levels
            lighter than the rim and not darker than 70
         3. only pixels reachable from the OUTER background, at most
            14 pixels deep -- the pale sheet inside a lens is enclosed
            and is never reached
         4. only strips at least three pixels deep over 30% of their
            length: a one- or two-pixel highlight on the rim's outer
            edge is not a shadow and stays
         5. only in the LOWER half of the frame. Light comes from above,
            so the highlight is on the top edge and the shadow is under
            the bottom rim; the top edge is never touched at all.
       A shadow to the side (light from one side) is not handled;
       the shooting rule is light from the front and above. */
    {
      let rimLum = -1;
      {
        const sample = [];
        for (let q = 0; q < W*H; q += 7){ if (p[q*4+3] > 40){ sample.push(p[q*4]*0.299 + p[q*4+1]*0.587 + p[q*4+2]*0.114); } }
        if (sample.length > 200){ sample.sort((a,b)=>a-b); rimLum = sample[sample.length>>1]; }
      }
      /* the sheet's shadow strip under the rim is background, not frame: cleared in simple mode too */
      if (rimLum >= 0 && rimLum < 60){
        const floor = Math.max(70, rimLum + 50);
        let fy0 = H, fy1 = 0;
        for (let q = 0; q < W*H; q += 3){ if (p[q*4+3] > 40){ const py = (q - q % W) / W; if (py < fy0) fy0 = py; if (py > fy1) fy1 = py; } }
        const midY = (fy0 + fy1) / 2;
        const MAXD = 14;
        const isCand = q => {
          if (p[q*4+3] <= 40) return false;
          const r0=p[q*4], g0=p[q*4+1], b0=p[q*4+2];
          if (Math.max(r0,g0,b0) - Math.min(r0,g0,b0) > 10) return false;
          return (r0*0.299 + g0*0.587 + b0*0.114) >= floor;
        };
        const depth = new Uint8Array(W*H);      /* 0 = not reached */
        let front = [];
        for (let q = 0; q < W*H; q++){
          if (!bg[q]) continue;
          const px = q % W, py = (q - px) / W;
          const nb = [];
          if (px > 0) nb.push(q-1); if (px < W-1) nb.push(q+1); if (py > 0) nb.push(q-W); if (py < H-1) nb.push(q+W);
          for (const n of nb){ if (!depth[n] && !bg[n] && isCand(n)){ depth[n] = 1; front.push(n); } }
        }
        for (let d = 2; d <= MAXD && front.length; d++){
          const next = [];
          for (const q of front){
            const px = q % W, py = (q - px) / W;
            const nb = [];
            if (px > 0) nb.push(q-1); if (px < W-1) nb.push(q+1); if (py > 0) nb.push(q-W); if (py < H-1) nb.push(q+W);
            for (const n of nb){ if (!depth[n] && !bg[n] && isCand(n)){ depth[n] = d; next.push(n); } }
          }
          front = next;
        }
        /* group the reached pixels and drop the thin groups */
        const seen = new Uint8Array(W*H);
        let removed = 0;
        for (let q0 = 0; q0 < W*H; q0++){
          if (!depth[q0] || seen[q0]) continue;
          const comp = [q0]; seen[q0] = 1; let deep = 0, sumY = 0;
          for (let k = 0; k < comp.length; k++){
            const q = comp[k]; if (depth[q] >= 3) deep++; sumY += (q - q % W) / W;
            const px = q % W, py = (q - px) / W;
            const nb = [];
            if (px > 0) nb.push(q-1); if (px < W-1) nb.push(q+1); if (py > 0) nb.push(q-W); if (py < H-1) nb.push(q+W);
            for (const n of nb){ if (depth[n] && !seen[n]){ seen[n] = 1; comp.push(n); } }
          }
          if (comp.length >= 40 && deep / comp.length >= 0.30 && sumY / comp.length > midY){ for (const q of comp){ p[q*4+3] = 0; bg[q] = 1; } removed += comp.length; }
        }
        if (removed) c.shadowRemovedPx = removed;
      }
    }

    /* THE NOSE PADS -- TRIED AND REMOVED. Do not add this back
       without solving the problem below.

       The moulded pads photograph as flat neutral grey, rgb(139,138,138)
       on the Fusion-X, and they were rendering opaque on the nose. A
       pass that faded neutral greys in the band between the lenses
       fixed that -- and also ate the rim, because the inner edge of a
       black rim carries a grey specular shine of exactly the same
       colour. The rim came out as a thin line instead of a thick one,
       right where the frame meets the nose.

       A thinned rim is a worse fault than a pale pad, and the rim must
       not be touched. Colour cannot separate the two: both are neutral
       grey. Shape cannot either -- the pads measure 56x180 pixels with
       a fill of 0.20, every bit as thin and sparse as the shine.

       Whatever solves this has to distinguish them some other way. */

    /* A front product photograph often shows the temples folded inward
       behind the lenses. Those pixels used to be pasted across the
       customer's eyes. Clean the complete lens interior before trimming:
       keep the photographed rim/bridge, remove anything folded behind it,
       and restore a controlled lens tint for sunglasses. */
    const lensPair = lenses.slice().sort((a,b)=>b.area-a.area).slice(0,2).sort((a,b)=>a.cx-b.cx);
    if (lensPair.length === 2){
      /* A Try-On front must be level. A generous tolerance accepted angled
         counter photos after background removal, which left one lens and its
         folded temple visibly higher than the other. */
      const sane = Math.abs(lensPair[0].cy-lensPair[1].cy) < H*.035 &&
                   Math.abs(lensPair[0].w-lensPair[1].w) < W*.25 &&
                   (lensPair[1].cx-lensPair[0].cx) > W*.15;
      if (sane){
        const colourName=String(opts.lensColour||'').toLowerCase();
        const tint = /brown|amber|gold/.test(colourName) ? [78,48,28] :
                     /green/.test(colourName) ? [28,58,48] :
                     /blue/.test(colourName) ? [28,48,78] : [38,43,49];
        /* A clear lens has to read as glass.

           At alpha 5 the lens was 1.8% different from bare skin --
           invisible, so a rimless frame looked like an empty wire loop
           and whatever sat behind the glass showed through instead.

           Lenskart brighten the skin behind their lens by about 34%,
           measured. That says "glass" but washes out the customer's
           eyes. 12% is the middle: plainly a lens, without changing
           anyone's eye colour. */
        const alpha = opts.sunglasses ? 112 : 5;
        /* SUNGLASSES ONLY.

           This paints every pixel inside a squared-off oval fitted to
           the lens box. A real lens opening has rounded corners and a
           power-4 superellipse is far squarer, so at the lower inner
           corner -- beside the nose -- it spilled straight over the
           RIM and made it transparent. Measured on the Fusion-X, going
           down that curve: the rim holds 27px in the photograph while
           the cut-out fell to 19, then 9, then 2. The rim tapered to a
           point and broke, which is exactly what it looked like.

           A clear lens does not need this at all: the opening is found
           by growing the light area inside the rim, and the hole fill
           takes care of anything behind the glass. Only a dark
           sunglass lens, which cannot be detected that way, still
           needs a shape painted in. */
        /* SUNGLASSES ARE LEFT EXACTLY AS PHOTOGRAPHED.

           This used to paint a flat invented tint over the lens area
           and force it to a fixed opacity. That threw away the real
           lens: a gradient tint came out flat, a mirror finish lost
           its colour, a brown lens and a green one looked the same,
           and the shape came from a superellipse rather than from the
           frame.

           A dark lens needs none of it. Dark against a pale background
           is the easy case for the cutter -- the lens survives on its
           own, in its own colour, with its own gradient and shine. The
           frame goes on the nose like any other and the glass is the
           glass in the photograph.

           Nothing is painted here now. The block is kept as a marker
           so nobody reinstates the tint by accident. */
      }
    }

    /* Did that actually cut anything out?

       This flood only removes LIGHT pixels from the edges inwards. A
       frame shot on white gives way. A frame photographed on the shop
       shelf does not: the flood stops at the first dark pixel, almost
       nothing is removed, and what comes back is the original
       rectangle -- shelves, wall, whoever was standing behind.

       That rectangle was then pasted onto a customer's face. It went
       out on the live site and it was humiliating. Nothing is worth
       that: if the background did not come away cleanly, this returns
       null and the page says the frame could not be fitted.

       Three things have to be true for a real cut-out:
         - a decent share of the picture was removed
         - the border is now mostly transparent, so the frame is not
           still touching the edges
         - what remains is a wide shape, the way glasses are */
    let cleared = 0;
    for (let q = 0; q < W*H; q++) if (p[q*4+3] === 0) cleared++;
    if (cleared / (W*H) < (opts.minCleared || 0.25)) return null;

    let border = 0, borderOpaque = 0;
    const edge = q => { border++; if (p[q*4+3] > 40) borderOpaque++; };
    for (let i = 0; i < W; i++){ edge(i); edge((H-1)*W + i); }
    for (let j = 1; j < H-1; j++){ edge(j*W); edge(j*W + W-1); }
    if (borderOpaque / border > (opts.maxBorder || 0.15)) return null;

    /* Make transparent coloured rims readable without painting a fake
       opaque frame over the face. Strengthen only coloured/darker frame
       pixels; keep the lens openings almost clear. This also suppresses
       the milky/white reflection that was covering one eye. */
    for (let q = 0; q < W*H; q++){
      const i4=q*4, a=p[i4+3];
      if (!a || bg[q]) continue;
      const r=p[i4], g=p[i4+1], b=p[i4+2];
      const lum=r*.299+g*.587+b*.114;
      const chroma=Math.max(r,g,b)-Math.min(r,g,b);
      if ((chroma > 14 || lum < 150) && a > lensAlpha){
        p[i4+3] = Math.max(a, chroma > 24 ? 205 : 155);
      }
    }
    /* Take the white fringe off the cut edge.

       Where the white sheet meets a dark rim the camera records a row
       of blended pixels, part background and part frame. Their
       luminance lands below the flood's threshold, so the flood keeps
       them -- and they end up drawn on the customer's face as a dotted
       pale outline around the whole frame. It is the single thing that
       makes an otherwise good cut-out look unfinished.

       Any pixel still opaque, touching a cleared one, and lighter than
       the rim it belongs to is one of those blend pixels. Fade it by
       how pale it is: nearly-background goes altogether, nearly-frame
       is left alone. Two passes, because the fringe is often two
       pixels wide on a phone photo.

       This only ever touches pixels on the boundary, so a frame cannot
       be eaten from the inside. */
    /* ONE pass, and only pixels close to the background.

       This faded anything brighter than thresh-55 (95) over two
       passes. On a glossy black frame the rim is not one tone: it is a
       grey gloss band at 100-150 sitting beside a black core at 15-40.
       Measured across the inner curve of the Fusion-X:
         background 254 | 149 151 108 101 | 15 22 20 39 | 254
       Everything from 149 down to 101 is real rim. The old floor ate
       all of it, twice over, so the rim tapered to a point and broke
       where it was glossiest -- at the curve beside the nose.

       A camera blend between sheet and rim lands close to the sheet,
       not halfway. thresh-25 keeps the gloss and still removes the
       pale outline, and one pass cannot chew inward. */
    const fringeCut = opts.fringe == null ? 1 : opts.fringe;
    if (fringeCut){
      for (let pass = 0; pass < 1; pass++){
        const doomed = [];
        for (let y = 0; y < H; y++){
          for (let x = 0; x < W; x++){
            const q = y*W + x, i4 = q*4;
            if (p[i4+3] < 40) continue;
            /* "Cleared" has to mean the lens openings too, not just the
               removed background. Those are left at a low alpha rather
               than zero, so testing for exactly zero missed every inner
               edge -- which is where the worst of the pale outline sits,
               ringing both lens openings. */
            const gone = k => p[k*4+3] < 40;
            const touching =
              (x > 0     && gone(q-1)) ||
              (x < W-1   && gone(q+1)) ||
              (y > 0     && gone(q-W)) ||
              (y < H-1   && gone(q+W));
            if (!touching) continue;
            const lum = p[i4]*0.299 + p[i4+1]*0.587 + p[i4+2]*0.114;
            /* thresh is the flood's idea of background. Anything close
               to it is mostly sheet; well below it is real frame. */
            const t = thresh - (opts.fringeFloor == null ? 25 : opts.fringeFloor);
            if (lum <= t) continue;
            const share = Math.min(1, (lum - t) / (thresh - t));   // 0..1
            doomed.push(q, Math.round(p[i4+3] * (1 - share)));
          }
        }
        if (!doomed.length) break;
        for (let k = 0; k < doomed.length; k += 2) p[doomed[k]*4+3] = doomed[k+1];
      }
    }

    /* FRONT ONLY -- CUT CORNER TO CORNER. (d16.16)

       Whatever sticks out sideways past the outer edge of the rim --
       an arm opened out flat, a hinge, the start of a temple on a
       standing frame -- is not the front, and drawing it on a face
       puts a bar across the customer's cheek. The shop asked for the
       cut to run from the right corner edge to the left corner edge
       and nothing beyond.

       The front is tall (rim plus lens opening); an arm is thin. So
       measure how tall each column of remaining pixels is, call the
       tall columns "front", join the two lens halves across the bridge
       (a gap no wider than the front is tall), and clear every column
       outside that span. Guards: the span must be at least twice as
       wide as it is tall, and any measured lens opening must sit
       inside it -- otherwise nothing is trimmed and the old outline
       stands. Rimless and half-rim frames fail the guard and are left
       alone on purpose. */
    let frontTrim = null;
    /* the corner-to-corner cut stays on in simple mode (shop, 13 Sep): the arms can show, and they must not reach the face */
    if (opts.frontOnly !== false){
      const ext = new Int32Array(W);
      let maxExt = 0;
      for (let xx = 0; xx < W; xx++){
        let top = -1, bot = -1;
        for (let y = 0; y < H; y++){
          if (p[(y*W+xx)*4+3] > 40){ if (top < 0) top = y; bot = y; }
        }
        ext[xx] = top < 0 ? 0 : bot - top + 1;
        if (ext[xx] > maxExt) maxExt = ext[xx];
      }
      if (maxExt > 0){
        const tall = maxExt * (opts.frontShare || 0.40);
        const runs = [];
        let rs = -1;
        for (let xx = 0; xx <= W; xx++){
          const isTall = xx < W && ext[xx] >= tall;
          if (isTall && rs < 0) rs = xx;
          if (!isTall && rs >= 0){ runs.push([rs, xx-1]); rs = -1; }
        }
        if (runs.length){
          const big = runs.reduce((a,b) => (b[1]-b[0]) > (a[1]-a[0]) ? b : a);
          const gap = maxExt * (opts.bridgeGapShare || 0.8);
          let f0 = big[0], f1 = big[1], grew = true;
          while (grew){
            grew = false;
            for (const r of runs){
              if (r[1] < f0 && f0 - r[1] <= gap){ f0 = r[0]; grew = true; }
              if (r[0] > f1 && r[0] - f1 <= gap){ f1 = r[1]; grew = true; }
            }
          }
          let s0 = -1, s1 = -1;
          for (let xx = 0; xx < W; xx++) if (ext[xx]){ if (s0 < 0) s0 = xx; s1 = xx; }
          /* KEEP THE CORNER (d16.26). The 40% rule alone cut the end
             pieces off: on the Ocelot the outer corner is a slanted
             block whose column height climbs from 3px to 150px over
             35 columns, and all of it went -- 6.5% of the width, and
             the frame drawn on the face lost its corners (shop, 12
             Sep: "you are cutting more"). A corner is a TAPER: the
             height keeps changing column by column. An arm is a
             PLATEAU: the same thickness column after column. So walk
             outward from the tall span and keep every column while
             the height is still changing; stop at the first plateau
             (that is the arm) or where the height falls below a
             hairline. Never further than a quarter of the frame's
             height, which no corner block exceeds. */
          {
            /* d16.28: a corner block SHRINKS steadily outward -- every
               column is no taller than the one inside it. A hinge or
               an arm's flared end grows again on the way out, and an
               arm holds its thickness; both stop the walk. Reach cut
               to 15% of the height: the shop saw a piece of arm kept
               under the old 25%. */
            const lowThr = Math.max(22 * (W/1400), maxExt * 0.06);
            const reach = Math.round(maxExt * 0.15);
            const flat = (a, b) => Math.abs(a - b) < 0.08 * Math.max(a, b);
            let n = 0;
            while (f0 - 1 >= s0 && n < reach){
              const xx = f0 - 1;
              if (ext[xx] < lowThr) break;
              if (ext[xx] > ext[xx+1] + 2) break;      /* grows outward: hinge or arm, not a corner */
              const far = Math.max(s0, xx - 10);
              if (flat(ext[xx], ext[far])) break;      /* arm: same thickness 10 columns further out */
              f0 = xx; n++;
            }
            n = 0;
            while (f1 + 1 <= s1 && n < reach){
              const xx = f1 + 1;
              if (ext[xx] < lowThr) break;
              if (ext[xx] > ext[xx-1] + 2) break;
              const far = Math.min(s1, xx + 10);
              if (flat(ext[xx], ext[far])) break;
              f1 = xx; n++;
            }
          }
          const fw = f1 - f0 + 1;
          let lensesInside = true;
          for (const L of lenses){
            if (L.minX != null && (L.minX < f0 - maxExt*0.2 || L.maxX > f1 + maxExt*0.2)) lensesInside = false;
          }
          if (fw >= maxExt * 2.0 && lensesInside && (f0 > s0 || f1 < s1)){
            for (let y = 0; y < H; y++){
              const row = y*W;
              for (let xx = s0; xx < f0; xx++) p[(row+xx)*4+3] = 0;
              for (let xx = f1+1; xx <= s1; xx++) p[(row+xx)*4+3] = 0;
            }
            frontTrim = { fullSpanPx: s1 - s0 + 1, frontPx: fw,
                          leftCutPx: f0 - s0, rightCutPx: s1 - f1 };
          }
        }
      }
    }

    x.putImageData(d, 0, 0);

    // trim to what is left
    let minX=W, minY=H, maxX=0, maxY=0, any=false;
    for (let y = 0; y < H; y++){
      for (let xx = 0; xx < W; xx++){
        if (p[(y*W+xx)*4+3] > 40){
          any = true;
          if (xx<minX) minX=xx; if (xx>maxX) maxX=xx;
          if (y<minY) minY=y;   if (y>maxY) maxY=y;
        }
      }
    }
    if (!any) return null;
    const cw = maxX-minX+1, ch = maxY-minY+1;

    /* Glasses are wide. Anything close to square is a photo that did
       not cut, or a stray object, not a frame. Real frames sit around
       2:1 to 4:1; the range below is deliberately generous. */
    const ratio = cw / ch;
    /* Frames are wide. The upper bound used to be 6:1, which quietly
       refused a very common product shot: the frame photographed with
       its arms folded out to the sides. That is wider than the frame
       front alone and sailed past the limit, so those frames showed
       "not suitable for try-on" for no good reason. Nine to one still
       excludes a banner or a shelf strip. */
    if (ratio < (opts.minRatio || 1.6) || ratio > (opts.maxRatio || 9)) return null;

    const t = document.createElement('canvas');
    t.width = cw; t.height = ch;
    t.getContext('2d').drawImage(c, minX, minY, t.width, t.height, 0, 0, t.width, t.height);

    /* Hand the lens positions on, as fractions of the trimmed picture,
       so whoever places this frame can put a pupil in the middle of a
       lens instead of guessing from the outline. Only the two biggest
       are kept: a frame has two lenses, and anything else found is a
       reflection or a gap in the bridge. */
    if (lenses.length >= 2){
      /* Take the MIDDLE OF THE OPENING, not the average of its pixels.

         A front product photo usually has the temples folded in behind
         the lenses, and an arm crossing the lower half of an opening
         removes those pixels from the region. The average of what is
         left then sits high -- and since this point is what gets put on
         the customer's pupil, the whole frame was drawn riding up on
         the eyebrows. That is the fault the shop kept reporting.

         The top and bottom edges of the opening do not move when an arm
         crosses the middle, so the midpoint between them is stable.
         Falls back to the pixel average if the edges were not recorded. */
      const two = lenses.sort((a,b) => b.area - a.area).slice(0, 2)
        .map(L => {
          const midX = (L.minX != null && L.maxX != null) ? (L.minX + L.maxX) / 2 : L.cx;
          const midY = (L.minY != null && L.maxY != null) ? (L.minY + L.maxY) / 2 : L.cy;
          return { x: (midX - minX) / cw, y: (midY - minY) / ch,
                   w: L.w / cw, h: L.h / ch };
        })
        .sort((a,b) => a.x - b.x);
      /* Two lenses side by side, roughly level and roughly the same
         size. Anything else is not a pair and is not trusted. */
      const sane = Math.abs(two[0].y - two[1].y) < 0.035 &&
                   Math.abs(two[0].w - two[1].w) < 0.25 &&
                   two[0].y > 0.22 && two[0].y < 0.70 &&
                   two[1].y > 0.22 && two[1].y < 0.70 &&
                   two[0].h > 0.55 && two[1].h > 0.55 &&
                   (two[1].x - two[0].x) > 0.15;
      if (sane) t.lenses = two;
    }
    /* Sunglasses.

       The search above finds lens openings by looking for LIGHT areas
       enclosed by the rim. That works for a clear frame, where the
       opening shows the white sheet behind it. A sunglass lens is dark,
       so nothing is found -- and refusing outright meant try-on was
       switched off for every pair of sunglasses in the shop, which is a
       large part of what Vision Gallery sells.

       When the shape is plainly a pair of glasses but the openings
       cannot be measured, place the lens centres where they sit on
       essentially every frame: a little in from each end, on the
       horizontal centre line. Marked as estimated, so the millimetre
       scaling below still refuses to trust it and falls back to the
       photo. A sensible placement beats no try-on at all. */
    if (!t.lenses){
      t.lenses = [{ x:0.22, y:0.50, w:0.30, h:0.55 },
                  { x:0.78, y:0.50, w:0.30, h:0.55 }];
      t.lensesEstimated = true;
    }
    if (frontTrim) t.frontTrim = frontTrim;
    if (c.shadowRemovedPx) t.shadowRemovedPx = c.shadowRemovedPx;
    t.greenSheet = !!greenSheet;
    return t;
  }

  /* ---- find the pupils on a model face ---------------------------- */

  /* Build the fitting measurements from landmarks already found by the
     live camera. Re-running FaceMesh on the captured JPEG can fail on the
     very same face (especially with prescription lenses/reflections), even
     though the live detector was tracking it correctly. */
  /* THE IRIS AS A RULER.

     A photograph has no scale in it. The sizing has been dividing the
     pupil distance by 63mm, an adult average -- fine for an adult man,
     wrong for a woman by a few percent and wrong for a child by 15-25%,
     because a child's pupils are 45-55mm apart, not 63.

     The coloured part of the eye is about 11.7mm across in almost
     everyone. It varies by well under a millimetre between people, and
     it reaches adult size in early childhood, so a child's iris and an
     adult's are nearly the same. That makes it a ruler already present
     in every photo -- no card, nothing to hold up, nothing to ask.

     Measured across, not down: eyelids cover the top and bottom of the
     iris, never the sides. 469/471 and 474/476 are the outer and inner
     edges of each iris. */
  function irisWidth(at){
    try {
      const r = Math.hypot(at(471).x - at(469).x, at(471).y - at(469).y);
      const l = Math.hypot(at(476).x - at(474).x, at(476).y - at(474).y);
      if (!isFinite(r) || !isFinite(l) || r <= 0 || l <= 0) return 0;
      /* Average the two, do not take the wider.

         Taking the wider one was meant to protect against a turned
         head, but eyelids never cover the SIDES of an iris, so there
         was nothing to protect against when facing forward -- and max
         of two noisy measurements is biased high every time. A wider
         iris reads as a smaller PD, and it under-reported a known 64mm
         PD as 59.2mm.

         Averaging is unbiased when square on. A genuinely turned head
         is handled by the caller, which falls back to the assumed PD
         when the iris and pupil distance disagree. */
      return (r + l) / 2;
    } catch (e){ return 0; }
  }

  /* THE NOSE'S MIDLINE, not one dot on it.

     Placement used landmark 6 alone. One landmark carries the error of
     one landmark: if it sits a millimetre off the true axis, or the
     bridge is fuller on one side, the frame follows the dot rather
     than the nose, and one inner curve presses while the other shows
     air.

     168, 6, 197 and 195 run down the bridge, all on the midline, over
     exactly the stretch where a frame rests. Averaging them cancels
     most of the wander in any single one. */
  function noseAxisX(at){
    try {
      const ids = [168, 6, 197, 195];
      let sum = 0, n = 0;
      for (const id of ids){
        const q = at(id);
        if (q && isFinite(q.x)){ sum += q.x; n++; }
      }
      return n ? sum / n : 0;
    } catch (e){ return 0; }
  }

  /* d17.97 (shop, 9 Oct: "a side photo must be a real 30-degree photo -- head level, not looking down"): the head's turn,
     nod and tilt in DEGREES, from the face finder's 3-D points: the line between the outer eye corners (turn, tilt) and
     the line from forehead to chin (nod). Level is about +3 degrees on a face looking straight ahead (measured on the six
     AI models); looking down gives a bigger number, looking up a smaller one. Turn is a size -- which way is decided
     elsewhere. */
  function headPose3(lm, W, H){
    try {
      if (!lm || lm.length < 400) return null;
      const P = i => [lm[i].x * W, lm[i].y * H, (lm[i].z || 0) * W];
      const a = P(33), b = P(263), t = P(10), c = P(152);
      const xa = [b[0]-a[0], b[1]-a[1], b[2]-a[2]], ya = [c[0]-t[0], c[1]-t[1], c[2]-t[2]];
      if (!lm[33].z && !lm[263].z && !lm[10].z) return null;          /* a 2-D-only finder: no depth, no pose */
      const k = (ya[0]*xa[0]+ya[1]*xa[1]+ya[2]*xa[2]) / ((xa[0]*xa[0]+xa[1]*xa[1]+xa[2]*xa[2]) || 1);
      const yu = [ya[0]-k*xa[0], ya[1]-k*xa[1], ya[2]-k*xa[2]];
      const deg = r => r * 180 / Math.PI;
      return { yaw: Math.abs(deg(Math.atan2(xa[2], Math.abs(xa[0]) || 1e-6))), pitch: deg(Math.atan2(yu[2], Math.hypot(yu[0], yu[1]) || 1e-6)),
               roll: deg(Math.atan2(xa[1], Math.abs(xa[0]) || 1e-6)) * (xa[0] < 0 ? -1 : 1) };
    } catch (e) { return null; }
  }
  function faceFromLandmarks(lm, W, H, mirrored){
    if (!lm || !lm.length || !W || !H) return null;
    const at = i => ({ x: (mirrored ? 1-lm[i].x : lm[i].x) * W, y: lm[i].y * H });
    const avg = ids => { const p=ids.map(at); return {x:p.reduce((a,b)=>a+b.x,0)/p.length,y:p.reduce((a,b)=>a+b.y,0)/p.length}; };
    const iris = lm.length > 477;
    let pR=iris?avg([468,469,470,471,472]):at(33), pL=iris?avg([473,474,475,476,477]):at(263);
    const irisPx = iris ? irisWidth(at) : 0;
    let cR=at(234), cL=at(454), eR=at(127), eL=at(356);
    if(pR.x>pL.x){const t=pR;pR=pL;pL=t;} if(cR.x>cL.x){const t=cR;cR=cL;cL=t;} if(eR.x>eL.x){const t=eR;eR=eL;eL=t;}
    /* d17.98 (shop, 9 Oct: "make sure the frame is level -- right side up, left side down won't look good"): glasses rest on
       both ears and the nose, so they tilt exactly as the head does. The tilt is read from the outer eye CORNERS (they move
       with the skull, not with the gaze) and is no longer softened to 70% or zeroed under 1 degree -- that left the frame
       up to 1.5 degrees off the face. */
    let cA=at(33), cB=at(263); if(cA.x>cB.x){const t=cA;cA=cB;cB=t;}
    let rawRoll=Math.atan2(cB.y-cA.y,cB.x-cA.x); if(!isFinite(rawRoll)) rawRoll=Math.atan2(pL.y-pR.y,pL.x-pR.x);
    let roll=isFinite(rawRoll)?rawRoll:0;
    const limit=12*Math.PI/180;
    roll=Math.max(-limit,Math.min(limit,roll));
    const nose=at(1), dR=Math.abs(nose.x-cR.x), dL=Math.abs(cL.x-nose.x), span=dR+dL;
    /* d17.40: the turn measure is no longer cut off at 0.6 -- a real 45-degree turn reads about 0.75-0.8, and capping it
       made every proper 45-degree photo look 'turned too far' to the side view. Straight-on faces read the same as before. */
    let yaw=span>0?(dL-dR)/span:0; yaw=isFinite(yaw)?Math.max(-.95,Math.min(.95,yaw)):0;
    const brow=at(10), chin=at(152), jawR=at(172), jawL=at(397), browR=at(21), browL=at(251);
    /* d17.87: how open the eyes are (lid gap / eye width, both eyes): about 0.25-0.35 open, under 0.12 shut. A shut or
       half-shut eye is never used to measure the face. */
    const dd=(a,b)=>Math.hypot(at(a).x-at(b).x,at(a).y-at(b).y);
    const eo=[dd(159,145)/(dd(33,133)||1), dd(386,374)/(dd(362,263)||1)].filter(v=>isFinite(v));
    const eyeOpen=eo.length?eo.reduce((a,b)=>a+b,0)/eo.length:null;
    return {pose:headPose3(lm,W,H),eyeOpen,brow,chin,jawW:Math.hypot(jawL.x-jawR.x,jawL.y-jawR.y),browW:Math.hypot(browL.x-browR.x,browL.y-browR.y),
      faceL:Math.hypot(chin.x-brow.x,chin.y-brow.y),pupilR:pR,pupilL:pL,pd:Math.hypot(pL.x-pR.x,pL.y-pR.y),
      /* WHICH measurement pd actually is.

         With refined iris landmarks it is pupil to pupil, about 63mm on
         an adult. Without them the points above fall back to 33 and 263
         -- the OUTER CORNERS of the eyes, about 90mm apart. The scaling
         divided by 63 either way, so whenever iris refinement dropped
         out the frame was drawn some 40% too wide, and the eyebrow rule
         (capped as a share of frame height) then pushed it further down
         as well. Both faults appeared together the moment the face got
         smaller in the picture -- which is exactly when iris refinement
         gives up. Say which one it is and let the scaling divide by the
         right number. */
      irisUsed: !!iris, irisPx: irisPx, noseAxisX: noseAxisX(at),
      roll,yaw,bridge:at(168),
      /* 168 is the TOP of the nose bridge, up between the eyebrows.
         Nothing rests there. 6 is further down the bridge, which is
         where a pair of glasses actually sits -- anchoring to 168 was
         why an attempt to seat the frame on the nose pushed it higher
         up the face instead of lower.
         130 and 359 are the outer corners of the eyes: a wider and
         steadier line than the pupils for reading head tilt. */
      noseSeat:at(6), eyeOutR:at(130), eyeOutL:at(359),
      /* d17.98 (shop, 9 Oct: "on a turned head the eyes look at the camera -- never use the pupils or the iris there"): the
         eye CORNERS move with the skull, not with the gaze. The tilt read from the two outer corners, not softened. */
      cornerOut33:at(33), cornerOut263:at(263), cornerIn133:at(133), cornerIn362:at(362),
      noseRidge:[168,6,197,195,5,4].map(at),   /* the nose ridge from between the eyes down to the tip -- where a bridge can rest */
      eyeRoll:(function(){ let a=at(33), b=at(263); if(a.x>b.x){const t=a;a=b;b=t;} const r=Math.atan2(b.y-a.y,b.x-a.x); return isFinite(r)?r:0; })(),
      /* 105 and 334 are the LOWER edge of each eyebrow.

         These were returned by the live camera path and not by this
         one, so the eyebrow limit fired on a photo taken with the
         camera and was silently skipped on a photo rebuilt from
         landmarks. The same face could be placed two different ways
         depending on which route it arrived by, which is why results
         looked inconsistent between attempts. Both paths return the
         same measurements now. */
      browR:at(105), browL:at(334),
      noseTip:at(1), chin:at(152),   // for the pitch reading above
      templeR:eR,templeL:eL,cheekR:cR,cheekL:cL,faceW:Math.hypot(cL.x-cR.x,cL.y-cR.y),w:W,h:H};
  }

  function findFace(img, opts){
    opts = opts || {};
    return new Promise((resolve) => {
      /* MediaPipe is fetched on demand (d16.31): wait for it rather than giving up */
      if (typeof FaceMesh === 'undefined'){
        if (typeof window.loadFaceMesh === 'function'){
          window.loadFaceMesh().then(() => { if (typeof FaceMesh === 'undefined') resolve(null); else run(); }).catch(() => resolve(null));
        } else resolve(null);
        return;
      }
      run();
      function run(){
      const mesh = new FaceMesh({
        locateFile: f => (window.FACEMESH_BASE || 'https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh@0.4/') + f
      });
      /* THE SAME PHOTOGRAPH MUST GIVE THE SAME ANSWER.

         Measured on one file run twice, nothing changed: iris 39px then
         40px, PD 63.6mm then 61.9mm. One pixel of iris is 1.7mm of PD.

         staticImageMode does not exist in the JavaScript build -- it is
         Python-only and was silently ignored; a fresh FaceMesh per call
         did not settle it either. What does: reset() before each look,
         THREE looks, and the point-by-point median, so the odd reading
         is thrown away rather than reported.

         This used to live only in the test page's own copy of the
         detector, so the bench was steady while the site still swung.
         It is here now, in the one place every caller uses, and the
         bench is a byte-for-byte copy of this file again. */
      mesh.setOptions({ maxNumFaces:1, refineLandmarks:true,
                        minDetectionConfidence:0.3, minTrackingConfidence:0.3 });
      const RUNS = opts.runs || 3;
      const runs = [];
      let waiting = null;
      mesh.onResults(res => {
        if (!waiting) return;
        const w = waiting; waiting = null;
        w(res.multiFaceLandmarks && res.multiFaceLandmarks[0] || null);
      });
      const once = () => new Promise(res => {
        /* A look that never answers must not hang the page at
           "Working..." -- eight seconds, then it counts as a miss. */
        const t = setTimeout(() => { const w = waiting; waiting = null; if (w) w(null); }, 8000);
        const done = v => { clearTimeout(t); res(v); };
        waiting = done;
        try { if (mesh.reset) mesh.reset(); } catch (e){}
        mesh.send({ image: img }).catch(() => { const w = waiting; waiting = null; if (w) w(null); });
      });
      (async () => {
        for (let n = 0; n < RUNS; n++){
          const lm = await once();
          if (lm) runs.push(lm);
        }
        /* Free the detector. Every call here builds one, and a phone
           that keeps them all alive stops detecting anything at all
           after a few calls -- measured the hard way on 11 Sep. */
        try { if (typeof mesh.close === 'function') mesh.close(); } catch (e){}
        if (!runs.length){ resolve(null); return; }
        let lm = runs[0];
        if (runs.length >= 3){
          lm = runs[0].map((_, i) => {
            const xs = runs.map(r => r[i].x).sort((a,b)=>a-b);
            const ys = runs.map(r => r[i].y).sort((a,b)=>a-b);
            const zs = runs.map(r => (r[i].z||0)).sort((a,b)=>a-b);
            const m = runs.length >> 1;
            return { x: xs[m], y: ys[m], z: zs[m] };
          });
        }
        resolve(faceFromLandmarks(lm, img.naturalWidth, img.naturalHeight));
      })();
      }

    });
  }


  /* Find the vertical line through the lenses, as a fraction of the
     cut-out's height.

     A pair of glasses seen from the front is widest across the lenses
     and narrow at the bridge and arms. So the row carrying the most
     ink, weighted toward the upper half where the lenses sit, is a
     good stand-in for the lens line without needing to recognise
     anything. */
  function lensLine(canvas){
    try {
      const x = canvas.getContext('2d');
      const d = x.getImageData(0, 0, canvas.width, canvas.height).data;
      const W = canvas.width, H = canvas.height;
      let best = -1, bestRow = null;
      for (let y = 0; y < H; y++){
        let n = 0;
        for (let xx = 0; xx < W; xx++) if (d[(y*W+xx)*4+3] > 40) n++;
        if (n > best){ best = n; bestRow = y; }
      }
      if (bestRow == null || !best) return 0.5;
      const f = bestRow / H;
      /* Guard against a nonsense answer from an odd photo. */
      return (f > 0.15 && f < 0.85) ? f : 0.5;
    } catch (e){
      return 0.5;      // tainted canvas, cross-origin photo, anything
    }
  }

  /* ---- what shape is this face? ---------------------------------

     Not a guess. It is worked out from three ratios an optician uses
     by eye: how long the face is against how wide, how the jaw
     compares to the cheekbones, and how the forehead compares to the
     jaw. The landmarks give those directly.

     What it must not do is overclaim. A face is rarely one clean
     shape, so this returns the closest match and how confident it is,
     and the wording on screen stays "usually suits", never "perfect
     for you". Someone who buys on a promise and dislikes the mirror
     comes back unhappy, and rightly. */

  const SHAPE_ADVICE = {
    round: {
      label: 'Round',
      why: 'Soft curves, and about as wide as it is long.',
      suits: ['Rectangle','Square','Geometric','Wayfarer'],
      because: 'Angular frames add definition and make a round face look longer.'
    },
    square: {
      label: 'Square',
      why: 'A strong jaw, close in width to the cheekbones.',
      suits: ['Round','Oval','Aviator','Cat eye'],
      because: 'Curved frames soften a strong jawline rather than echoing it.'
    },
    oval: {
      label: 'Oval',
      why: 'Balanced \u2014 a little longer than wide, with a gently tapered jaw.',
      suits: ['Rectangle','Square','Round','Aviator','Cat eye','Geometric'],
      because: 'Most shapes work on an oval face. Go by what you like.'
    },
    oblong: {
      label: 'Long',
      why: 'Noticeably longer than it is wide.',
      suits: ['Square','Round','Wayfarer'],
      because: 'A deeper frame breaks up the length. Avoid narrow ones.'
    },
    heart: {
      label: 'Heart',
      why: 'Wider at the forehead, narrowing to the chin.',
      suits: ['Round','Oval','Aviator'],
      because: 'Frames that are lighter at the bottom balance a wider forehead.'
    },
    diamond: {
      label: 'Diamond',
      why: 'Widest across the cheekbones, narrower at forehead and jaw.',
      suits: ['Oval','Cat eye','Round'],
      because: 'Softer frames with some width at the brow open up the eyes.'
    }
  };

  function faceShape(face){
    if (!face || !face.faceL || !face.faceW) return null;

    const lengthRatio = face.faceL / face.faceW;    // long vs wide
    const jawRatio    = face.jawW  / face.faceW;    // jaw vs cheekbones
    const browRatio   = face.browW / face.jawW;     // forehead vs jaw

    let key;
    if (lengthRatio > 1.55)                       key = 'oblong';
    else if (browRatio > 1.18)                    key = 'heart';
    else if (jawRatio < 0.78 && browRatio < 1.05) key = 'diamond';
    else if (lengthRatio < 1.28){
      key = jawRatio > 0.86 ? 'square' : 'round';
    }
    else key = 'oval';

    /* How clear-cut was it? Ratios sitting near a boundary mean the
       face is between two shapes, and the wording should soften. */
    const edges = [
      Math.abs(lengthRatio - 1.28), Math.abs(lengthRatio - 1.55),
      Math.abs(jawRatio - 0.86), Math.abs(browRatio - 1.18)
    ];
    const margin = Math.min.apply(null, edges);
    const sure = margin > 0.09 ? 'clear' : 'close';

    return Object.assign({ key: key, sure: sure,
      ratios: { length: lengthRatio, jaw: jawRatio, brow: browRatio } },
      SHAPE_ADVICE[key]);
  }

  /* ---- is this photo good enough to fit frames to? --------------

     The whole approach rests on one straight-on photo. Get that right
     once and every frame in the shop lands correctly on it. Get it
     wrong -- head turned, head tilted, face off to one side, standing
     too far back -- and every frame after it sits wrong, and it looks
     like the fitting is broken when really the photo was.

     So check before saving, and say which thing to fix. One clear
     instruction at a time; a list of five faults helps nobody. */

  function checkShot(face){
    if (!face) return { ok:false, why:'No face found. Face a window or a lamp and try again.' };

    const yaw  = Math.abs(face.yaw || 0);
    const roll = Math.abs(face.roll || 0) * 180 / Math.PI;

    if (yaw > 0.16)
      return { ok:false, why:'Your head is turned. Look straight at the camera.' };

    if (roll > 12)            /* d17.98: the tilt is read in full now (it was softened and capped at 7) -- same photos pass as before */
      return { ok:false, why:'Your head is tilted. Keep it level.' };

    /* Too small and the landmarks are guesswork; too large and the
       frame runs off the edge of the picture. */
    const across = (face.faceW || 0) / face.w;
    if (across < 0.22) return { ok:false, why:'Too far away. Hold the phone closer.' };
    if (across > 0.75) return { ok:false, why:'Too close. Hold the phone a little further back.' };

    /* Off to one side and the frame can be cut off by the edge. */
    const pupilCx = (face.pupilR.x + face.pupilL.x) / 2;
    /* Blend the nose bridge and pupil midpoint. The bridge is the true
       mechanical centre of a worn frame; the pupil midpoint keeps the
       fit stable when a landmark is noisy. */
    const cx = face.bridge ? (face.bridge.x * 0.72 + pupilCx * 0.28) : pupilCx;
    const pupilCy = (face.pupilR.y + face.pupilL.y) / 2;
    /* Shot validation must use face landmarks only. An earlier build
       accidentally referred to compose() variables (h/opts) here; that
       could throw during selfie validation and silently bypass the very
       pose checks that keep the frame level. */
    const cy = pupilCy;
    if (Math.abs(cx / face.w - 0.5) > 0.16)
      return { ok:false, why:'Move to the middle of the picture.' };
    if (cy / face.h < 0.12 || cy / face.h > 0.68)
      return { ok:false, why:'Move your face to the middle of the picture.' };

    return { ok:true };
  }

  /* ---- put the frame on the face ---------------------------------- */

  /* face: from findFace. frameCanvas: from cutout.
     widthMM: the frame's true width, so it lands at the right size.  */
  /* The colour to draw the arms in: the frame's own. Taken from the
     solid pixels along the outer edges of the rim, where the plastic
     is, rather than an average of the whole picture -- which would be
     diluted by the see-through lenses. */
  /* Where the frame actually touches the nose.

     Between the two lenses there is the bridge, and its UNDERSIDE is
     the part that sits on the nose. Everything about a worn frame's
     height follows from that one contact point -- not from the pupils,
     which is what this was anchored to before. Anchoring to the pupils
     is why the frame kept floating up onto the eyebrows: nothing in the
     maths knew the nose was there.

     Returns the underside as a fraction of the cut-out height, or null
     when the bridge cannot be read. */
  function bridgeRest(cv, lenses){
    if (cv.__bridgeRest !== undefined) return cv.__bridgeRest;
    try {
      if (!lenses || lenses.length < 2) return null;
      const x = cv.getContext('2d');
      const d = x.getImageData(0, 0, cv.width, cv.height).data;
      /* Look only between the inner edges of the two lenses. */
      const from = Math.round((lenses[0].x + lenses[0].w / 2) * cv.width);
      const to   = Math.round((lenses[1].x - lenses[1].w / 2) * cv.width);
      if (!(to > from + 2)) return null;
      let lowest = -1;
      for (let X = from; X <= to; X++){
        for (let Y = cv.height - 1; Y >= 0; Y--){
          if (d[((Y * cv.width) + X) * 4 + 3] > 200){
            if (Y > lowest) lowest = Y;
            break;
          }
        }
      }
      if (lowest < 0) return null;
      return lowest / cv.height;
    } catch (e){ return null; }
  }

  /* The underside of the frame's bridge: the part that touches the
     nose. Measured between the inner edges of the two lenses, as a
     fraction of the cut-out height. */
  function bridgeRest(cv, lenses){
    try {
      if (!lenses || lenses.length < 2) return null;
      const x = cv.getContext('2d');
      const d = x.getImageData(0, 0, cv.width, cv.height).data;
      const from = Math.round((lenses[0].x + lenses[0].w / 2) * cv.width);
      const to   = Math.round((lenses[1].x - lenses[1].w / 2) * cv.width);
      if (!(to > from + 2)) return null;
      let lowest = -1;
      for (let X = from; X <= to; X++){
        for (let Y = cv.height - 1; Y >= 0; Y--){
          if (d[((Y * cv.width) + X) * 4 + 3] > 200){ if (Y > lowest) lowest = Y; break; }
        }
      }
      cv.__bridgeRest = lowest < 0 ? null : lowest / cv.height;
      return cv.__bridgeRest;
    } catch (e){ cv.__bridgeRest = null; return null; }
  }

  function wipePrint(cv, lenses){
    try {
      if (cv.__printWiped) return;
      cv.__printWiped = 0;
      const W = cv.width, H = cv.height;
      const x = cv.getContext('2d');
      const im = x.getImageData(0, 0, W, H), d = im.data;
      const at = (X, Y) => ((Y * W) + X) * 4;
      let wiped = 0;

      lenses.forEach(L => {
        /* The whole lens opening, inset just enough to stay off the
           rim. Printing sits low in the lens, so the box has to reach
           most of the way down. */
        /* Keep the box inside the picture. When it ran to the very
           edge, anything printed near the outside of a lens -- which is
           exactly where a brand logo goes -- counted as "touching the
           edge" and was spared. That is why the GOLD lettering survived
           while the model number was removed. */
        /* L.w is the FULL width of the opening, so the half-width is
           L.w/2. This read L.w * 0.92, which made the box nearly twice
           the lens -- wide enough to swallow the bridge and reach into
           the other lens. Frame parts then sat inside the box, failed
           the escape test, and were deleted: a slice was cut out of the
           inner rim beside the bridge, which is exactly the "you broke
           the frame" that showed up on a customer's face.
           0.42 keeps the box inside the opening, clear of the rim. */
        const x0 = Math.max(2, Math.round((L.x - L.w * 0.42) * W));
        const x1 = Math.min(W-3, Math.round((L.x + L.w * 0.42) * W));
        /* Reach the bottom of the lens. The printing sits LOW -- the
           model number and the logo both run along the lower part of
           the glass, below where a half-height box reaches. That is
           why the first attempts removed some stray marks and left the
           actual text sitting on the cheek.
           Going this low is safe because of the escape rule: a bottom
           rim runs out of the box and is spared, while a line of text
           floats free inside it. */
        /* Reach the bottom of the demo lens. The printing runs low on
           the glass -- on the GOLD half-rim it sits at about 88% of the
           picture height, well below a half-height box.
           Going deep is safe now that the box is no longer too WIDE:
           the bottom rim of a full-rim frame runs out of the box
           sideways and is spared by the escape rule, and the size cap
           is measured against the lens. It was the width that ate the
           bridge, not the depth. */
        const y0 = Math.max(2, Math.round((L.y - L.h * 0.40) * H));
        const y1 = Math.min(H-3, Math.round((L.y + L.h * 0.86) * H));
        if (x1 - x0 < 8 || y1 - y0 < 8) return;

        const cols = x1 - x0 + 1;
        const seen = new Uint8Array(cols * (y1 - y0 + 1));
        for (let Y = y0; Y <= y1; Y++){
          for (let X = x0; X <= x1; X++){
            const key = (Y - y0) * cols + (X - x0);
            if (seen[key] || d[at(X, Y) + 3] < 120) continue;
            const blob = [];
            let escapes = false;
            const st = [[X, Y]];
            seen[key] = 1;
            while (st.length){
              const [cx, cy] = st.pop();
              blob.push([cx, cy]);
              if (cx <= x0 || cx >= x1 || cy <= y0 || cy >= y1) escapes = true;
              /* A brand logo is several hundred to a few thousand
                 pixels; the old cap of 3000 spared exactly those. The
                 protection that matters is not size but whether the
                 shape stays clear of the rim, which is checked above. */
              if (blob.length > 30000){ escapes = true; break; }
              for (const [nx, ny] of [[cx+1,cy],[cx-1,cy],[cx,cy+1],[cx,cy-1]]){
                if (nx < x0 || nx > x1 || ny < y0 || ny > y1){ escapes = true; continue; }
                const k = (ny - y0) * cols + (nx - x0);
                if (seen[k] || d[at(nx, ny) + 3] < 120) continue;
                seen[k] = 1; st.push([nx, ny]);
              }
            }
            /* Small, and it never reaches the edge of the lens: that is
               a printed character, not part of the frame. */
            /* Judge the size against the LENS, not the whole picture.
               2% of the picture was about ten thousand pixels here --
               large enough to cover a piece of rim. Printing is a
               fraction of that, so measuring against the lens box makes
               the rule mean what it says. */
            const boxArea = (x1 - x0 + 1) * (y1 - y0 + 1);
            if (!escapes && blob.length > 2 && blob.length < boxArea * 0.06){
              blob.forEach(([bx, by]) => { d[at(bx, by) + 3] = 0; });
              wiped += blob.length;
            }
          }
        }
      });
      if (wiped) x.putImageData(im, 0, 0);
      cv.__printWiped = wiped;
    } catch (e){}
  }

  function armColour(cv){
    /* Reading every pixel of the cut-out to find the frame's colour is
       cheap once and ruinous sixty times a second, so the answer is
       kept on the canvas it came from. */
    if (cv.__armColour !== undefined) return cv.__armColour;
    try {
      const x = cv.getContext('2d');
      const d = x.getImageData(0, 0, cv.width, cv.height).data;
      let r = 0, g = 0, b = 0, n = 0;
      const y0 = Math.round(cv.height * 0.25), y1 = Math.round(cv.height * 0.75);
      for (let y = y0; y < y1; y++){
        for (let side = 0; side < 2; side++){
          const from = side ? cv.width - 1 : 0;
          const step = side ? -1 : 1;
          for (let k = 0; k < cv.width * 0.25; k++){
            const i = ((y * cv.width) + (from + step * k)) * 4;
            if (d[i+3] > 200){ r += d[i]; g += d[i+1]; b += d[i+2]; n++; break; }
          }
        }
      }
      if (!n){ cv.__armColour = null; return null; }
      cv.__armColour = 'rgb(' + Math.round(r/n) + ',' + Math.round(g/n) + ',' + Math.round(b/n) + ')';
      return cv.__armColour;
    } catch (e){ cv.__armColour = null; return null; }
  }

  /* Quick AI fit report.
     A normal selfie does not contain a ruler, so this is an estimated
     fit using facial proportions and the frame's real stored width. It
     deliberately reports confidence instead of pretending millimetres
     are clinical measurements. */
  function fitReport(face, frameCanvas, widthMM, opts){
    opts=opts||{};
    if(!face||!face.pd||!frameCanvas||!widthMM) return null;
    /* d17.29: the customer's PD -- typed, else estimated from THEIR irises (about 12 mm across), and only then the
       63 mm average. The badge used to assume 63 mm for everyone, so on a small or wide face it could be wrong. */
    let pdMM=Number(opts.pdMM)||0;
    if(!pdMM && face.irisPx>0 && face.pd>0){ const share=face.irisPx/face.pd; if(share>0.10&&share<0.40){ const est=face.pd/(face.irisPx/12.0); if(est>46&&est<80) pdMM=est; } }
    if(!pdMM) pdMM=63;
    let perMM=face.pd/pdMM;
    /* d17.87: the locked measurement of this face, when the live try-on has one -- the advice never changes as you move */
    if(Number(opts.perMM)>0 && !Number(opts.pdMM)){ perMM=Number(opts.perMM); pdMM=face.pd/perMM; }
    const faceMM=perMM ? (face.faceW||0)/perMM : 0;
    const frameMM=Number(widthMM)||0;
    const diff=faceMM ? frameMM-faceMM : 0;
    let status='GOOD FIT', size='Medium', reason='Frame width is close to your estimated face width.';
    /* The band was +/-6mm with a "check" zone from 3. On the shop
       owner's own face a 137mm frame read GOOD FIT and a 140mm frame
       MAY BE WIDE -- both fit him well in the hand. Face width from a
       photograph is an estimate; a band that flips on 3mm flips on
       noise. Wider band, softer words (d16.16). The shop's own
       tolerance, once given, replaces these numbers. */
    /* d17.88: "Perfect fit" only within 5 mm (about one size group) -- 10 mm let a Medium frame read Perfect on a face the
       same page called Wide; up to 14 mm stays "Good fit", so 2-3 mm never tips anyone into "a little wide/narrow" */
    /* d17.90: "Perfect fit" = the frame is inside the customer's own size range (face width +- 4 mm), the same range the
       page shows as "Your frame size" -- so the two can never disagree */
    const OK = opts.okMM || 4, CHECK = opts.checkMM || 14;
    if(faceMM){
      if(diff>CHECK){status='MAY BE WIDE';reason='This frame is on the wide side for your estimated face width.';}
      else if(diff<-CHECK){status='MAY BE NARROW';reason='This frame is on the narrow side for your estimated face width.';}
      else if(Math.round(frameMM)<Math.round(Math.round(faceMM*10)/10-OK)||Math.round(frameMM)>Math.round(Math.round(faceMM*10)/10+OK)){status='GOOD / CHECK FIT';   /* d17.90: decided on the SAME rounded mm the customer sees ("Your frame size: lo–hi mm" and "135 mm"), so the two can never disagree */reason='This frame is close to your estimated fit range.';}
    }
    /* SIZE BANDS (22 Sep, shop): Medium used to stop at 142mm, so a 143mm
       frame that fits well was labelled Large one millimetre over. Men's
       frames run 140-146 routinely, so Medium now covers 134-146. */
    if(frameMM<134) size='Small'; else if(frameMM<=146) size='Medium'; else size='Large';
    const LN=frameCanvas.lenses;
    /* ONE VERDICT FOR THE CUSTOMER (d16.26).

       This used to add a third badge -- "Frame PD differs from face
       PD" -- beside GOOD FIT, which read as a contradiction: the frame
       fits, and also something is wrong. Nothing was wrong. Lens
       centres sit wider than the eyes on almost every frame (a 52-18
       has its centres 70mm apart; eyes are 60-66) and the optician
       decentres the lenses as a matter of routine. The number is a
       real measurement and stays in the trial readout for the shop.
       The customer is never told about it: the shop's decision is two
       badges only, the fit verdict and the frame size. */
    let pupil='', lensGapMM=null, decentration=null;
    if(LN&&LN.length>=2){
      lensGapMM=(LN[1].x-LN[0].x)*frameMM;
      decentration=(lensGapMM-pdMM)/2;
      const a=Math.abs(decentration);
      pupil='';   /* nothing for the customer, by the shop's decision */
    }
    return {status,size,reason,frameMM:Math.round(frameMM*10)/10,
      faceMM:faceMM?Math.round(faceMM*10)/10:null,pupil,
      lensGapMM:lensGapMM?Math.round(lensGapMM*10)/10:null,
      decentration:decentration==null?null:Math.round(decentration*10)/10,
      confidence:(Math.abs(face.yaw||0)<.08&&Math.abs(face.roll||0)<.08)?'High for visual fit':'Medium'};
  }

  /* d17.101 (shop, 9 Oct: "in the LIVE front view, let the frame turn with the head 10-15 degrees each way and show the
     side going back to the hair"): the front cut-out seen turned. A frame front is not flat -- each half bends back about
     8 degrees from the bridge (face form) -- so on a head turned by T the near half is seen at (T - 8) and the far half at
     (T + 8). The front photo already shows both halves at 8, so relative to it the near half is cos(T-8)/cos 8 wide and
     the far half cos(T+8)/cos 8. Heights never change. Split at the bridge (the middle between the lens centres); the
     lens boxes and the measured hinge pieces are carried over, so the arm join works exactly as on the straight view. */
  function turnFront(fc, deg, nearRight){
    const L = fc && fc.lenses; if (!L || L.length < 2 || !(Math.abs(deg) >= 1)) return null;
    const W = fc.width, H = fc.height, bx = (L[0].x + L[1].x) / 2 * W;
    const th = Math.abs(deg) * Math.PI / 180, F8 = 8 * Math.PI / 180, c8 = Math.cos(F8);
    const kN = Math.cos(th - F8) / c8, kF = Math.cos(th + F8) / c8;
    const kL = nearRight ? kF : kN, kR = nearRight ? kN : kF;            /* nearRight: the picture's right half is the near one */
    const wL = Math.max(1, Math.round(bx * kL)), wR = Math.max(1, Math.round((W - bx) * kR));
    const c = document.createElement('canvas'); c.width = wL + wR; c.height = H;
    const g = c.getContext('2d'); g.imageSmoothingEnabled = true; if ('imageSmoothingQuality' in g) g.imageSmoothingQuality = 'high';
    g.drawImage(fc, 0, 0, bx, H, 0, 0, wL, H);
    g.drawImage(fc, bx, 0, W - bx, H, wL, 0, wR, H);
    const mapX = xn => { const px = xn * W; return (px <= bx ? px * kL : wL + (px - bx) * kR) / c.width; };
    c.lenses = L.map(l => ({ x: mapX(l.x), y: l.y, w: l.w * W * ((l.x * W) <= bx ? kL : kR) / c.width, h: l.h }));
    ['hinges', 'alreadyCut', 'armsInLensCleared', 'lensesEstimated', 'armCornerInfo'].forEach(k => { if (fc[k] !== undefined) c[k] = fc[k]; });
    c.turned = { deg: +Math.abs(deg).toFixed(1), nearRight: !!nearRight, nearK: +kN.toFixed(4), farK: +kF.toFixed(4), widthRatio: c.width / W, bridgeX: wL / c.width };
    return c;
  }
  /* the bridge's underside, as a fraction of the frame picture's height: at the bridge column (between the lens centres),
     the bottom of the first solid run from the top (cached on the picture) */
  function bridgeUnderFrac(fc){
    if (fc.__bridgeUnder !== undefined) return fc.__bridgeUnder;
    let r = null;
    try {
      const L = fc.lenses; if (L && L.length >= 2){
        const W = fc.width, H = fc.height, bx = Math.round((fc.turned ? fc.turned.bridgeX : (L[0].x + L[1].x) / 2) * W);
        const d = fc.getContext('2d').getImageData(Math.max(0, bx - 2), 0, 5, H).data, ys = [];
        for (let k = 0; k < 5; k++){ let y = 0; while (y < H && d[(y * 5 + k) * 4 + 3] <= 60) y++; if (y >= H) continue; while (y + 1 < H && d[((y + 1) * 5 + k) * 4 + 3] > 60) y++; ys.push(y); }
        if (ys.length >= 3){ ys.sort((a, b) => a - b); const u = ys[ys.length >> 1] / H; if (u > 0.05 && u < 0.7) r = u; }
      }
    } catch (e){ r = null; }
    fc.__bridgeUnder = r; return r;
  }
  /* where the hinge plate ends along the real arm's photo strip (x = 0 is the hinge): the first place the arm's band
     turns clearly lighter than the dark plate and stays so; 0 when the arm has no separate plate (cached on the arm) */
  function plateEndPx(RA){
    if (RA.__plateEnd !== undefined) return RA.__plateEnd;
    let r = 0;
    try {
      const S = RA.canvas, W = S.width, H = S.height, y0 = Math.max(0, Math.round(RA.padPx || 0)), th = Math.max(2, Math.round(RA.thickPx || H));
      const d = S.getContext('2d').getImageData(0, y0, W, Math.min(th, H - y0)).data, hh = Math.min(th, H - y0), lum = [];
      for (let X = 0; X < W; X++){ let s = 0, n = 0; for (let Y = 0; Y < hh; Y++){ const j = (Y * W + X) * 4; if (d[j + 3] > 100){ s += 0.299 * d[j] + 0.587 * d[j + 1] + 0.114 * d[j + 2]; n++; } } lum.push(n > hh * 0.3 ? s / n : null); }
      const head = lum.slice(0, Math.max(3, Math.round(W * 0.06))).filter(v => v != null), plate = head.length ? head.reduce((a, b) => a + b, 0) / head.length : null;
      if (plate != null) for (let X = 3; X < W * 0.45; X++){
        const thr = plate + Math.max(12, plate * 1.2); let sm = 0, n = 0, low = 0; for (let k = 0; k < 8; k++){ const v = lum[X + k]; if (v == null){ low = 9; break; } sm += v; n++; if (v < plate + 6) low++; }
        if (n === 8 && low === 0 && sm / n >= thr){ r = X; break; }
      }
    } catch (e){ r = 0; }
    RA.__plateEnd = r; return r;
  }
  /* the nose ridge's x at height y (the ridge runs from between the eyes down to the tip) */
  function ridgeXAt(face, y){
    const rg = Array.isArray(face.noseRidge) ? face.noseRidge.filter(p => p && isFinite(p.x) && isFinite(p.y)).sort((p, q) => p.y - q.y) : [];
    if (rg.length < 2) return face.noseSeat ? face.noseSeat.x : null;
    if (y <= rg[0].y) return rg[0].x;
    for (let i = 0; i < rg.length - 1; i++) if (y >= rg[i].y && y <= rg[i + 1].y) return rg[i].x + (rg[i + 1].x - rg[i].x) * (y - rg[i].y) / ((rg[i + 1].y - rg[i].y) || 1);
    return rg[rg.length - 1].x;
  }
  function compose(faceImg, face, frameCanvas, widthMM, opts){
    opts = opts || {};
    /* d17.101: the live view passes the head's turn (degrees, skull points); 0-1 degree is drawn straight */
    const TURN = isFinite(opts.turnDeg) ? Math.abs(opts.turnDeg) : null;
    if (TURN != null && TURN >= 1){ if (frameCanvas.lenses && frameCanvas.lenses.length >= 2) wipePrint(frameCanvas, frameCanvas.lenses); const tf = turnFront(frameCanvas, TURN, !!opts.turnNearRight); if (tf){ tf.__printWiped = frameCanvas.__printWiped; widthMM = (Number(widthMM) || 140) * tf.turned.widthRatio; frameCanvas = tf; } }
    const out = document.createElement('canvas');
    out.width = face.w; out.height = face.h;
    const x = out.getContext('2d');
    /* Draw the frame at the best quality the browser offers (d16.33).
       Without this a canvas uses fast, low-quality scaling, and the
       rim's edge -- the one thing the customer looks at -- comes out
       soft on a high-resolution phone screen. */
    x.imageSmoothingEnabled = true;
    if ('imageSmoothingQuality' in x) x.imageSmoothingQuality = 'high';
    x.drawImage(faceImg, 0, 0, face.w, face.h);

    /* Work out how many pixels a millimetre is, two different ways.

       Pupil distance alone was the old method. It is fine on a
       straight-on photo but drifts badly the moment the head turns,
       because the pupils close up while the face does not. Temple
       width holds up much better under a turn. Neither is reliable on
       its own, so take both and lean on whichever the pose favours:
       square on, trust the pupils; turned, trust the temples. */
    /* Where the lenses are, worked out rather than hunted for.

       The cutter finds a lens by looking for an enclosed light area
       inside the rim. On a black acetate frame that works perfectly.
       It cannot work on a half-rim, because there is no bottom rim and
       nothing is enclosed; and it cannot work on a clear crystal frame,
       because the rim is barely darker than the sheet behind it. Both
       are a large part of what the shop sells, and both were falling
       back to a fixed guess of 22% and 78%.

       But the answer is already known. The distance between the two
       lens centres IS lens width plus bridge, and the frame's total
       width is measured too -- both are printed on the lens and both
       are typed into admin. On this GOLD frame, 51 + 18 = 69mm across a
       142mm frame: the centres sit at 24.3% either side of the middle,
       not the 28% the fixed guess assumed.

       So when detection fails, calculate instead of guessing. It needs
       nothing from the photograph, which is exactly why it works on the
       frames the photograph cannot answer for. */
    let LN0 = frameCanvas.lenses;
    if (frameCanvas.lensesEstimated && opts.ocMM > 20 && widthMM > 60){
      const share = Math.max(0.30, Math.min(0.62, opts.ocMM / widthMM));
      const half  = share / 2;
      /* Photographs include a little beyond the frame itself -- hinge
         barrels, a folded arm tip, the margin the camera left. Measure
         how much wider the cut-out is than the frame and allow for it,
         so the centres are placed against the frame rather than against
         the edges of the picture. */
      const lensH = (LN0 && LN0[0] && LN0[0].h) ? LN0[0].h : 0.55;
      /* The box has to be the DEMO LENS -- the opening inside the rim --
         never the rim itself. A box drawn to the outer rim contains
         frame, and anything inside a box that does not run out of it
         gets removed, so the rim is what gets eaten.

         share * 0.62 was a fudge with no measurement behind it. The
         lens width in millimetres is typed into admin and is exactly
         this number: the demo lens, measured inside the rim. Divided
         by the frame's total width it gives the lens as a fraction of
         the picture directly. 0.92 keeps the box just inside the
         glass so the surrounding rim is never included. */
      const lensW = (opts.lensMM > 10 && opts.lensMM < widthMM)
        ? (opts.lensMM / widthMM) * 0.92
        : share * 0.62;
      LN0 = [{ x: 0.5 - half, y: 0.5, w: lensW, h: lensH },
             { x: 0.5 + half, y: 0.5, w: lensW, h: lensH }];
      frameCanvas.lensesCalculated = true;

      /* And now the supplier's printing can go.

         Frames arrive with the model number and size printed on one
         lens and a brand logo on the other -- "27027 51-18-142",
         "GOLD EYEWEAR". They are dark, so the cutter keeps them exactly
         as it keeps the frame, and they end up sitting on the
         customer's cheek. Three frames out of three had it.

         This could not be done before, because it was never certain
         where the lens was. Now it is: the box comes from the frame's
         own measurements. A printed mark is small and floats free
         inside that box; a rim is large and runs out of it. Only marks
         with both properties are removed, so the frame cannot be
         eaten. */
    }

    /* Take the supplier's printing off, however the lens boxes were
       arrived at.

       This used to sit inside the branch above, which only runs when
       the lens positions have to be CALCULATED because detection
       failed. On a good white-background photo of a dark frame,
       detection succeeds -- so the wipe was skipped and the model
       number and brand logo stayed on the lens and landed on the
       customer's cheek. The better the photograph, the less likely the
       printing was removed, which is exactly backwards.

       A printed mark is small and floats free inside the lens box; a
       rim is large and runs out of it. Only marks with both properties
       go, so the frame itself cannot be eaten. */
    if (LN0 && LN0.length >= 2) wipePrint(frameCanvas, LN0);

    /* Trim outside the front's own corners. OFF unless asked for.

       opts.trimArms must be explicitly true. The shop never sets it;
       only the test page does, so this cannot affect a customer.

       It measures the outermost frame pixels along the lens band and
       clears everything beyond them. On the Fusion-X that finds 87px
       of arm -- and takes the gold hinge stripes with it, because that
       detail sits above the band. See the note below: widening the
       band to save the gold lets the arms inside it and then nothing
       is cut at all. Kept here so the result can be looked at rather
       than argued about. */
    if (opts.trimArms === true && LN0 && LN0.length >= 2){
      try {
        const fw = frameCanvas.width, fh = frameCanvas.height;
        const fx = frameCanvas.getContext('2d');
        const px = fx.getImageData(0, 0, fw, fh).data;
        const reach  = LN0[0].h * (opts.trimBand || 0.20);
        const bandY0 = Math.round(Math.max(0,    (LN0[0].y - reach) * fh));
        const bandY1 = Math.round(Math.min(fh-1, (LN0[0].y + reach) * fh));
        let left = fw, right = -1;
        for (let y = bandY0; y <= bandY1; y++){
          for (let x = 0; x < fw; x++)    if (px[((y*fw)+x)*4+3] > 120){ if (x < left)  left  = x; break; }
          for (let x = fw-1; x >= 0; x--) if (px[((y*fw)+x)*4+3] > 120){ if (x > right) right = x; break; }
        }
        frameCanvas.__frontWidthPx = (right > left) ? right - left + 1 : fw;
        if (right > left && (left > 3 || right < fw - 4)){
          const pad = 3;
          const L = Math.max(0, left - pad), R = Math.min(fw, right + 1 + pad);
          if (L > 0)  fx.clearRect(0, 0, L, fh);
          if (R < fw) fx.clearRect(R, 0, fw - R, fh);
          frameCanvas.__armsTrimmed = L + (fw - R);
        } else frameCanvas.__armsTrimmed = 0;
      } catch (e){}
    }

    /* REMOVING THE TEMPLES FROM A FRONT PHOTO -- FOUR ATTEMPTS, ALL
       REVERTED. Read this before trying a fifth.

       The temples show in a front photograph, folded behind the lenses
       or angled back across the front, and they land on the customer
       as a haze inside the glass and a shape at the temple corner.

       1. Fill the lens opening's convex hull.
          Did not cover the arm, and thinned the rim: 34px -> 30, 41 -> 33.

       2. Trim beyond the hinge using the total width typed in admin.
          Cut nothing on either real frame -- the arms angle back across
          the front, not sideways past it. Also unsafe: that box has
          repeatedly held the ARM LENGTH (140 for a 132mm front), and a
          total that is too small cuts into the frame.

       3. Measure the front's corners along the lens centre band.
          Found 87px of arm on the Fusion-X and cut it -- along with the
          GOLD HINGE STRIPES, which sit above that band.

       4. Same, with the band widened to the whole rim so the gold
          survives. The arms fall inside the wider band, so the measured
          front is the full picture and nothing is cut at all.

       3 and 4 together are the proof: no horizontal line through these
       photographs has arm on one side and only frame on the other. The
       arms overlap the front in every direction, so nothing measured
       from the picture can separate them.

       The fix is at the camera. Shoot with the arms opened straight out
       to the sides: then they lie outside the front, behind nothing,
       and both the cut-out and a hinge trim become trivial. */
    /* Divide by whatever pd actually measured.

       63mm is pupil to pupil. When the iris landmarks were unavailable
       pd is the distance between the outer eye corners instead, which
       is about 90mm on an adult -- dividing that by 63 made the frame
       roughly 40% too wide. */
    const EYE_MM  = opts.eyeCornerMM || 90;   // outer corner to outer corner
    let PD_MM = (face.irisUsed === false ? EYE_MM : 63);

    /* Scale from the IRIS where we can, not from an assumed 63mm.

       63mm is the average distance between an adult's pupils. A woman's
       is nearer 60, a child's 45-55, so the same frame came out several
       percent too large on one and up to a quarter too small on the
       other. The iris is about 11.7mm across on almost everybody,
       child included, so measuring it gives the real scale from the
       photograph itself.

       Only trusted when it agrees roughly with the pupil distance: an
       iris should be between a tenth and a third of the way across the
       eyes. Outside that the landmarks are wrong -- a half-shut eye, a
       blurred face -- and the old assumption is the safer answer. */
    /* 12.0, not 11.7 (d16.26). The 11.7 came from a world average.
       The shop's own counter experience of Indian eyes is 11.5-12.5,
       so the middle of that range is used; on a 12.4 iris the old
       figure drew everything 6% small, the new one 3%. A typed PD or
       the card photo still wins over any assumption. */
    const IRIS_MM = opts.irisMM || 12.0;
    let perMM_iris = 0;
    /* A PD the person actually gave wins outright.

       This measured the iris first and used it whenever it was
       available, so a real 64mm PD typed in from the shop machine was
       read, stored, and then quietly ignored. An 11.7mm average can
       never beat a number someone measured on that face. Only estimate
       when there is nothing better. */
    /* A PD from a machine is a DISTANCE PD. A selfie is not.

       Looking at a phone, the eyes converge, so the pupils in the
       photograph sit closer together than they do looking across a
       room. The optical relation is
           near PD = distance PD x w / (w + 27)
       with w the working distance and 27mm from the spectacle plane to
       the centres of rotation. At arm's length, about 350mm:
           64 x 350 / 377 = 59.4mm
       and the iris measured this face at 59.3 and 59.8 on two separate
       photographs. The iris was right; the comparison was wrong.

       So a typed-in distance PD has to be converted before it can be
       divided into a photograph, or the scale comes out 7% small and
       every frame is drawn 7% too large. */
    const WORK_MM = opts.workingMM || 350;
    const givenRaw = Number(opts.pdMM) || 0;
    const givenPD = (givenRaw >= 40 && givenRaw <= 82)
      ? givenRaw * WORK_MM / (WORK_MM + 27)
      : 0;
    if (!givenPD && face.irisPx > 0 && face.pd > 0){
      const share = face.irisPx / face.pd;
      if (share > 0.10 && share < 0.33) perMM_iris = face.irisPx / IRIS_MM;
    }
    const FACE_MM = opts.faceMM || 139;   // temple to temple, adult average
    const yaw = Math.abs(face.yaw || 0);

    if (givenPD) PD_MM = givenPD;
    const perMM_pd   = perMM_iris > 0 ? perMM_iris : (face.pd / PD_MM);
    const perMM_face = (face.faceW || 0) / FACE_MM;

    let perMM;
    if (!perMM_face) perMM = perMM_pd;
    else {
      const trustFace = Math.min(1, yaw / 0.35);          // 0 square on, 1 well turned
      perMM = perMM_pd * (1 - trustFace) + perMM_face * trustFace;
    }

    /* d17.87 THE FACE, MEASURED ONCE AND LOCKED: the live try-on measures this face over its first second (eyes open,
       straight on) and from then on gives the scale itself -- a blink, a shut eye or a turn no longer changes the size */
    if (Number(opts.perMM) > 0) perMM = Number(opts.perMM);
    let scale = (perMM * (widthMM || 140)) / frameCanvas.width;

    /* Scale from the lenses, not the edges of the photograph.

       The line above sizes the frame by assuming the picture is
       exactly as wide as the frame. It is not: a product shot carries
       hinges, folded arms, a shadow and whatever white margin the
       camera left. Those margins differ from photo to photo, so the
       same 140mm frame came out a different size depending on how it
       was shot, and no amount of fit tuning could correct it because
       the reference itself was wrong.

       Lens width and bridge are both mandatory in admin, and the
       distance between the two lens centres IS lens + bridge. That is
       a hard number in millimetres, and the cut-out already reports
       where those two centres sit in the picture. Scaling one against
       the other is exact and ignores the margins entirely. Measured
       against a known 122mm frame front: photo-width sizing was 9%
       out with the arms hidden and 11% out with them showing; this is
       exact in both cases. */
    const ocMM = Number(opts.ocMM) || 0;
    if (ocMM > 20 && LN0 && LN0.length >= 2 && !frameCanvas.lensesEstimated){
      const gapPx = Math.abs(LN0[1].x - LN0[0].x) * frameCanvas.width;
      if (gapPx > 8){
        const measured = (perMM * ocMM) / gapPx;
        /* Trust this over the photo estimate by a wide margin: it is
           built from two real millimetre measurements and two detected
           lens centres. The bounds only catch a genuinely misread lens
           region -- half size or double is a detection failure, not a
           frame. */
        if (measured / scale > 0.5 && measured / scale < 2.0) scale = measured;
      }
    }

    /* Fit to the lenses, not to the outline.

       Sizing by the overall width of the picture assumes the lenses
       fall wherever the average frame's lenses fall. They do not, and
       the result was pupils sitting off toward the nose or out past
       the rim -- which is exactly what an optician would reject.

       When the cut-out told us where its two lenses are, size the
       frame so the gap between the lens centres equals this face's
       pupil distance. Then the pupils land in the middle of the
       lenses, which is the whole point. */
    const LN = LN0;
    let lensMidX = 0.5, lensMidY = null;
    if (LN && face.pd > 0){
      /* Keep the REAL frame-size scale. The old version resized every
         frame until its two lens centres exactly matched the customer's
         two pupils. That made a small and a large frame look almost the
         same size and defeated AI fit guidance. We still use the detected
         lens centres as the alignment anchor, but do not change scale to
         force a false geometric fit. */
      lensMidX = (LN[0].x + LN[1].x) / 2;
      lensMidY = (LN[0].y + LN[1].y) / 2;
    }

    /* Keep the real frame width, but correct a SMALL amount when the
       detected lens-centre spacing and the customer's pupil spacing disagree.
       Pure true-size scaling can leave both pupils visibly off-centre because
       a front product photo includes hinges/arms and transparent margins.
       Pure PD scaling makes every frame look the same size. A bounded blend
       (max about 5%) gives natural visual seating without falsifying size. */
    /* Only when there is no real measurement to work from. Once the
       scale comes from lens + bridge in millimetres it is exact, and
       nudging it toward "pupils dead centre" makes it wrong again: a
       70mm frame on a 63mm face SHOULD sit 3.5mm wide of each pupil,
       and hiding that hides real fitting information. */
    if (!ocMM && TURN == null && LN && LN.length >= 2 && face.pd > 0){   /* d17.101: not on the live view -- the pupils follow the screen there */
      const lensGapPx = Math.abs(LN[1].x - LN[0].x) * frameCanvas.width * scale;
      if (lensGapPx > 8){
        const want = Math.max(0.94, Math.min(1.06, face.pd / lensGapPx));
        scale *= (1 + (want - 1) * 0.78);
      }
    }

    if (opts.sizeTrim) scale *= opts.sizeTrim;
    let w = frameCanvas.width * scale;
    const h = frameCanvas.height * scale;

    /* A turned head shows the frame at an angle, so it covers less
       width. Squeezing by the cosine of the turn is the same thing a
       3D model would do, just approximated. */
    if (TURN == null) w *= Math.cos(yaw * Math.PI / 2 * 0.55);   /* d17.101: the live view turns the frame itself (turnFront) */

    // Optical centre of the lens on the pupil line, same rule an
    // optician fits to.
    /* Horizontally, sit on the nose bridge if we found it. On a turned
       head the midpoint between the pupils drifts toward the near
       side, which slid the frame off centre; the bridge does not
       move. Vertically stay on the pupil line -- that is where an
       optician sets the optical centre. */
    const pupilCx = (face.pupilR.x + face.pupilL.x) / 2;
    /* Blend the nose bridge and pupil midpoint. The bridge is the true
       mechanical centre of a worn frame; the pupil midpoint keeps the
       fit stable when a landmark is noisy. */
    /* On the straight-on photo that try-on requires, the two pupil
       centres are the most stable horizontal fitting anchor. Use the nose
       bridge only as a light stabiliser; relying on it heavily pulled the
       front sideways on some faces. */
    /* THE FRAME GOES WHERE THE NOSE IS.

       This centred the frame between the pupils, which is what an
       optician measures but not what a worn frame does. Glasses rest
       ON THE NOSE -- that is the contact point holding them up. When
       someone's nose is not exactly midway between their pupils, a
       real pair sits where the nose is and the lenses end up slightly
       off the pupils. That is the whole reason pads get bent at the
       counter: to pull the lenses back afterwards.

       Two different faces measured the same way round -- noses 1.4mm
       and 1.9mm off their own pupil midline, both to the same side --
       and on both the bridge looked pressed against one side of the
       nose while the other side showed a gap. Pupil centring was
       putting the bridge where no real frame would sit.

       So anchor horizontally on the nose. The resulting distance from
       the pupil centre is not an error to be removed; it is a real
       measurement, and it is reported for the fit rather than hidden.

       The limit below is only for a misread landmark: a nose more than
       8mm off the pupil midline is a detection failure, not a face. */
    let cx = pupilCx;
    const noseX = (face.noseAxisX && isFinite(face.noseAxisX))
      ? face.noseAxisX
      : (face.noseSeat ? face.noseSeat.x : 0);
    if (noseX){
      const limit = (perMM > 0 ? perMM : 1) * (opts.noseLimitMM || 8);
      const off = noseX - pupilCx;
      cx = pupilCx + Math.max(-limit, Math.min(limit, off));
    } else if (face.bridge){
      cx = face.bridge.x;
    }
    /* d17.101: on the live view the bridge goes ON THE NOSE RIDGE at eye level (the eye corners' line) -- never between the
       pupils, which follow the screen as the head turns */
    if (TURN != null && face.cornerOut33 && face.cornerOut263){
      const rX = ridgeXAt(face, (face.cornerOut33.y + face.cornerOut263.y + (face.cornerIn133 ? face.cornerIn133.y + face.cornerIn362.y : face.cornerOut33.y + face.cornerOut263.y)) / 4);
      if (isFinite(rX)) cx = rX;
    }
    const pupilCy = (face.pupilR.y + face.pupilL.y) / 2;
    /* The detected lens-centre line belongs on the pupil line. Previous
       builds deliberately dropped it by 7.5% of the frame height, which is
       why a progressive/optical frame could look as though the pupil was in
       the wrong part of the lens. Keep only a tiny natural wearing drop. */
    /* A worn frame sits with the pupil slightly above the geometric lens
       centre. A small downward seating allowance prevents the upper rim
       riding on the eyebrow without falsifying the frame's true size. */
    /* ONE RULE FOR HEIGHT.

       This was three rules, and they fought each other. A drop taken
       from the lens depth, then a nose anchor blended 45/55, then an
       eyebrow push that ran last and therefore won. Measured on a real
       face: the nose anchor put the frame 11mm too HIGH, the eyebrow
       rule shoved it 19mm too LOW, and which one you got depended on
       which code path had built the face. Each rule had been added to
       correct the previous one without the previous one being removed.

       An optician sets the optical centre of the lens on the pupil.
       That is the whole rule, and it is the one thing here that is not
       a guess. A couple of millimetres below allows for the fact that
       a worn frame settles slightly, which is what a dispensing
       fitting height allows for too.

       Measured in millimetres rather than as a share of the picture,
       so a tall photo with folded arms and a tightly cropped one place
       the frame identically. */
    const SEAT_MM = opts.seatMM == null ? 6 : opts.seatMM;   /* 3 Oct 2026, shop: "4 mm down" (was 2) -- chosen on the AI model from 2/4/6/8 */
    const cy = pupilCy + (perMM > 0 ? perMM * SEAT_MM : 0);

    /* Where the lens centre sits inside the cut-out. Measuring where
       the ink actually is, rather than assuming the middle of the
       picture, is what makes the rule above land correctly on a frame
       photographed with its arms folded back. */
    const anchorY = lensMidY != null ? lensMidY
                  : (opts.anchorY != null ? opts.anchorY : lensLine(frameCanvas));
    let dy = (0.5 - anchorY) * h;

    /* The eyebrow limit, demoted to what it should always have been:
       a guard, not a positioning rule.

       It fires only when the rim would genuinely cover the brow, moves
       only as far as needed to clear it, and can never shift the frame
       more than 6mm. Previously it could move the frame by 30% of the
       picture height, which on an arms-folded photo was enough to put
       the lenses on the nose tip. */
    if (face.browR && face.browL && LN && LN.length >= 2){
      const browY   = Math.max(face.browR.y, face.browL.y);   // lower of the two
      const lensTop = Math.min(LN[0].y - LN[0].h / 2, LN[1].y - LN[1].h / 2);
      const topFrac = Math.max(0, lensTop - Math.max(LN[0].h, LN[1].h) * 0.12);
      const frameTop = cy + dy + (topFrac - 0.5) * h;
      /* Real frames touch the eyebrow -- plenty of people wear them
         that way, and a deep frame always will. The guard is for
         "glasses on the forehead", not for "rim near the brow", so it
         allows the rim to reach 5mm above the lower brow edge before
         it does anything at all. Without this allowance it fired on
         ordinary frames and quietly added 6mm of drop to every face. */
      const allow = perMM > 0 ? perMM * 5 : h * 0.05;
      const limit = perMM > 0 ? perMM * 6 : h * 0.06;
      const push = (browY - allow) - frameTop;
      if (push > 0) dy += Math.min(push, limit);

      if (opts.debug){
        opts.debug.browY    = browY;
        opts.debug.frameTop = frameTop;
        opts.debug.topFrac  = topFrac;
        opts.debug.browPush = push > 0 ? Math.min(push, limit) : 0;
        opts.debug.browCapped = push > limit;
      }
    }


    const dx = (0.5 - lensMidX) * w;

    if (opts.debug){
      const dbg = opts.debug;
      dbg.frameH          = h;
      dbg.lensesFound     = !!(LN && LN.length >= 2);
      dbg.lensesEstimated = !!frameCanvas.lensesEstimated;
      if (LN && LN.length >= 2) dbg.lensBox = { y:+LN[0].y.toFixed(3), h:+LN[0].h.toFixed(3) };
      dbg.pupilY        = pupilCy;
      dbg.noseSeatY     = face.noseSeat ? face.noseSeat.y : null;
      dbg.seatDrop      = perMM > 0 ? perMM * SEAT_MM : 0;
      dbg.cy            = cy;
      dbg.anchorY       = anchorY;
      dbg.dyFinal       = dy;
      dbg.lensCentreY   = cy + dy;
      dbg.lensVsPupilPx = +((cy + dy) - pupilCy).toFixed(1);
      if (face.pd > 0) dbg.lensVsPupilMM = +(((cy + dy) - pupilCy) * (63 / face.pd)).toFixed(1);
      /* Sideways as well as up and down. A frame can sit at the right
         height and still be off toward one ear, which reads as the
         bridge not being on the nose. Positive means the frame sits to
         the LEFT of the picture's centre line between the pupils. */
      /* HOW FAR THE PHONE IS TILTED UP OR DOWN.

         The code measures head tilt sideways and turn left-right, but
         nothing about a camera held low and angled up -- ceiling and
         nostrils in shot. That photo lands the frame low and nothing
         detects it.

         A 2D mesh has no true pitch, but the face foreshortens in a
         readable way: seen from below the nose tip drops relative to
         the chin and the forehead compresses. The ratio below is that
         signal. It is REPORTED ONLY for now -- the threshold has to be
         read off real photographs, level and angled, before anything
         is refused on the strength of it. */
      if (face.noseTip && face.chin){
        const eyeToNose = face.noseTip.y - pupilCy;
        const eyeToChin = face.chin.y - pupilCy;
        if (eyeToChin > 1) dbg.pitchRatio = +(eyeToNose / eyeToChin).toFixed(3);
      }
      dbg.irisPx        = face.irisPx || 0;
      dbg.scaleFrom     = perMM_iris > 0 ? 'iris ('+IRIS_MM+'mm)'
                        : (givenPD
                            ? 'your PD ' + givenRaw + 'mm, converted to ' + givenPD.toFixed(1) + 'mm for this distance'
                            : 'assumed PD ' + PD_MM.toFixed(0) + 'mm');
      if (perMM_iris > 0){
        dbg.nearPD_MM = +(face.pd / perMM_iris).toFixed(1);
        dbg.distancePD_MM = +(dbg.nearPD_MM * (WORK_MM + 27) / WORK_MM).toFixed(1);
      }
      dbg.pupilMidX     = pupilCx;
      /* Where the nose sits relative to the midpoint between the
         pupils. Glasses are centred on the pupils, so if the nose is
         not midway between them the bridge will look closer to one
         side however perfectly the frame is placed. Measuring it says
         whether an off-centre look is the code or the face. */
      if (face.noseSeat){
        dbg.noseSeatVsPupilPx = +(face.noseSeat.x - pupilCx).toFixed(1);
        dbg.noseVsPupilMidPx = +(((face.noseAxisX || face.noseSeat.x)) - pupilCx).toFixed(1);
        if (face.pd > 0)
          dbg.noseVsPupilMidMM = +(dbg.noseVsPupilMidPx * (63 / face.pd)).toFixed(1);
      }
      dbg.frameMidX     = cx + dx;
      dbg.sidewaysPx    = +((cx + dx) - pupilCx).toFixed(1);
      if (face.pd > 0) dbg.sidewaysMM = +(((cx + dx) - pupilCx) * (63 / face.pd)).toFixed(1);
    }

    /* d17.102 (shop, 9 Oct: "compare left and right -- the frame is not sitting on the nose"): the nose ridge slopes, so
       its x is taken where the BRIDGE actually rests -- the bridge's underside, measured in this frame's picture -- not at
       the eye-corner line, which is lower (on a turned head that put the bridge ~3 mm toward the far side of the nose) */
    let bridgeY = null;
    if (TURN != null && face.noseRidge){
      const uF = bridgeUnderFrac(frameCanvas);
      if (uF != null){
        const co0 = Math.cos(face.roll || 0), si0 = Math.sin(face.roll || 0), bxL = ((frameCanvas.turned ? frameCanvas.turned.bridgeX : lensMidX) - 0.5) * w, byL = (uF - 0.5) * h;
        bridgeY = cy + dy + bxL * si0 + byL * co0;
        const rX2 = ridgeXAt(face, bridgeY), bxNow = cx + dx + bxL * co0 - byL * si0;
        if (isFinite(rX2)) cx += rX2 - bxNow;
      }
    }
    if (opts.debug) opts.debug.frameRect = { cx: cx + dx, cy: cy + dy, w: w, h: h, roll: face.roll || 0, perMM: perMM, turned: frameCanvas.turned || null, bridgeAt: cx, bridgeY: bridgeY };   /* d17.65: where the frame was drawn */
    x.save();
    x.translate(cx + dx, cy + dy);
    x.rotate(face.roll);          // follow the head tilt

    /* The arms.

       A frame is photographed from the front, so its arms are folded
       and there is nothing to paste. Without them the frame floats on
       the face like a sticker -- the shop said so, and was right. Draw
       them: a tapered line from the outer top corner of each rim back
       to the side of the head, behind the frame, in the frame's own
       colour. It is a drawing, not a photograph, but it is where a
       real arm goes and it reads as a pair of glasses.

       Skipped when the face landmarks are not there to aim at. */
    const arm = armColour(frameCanvas);
    /* Do not invent a temple when the product photo does not contain one.
       A 2D FaceMesh lateral-head point is not an ear landmark, and drawing a
       synthetic arm from it caused the vertical bars seen beside the eyes.
       Real temple pixels already present in the frame cut-out remain intact.
       Synthetic arms can still be explicitly enabled for controlled assets. */
    if (opts.drawSyntheticArms === true && arm && face.templeR && face.templeL){
      /* The hinge is the outer edge of the rim, at the lens line.

         In the frame's own coordinates the picture is drawn from
         (-w/2, -h/2), and the lens line has already been shifted onto
         the pupil line, so the lens line sits at local y = -dy. Turn
         that corner through the head tilt to find it on the face. */
      const co = Math.cos(face.roll), si = Math.sin(face.roll);
      const armW = Math.max(2, h * (opts.armWidth == null ? 0.055 : opts.armWidth));
      x.save();
      x.rotate(-face.roll);
      x.translate(-(cx + dx), -(cy + dy));
      x.strokeStyle = arm;
      x.lineWidth = armW;
      x.lineCap = 'round';
      x.globalAlpha = 0.92;
      [[-1, face.templeR], [1, face.templeL]].forEach(function(pair){
        const side = pair[0], ear = pair[1];
        if (!ear) return;
        /* The far arm disappears behind the head once it turns. */
        const away = (side < 0 && face.yaw > 0.18) || (side > 0 && face.yaw < -0.18);
        if (away) return;
        /* The spectacle temple joins at the hinge near the upper outer
           rim, not through the optical centre. Starting it on the pupil
           line was the reason the arm visibly crossed the eye. */
        const lx = side * (w / 2), ly = -dy - h * 0.16;
        const hx = cx + dx + lx * co - ly * si;
        const hy = cy + dy + lx * si + ly * co;
        /* Stop short of the ear so the arm tucks behind it rather
           than ending on top of it. */
        const tx = hx + (ear.x - hx) * 0.985;
        /* FaceMesh's lateral head point sits nearer the temple than the
           actual top of the ear. Derive a minimum ear-rest level from
           the eye line and face length so the arm cannot finish up near
           the eyebrow. */
        const eyeLine = pupilCy;
        const minRestY = eyeLine + Math.max(h * 0.18, (face.faceL || h * 5) * 0.035);
        const earRestY = Math.max(ear.y, minRestY);
        const ty = hy + (earRestY - hy) * 0.985;
        /* Never draw a fake vertical side-bar. If FaceMesh's lateral
           landmark is not actually behind the hinge in the image, there
           is not enough 2D information to draw a believable temple.
           Omitting that arm is far more realistic than a line down the
           side of the eye (the failure visible in the shop test photo). */
        const horizontalRun = side * (tx - hx);
        if(horizontalRun < Math.max(10, h * 0.16)) return;
        /* A soft dark under-stroke gives the arm depth, then the
           sampled frame colour sits on top. This reads much more like a
           real temple than a single flat line. */
        /* Keep the temple travelling naturally toward the ear. The old
           upward bow made the arm cross the eyebrow before reaching the
           side of the head. A very small downward/neutral bend reads like
           a real worn temple and finishes at ear height. */
        /* A real temple leaves the hinge nearly straight, then curves
           gently down over the ear. Bias the control point toward the ear
           and below the straight chord to produce that natural drop. */
        /* Real temples leave the hinge almost straight and only bend
           downward as they approach the ear. A cubic curve models that
           better than the old single quadratic bow. */
        const c1x = hx + (tx - hx) * 0.34;
        const c1y = hy + h * 0.015;
        const c2x = hx + (tx - hx) * 0.78;
        const c2y = ty - h * 0.045;
        x.save();
        x.strokeStyle = 'rgba(0,0,0,.24)';
        x.lineWidth = armW * 1.55;
        x.beginPath(); x.moveTo(hx,hy); x.bezierCurveTo(c1x,c1y,c2x,c2y,tx,ty); x.stroke();
        x.restore();
        x.strokeStyle = arm; x.lineWidth = armW;
        x.beginPath(); x.moveTo(hx,hy); x.bezierCurveTo(c1x,c1y,c2x,c2y,tx,ty); x.stroke();
        x.fillStyle = arm;
        x.beginPath(); x.arc(hx, hy, Math.max(1.4, armW*.7), 0, Math.PI*2); x.fill();
      });
      x.restore();
    }

    /* ARMS TO WHERE THE HAIR STARTS (d17.27, shop, 3 Oct 2026). Lenskart's front never shows an arm reaching the ear:
       it runs back from the hinge and disappears where the hair starts at the side of the head. Measured on THIS
       photo, per side:
         1. the hinge -- the outer end of the frame, a little above the lens line (as the old drawing);
         2. the eye's outer corner (130 / 359) and the side of the head beside the eye (127 / 356);
         3. the ear level (234 / 454), for the arm's slight drop;
         4. where the hair starts: from inside the temple outward along the arm's path, the first place the
            picture stops looking like this person's skin (and stays so for a few pixels);
         5. no hair found (bald, very short hair, hair the colour of the background): the side of the head.
       The arm ends a little into the hair, tapers and fades out over its last ~3.5 mm. An arm whose end would not
       lie outward of the hinge (a frame wider than the head) is not drawn at all -- that arm goes straight back
       and a front view would not show it. Off unless opts.armsToHair is true (the shop switches it on). */
    if (opts.armsToHair === true && face.templeR && face.templeL && face.eyeOutR && face.eyeOutL){
      const armInfo = { sides: [] };
      try {
        const col = armColour(frameCanvas) || 'rgb(40,40,44)';
        const pxmm = (w / Math.max(60, Number(widthMM) || 140));                    /* picture pixels per mm, from the frame's true width */
        /* the photo's own pixels, to tell skin from hair */
        const REAL = !!(opts.realArm && opts.realArm.canvas);
        let PD = null;
        if (!REAL || TURN != null){                                     /* d17.89: the real arm ends at the ear; d17.104: the live view needs the head's outline */
          const pc = document.createElement('canvas'); pc.width = face.w; pc.height = face.h;
          const pg = pc.getContext('2d', { willReadFrequently: true }); pg.drawImage(faceImg, 0, 0, face.w, face.h);
          PD = pg.getImageData(0, 0, face.w, face.h).data;
        }
        const px = (X, Y) => { if (!PD) return null; X = Math.round(X); Y = Math.round(Y); if (X < 0 || Y < 0 || X >= face.w || Y >= face.h) return null; const j = (Y * face.w + X) * 4; return [PD[j], PD[j + 1], PD[j + 2]]; };
        const co = Math.cos(face.roll), si = Math.sin(face.roll);
        /* skin is sampled just below the eye's outer corner, on the cheekbone -- hair never covers it there */
        const cheekPt = (eye, temple) => ({ x: eye.x, y: eye.y + (face.faceW || w) * 0.09 });
        /* d17.105 (shop, 9 Oct: "BOTH arms always, also at 15 degrees -- never remove one; as the head turns, the far arm gets
           SHORTER, pressed into the hair, and when the head comes back it grows again; the near arm grows"): on the live
           view each arm's length follows the turn smoothly. The straight-view length is the mean of the two sides' hinge-to-
           ear distances (this barely changes as the head turns, so it is steady), held to 18-28 mm; then
             near arm = that x (1 + 0.9 x turn/15)      far arm = that x (1 - turn/40)   (at 15 degrees: 1.9x and 0.63x) */
        let LIVE_ARM = null;
        if (REAL && TURN != null){
          const hingeX = side => { const HGq = frameCanvas.hinges, fyq = HGq ? (side < 0 ? HGq.yL : HGq.yR) : null, lyq = fyq != null ? (fyq - 0.5) * h : -dy - h * 0.16, lxq = side * (w / 2); return cx + dx + lxq * co - lyq * si; };
          const toEar = (side, ear) => ear ? side * (ear.x + side * 5 * pxmm - hingeX(side)) : null;
          const dR = toEar(-1, face.cheekR), dL = toEar(1, face.cheekL);
          const base = (dR != null && dL != null) ? (dR + dL) / 2 : 16 * pxmm;
          LIVE_ARM = { base: Math.max(18 * pxmm, Math.min(28 * pxmm, base)), nearSide: opts.turnNearRight ? 1 : -1 };
        }
        [[-1, face.templeR, face.eyeOutR, face.cheekR], [1, face.templeL, face.eyeOutL, face.cheekL]].forEach(function(S){
          const side = S[0], temple = S[1], eyeOut = S[2], earPt = S[3];
          const info = { side: side < 0 ? 'image-left' : 'image-right' };
          armInfo.sides.push(info);
          /* the far arm is hidden once the head turns */
          /* d17.103 (shop, 9 Oct: "this is a straight view we show the client -- keep BOTH arms"): with the real arm, both sides
             are always drawn; on a turned head the far arm shows a short piece behind its hinge and then goes behind the head */
          if (!REAL && ((side < 0 && face.yaw > 0.18) || (side > 0 && face.yaw < -0.18))){ info.skip = 'head turned away'; return; }
          /* 1. the hinge, in picture coordinates */
          /* d17.89: the hinge where THIS frame's end piece really is (measured from its picture), else the old estimate */
          const HG = frameCanvas.hinges, fy = HG ? (side < 0 ? HG.yL : HG.yR) : null;
          const lx = side * (w / 2), ly = fy != null ? (fy - 0.5) * h : -dy - h * 0.16;
          const hx = cx + dx + lx * co - ly * si, hy = cy + dy + lx * si + ly * co;
          info.hinge = [Math.round(hx), Math.round(hy)];
          /* 4. this person's skin, sampled on the cheekbone between the eye and the temple */
          const cp = cheekPt(eyeOut, temple); let sr = 0, sg = 0, sb = 0, sn = 0;
          for (let yy = -3; yy <= 3; yy++) for (let xx = -3; xx <= 3; xx++){ const p = px(cp.x + xx, cp.y + yy); if (p){ sr += p[0]; sg += p[1]; sb += p[2]; sn++; } }
          if (!sn && !REAL){ info.skip = 'no skin sample'; return; }
          if (!sn){ sr = sg = sb = 128; sn = 1; }
          sr /= sn; sg /= sn; sb /= sn;
          const skinL = 0.299 * sr + 0.587 * sg + 0.114 * sb;
          info.skin = [Math.round(sr), Math.round(sg), Math.round(sb)];
          const isSkin = p => { if (!p) return false; const d = Math.hypot(p[0] - sr, p[1] - sg, p[2] - sb); const L = 0.299 * p[0] + 0.587 * p[1] + 0.114 * p[2]; return d < 45 && Math.abs(L - skinL) < 50; };
          /* walk along the arm's path, from the hinge outward -- 2 mm below the hinge, clear of the eyebrow's tail */
          const yWalk = Math.max(hy + 2 * pxmm, Math.min(temple.y, hy + 4 * pxmm));
          const x0 = side > 0 ? Math.max(hx, eyeOut.x) : Math.min(hx, eyeOut.x), x1 = temple.x + side * 0.12 * (face.faceW || w);
          let hairX = null, run = 0, firstNon = null;
          for (let X = x0; side > 0 ? X <= x1 : X >= x1; X += side){
            const p = px(X, yWalk);
            if (isSkin(p)){ run = 0; firstNon = null; continue; }
            if (firstNon == null) firstNon = X;
            if (++run >= 4){ hairX = firstNon; break; }
          }
          /* 5. where the arm ends */
          let endX, how;
          /* d17.89 THE REAL ARM runs over the sideburn hair and rests on the TOP OF THE EAR, which is where a front photo
             shows it: it ends at the ear root (just outside the face outline at ear level) and fades behind the ear */
          if (opts.realArm && opts.realArm.canvas && earPt){
            endX = earPt.x + side * 5 * pxmm; how = 'real arm: to the top of the ear';
            if (LIVE_ARM){
              const near = TURN >= 1 && side === LIVE_ARM.nearSide, far = TURN >= 1 && !near;
              const run = LIVE_ARM.base * (far ? Math.max(0, 1 - TURN / 30) : 1);   /* d17.106: the near arm stays as it is; the far arm shortens from the ear end, gone at 30 */
              if (run < 2 * pxmm){ info.skip = 'far arm pressed into the hair at this turn'; return; }
              endX = hx + side * run; how = far ? 'live: far arm, shorter from the ear end' : 'live: as straight';
              info.liveRunMM = +(run / pxmm).toFixed(1); info.live = true;
            } else
            /* d17.103: never left out -- where the ear is not outward of the hinge (a frame wider than the head, or the far
               side of a turned head) the arm shows its first 6 mm going back behind the head, under the frame's end piece */
            if (side * (endX - hx) < 5 * pxmm){
              /* d17.104 (shop, 9 Oct: "show BOTH arms, whole -- one arm cut looks fake; the side is attached to the front and
                 moves with it"): where the ear is not outward of the hinge (a frame as wide as the head, the far side of a
                 turned head), the arm still runs SOLID from the hinge back over the hair and ends where the head's outline
                 meets the background -- it goes behind the head there, it does not fade out in the air */
              let outX = null;
              if (PD){
                const yS = Math.round(hy + 1.5 * pxmm), bgX = side > 0 ? Math.round(face.w * 0.985) : Math.round(face.w * 0.015);
                const bg = px(bgX, yS);
                if (bg) for (let X = hx + side * 3 * pxmm; side > 0 ? X <= hx + side * 28 * pxmm : X >= hx + side * 28 * pxmm; X += side){
                  const q = px(X, yS); if (!q) break;
                  if (Math.hypot(q[0] - bg[0], q[1] - bg[1], q[2] - bg[2]) < 28){ outX = X; break; }
                }
              }
              const minRun = 9 * pxmm, maxRun = 22 * pxmm;
              const runX = outX != null ? Math.max(minRun, Math.min(maxRun, side * (outX - hx) - 0.5 * pxmm)) : 14 * pxmm;
              endX = hx + side * runX; how = outX != null ? 'real arm: over the hair to the head\'s outline' : 'real arm: back over the hair'; info.stub = true; info.outX = outX != null ? Math.round(outX) : null;
            }
            info.hairX = hairX != null ? Math.round(hairX) : null; info.end = how;
          }
          else if (hairX != null && side * (hairX - hx) < 1.5 * pxmm){ info.hairX = Math.round(hairX); info.skip = 'hair starts right at the hinge: the arm is hidden in it'; return; }
          if (!how){
          if (hairX != null){ endX = hairX + side * 1.5 * pxmm; how = 'skin ends (hair or the side of the head)'; }
          else { endX = temple.x + side * 0.5 * pxmm; how = 'no edge found: side of the head (face outline)'; }
          /* never past the side of the head (the face outline) by more than 3 mm */
          if (side * (endX - (temple.x + side * 3 * pxmm)) > 0){ endX = temple.x + side * 3 * pxmm; how += ', held at the side of the head'; }
          info.hairX = hairX != null ? Math.round(hairX) : null; info.end = how;
          }
          /* 3. a slight drop toward the ear */
          const earY = earPt ? earPt.y : temple.y;
          const endY = REAL ? hy + Math.max(0, Math.min(1.5 * pxmm, (earY - hy) * 0.2))   /* d17.89: the real arm runs STRAIGHT on from the hinge piece, only a slight drop */
                            : hy + Math.max(0, Math.min(2.5 * pxmm, (earY - hy) * 0.15));
          info.endAt = [Math.round(endX), Math.round(endY)];
          /* an arm that would not reach outward of the hinge is not drawn */
          if (!REAL && side * (endX - hx) < 1.5 * pxmm){ info.skip = 'frame wider than the head here: arm goes straight back'; return; }
          /* draw: a tapered arm, fading out over its last 3.5 mm */
          const len = Math.hypot(endX - hx, endY - hy), ux = (endX - hx) / len, uy = (endY - hy) / len, nx = -uy, ny = ux;
          const w0 = Math.max(2, 2.4 * pxmm) / 2, w1 = Math.max(1.4, 1.7 * pxmm) / 2;
          const g = x.createLinearGradient(hx, hy, endX, endY);
          const fadeAt = Math.max(0, Math.min(0.95, 1 - ((info.live ? Math.min(3.5, 0.35 * len / pxmm) : info.stub ? 1.5 : 3.5) * pxmm) / len));   /* d17.104: a solid arm, only its very end softened; d17.106: the same soft end on both live arms */
          g.addColorStop(0, col); g.addColorStop(fadeAt, col); g.addColorStop(1, 'rgba(0,0,0,0)');
          x.save();
          x.setTransform(1, 0, 0, 1, 0, 0);                                    /* picture coordinates */
          const RA = opts.realArm;
          if (RA && RA.canvas){
            /* d17.89: THE REAL ARM -- its first ~28 mm behind the hinge, seen end-on from the front, so squeezed into the
               short visible piece; as thick as the frame's own hinge at the front, thinner further back, fading into the hair */
            const S = RA.canvas, mmPerSrc = Number(RA.mmPerPx) || 0.2;
            /* d17.101: on a turned head more of the arm is seen -- the visible run is about L x sin(turn + 10 deg) of the arm */
            let srcMM = 28;
            if (LIVE_ARM){ srcMM = 28 * (Math.hypot(endX - hx, endY - hy) + 2.5 * pxmm) / (LIVE_ARM.base + 2.5 * pxmm); }   /* d17.106: the same arm picture at the same scale as straight -- a shorter arm is the same arm cut at its ear end, not squeezed */
            else if (TURN != null && TURN >= 3){ const runMM = Math.hypot(endX - hx, endY - hy) / pxmm; srcMM = Math.max(28, Math.min((Number(opts.templeMM) || 140) * 0.7, runMM / Math.sin((TURN + 10) * Math.PI / 180))); }
            /* d17.105: the FAR arm is seen from its inner side -- the hinge plate sits on the OUTER side of the arm, so the
               far arm shows the arm itself (the plate part of the photo strip is skipped) */
            const skipPx = 0;   /* d17.106: the far arm is the same arm as straight, only shorter (no change of picture) */
            const srcLen = Math.max(2, Math.min(S.width - skipPx, Math.round(srcMM / mmPerSrc)));
            const tmp = document.createElement('canvas'); tmp.width = srcLen; tmp.height = S.height; const tg = tmp.getContext('2d');
            if (skipPx > 0){
              /* the part under the frame's end piece keeps the plate (the end piece looks as on the straight view); from
                 the frame's edge on, the far arm shows the arm itself */
              const fU = Math.max(0, Math.min(0.6, (2.5 * pxmm) / (len + 2.5 * pxmm))), uPx = Math.round(srcLen * fU);
              if (uPx > 0) tg.drawImage(S, 0, 0, uPx, S.height, 0, 0, uPx, S.height);
              tg.drawImage(S, skipPx, 0, srcLen - uPx, S.height, uPx, 0, srcLen - uPx, S.height);
            } else tg.drawImage(S, 0, 0, srcLen, S.height, 0, 0, srcLen, S.height);
            info.plateSkipPx = skipPx;
            const fg = tg.createLinearGradient(0, 0, srcLen, 0); fg.addColorStop(0, 'rgba(0,0,0,1)'); fg.addColorStop(fadeAt, 'rgba(0,0,0,1)'); fg.addColorStop(1, 'rgba(0,0,0,0)');
            tg.globalCompositeOperation = 'destination-in'; tg.fillStyle = fg; tg.fillRect(0, 0, srcLen, S.height);
            /* THE JOIN (shop, 8 Oct: "the side's top and the frame's top must merge, and the side's bottom and the frame's
               bottom too -- parallel, not going inside"): the arm's TOP edge starts exactly at the hinge piece's top edge and
               its BOTTOM edge exactly at the hinge piece's bottom edge (both measured in the front picture), and the two
               edges run back towards the ear PARALLEL. It starts 2.5 mm behind the hinge piece, which is drawn over it. */
            const TB = HG ? (side < 0 ? HG.tbL : HG.tbR) : null;
            const rot = (LX, LY) => [cx + dx + LX * co - LY * si, cy + dy + LX * si + LY * co];
            let topJ, botJ;
            /* the arm's own height (from the 30-degree photo). On a thin metal frame the hinge piece IS that tall, top to bottom; on a
               thick frame the corner is much taller than the arm, which runs along the corner's TOP -- so the top edge always
               starts at the hinge piece's top, and the arm is never taller than itself */
            const armPx = Math.max(2, (Number(RA.hingeMM) || 2.4) * pxmm);
            if (TB){ topJ = rot(lx, (TB[0] - 0.5) * h); const fullB = rot(lx, (TB[1] - 0.5) * h);
              const tbPx = Math.hypot(fullB[0] - topJ[0], fullB[1] - topJ[1]), useH = Math.min(tbPx, armPx * 1.1);
              botJ = [topJ[0] + (fullB[0] - topJ[0]) * useH / tbPx, topJ[1] + (fullB[1] - topJ[1]) * useH / tbPx]; }
            else { topJ = [hx, hy - armPx / 2]; botJ = [hx, hy + armPx / 2]; }
            const Hj = Math.hypot(botJ[0] - topJ[0], botJ[1] - topJ[1]);
            /* where it goes: from the join towards the top of the ear (the same move for both edges = parallel) */
            const mvx = endX - hx, mvy = endY - hy, mlen = Math.hypot(mvx, mvy) || 1, ux = mvx / mlen, uy = mvy / mlen;
            const back = 2.5 * pxmm;
            const T0 = [topJ[0] - ux * back, topJ[1] - uy * back];        /* the top edge's start, behind the hinge piece */
            const runLen = mlen + back;
            const yPad = (RA.padPx || 0), kY = Hj / Math.max(1, RA.thickPx || S.height);
            x.globalAlpha = 0.98;
            /* the strip is mapped so that its x runs along the arm and its y stays straight down the hinge piece's own edge:
               the arm's top edge lies on the line from the hinge piece's top edge, its bottom edge on the line from the bottom */
            const ex = [(botJ[0] - topJ[0]) / Hj, (botJ[1] - topJ[1]) / Hj];   /* down the hinge piece */
            x.setTransform(ux * runLen / srcLen, uy * runLen / srcLen, ex[0] * kY, ex[1] * kY, T0[0] - ex[0] * yPad * kY, T0[1] - ex[1] * yPad * kY);
            x.drawImage(tmp, 0, 0);
            x.setTransform(1, 0, 0, 1, 0, 0);
            info.join = { top: topJ.map(Math.round), bottom: botJ.map(Math.round), heightPx: +Hj.toFixed(1) }; info.srcMM = +srcMM.toFixed(1);
            info.real = true;
          } else {
          x.globalAlpha = 0.95; x.fillStyle = g;
          x.beginPath();
          x.moveTo(hx + nx * w0, hy + ny * w0); x.lineTo(endX + nx * w1, endY + ny * w1);
          x.lineTo(endX - nx * w1, endY - ny * w1); x.lineTo(hx - nx * w0, hy - ny * w0); x.closePath(); x.fill();
          }
          if (opts.armsDebug){
            const dot = (X, Y, c) => { x.globalAlpha = 1; x.fillStyle = c; x.beginPath(); x.arc(X, Y, Math.max(3, 1.2 * pxmm), 0, Math.PI * 2); x.fill(); };
            dot(hx, hy, '#00c853'); dot(cp.x, cp.y, '#ffd600'); dot(temple.x, temple.y, '#2979ff');
            if (earPt) dot(earPt.x, earPt.y, '#aa00ff'); if (hairX != null) dot(hairX, yWalk, '#ff1744');
          }
          x.restore();
          info.drawn = true;
        });
      } catch (e){ armInfo.error = String(e && e.message || e); }
      if (opts.debug) opts.debug.arms = armInfo;
    }

    // shadow first, so the frame sits on the face
    x.save();
    x.globalAlpha = 0.28;
    x.filter = 'blur(' + Math.max(2, h*0.09) + 'px) brightness(0)';
    x.drawImage(frameCanvas, -w/2 + w*0.01, -h/2 + h*0.16, w, h);
    x.restore();

    x.drawImage(frameCanvas, -w/2, -h/2, w, h);

    /* Soften the outline.

       The cut-out has a hard edge: a pixel is either frame or nothing.
       Against skin that reads as a shape stuck on top -- most obviously
       along the bottom of the rim where it crosses the cheek, which
       came out as a drawn black line rather than an object resting
       there.

       A real edge is never that abrupt. Redrawing the frame once more,
       very faintly and a shade blurred, blends the outline into the
       skin without moving anything or softening the frame itself. */
    if (opts.softEdge !== false){
      const soft = opts.softEdge == null ? 0.30 : opts.softEdge;
      if (soft > 0){
        x.save();
        x.globalAlpha = soft;
        x.filter = 'blur(' + Math.max(0.6, h * 0.006) + 'px)';
        x.drawImage(frameCanvas, -w/2, -h/2, w, h);
        x.restore();
      }
    }

    /* Light on the lens.

       A real anti-glare coating catches the light in a soft band
       across the top of each lens. Without it a clear frame reads as
       an empty hole cut in the picture. Drawn only inside the lens
       openings, and only where they were actually measured -- guessing
       where a lens is and painting a shine on the cheek would look
       far worse than no shine at all. */
    if (LN && LN.length >= 2 && opts.lensGlow !== false){
      /* A clear lens has to read as glass.

         At 0.16, fading out by 62% of the way across, the lens
         measured 4% different from bare skin at its strongest and
         nothing at all at the pupil. Invisible -- so a clear frame
         looked like an empty hole and whatever sat behind the glass
         showed through instead of a lens.

         Lenskart brighten the skin behind their lens by about 34%,
         measured on their own render. That reads unmistakably as glass
         but washes out the customer's eyes. This sits between: a sheen
         across the whole lens that says there is glass here, without
         changing anyone's eye colour. */
      /* Back to 0.16 in d16.11: at 0.45, carried across the whole
         ellipse, the sheen showed as grey eggs over the eyes on a live
         photo. The measurements above were on a synthetic face. */
      const strength = opts.lensGlow == null ? 0.16 : opts.lensGlow;
      if (strength > 0){
        x.save();
        LN.forEach(L => {
          const lx = -w/2 + L.x * w, ly = -h/2 + L.y * h;
          const lw = L.w * w * 0.94, lh = L.h * h * 0.94;
          const gr = x.createLinearGradient(lx - lw/2, ly - lh/2, lx + lw/2, ly + lh/2);
          /* carried right across the lens, not faded out two thirds of
             the way -- a lens is glass all over, brighter where the
             light catches it */
          gr.addColorStop(0.00, 'rgba(255,255,255,' + strength + ')');
          gr.addColorStop(0.42, 'rgba(255,255,255,' + (strength*0.30) + ')');
          gr.addColorStop(0.62, 'rgba(255,255,255,0)');
          x.fillStyle = gr;
          x.beginPath();
          x.ellipse(lx, ly, lw/2, lh/2, 0, 0, Math.PI*2);
          x.fill();
        });
        x.restore();
      }
    }

    x.restore();
    return out;
  }

  /* Its own stamp. check.html compares this against the page build, so
     a phone quietly serving an old cached onface.js can be spotted
     instead of guessed at -- which cost a full day of testing a fix
     that was never actually running. */
  const VERSION = '2026-10-09 d17.108';


  /* A NARROW STRIP ACROSS THE EYES, for checking the PD by hand.

     The PD measured from a photograph is an estimate: it divides by an
     11.7mm iris, and a real iris runs 10.2 to 13.0. On a progressive
     order that error is expensive, so an optician needs to check it.

     Storing the whole face would be a privacy commitment and a storage
     cost for no benefit -- the only thing anyone needs to look at is
     the eyes. This crops a band across them: about 8KB against 24KB
     for the face, and no identifiable portrait.

     Returns the strip, the pupils in STRIP coordinates so the dots
     land in the right place, and the iris width for scale, so moving a
     dot recomputes the PD immediately. */
  function eyeStrip(faceImg, face, opts){
    opts = opts || {};
    try {
      if (!face || !face.pupilR || !face.pupilL) return null;
      const pd = Math.hypot(face.pupilL.x - face.pupilR.x, face.pupilL.y - face.pupilR.y);
      if (!(pd > 10)) return null;
      /* wide enough to show the outer corners, tall enough to see the
         whole eye -- an optician needs the context to judge a pupil */
      const halfW = pd * 1.15, halfH = pd * 0.34;
      const cx = (face.pupilR.x + face.pupilL.x) / 2;
      const cy = (face.pupilR.y + face.pupilL.y) / 2;
      const sx = Math.max(0, Math.round(cx - halfW));
      const sy = Math.max(0, Math.round(cy - halfH));
      const sw = Math.min(face.w - sx, Math.round(halfW * 2));
      const sh = Math.min(face.h - sy, Math.round(halfH * 2));
      if (sw < 20 || sh < 8) return null;

      const outW = Math.min(opts.width || 620, sw);
      const k = outW / sw;
      const c = document.createElement('canvas');
      c.width = Math.round(sw * k); c.height = Math.round(sh * k);
      const x = c.getContext('2d');
      x.imageSmoothingQuality = 'high';
      x.drawImage(faceImg, sx, sy, sw, sh, 0, 0, c.width, c.height);

      let data = '';
      try { data = c.toDataURL('image/webp', 0.86); } catch (e){}
      if (!data || data.length < 40) data = c.toDataURL('image/jpeg', 0.86);

      return {
        image: data,
        w: c.width, h: c.height,
        pupilR: { x: (face.pupilR.x - sx) * k, y: (face.pupilR.y - sy) * k },
        pupilL: { x: (face.pupilL.x - sx) * k, y: (face.pupilL.y - sy) * k },
        irisPx: (face.irisPx || 0) * k,
        irisUsed: !!face.irisUsed,
        /* the facial midline, in strip coordinates. Monocular PD is
           measured from the nose, not from half the total -- unequal
           halves are a common cause of progressive rejections. */
        noseX: (face.noseAxisX || (face.noseSeat ? face.noseSeat.x : cx) ) ? 
               (((face.noseAxisX || (face.noseSeat ? face.noseSeat.x : cx))) - sx) * k : null
      };
    } catch (e){ return null; }
  }


  /* THE SIDE VIEW.

     A front photograph does not contain anyone's profile, so a side
     view needs a second photograph of the customer, turned. This
     places the frame's own side photo on that turned face.

     Two anchors, because two points fix position, angle and size at
     once:
       - the visible eye, where the lens sits
       - the temple, where the arm runs to

     Scale comes from the iris as everywhere else, and the arm is drawn
     at the TEMPLE LENGTH printed on the frame -- the third number,
     140 or 142. So if a 140mm arm does not reach that customer's ear,
     it genuinely does not fit them, and the picture says so honestly
     rather than stretching to fit.

     The arm is deliberately NOT extended to the ear. On a real face it
     disappears into the hair before then, and a drawn arm that reaches
     the ear looks stuck on. Cutting it where the hair starts is what a
     photograph actually looks like.

     Returns null rather than guessing when the head is not turned
     enough for a profile to make sense. */
  function composeSide(faceImg, face, sideCanvas, templeMM, opts){
    opts = opts || {};
    try {
      if (!faceImg || !face || !sideCanvas) return null;
      const yaw = face.yaw || 0;
      const MIN = opts.minYaw == null ? 0.22 : opts.minYaw;
      if (Math.abs(yaw) < MIN) return null;          // not turned enough

      /* the near side of a turned head: the eye and temple we can see */
      const toLeft = yaw < 0;
      const eye    = toLeft ? face.pupilR : face.pupilL;
      const temple = toLeft ? face.templeR : face.templeL;
      if (!eye || !temple) return null;

      const W = face.w, H = face.h;
      const out = document.createElement('canvas');
      out.width = W; out.height = H;
      const x = out.getContext('2d');
      x.imageSmoothingEnabled = true;
      if ('imageSmoothingQuality' in x) x.imageSmoothingQuality = 'high';   /* d16.33 */
      x.drawImage(faceImg, 0, 0, W, H);

      /* pixels per millimetre, from the iris where we can */
      let perMM = 0;
      if (face.irisPx > 0){
        const share = face.irisPx / (face.pd || 1);
        if (share > 0.10 && share < 0.40) perMM = face.irisPx / 12.0;   /* same figure as IRIS_MM in compose */
      }
      if (!perMM && face.pd > 0) perMM = face.pd / 63;
      if (!perMM) return null;

      const armMM  = (templeMM > 80 && templeMM < 200) ? templeMM : 140;
      const armPx  = armMM * perMM;

      /* the side photo is framed lens-end to arm-tip, so its width is
         the whole temple. Scale it to the real arm length. */
      const k = armPx / sideCanvas.width;
      const dw = sideCanvas.width * k, dh = sideCanvas.height * k;

      /* angle from the eye back to the temple: the arm lies along it */
      const ang = Math.atan2(temple.y - eye.y, temple.x - eye.x);

      /* CUT IT WHERE THE HEAD ENDS.

         Drawn at its true length the arm shoots past the head into the
         background: at a partial turn the arm is foreshortened, and a
         140mm arm measured 694px against 180px from eye to temple.

         It should not reach the ear in any case. On a real face the arm
         disappears into the hair before then, and one drawn all the way
         to the ear looks stuck on. So the size stays honest -- the arm
         is scaled to the temple length printed on the frame -- and the
         drawing is simply clipped at the temple, with a little beyond
         so it runs under the hairline rather than stopping in mid-air.

         If a 140mm arm is clipped very early, that frame is genuinely
         too long for this face, and the fit report can say so. */
      const reach = Math.hypot(temple.x - eye.x, temple.y - eye.y) *
                    (opts.reach == null ? 1.12 : opts.reach);

      x.save();
      x.translate(eye.x, eye.y);
      x.rotate(ang);
      if (toLeft) x.scale(-1, 1);        // the photo is shot one way round
      x.beginPath();
      x.rect(-dh, -dh, reach + dh, dh * 2);
      x.clip();
      /* the lens end sits on the eye; the arm runs back from there */
      x.globalAlpha = opts.alpha == null ? 1 : opts.alpha;
      x.drawImage(sideCanvas, 0, -dh * (opts.lensAt == null ? 0.5 : opts.lensAt), dw, dh);
      x.restore();

      return out;
    } catch (e){ return null; }
  }

  /* THE PHOTO THE CUTTER MUST SEE: the frame as it was shot, on the
     grey sheet, with nothing done to it.

     Admin used to save every product photo behind two Cloudinary
     instructions -- remove the background (a paid add-on that is not
     enabled) and pad to a square filled with WHITE. Try-on loaded the
     background-removal address first, which failed, and fell back to
     the white one. So the grey sheet never reached the cutter on the
     live site; only the diagnostic, reading the file straight off the
     phone, ever saw grey. The measured-background cutter of d16.4 had
     never run on a real shop photo.

     This strips every instruction off a Cloudinary address and asks
     only for a size limit, which changes no colour. Anything that is
     not a Cloudinary address is returned untouched. Every page that
     feeds the cutter goes through here, and admin's own check does
     too, so admin judges the same picture the customer gets. */
  function tryOnSource(url){
    const s = String(url || '');
    const i = s.indexOf('/image/upload/');
    if (i === -1) return s;
    const base = s.slice(0, i + 14);
    const segs = s.slice(i + 14).split('/');
    while (segs.length > 1 && /^(e_|c_|f_|q_|w_|h_|b_|g_|dpr_)/.test(segs[0])) segs.shift();
    const id = segs.join('/');
    return id ? base + 'c_limit,w_1400/' + id : s;
  }


  /* ---- d17.87 FACE LOCK (shop, 8 Oct: "measure the face over the first second with the eyes open, then lock it; the
     size uses the same lock") ------------------------------------------------------------------------------------------
     A camera only sees pixels, so the face's size in millimetres comes from the eye (iris about 12 mm), or from a PD the
     customer gave. One picture wobbles: the iris is only ~40 px wide, so one pixel is 2.5 %. So:
       - during the first second, every picture with BOTH EYES OPEN and the face STRAIGHT is measured, and the face's own
         distances are written down in millimetres (pupil to pupil, cheek to cheek, brow to chin);
       - after ~15 such pictures their middle value (median) is LOCKED;
       - from then on each picture only asks "how big is this face on the screen now?" using those locked millimetres --
         the middle of the three, so a shut eye, an open mouth or a turn cannot pull it. Closer or further from the phone,
         the frame grows and shrinks with the face; blinking changes nothing.
     The lock is the face's size in MILLIMETRES, never in pixels. */

  /* ---- d17.89 THE REAL ARM (shop, 8 Oct: "can the AI model wear the complete frame, with the arms?") ----
     From the 30-degree cut-out the robot made, the NEAR arm -- the one coming towards the camera -- is taken from the hinge
     backwards (its first part, before the tip bends down), straightened into a flat strip, hinge end first. The front
     view then lays this real arm (its own colour, shine and any print) from each hinge back into the hair. */
  function armStripFrom30(img){
    if (!img) return null;
    const W = img.naturalWidth || img.width, H = img.naturalHeight || img.height; if (!W || !H) return null;
    const c = document.createElement('canvas'); c.width = W; c.height = H;
    const g = c.getContext('2d', { willReadFrequently: true }); g.drawImage(img, 0, 0);
    const D = g.getImageData(0, 0, W, H).data, A = (x, y) => D[(y * W + x) * 4 + 3];
    /* per column: how many frame pixels, and the topmost run (start, length) */
    const cnt = new Int32Array(W), top = new Int32Array(W).fill(-1), run = new Int32Array(W);
    /* per column: the LONGEST solid run (the arm itself -- a speck or a faint edge above it cannot fool it) */
    for (let x = 0; x < W; x++){ let n = 0, bs = -1, bl = 0, cs = -1, cl = 0;
      for (let y = 0; y < H; y++){ const on = A(x, y) > 110; if (on){ n++; if (cs < 0){ cs = y; cl = 0; } cl++; if (cl > bl){ bl = cl; bs = cs; } } else cs = -1; }
      cnt[x] = n; top[x] = bs; run[x] = bl; }
    /* the arm side: walking in from that edge, many columns hold ONLY a thin run (the arm) before the near lens's rim */
    function armCols(dir){
      const cols = []; let x = dir > 0 ? W - 1 : 0, seenArm = 0;
      for (; x >= 0 && x < W; x -= dir){
        if (cnt[x] === 0){ if (seenArm > W * 0.05) break; cols.length = 0; seenArm = 0; continue; }   /* a stray speck at the edge never ends the search */
        const thin = cnt[x] <= Math.max(6, run[x] * 1.6) && run[x] < H * 0.26;      /* one run only; up to a thick acetate arm (d17.89) */
        if (thin){ cols.push(x); seenArm++; } else if (seenArm > W * 0.05) break; else { cols.length = 0; seenArm = 0; }
      }
      return cols;                                                       /* from the tip end towards the hinge */
    }
    const R = armCols(1), L = armCols(-1), cols = (R.length >= L.length ? R : L).slice();
    if (cols.length < W * 0.12) return null;
    /* which side of the picture the arm is on, and its hinge end = the end nearer the middle of the picture */
    const meanX = cols.reduce((a, b) => a + b, 0) / cols.length, side = meanX > W / 2 ? 1 : -1;
    cols.sort((a, b) => side > 0 ? a - b : b - a);                       /* hinge end first */
    /* keep the straight part: stop where the arm starts to bend down (its top drops away from the line) */
    const t0 = cols.slice(0, Math.max(5, cols.length >> 3)).map(x => top[x] + run[x] / 2);
    const y0 = t0.reduce((a, b) => a + b, 0) / t0.length;
    const thick = cols.map(x => run[x]).sort((a, b) => a - b)[cols.length >> 1];
    let keep = cols.length;
    for (let i = 0; i < cols.length; i++){ const yc = top[cols[i]] + run[cols[i]] / 2; if (Math.abs(yc - y0) > Math.max(6, thick * 2.5) + i * 0.08){ keep = i; break; } }
    const use = cols.slice(0, Math.max(10, Math.min(keep, Math.round(cols.length * 0.85))));
    const T = Math.max(3, thick), pad = Math.max(2, Math.round(T * 0.6)), SH = T + pad * 2;
    const out = document.createElement('canvas'); out.width = use.length; out.height = SH; const og = out.getContext('2d');
    /* ONLY the arm itself, column by column (nothing of the frame above or below it), and every column brought to the arm's
       own height -- so its top and bottom edges come out as two clean parallel lines that continue the hinge piece's edges */
    use.forEach((x, i) => { if (run[x] > 0) og.drawImage(c, x, top[x], 1, run[x], i, pad, 1, T); });
    /* the near lens's full height (rim top to rim bottom) -- a sideways turn does not shorten heights, so this gives the
       picture's scale when compared with the same lens in the front picture */
    const hingeX = use[0], ext = [];
    for (let k = 1; k <= Math.round(W * 0.35); k++){ const x = hingeX - side * k; if (x < 0 || x >= W) break;
      let t = -1, bt = -1; for (let y = 0; y < H; y++) if (A(x, y) > 110){ if (t < 0) t = y; bt = y; } if (t >= 0) ext.push(bt - t + 1); }
    ext.sort((a, b) => a - b);
    const lensHpx = ext.length ? ext[Math.floor(ext.length * 0.9)] : 0;
    return { canvas: out, thickPx: T, padPx: pad, side, lenPx: use.length, srcW: W, lensHpx };
  }
  function faceLock(o){
    o = o || {};
    const NEED = o.need || 15, KEEP = 30;
    const st = { samples: [], lock: null, lastSeen: 0, ema: 0 };
    const med = a => { const b = a.filter(v => isFinite(v) && v > 0).sort((x, y) => x - y); if (!b.length) return 0; const m = b.length >> 1; return b.length % 2 ? b[m] : (b[m - 1] + b[m]) / 2; };
    const cosY = f => Math.sqrt(Math.max(0.3, 1 - Math.pow(Math.min(0.9, Math.abs(f.yaw || 0)), 2)));
    const nearPD = () => { const k = Number(o.pdMM) || 0; return (k >= 40 && k <= 82) ? k * 350 / 377 : 0; };
    function measurable(f){
      if (!f || f.estimated || !(f.pd > 0)) return false;
      if (Math.abs(f.yaw || 0) > 0.12 || Math.abs(f.roll || 0) > 0.143) return false;   /* d17.98: the tilt is no longer softened to 70% -- 0.143 is the old 0.10 */
      if (f.eyeOpen != null && f.eyeOpen < 0.18) return false;
      if (nearPD()) return true;
      if (!f.irisUsed || !(f.irisPx > 0)) return false;
      const share = f.irisPx / f.pd; return share > 0.10 && share < 0.33;
    }
    function add(f, now){
      now = now == null ? Date.now() : now;
      if (f && !f.estimated) { if (st.lastSeen && now - st.lastSeen > 3000) reset(); st.lastSeen = now; }
      if (st.lock || !measurable(f)) return false;
      const p = nearPD() ? f.pd / nearPD() : f.irisPx / 12.0;          /* pixels per mm in THIS picture */
      st.samples.push({ pd: f.pd / p, fw: (f.faceW || 0) / p, fl: (f.faceL || 0) / p });
      if (st.samples.length > KEEP) st.samples.shift();
      if (st.samples.length >= NEED) st.lock = dims();
      return true;
    }
    function dims(){ return { pd: med(st.samples.map(x => x.pd)), fw: med(st.samples.map(x => x.fw)), fl: med(st.samples.map(x => x.fl)), n: st.samples.length }; }
    function perMM(f){
      const L = st.lock || (st.samples.length >= 3 ? dims() : null);
      if (!L || !f || f.estimated) return 0;
      const c = cosY(f), cand = [];
      if (L.pd > 0 && f.pd > 0 && (f.eyeOpen == null || f.eyeOpen >= 0.12) && Math.abs(f.yaw || 0) < 0.45) cand.push(f.pd / c / L.pd);
      if (L.fw > 0 && f.faceW > 0 && Math.abs(f.yaw || 0) < 0.30) cand.push(f.faceW / c / L.fw);
      if (L.fl > 0 && f.faceL > 0) cand.push(f.faceL / L.fl);
      let v = med(cand); if (!v) return 0;
      st.ema = st.ema ? st.ema * 0.4 + v * 0.6 : v;                       /* a light touch of smoothing; follows the face in ~0.15 s */
      return st.ema;
    }
    function reset(){ st.samples = []; st.lock = null; st.ema = 0; }
    function restore(L){ if (L && L.pd > 0 && L.fw > 0 && L.fl > 0) { st.lock = { pd: +L.pd, fw: +L.fw, fl: +L.fl, n: +L.n || NEED }; return true; } return false; }
    return { add, perMM, reset, restore, measurable,
      locked: () => !!st.lock, lock: () => st.lock ? Object.assign({}, st.lock) : null,
      progress: () => st.lock ? 1 : Math.min(1, st.samples.length / NEED) };
  }
  /* the real arm, ready to draw: the strip and its scale. The scale comes from the LENS HEIGHT (rim top to rim bottom), which
     a 30-degree turn does not change: measured in the front picture (whose millimetres are known from the frame's width)
     and in the 30-degree picture. */
  function lensHeightPx(fc){
    const W = fc.width, H = fc.height, g = fc.getContext('2d', { willReadFrequently: true }), D = g.getImageData(0, 0, W, H).data, out = [];
    (fc.lenses || []).forEach(L => { const x0 = Math.max(0, Math.round((L.x - L.w * 0.35) * W)), x1 = Math.min(W - 1, Math.round((L.x + L.w * 0.35) * W));
      for (let x = x0; x <= x1; x++){ let t = -1, bt = -1; for (let y = 0; y < H; y++) if (D[(y * W + x) * 4 + 3] > 110){ if (t < 0) t = y; bt = y; } if (t >= 0) out.push(bt - t + 1); } });
    out.sort((a, b) => a - b); return out.length ? out[Math.floor(out.length * 0.9)] : 0;
  }
  function realArmFrom30(img, frontCut, frontWidthMM){
    const st = armStripFrom30(img); if (!st || !(st.lensHpx > 20) || !frontCut || frontCut.lensesEstimated) return null;
    const fh = lensHeightPx(frontCut), fw = Number(frontWidthMM) || 0; if (!(fh > 20) || !(fw > 90)) return null;
    const lensHmm = fh / (frontCut.width / fw);
    const pxmm30 = st.lensHpx / lensHmm;
    const hingeMM = Math.max(1.2, Math.min(12, st.thickPx / pxmm30));          /* thin metal ~2 mm .. thick acetate ~10 mm */
    return { canvas: st.canvas, thickPx: st.thickPx, padPx: st.padPx, mmPerPx: 1 / (pxmm30 * Math.sin(30 * Math.PI / 180)), hingeMM, side: st.side };
  }
  global.VGOnFace = { turnFront, ridgeXAt, headPose3, realArmFrom30, armStripFrom30, faceLock, VERSION, cutout, eyeStrip, composeSide, findFace, faceFromLandmarks, compose, fitReport, lensLine, checkShot, faceShape, SHAPE_ADVICE, tryOnSource };

})(window);

/* Vision Gallery — RIM CHECK ALL ROUND (d17.186, shop 26 Oct: "in the original photo the rim is clearly visible -- measure the
   thickness of the entire rim: top, bottom, sides, front and side views. If the thickness is missing, they cut the rim.
   Very easy to find. And repair it at that particular place, in the same colour.")

   For one try-on picture (FRONT, 30° LEFT or 30° RIGHT) and the ORIGINAL photo it was cut from (the robot keeps the same
   crop beside every cut-out, same size):
     1. the lens openings are found in the cut-out (a small break in the rim is bridged, so a lens is still found);
     2. from the middle of each lens, 360 lines go out, one every degree. On each line the rim is measured twice:
          CUT   = from the lens edge to where the cut-out ends;
          PHOTO = from the lens edge to the frame's own outline in the photo (the last sharp edge of the frame -- a soft
                  shadow under the frame is not frame), plus any frame the cut ate from the lens side;
     3. where the cut is clearly thinner than the photo (more than 2 px, or more than 10% of it, missing -- judged with the
        lines next to it) over a stretch of the rim, that place is reported: which lens, where (top, bottom, outer side,
        nose side, corners), photo px and cut px;
     4. REPAIR puts exactly the missing part back FROM THE PHOTO'S OWN PIXELS (same colour, same pattern -- nothing painted),
        only between the cut's edge and the photo's outline, and only where the photo shows frame.
   Lines that cross a bridge, a hinge, an arm or a nose pad (much thicker than the rim) are not counted as rim.
   d17.187 (shop 26 Oct, Fusion-X: "the report says the rim is the same, but the top of the rim is cut"): the old measure
   took away "the usual difference" before comparing, so a rim the robot shaved evenly all along looked fine, and it counted
   a half see-through rim as solid. Now both edges are found to a fraction of a pixel and compared directly, only SOLID rim
   counts (a half see-through rim counts half), the top is found from above (from the sheet down), and the repair fills
   exactly the photo's band, edge pixels by their share (the same soft edge), never past the photo's unbroken frame.
   VGRim.check(cutImage, photoImage, { marks, repair }) -> { measured, ok, lenses, places, thinPct, medRim, marks, repair, added } */
(function (g) {
  'use strict';
  if (g.VGRim) return;
  const NR = 360;
  function data(img, W, H) {
    const c = document.createElement('canvas'); c.width = W; c.height = H;
    const x = c.getContext('2d', { willReadFrequently: true }); x.drawImage(img, 0, 0, W, H);
    return x.getImageData(0, 0, W, H);
  }
  /* the sheet behind the frame, from the photo itself: shrunk 8 times, a median that wipes out anything thin (rims, arms,
     bars), spread back smoothly -- what is left is the sheet with its shading */
  function background(sd, W, H) {
    const sw = Math.max(8, Math.round(W / 8)), sh = Math.max(8, Math.round(H / 8)), sn = sw * sh;
    const sm = new Float32Array(sn * 3), cnt = new Float32Array(sn);
    for (let y = 0; y < H; y++) { const yy = Math.min(sh - 1, Math.floor(y * sh / H));
      for (let x = 0; x < W; x++) { const xx = Math.min(sw - 1, Math.floor(x * sw / W)), q = yy * sw + xx, j = (y * W + x) * 4;
        sm[q * 3] += sd[j]; sm[q * 3 + 1] += sd[j + 1]; sm[q * 3 + 2] += sd[j + 2]; cnt[q]++; } }
    for (let q = 0; q < sn; q++) { const c = cnt[q] || 1; sm[q * 3] /= c; sm[q * 3 + 1] /= c; sm[q * 3 + 2] /= c; }
    const MR = Math.max(4, Math.round(Math.min(sw, sh) * 0.12)), med = new Float32Array(sn * 3), buf = [];
    for (let y = 0; y < sh; y++) for (let x = 0; x < sw; x++) for (let ch = 0; ch < 3; ch++) {
      buf.length = 0;
      for (let dy = -MR; dy <= MR; dy++) { const yy = Math.min(sh - 1, Math.max(0, y + dy));
        for (let dx = -MR; dx <= MR; dx++) { const xx = Math.min(sw - 1, Math.max(0, x + dx)); buf.push(sm[(yy * sw + xx) * 3 + ch]); } }
      buf.sort((a, b) => a - b); med[(y * sw + x) * 3 + ch] = buf[buf.length >> 1];
    }
    const bg = new Float32Array(W * H * 3);
    for (let y = 0; y < H; y++) { const fy = Math.min(sh - 1, Math.max(0, (y + 0.5) * sh / H - 0.5)), y0 = Math.floor(fy), y1 = Math.min(sh - 1, y0 + 1), wy = fy - y0;
      for (let x = 0; x < W; x++) { const fx = Math.min(sw - 1, Math.max(0, (x + 0.5) * sw / W - 0.5)), x0 = Math.floor(fx), x1 = Math.min(sw - 1, x0 + 1), wx = fx - x0, i = (y * W + x) * 3;
        for (let ch = 0; ch < 3; ch++) {
          const a = med[(y0 * sw + x0) * 3 + ch] * (1 - wx) + med[(y0 * sw + x1) * 3 + ch] * wx, b = med[(y1 * sw + x0) * 3 + ch] * (1 - wx) + med[(y1 * sw + x1) * 3 + ch] * wx;
          bg[i + ch] = a * (1 - wy) + b * wy; } } }
    return bg;
  }
  function photoMaps(sd, W, H) {
    const N = W * H, bg = background(sd, W, H), F = new Uint8Array(N), Fs = new Uint8Array(N), Dk = new Uint8Array(N), Dm = new Float32Array(N), Cm = new Float32Array(N), Bg = new Float32Array(N), G = new Float32Array(N), gray = new Float32Array(N);
    for (let i = 0, j = 0; i < N; i++, j += 4) {
      const r = sd[j], gg = sd[j + 1], b = sd[j + 2]; gray[i] = 0.299 * r + 0.587 * gg + 0.114 * b;
      const d = Math.max(Math.abs(r - bg[i * 3]), Math.abs(gg - bg[i * 3 + 1]), Math.abs(b - bg[i * 3 + 2]));
      const bgG = 0.299 * bg[i * 3] + 0.587 * bg[i * 3 + 1] + 0.114 * bg[i * 3 + 2], sat = (Math.max(r, gg, b) - Math.min(r, gg, b)) / 255;
      F[i] = (d > 24 || gray[i] < bgG - 18 || sat > 0.22) ? 1 : 0;
      Fs[i] = (d > 45 || gray[i] < bgG - 35 || sat > 0.3) ? 1 : 0;      /* clearly frame (not the camera's soft halo) */
      Dk[i] = (gray[i] < bgG - 8 || sat > 0.15) ? 1 : 0;                /* darker than the sheet or coloured (a shine is lighter) */
      Dm[i] = Math.max(0, bgG - gray[i], sat > 0.15 ? d : 0);           /* how much frame: darker than the sheet, or coloured */
      Cm[i] = d;                                                          /* how different from the sheet at all (a rim's light top edge too) */
      Bg[i] = bgG;
    }
    for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) { const i = y * W + x; G[i] = Math.abs(gray[i + 1] - gray[i - 1]) + Math.abs(gray[i + W] - gray[i - W]); }
    return { F, Fs, Dk, D: Dm, C: Cm, Bg, G };
  }
  function dilate(m, W, H, r) {               /* square, separable */
    const N = W * H, t = new Uint8Array(N), o = new Uint8Array(N);
    for (let y = 0; y < H; y++) { let last = -1e9; const row = y * W;
      for (let x = 0; x < W; x++) { if (m[row + x]) last = x; if (x - last <= r) t[row + x] = 1; }
      last = 1e9; for (let x = W - 1; x >= 0; x--) { if (m[row + x]) last = x; if (last - x <= r) t[row + x] = 1; } }
    for (let x = 0; x < W; x++) { let last = -1e9;
      for (let y = 0; y < H; y++) { if (t[y * W + x]) last = y; if (y - last <= r) o[y * W + x] = 1; }
      last = 1e9; for (let y = H - 1; y >= 0; y--) { if (t[y * W + x]) last = y; if (last - y <= r) o[y * W + x] = 1; } }
    return o;
  }
  /* the lens openings: see-through areas closed in by the frame (a break of a few px in the rim is bridged first), with any
     speck inside them counted as lens */
  function lensesOf(op, W, H) {
    const N = W * H, R = Math.max(3, Math.round(Math.max(W, H) / 300)), dil = dilate(op, W, H, R), lab = new Int32Array(N), pieces = [];
    let L = 0; const st = [];
    for (let s = 0; s < N; s++) { if (dil[s] || lab[s]) continue;
      L++; let size = 0, edge = false; lab[s] = L; st.push(s);
      while (st.length) { const q = st.pop(), x = q % W, y = (q - x) / W; size++;
        if (x === 0 || y === 0 || x === W - 1 || y === H - 1) edge = true;
        if (x > 0 && !dil[q - 1] && !lab[q - 1]) { lab[q - 1] = L; st.push(q - 1); }
        if (x < W - 1 && !dil[q + 1] && !lab[q + 1]) { lab[q + 1] = L; st.push(q + 1); }
        if (y > 0 && !dil[q - W] && !lab[q - W]) { lab[q - W] = L; st.push(q - W); }
        if (y < H - 1 && !dil[q + W] && !lab[q + W]) { lab[q + W] = L; st.push(q + W); } }
      if (!edge && size >= N * 0.001) pieces.push(L);
    }
    /* one lens can be split in two by a far arm or a bar seen through it (kept in the cut): two pieces one above the other
       (mostly the same columns) with only a thin band between them are one lens -- the band is counted as lens. Two lenses
       side by side are never joined. */
    let fy0 = H, fy1 = -1; for (let i = 0; i < N; i++) if (op[i]) { const y = (i - i % W) / W; if (y < fy0) fy0 = y; if (y > fy1) fy1 = y; }
    const fh = Math.max(1, fy1 - fy0 + 1), band = Math.max(16, Math.round(fh * 0.35));
    const info = {}; pieces.forEach(l => { info[l] = { l, x0: W, x1: -1, y0: H, y1: -1, top: null, bot: null }; });
    for (let i = 0; i < N; i++) { const pi = info[lab[i]]; if (!pi) continue; const x = i % W, y = (i - x) / W;
      if (x < pi.x0) pi.x0 = x; if (x > pi.x1) pi.x1 = x; if (y < pi.y0) pi.y0 = y; if (y > pi.y1) pi.y1 = y; }
    pieces.forEach(l => { const pi = info[l], w = pi.x1 - pi.x0 + 1; pi.top = new Int32Array(w).fill(H); pi.bot = new Int32Array(w).fill(-1); });
    for (let i = 0; i < N; i++) { const pi = info[lab[i]]; if (!pi) continue; const x = i % W, y = (i - x) / W, c = x - pi.x0;
      if (y < pi.top[c]) pi.top[c] = y; if (y > pi.bot[c]) pi.bot[c] = y; }
    const par = {}; pieces.forEach(l => { par[l] = l; }); const find = l => { while (par[l] !== l) l = par[l] = par[par[l]]; return l; };
    const fills = [];
    for (let i1 = 0; i1 < pieces.length; i1++) for (let i2 = i1 + 1; i2 < pieces.length; i2++) {
      let A = info[pieces[i1]], B = info[pieces[i2]]; if (A.y0 > B.y0) { const t = A; A = B; B = t; }   /* A above */
      const ox0 = Math.max(A.x0, B.x0), ox1 = Math.min(A.x1, B.x1), ov = ox1 - ox0 + 1;
      if (ov < 0.6 * Math.min(A.x1 - A.x0 + 1, B.x1 - B.x0 + 1)) continue;
      const gaps = [];
      for (let x = ox0; x <= ox1; x++) { const ab = A.bot[x - A.x0], bt = B.top[x - B.x0]; if (ab >= 0 && bt < H && bt > ab) gaps.push([x, ab, bt]); }
      if (gaps.length < ov * 0.5) continue;
      const gm = median(gaps.map(gq => gq[2] - gq[1]));
      if (gm > band) continue;
      par[find(A.l)] = find(B.l); fills.push(gaps.filter(gq => gq[2] - gq[1] <= band * 1.5));
    }
    const lab2 = new Int32Array(N), out = [];
    for (let i = 0; i < N; i++) if (info[lab[i]]) lab2[i] = find(lab[i]);
    fills.forEach(gs => gs.forEach(([x, ab, bt]) => { const g0 = lab2[ab * W + x]; for (let y = ab + 1; y < bt; y++) if (!lab2[y * W + x]) lab2[y * W + x] = g0; }));
    const grp = {};
    for (let i = 0; i < N; i++) { const g0 = lab2[i]; if (!g0) continue; const x = i % W, y = (i - x) / W;
      const o = grp[g0] || (grp[g0] = { id: g0, size: 0, own: 0, sx: 0, sy: 0, x0: W, x1: -1, y0: H, y1: -1 });
      o.size++; if (lab[i]) o.own++; o.sx += x; o.sy += y; if (x < o.x0) o.x0 = x; if (x > o.x1) o.x1 = x; if (y < o.y0) o.y0 = y; if (y > o.y1) o.y1 = y; }
    Object.values(grp).forEach(o => {
      if (o.own >= N * 0.003 && (o.y1 - o.y0 + 1) >= fh * 0.3 && o.size / ((o.x1 - o.x0 + 1) * (o.y1 - o.y0 + 1)) >= 0.45)
        out.push({ id: o.id, size: o.size, cx: o.sx / o.size, cy: o.sy / o.size, x0: o.x0, x1: o.x1, y0: o.y0, y1: o.y1 }); });
    out.sort((a, b) => b.size - a.size); out.length = Math.min(out.length, 2);
    /* each lens with everything inside it (specks, a far arm across it) counted as lens */
    out.forEach(ln => {
      const m = new Uint8Array(N); for (let i = 0; i < N; i++) if (lab2[i] === ln.id) m[i] = 1;
      const reach = new Uint8Array(N);
      const seed = q => { if (!m[q] && !reach[q]) { reach[q] = 1; st.push(q); } };
      for (let x = 0; x < W; x++) { seed(x); seed(N - W + x); } for (let y = 0; y < H; y++) { seed(y * W); seed(y * W + W - 1); }
      while (st.length) { const q = st.pop(), x = q % W;
        if (x > 0) seed(q - 1); if (x < W - 1) seed(q + 1); if (q >= W) seed(q - W); if (q < N - W) seed(q + W); }
      for (let i = 0; i < N; i++) if (!reach[i]) m[i] = 1;
      ln.mask = m; ln.grow = R;
    });
    return out;
  }
  function median(a) { if (!a.length) return 0; const b = a.slice().sort((x, y) => x - y); return b[b.length >> 1]; }
  function whereOf(dx, dy) {
    const a = Math.atan2(dy, dx) * 180 / Math.PI;           /* image: y down */
    if (a >= -112.5 && a < -67.5) return 'top';
    if (a >= 67.5 && a < 112.5) return 'bottom';
    if (a >= -22.5 && a < 22.5) return 'R';
    if (a >= 157.5 || a < -157.5) return 'L';
    if (a >= -67.5 && a < -22.5) return 'top R';
    if (a >= -157.5 && a < -112.5) return 'top L';
    if (a >= 22.5 && a < 67.5) return 'bottom R';
    return 'bottom L';
  }
  /* EXACT RIM EDGES along one line (d17.187, shop 26 Oct: "the report says same, but the top of the rim is cut -- something
     is wrong"): the darkest point of the rim on that line, then on each side the place where the photo is half way between
     that and the sheet -- to a fraction of a pixel (one lighter pixel inside the rim, a shine line, is passed over). The
     cut-out's rim on the same stretch counts only as SOLID as it is: a half see-through rim counts half. Nothing is averaged
     away -- a rim the robot shaved all the way along is a shaved rim. */
  /* Going OUT and IN from the rim's middle, O and I say what still counts as frame (f) and how strongly (v): on the top and the
     sides any clear difference from the sheet (the rim's own light top edge, a light-brown band of a two-tone frame); under the
     frame and into the lens only darker-or-coloured (a light reflection on the table or on the glass is not frame). The edge
     itself: where the photo is half way between the frame just inside it and the sheet -- to a fraction of a pixel. */
  function edgesAlong(Kat, Aat, c0, c1, outReach, inLimit, O, I) {
    let core = -1, Kr = 0;
    for (let u = c0; u <= c1; u++) { const v = Kat(u); if (v > Kr) { Kr = v; core = u; } }
    if (Kr < 35) return null;                                        /* too little contrast to measure (a clear part, glare) */
    /* walk while the photo is still at least 45% as strong as the frame just behind (the last 4 px): a lighter band of a
       two-tone rim or its light top edge goes on, the sheet or a faint shadow next to a dark rim stops it */
    const walk = (M, dir, limit) => {
      const vals = [Math.max(M.v(core), Kr)]; let u = core, cap = false;
      const plat = () => Math.max.apply(null, vals.slice(-4));
      while (true) {
        if (dir > 0 ? u + 1 > limit : u - 1 < limit) { cap = true; break; }
        const pl = plat(), n1 = M.v(u + dir), n2 = M.v(u + 2 * dir);
        if (n1 >= 0.45 * pl) { u += dir; vals.push(n1); }
        else if (n2 >= 0.45 * pl && (dir > 0 ? u + 2 <= limit : u - 2 >= limit)) { u += 2 * dir; vals.push(n2); }
        else break;
      }
      const h = plat() / 2; let j = u;
      while (j !== core && M.v(j) < h) j -= dir;
      const a0 = M.v(j), a1 = M.v(j + dir);
      return { at: j + dir * (a0 > a1 ? Math.min(1, Math.max(0, (a0 - h) / (a0 - a1))) : 0.5), cap, u };
    };
    const o = walk(O, 1, core + outReach), i = walk(I, -1, inLimit);
    const pOut = o.at, pIn = i.cap ? i.u : i.at;
    let solid = 0; for (let t = pIn; t < pOut; t += 0.25) solid += Aat(Math.round(t)) * Math.min(0.25, pOut - t);
    return { pIn, pOut, tP: pOut - pIn, solid, capped: i.cap, Dr: Kr };
  }
  /* THE TOP OF THE FRAME, column by column (lines from the lens middle cannot reach the top over the bridge, where the rim
     runs into it): in every column over the lenses and the bridge, where the frame's top outline is in the photo and where
     the cut-out starts. A cut-out that starts clearly lower than the photo's outline over 20 px or more has lost the top of
     the rim there (a soft glow above a frame is a weak edge and does not count). */
  function topScan(op, A, P, W, H, lenses) {
    const res = { places: [], cols: [] };
    if (!lenses.length) return res;
    const x0 = Math.max(0, Math.min(...lenses.map(l => l.x0)) - 4), x1 = Math.min(W - 1, Math.max(...lenses.map(l => l.x1)) + 4);
    const cols = [], mr = median(lenses.map(q => q.medRim || 1)) || 1;
    for (let x = x0; x <= x1; x++) {
      /* where the cut starts: 3 cut pixels in a row (a loose soft pixel above an eaten rim is not the rim) */
      let ct = -1; for (let y = 0; y < H - 2; y++) if (op[y * W + x] && op[(y + 1) * W + x] && op[(y + 2) * W + x]) { ct = y; break; }
      if (ct < 0) continue;
      let cb = ct; while (cb < H && op[cb * W + x]) cb++;
      const thick = cb - ct, ok = y => y >= 0 && y < H, Aat = y => ok(y) ? A[y * W + x] / 255 : 0, Cat = y => ok(y) ? P.C[y * W + x] : 0;
      const FS = y => ok(y) && P.Fs[y * W + x] === 1;
      /* the photo's top outline, found from ABOVE (from the sheet down): the first 3 clearly-frame pixels in a row -- so a
         two-tone rim, its light top edge or a line inside it cannot stop it short */
      let yf = -1; for (let y = Math.max(0, ct - Math.round(1.5 * mr + 6)); y <= ct + 2; y++) if (FS(y) && FS(y + 1) && FS(y + 2)) { yf = y; break; }
      if (yf < 0) continue;                                             /* no frame in the photo above the cut's start: nothing lost */
      let lv = 0; for (let y = yf; y < yf + 5; y++) lv = Math.max(lv, Cat(y));
      if (lv < 35) continue;
      const h = lv / 2; let j = yf; for (let s2 = 0; s2 < 3 && Cat(j - 1) >= h; s2++) j--;
      while (j < yf + 4 && Cat(j) < h) j++;
      const lo = Cat(j - 1), hi = Cat(j), pTop = (j - 1) + (hi > lo ? Math.min(1, Math.max(0, (h - lo) / (hi - lo))) : 0.5);
      /* the bottom of the top band: on down while the photo stays at least 45% as strong as the frame just above it */
      const vals = [lv]; let u = j; const uMax = j + Math.round(3 * mr + 8);
      while (u < uMax) { const pl = Math.max.apply(null, vals.slice(-4)), n1 = Cat(u + 1), n2 = Cat(u + 2);
        if (n1 >= 0.45 * pl) { u++; vals.push(n1); } else if (n2 >= 0.45 * pl) { u += 2; vals.push(n2); } else break; }
      const hb = Math.max.apply(null, vals.slice(-4)) / 2; let k = u; while (k > j && Cat(k) < hb) k--;
      const b0 = Cat(k), b1 = Cat(k + 1), pBot = k + (b0 > b1 ? Math.min(1, Math.max(0, (b0 - hb) / (b0 - b1))) : 0.5);
      const tP = pBot - pTop;
      if (tP < 2) continue;                                             /* only a line: not the frame's top */
      /* what the cut is missing from the photo's top down to where the cut is fully solid -- as far as the photo is frame */
      const lim = Math.min(H - 3, Math.round(pTop + 3 * mr + 8));
      let fBot = Math.ceil(pTop) + 1; while (fBot < lim && (P.F[fBot * W + x] || P.F[(fBot + 1) * W + x])) fBot++;   /* frame without a break */
      let ys = Math.max(0, Math.floor(pTop)); while (ys < fBot && !(Aat(ys) >= 0.98 && Aat(ys + 1) >= 0.98 && Aat(ys + 2) >= 0.98)) ys++;
      const yEnd = Math.min(ys, Math.max(fBot, pBot)); let deficit = 0;
      for (let t = pTop; t < yEnd; t += 0.25) deficit += (1 - Aat(Math.round(t))) * Math.min(0.25, yEnd - t);
      /* the numbers shown: the photo's top band from its top outline down to the cut's own lower edge of that band, and what
         the cut has of it (photo minus what is missing) */
      const band = Math.max(Math.min(cb, lim), yEnd) - pTop;
      cols.push({ x, ct, cb, thick, pTop, pBot, fBot, yEnd, tP: band, solid: band - deficit, walkP: tP });
    }
    if (cols.length < 10) return res;
    res.bias = 0;
    cols.forEach(c => { c.loss = c.tP - c.solid; });
    /* the top edge: more than 2 px missing, however thick the bar -- judged on the columns around it (the middle value of
       the columns within 6 px), so one column read a pixel differently does not break a stretch, and one odd column does
       not make one */
    cols.forEach((c, i) => { const near = []; for (let j = i; j >= 0 && cols[j].x >= c.x - 6; j--) near.push(cols[j].loss);
      for (let j = i + 1; j < cols.length && cols[j].x <= c.x + 6; j++) near.push(cols[j].loss);
      c.lossM = median(near); c.thin = c.lossM > 2; });
    res.cols = cols;
    /* stretches of thin columns (2 fine columns in between may be fine), 20 px or more */
    let cur = null; const groups = [];
    let lastFine = -1e9;                   /* columns the photo could not be read in (no column at all) do not split a stretch */
    cols.forEach((c, i) => { if (!c.thin) { lastFine = c.x; return; }
      if (cur && (c.x - cur.last <= 3 || (c.x - cur.last <= 8 && lastFine < cur.last))) { cur.cs.push(c); cur.last = c.x; }
      else { if (cur) groups.push(cur); cur = { cs: [c], last: c.x }; } });
    if (cur) groups.push(cur);
    groups.filter(gq => gq.last - gq.cs[0].x + 1 >= 20 && gq.cs.length >= 10).forEach(gq => {   /* 20 px of frame or more */
      const mx = median(gq.cs.map(c => c.x)), ln = lenses.find(l => mx >= l.x0 && mx <= l.x1);
      res.places.push({ lens: ln ? ln.name : 'bridge', where: 'top', photoPx: median(gq.cs.map(c => c.tP)), cutPx: median(gq.cs.map(c => c.solid)), arcPx: gq.last - gq.cs[0].x + 1, topCols: gq.cs.map(c => c.x) });
    });
    return res;
  }
  function measure(A, P, W, H, pic) {
    const N = W * H, op = new Uint8Array(N);
    for (let i = 0; i < N; i++) op[i] = A[i] >= 60 ? 1 : 0;          /* a clear (see-through) rim is half solid in the cut: still rim */
    let lenses = lensesOf(op, W, H), helped = false;
    if (lenses.length < 2) {
      /* a lens open to the outside (the rim cut right through): the photo's own clear frame next to the cut closes it, so
         that lens is still measured -- and its break shows as the place where the rim is missing */
      const op2 = new Uint8Array(op), st2 = [];
      for (let i = 0; i < N; i++) if (op[i]) st2.push(i);
      while (st2.length) { const q = st2.pop(), x = q % W;                   /* the photo's clear frame joined to the cut's frame */
        for (const k of [q - 1, q + 1, q - W, q + W]) { if (k < 0 || k >= N || op2[k] || !P.Fs[k]) continue; if (Math.abs((k % W) - x) > 1) continue; op2[k] = 1; st2.push(k); } }
      const l2 = lensesOf(op2, W, H);
      if (l2.length > lenses.length) {
        const own = lenses;                                       /* the lenses the cut closes by itself are not "broken" */
        l2.forEach(l => { const c = Math.round(l.cy) * W + Math.round(l.cx); l.broken = !own.some(o => o.mask[c]); });
        lenses = l2; helped = op2; }
    }
    if (!lenses.length) return { measured: false, reason: 'no closed lens found in the cut-out (a rim may be broken right through)', lenses: [] };
    lenses.sort((a, b) => a.cx - b.cx);
    const midX = lenses.reduce((s, l) => s + l.cx, 0) / lenses.length;
    const at = (x, y) => { const xi = Math.round(x), yi = Math.round(y); return (xi < 0 || yi < 0 || xi >= W || yi >= H) ? -1 : yi * W + xi; };
    const maxLen = Math.hypot(W, H);
    lenses.forEach((ln, li) => {
      ln.name = lenses.length === 1 ? 'lens' : li === 0 ? 'left lens' : li === lenses.length - 1 ? 'right lens' : 'middle lens';
      ln.outerIsLeft = ln.cx < midX || (lenses.length === 1 && ln.cx < W / 2);
      const rays = [];
      for (let k = 0; k < NR; k++) {
        const a = k * Math.PI / 180, dx = Math.cos(a), dy = Math.sin(a), ray = { k, dx, dy, valid: false };
        let t = 0, q;
        while (t < maxLen) { q = at(ln.cx + dx * t, ln.cy + dy * t); if (q < 0 || !ln.mask[q]) break; t++; }
        if (q < 0) { rays.push(ray); continue; }
        const t0 = t; let gap = false;
        while (t < t0 + 2 * ln.grow + 3) { q = at(ln.cx + dx * t, ln.cy + dy * t); if (q < 0 || op[q]) break; t++; }
        if (q < 0) { rays.push(ray); continue; }
        if (!op[q]) {                                             /* the cut has no rim here: start at the photo's own rim */
          gap = true; t = t0 + ln.grow;
          for (let u = t0; u < t0 + 2 * ln.grow + 3; u++) { const qq = at(ln.cx + dx * u, ln.cy + dy * u); if (qq < 0) break; if (helped ? helped[qq] : P.Fs[qq]) { t = u; break; } }
        }
        const rin = t;
        let last = rin - 1, miss = 0;
        for (let u = rin; u < maxLen; u++) { const qq = at(ln.cx + dx * u, ln.cy + dy * u); if (qq < 0) break; if (op[qq]) { last = u; miss = 0; } else if (++miss > 1) break; }
        ray.rin = rin; ray.cutEnd = last + 1; ray.tC = gap ? 0 : last + 1 - rin; ray.gap = gap;
        rays.push(ray);
      }
      const tcs = rays.filter(r => r.rin !== undefined && r.tC > 0).map(r => r.tC);
      ln.medRim = median(tcs);
      const reach = Math.max(8, Math.round(3 * ln.medRim + 10)), cap = 2.5 * ln.medRim + 4;
      rays.forEach(r => {
        if (r.rin === undefined) return;
        const pos = u => at(ln.cx + r.dx * u, ln.cy + r.dy * u);
        const Aat = u => { const q = pos(u); return q < 0 ? 0 : A[q] / 255; }, Cat = u => { const q = pos(u); return q < 0 ? 0 : P.C[q]; };
        const Dat = u => { const q = pos(u); return q < 0 ? 0 : P.D[q]; }, ANY = { v: Cat }, DARK = { v: Dat };
        const e = edgesAlong(Dat, Aat, r.rin - 3, r.rin + Math.max(r.tC, 4) + 3, reach, r.rin - (Math.max(r.tC, ln.medRim) + 4), r.dy > 0.3 ? DARK : ANY, DARK);
        if (!e) return;
        let pIn = e.pIn, solid = e.solid;
        /* past that edge the photo may still be clearly frame without a break -- a lighter patch of a tortoise rim, the light
           band of a two-tone rim: then the outline is where that ends (half way to the sheet, judged against the last 5 px, so
           a camera's soft glow does not count). Anything with a gap of sheet in between (a shadow line, the table) does not. */
        { const isF = r.dy > 0.3 ? (u => { const q = pos(u); return q >= 0 && P.Fs[q] === 1 && P.Dk[q] === 1; }) : (u => { const q = pos(u); return q >= 0 && P.Fs[q] === 1; }),
            val = r.dy > 0.3 ? Dat : Cat, base = e.pOut, lim = base + Math.max(4, Math.round(0.6 * Math.max(r.tC, e.tP)));
          let u = Math.round(base);
          while (u < lim) { if (isF(u + 1)) u++; else if (isF(u + 2) && u + 2 <= lim) u += 2; else break; }
          if (u > base + 1) {
            let lv = 0; for (let k2 = u; k2 > u - 5; k2--) lv = Math.max(lv, val(k2));
            const h = lv / 2; let j = u; while (j > base && val(j) < h) j--;
            const a0 = val(j), a1 = val(j + 1), po = j + (a0 > a1 ? Math.min(1, Math.max(0, (a0 - h) / (a0 - a1))) : 0.5);
            if (po > e.pOut + 0.5) { e.pOut = po; e.solid = 0; for (let t = e.pIn; t < po; t += 0.25) e.solid += Aat(Math.round(t)) * Math.min(0.25, po - t); solid = e.solid; r.fromOut = true; }
          } }
        if (e.capped) {                                     /* dark on into the lens (an arm behind the glass): start at the cut's edge */
          pIn = r.rin - 0.5; solid = 0; for (let t = pIn; t < e.pOut; t += 0.25) solid += Aat(Math.round(t)) * Math.min(0.25, e.pOut - t); }
        r.pIn = pIn; r.pOut = e.pOut; r.tP = e.pOut - pIn; r.tCs = solid;
        r.outl = e.pOut; r.inn = Math.max(0, r.rin - pIn);
        r.valid = r.tP >= 2 && Math.max(r.tP, r.tC) <= cap;
      });
      ln.bias = 0;
      /* a line where the photo's "rim" is far thicker than this lens's ordinary rim runs along an arm, a hinge or a nose pad
         (the robot leaves the arms out on purpose): not a rim line */
      const pm = median(rays.filter(r => r.valid).map(r => r.tP));
      rays.forEach(r => { if (r.valid && r.tP > 1.6 * pm + 4) { r.valid = false; r.arm = true; } });
      /* thin = the solid rim in the cut is clearly less than the photo's rim: more than 2 px, or more than 10% of it, missing */
      rays.forEach((r, k) => { if (!r.valid) return; const near = [];
        for (let d = -2; d <= 2; d++) { const q = rays[(k + d + NR) % NR]; if (q && q.valid) near.push(q.tP - q.tCs); }
        r.thin = median(near) > Math.max(2, 0.1 * r.tP); });   /* judged with the 2 lines each side (one odd line does not count) */
      ln.rays = rays;
      /* places: stretches of thin lines round the lens (one line in between may be fine), at least 6 px of rim long */
      const places = [], n = NR;
      let start = -1;
      for (let k0 = 0; k0 < n; k0++) if (!rays[k0].thin) { start = k0; break; }
      if (start < 0) start = 0;
      let cur = null;
      for (let s = 1; s <= n; s++) {
        const k = (start + s) % n, r = rays[k];
        if (r.thin) { if (!cur) cur = { ks: [k], miss: 0 }; else { cur.ks.push(k); cur.miss = 0; } }
        else if (cur) { if (++cur.miss > 1) { places.push(cur); cur = null; } }
      }
      if (cur) places.push(cur);
      const val0 = rays.filter(r => r.valid), photoMed = median(val0.map(r => r.tP));
      ln.places = places.map(pl => {
        const rs = pl.ks.map(k => rays[k]), rr = median(rs.map(r => r.rin)), arc = pl.ks.length * Math.PI / 180 * rr;
        const sx = rs.reduce((s, r) => s + r.dx, 0), sy = rs.reduce((s, r) => s + r.dy, 0);
        let w = whereOf(sx, sy);
        w = w.replace(/\bL\b/, ln.outerIsLeft ? 'outer side' : 'nose side').replace(/\bR\b/, ln.outerIsLeft ? 'nose side' : 'outer side');
        if (/^(top|bottom) (outer|nose) side$/.test(w)) w = w.replace(' side', ' corner');
        return { lens: ln.name, where: w, photoPx: median(rs.map(r => r.tP)), cutPx: median(rs.map(r => r.tCs)), arcPx: Math.round(arc), ks: pl.ks };
      }).filter(pl => pl.photoPx - pl.cutPx >= 2 && (pl.cutPx <= 1
        /* a gap: where the cut really leaves this lens open, from 8 px of rim; otherwise only a long stretch (30 px or more)
           that looks like this lens's ordinary rim in the photo -- a short one beside a nose pad or an arm is not counted */
        ? (ln.broken && pl.arcPx >= 8) || (pl.arcPx >= 30 && Math.abs(pl.photoPx - photoMed) <= Math.max(3, 0.5 * ln.medRim))
        : pl.arcPx >= 20));                  /* a thinner rim: from 20 px of rim */
      const val = rays.filter(r => r.valid);
      ln.photoPx = median(val.map(r => r.tP)); ln.cutPx = median(val.map(r => r.tCs)); ln.validRays = val.length; ln.thinRays = val.filter(r => r.thin).length;
    });
    const top = topScan(op, A, P, W, H, lenses);
    const valid = lenses.reduce((s, l) => s + l.validRays, 0), thin = lenses.reduce((s, l) => s + l.thinRays, 0);
    const places = [].concat.apply([], lenses.map(l => l.places));
    top.places.forEach(tp => {                                    /* the top seen both ways is listed once: the column count */
      for (let i = places.length - 1; i >= 0; i--) if (places[i].lens === tp.lens && /^top/.test(places[i].where) && !places[i].topCols) places.splice(i, 1);
      places.push(tp); });
    const medRim = median(lenses.map(l => l.medRim));
    if (medRim < 2.5) return { measured: false, reason: 'the rim is too thin to measure (rimless or a very fine wire)', lenses, medRim };
    if (valid < NR * 0.25 * lenses.length) return { measured: false, reason: 'too little plain rim to measure', lenses, medRim };
    let closed = null; if (helped) { closed = new Uint8Array(N); for (let i = 0; i < N; i++) if (helped[i] && !op[i]) closed[i] = 1; }
    const dots = dotsOf(A, pic, lenses, top, W, H);
    dots.forEach(d => {
      const ln = lenses.slice().sort((a, b) => Math.hypot(a.cx - d.x, a.cy - d.y) - Math.hypot(b.cx - d.x, b.cy - d.y))[0];
      const inL = ln && d.x >= ln.x0 - 4 && d.x <= ln.x1 + 4;
      let w = whereOf(d.x - ln.cx, d.y - ln.cy);
      w = w.replace(/\bL\b/, ln.outerIsLeft ? 'outer side' : 'nose side').replace(/\bR\b/, ln.outerIsLeft ? 'nose side' : 'outer side');
      if (/^(top|bottom) (outer|nose) side$/.test(w)) w = w.replace(' side', ' corner');
      places.push({ lens: inL ? ln.name : 'bridge', where: inL ? w : 'top', dot: true, photoPx: 0, cutPx: 0, arcPx: d.pix.length, at: [d.x, d.y] });
    });
    return { measured: true, ok: places.length === 0, lenses, places, thinPct: valid ? Math.round(100 * thin / valid) : 0, medRim: Math.round(medRim), broken: !!helped, closed, top, dots };
  }
  /* WHITE DOTS on the rim (shop 26 Oct: "the right eye upper ring has a white dot -- my eyes go to it. It has to be black,
     like the real frame"): a tiny light spot (4 x 4 px or less) inside the solid rim, with even dark rim all round it --
     dust or a glint in the photo, not part of the frame. A crystal, a stud or a logo is bigger; a tortoise pattern is not
     even around it, so those are never touched. The repair gives the dot the colour of the rim around it. */
  function dotsOf(A, pic, lenses, top, W, H) {
    if (!pic) return [];
    const N = W * H, zone = new Uint8Array(N), used = new Uint8Array(N), out = [];
    const gray = i => 0.299 * pic[i * 4] + 0.587 * pic[i * 4 + 1] + 0.114 * pic[i * 4 + 2];
    /* only the rim round the lenses and the top between them -- not the outer sides, where end pieces carry pins and studs */
    lenses.forEach(ln => (ln.rays || []).forEach(r => { if (!r.valid || !(r.tC >= 7)) return;
      if (Math.abs(r.dy) < 0.77 && (r.dx < 0) === !!ln.outerIsLeft) return;
      for (let t = r.rin + 3; t <= r.rin + r.tC - 4; t += 0.5) { const x = Math.round(ln.cx + r.dx * t), y = Math.round(ln.cy + r.dy * t); if (x >= 0 && y >= 0 && x < W && y < H) zone[y * W + x] = 1; } }));
    const xa = Math.min(...lenses.map(l => l.x0)), xb = Math.max(...lenses.map(l => l.x1));
    ((top && top.cols) || []).forEach(c => { if (c.x < xa || c.x > xb) return; for (let y = c.ct + 3; y <= Math.min(c.cb, c.ct + 60) - 4; y++) zone[y * W + c.x] = 1; });
    for (let y = 3; y < H - 3; y++) for (let x = 3; x < W - 3; x++) {
      const i = y * W + x; if (!zone[i] || used[i] || A[i] < 200) continue;          /* (a rim the robot left half see-through counts too) */
      const g = gray(i); let peak = true;
      for (let dy = -1; dy <= 1 && peak; dy++) for (let dx = -1; dx <= 1; dx++) if ((dx || dy) && gray(i + dy * W + dx) > g) { peak = false; break; }
      if (!peak) continue;
      const ring = []; let solid = true;
      for (let dy = -3; dy <= 3; dy++) for (let dx = -3; dx <= 3; dx++) { if (Math.max(Math.abs(dx), Math.abs(dy)) !== 3) continue; const q = i + dy * W + dx; if (A[q] < 110) { solid = false; break; } ring.push(q); }
      if (!solid || ring.length !== 24) continue;
      const rg = ring.map(gray).sort((a, b) => a - b), med = rg[12], mean = rg.reduce((a, b) => a + b, 0) / 24;
      const sd = Math.sqrt(rg.reduce((a, b) => a + (b - mean) * (b - mean), 0) / 24);
      if (med > 60 || g - med < 45 || g < 2 * med + 25 || sd > 14) continue;      /* a clearly light dot on a dark, even rim */
      const pix = []; let x0 = 9, x1 = -9, y0 = 9, y1 = -9;
      for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) { const q = i + dy * W + dx; if (gray(q) > med + 12) { pix.push(q); x0 = Math.min(x0, dx); x1 = Math.max(x1, dx); y0 = Math.min(y0, dy); y1 = Math.max(y1, dy); } }
      if (pix.length > 12 || x1 - x0 > 3 || y1 - y0 > 3) continue;
      const col = [0, 1, 2].map(ch => { const v = ring.map(q => pic[q * 4 + ch]).sort((a, b) => a - b); return v[12]; });
      pix.forEach(q => { used[q] = 1; });
      out.push({ x, y, pix, col });
    }
    return out;
  }
  /* THE MISSING PART of each place, to put back to EXACTLY the photo's thickness (shop, 26 Oct: "if it is 32 px in the photo,
     after the repair it has to be 32 px -- it should not cut, it should not dot"): the whole band from the photo's inner rim
     edge to the photo's own outline, solid -- every pixel of it, shine included -- over the whole stretch and 3 lines more at
     each end (so it blends into the rim that is there); a line inside the stretch that could not be measured takes its
     neighbours' band. Only where the cut has less than the photo. Nothing is ever taken away. */
  function missingMask(res, A, P, W, H, pic, sd) {
    /* each pixel gets the solid it should have: a pixel wholly inside the photo's rim 255, a pixel the photo's edge runs
       through only its share (an edge half across it: half) -- so the rim comes back to the photo's thickness to a fraction
       of a pixel, with the same soft edge, never thicker */
    const N = W * H, m = new Uint8Array(N), from = new Int32Array(N).fill(-1), paint = new Uint8Array(N), rgb = new Int32Array(N).fill(-1), clear = new Uint8Array(N), setA = new Int16Array(N).fill(-1);
    m.from = from; m.paint = paint; m.rgb = rgb; m.clear = clear; m.setA = setA;   /* an edge pixel takes the colour of the rim just inside it (no light line along the edge) */
    const gr = (a, i) => 0.299 * a[i * 4] + 0.587 * a[i * 4 + 1] + 0.114 * a[i * 4 + 2];
    /* a white dot on the rim: the colour of the rim around it (and the pixel next to it, if it is lighter too) */
    (res.dots || []).forEach(dt => { const c = (dt.col[0] << 16) | (dt.col[1] << 8) | dt.col[2], lim = 0.299 * dt.col[0] + 0.587 * dt.col[1] + 0.114 * dt.col[2] + 8;
      const i0 = dt.y * W + dt.x;           /* every pixel of the 5 x 5 round it that is lighter than the rim (the dot and its glow) */
      for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) { const k = i0 + dy * W + dx; if (k < 0 || k >= N || !pic) continue; if (gr(pic, k) > lim || dt.pix.includes(k)) { paint[k] = 2; rgb[k] = c; } } });
    /* a solid pixel inside the photo's rim band whose colour is far from the photo (a light block the clean-up left in the
       rim) gets the photo's own colour back -- only in the places being repaired, only where the photo is clearly frame */
    const odd = i => pic && sd && P.Fs[i] && Math.max(Math.abs(pic[i * 4] - sd[i * 4]), Math.abs(pic[i * 4 + 1] - sd[i * 4 + 1]), Math.abs(pic[i * 4 + 2] - sd[i * 4 + 2])) > 60;
    /* an edge pixel the cut already has, but lighter than the rim just inside it (a light fringe along the edge): the rim's colour */
    const fringe = (i, f) => pic && sd && f >= 0 && gr(pic, i) - gr(sd, f) > 40;
    /* just outside the photo's outline: where the photo shows only the sheet, the robot's haze goes; where the photo has the
       rim's light edge, the cut's pixel gets the photo's light colour (the robot left it grey -- a grey haze line) */
    const haze = (i, ref, outer) => {
      if (!sd || ref < 0) return;
      /* the sheet right beside it (3 px further out) or the sheet estimate, whichever is lighter */
      const sh = Math.max(P.Bg[i], outer >= 0 ? gr(sd, outer) : 0), dark = sh - gr(sd, i), rimDark = Math.max(20, sh - gr(sd, ref));
      if (dark > 6) {                     /* the photo's own soft edge here: exactly as solid as the photo is dark, in the rim's colour */
        const a = Math.round(255 * Math.min(1, dark / rimDark)); if (Math.abs(a - A[i]) > 12) { setA[i] = a; from[i] = ref; } return; }
      if (!P.F[i]) clear[i] = 1;          /* plain sheet: the robot's haze goes */
      else if (pic && gr(sd, i) - gr(pic, i) > 60) paint[i] = 1;   /* the rim's light edge: its light colour, not grey */
    };
    const cover = (d, L, Hh) => Math.max(0, Math.min(d + 0.5, Hh) - Math.max(d - 0.5, L));
    res.lenses.forEach(ln => {
      if (!(ln.places && ln.places.length)) return;
      const rays = ln.rays, want = new Uint8Array(NR);
      const short = k => { const r = rays[(k + NR) % NR]; return r && r.valid && r.tP - r.tCs >= 1; };
      ln.places.forEach(pl => { let a0 = pl.ks[0], n0 = (pl.ks[pl.ks.length - 1] - a0 + NR) % NR;
        /* the stretch goes on as long as the rim next to it is still short of the photo (the ends of a loss are shallower) */
        for (let g2 = 0; g2 < 40 && (short(a0 - 1) || short(a0 - 2)); g2++) { a0 = (a0 - 1 + NR) % NR; n0++; }
        for (let g2 = 0; g2 < 40 && (short(a0 + n0 + 1) || short(a0 + n0 + 2)); g2++) n0++;
        for (let d = -3; d <= n0 + 3; d++) want[(a0 + d + NR) % NR] = 1; });
      const lo = new Float32Array(NR).fill(NaN), hi = new Float32Array(NR).fill(NaN);
      for (let k = 0; k < NR; k++) { if (!want[k]) continue; const r = rays[k];
        if (r.valid && r.tP - r.tCs >= 0.5) { lo[k] = r.pIn; hi[k] = r.pOut; } }
      for (let k = 0; k < NR; k++) { if (!want[k] || !isNaN(lo[k])) continue;
        let da = 0, db = 0;
        for (let d = 1; d <= 6; d++) { if (!da && !isNaN(lo[(k - d + NR) % NR])) da = d; if (!db && !isNaN(lo[(k + d) % NR])) db = d; }
        if (da && db) { const ka = (k - da + NR) % NR, kb = (k + db) % NR, f = da / (da + db);
          lo[k] = lo[ka] * (1 - f) + lo[kb] * f; hi[k] = hi[ka] * (1 - f) + hi[kb] * f; } }
      let R = 0; for (let k = 0; k < NR; k++) if (!isNaN(hi[k]) && hi[k] > R) R = hi[k];
      if (!R) return; R = Math.ceil(R) + 2;
      const x0 = Math.max(0, Math.floor(ln.cx - R)), x1 = Math.min(W - 1, Math.ceil(ln.cx + R)), y0 = Math.max(0, Math.floor(ln.cy - R)), y1 = Math.min(H - 1, Math.ceil(ln.cy + R));
      for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) {
        const i = y * W + x;
        const dx = x - ln.cx, dy = y - ln.cy, d = Math.hypot(dx, dy);
        let deg = Math.atan2(dy, dx) * 180 / Math.PI; if (deg < 0) deg += 360;
        const ka = Math.floor(deg) % NR, kb = (ka + 1) % NR, f = deg - Math.floor(deg);
        let L, Hh;
        if (!isNaN(lo[ka]) && !isNaN(lo[kb])) { L = lo[ka] * (1 - f) + lo[kb] * f; Hh = hi[ka] * (1 - f) + hi[kb] * f; }
        else if (!isNaN(lo[ka]) && f < 0.5) { L = lo[ka]; Hh = hi[ka]; }
        else if (!isNaN(lo[kb]) && f >= 0.5) { L = lo[kb]; Hh = hi[kb]; }
        else continue;
        /* just outside the photo's outline (not under the frame), where the photo shows only the sheet: a light haze the robot
           left there is taken away, so the edge is as clean as in the photo */
        if (d >= Hh + 0.5) { if (d <= Hh + 3.5 && dy <= 0.3 * d && A[i] > 0) { const t = Math.max(L + 0.5, Hh - 2), xr = Math.round(ln.cx + dx / d * t), yr = Math.round(ln.cy + dy / d * t);
            const xo = Math.round(ln.cx + dx / d * (d + 3)), yo = Math.round(ln.cy + dy / d * (d + 3));
            haze(i, xr >= 0 && yr >= 0 && xr < W && yr < H ? yr * W + xr : -1, xo >= 0 && yo >= 0 && xo < W && yo < H ? yo * W + xo : -1); } continue; }
        const cv = cover(d, L, Hh); if (cv <= 0.02) continue;
        let fi = -1;
        if (cv < 0.98) { const t = Hh - L > 3 ? Math.min(Hh - 1.5, Math.max(L + 1.5, d)) : (L + Hh) / 2,
          xi = Math.round(ln.cx + dx / d * t), yi = Math.round(ln.cy + dy / d * t); if (xi >= 0 && yi >= 0 && xi < W && yi < H) fi = yi * W + xi; }
        if (A[i] >= 250) { if (cv >= 0.98 && odd(i)) paint[i] = 1; else if (cv < 0.98 && fringe(i, fi)) { paint[i] = 1; from[i] = fi; } continue; }
        const wantA = Math.round(255 * Math.min(1, cv));
        if (wantA <= A[i]) { if (cv < 0.98 && fringe(i, fi)) { paint[i] = 1; from[i] = fi; } continue; }
        m[i] = Math.max(1, wantA); from[i] = fi;
      }
    });
    /* the top of the frame, column by column: every column of the stretch (and 3 more each side) that has less solid rim
       than the photo is filled over the photo's own band, edge pixels by their share */
    if (res.top && res.top.places.length) {
      const byX = {}; res.top.cols.forEach(c => { byX[c.x] = c; });
      const shortX = x => byX[x] && byX[x].tP - byX[x].solid >= 1;
      const near = (x, d) => { for (let k = 1; k <= 6; k++) { const c = byX[x + d * k]; if (c) return c; } return null; };
      const mr = median(res.lenses.map(q => q.medRim || 1)) || 1;
      res.top.places.forEach(pl => { let xa = Math.min(...pl.topCols), xb = Math.max(...pl.topCols);
        /* as long as the top next to it is still short of the photo (a column or two the photo could not be read in is passed) */
        const goOn = (x, d) => { let seen = 0; for (let k = 1; k <= 8 && seen < 3; k++) { const c = byX[x + d * k]; if (!c) continue; seen++; if (shortX(x + d * k)) return true; } return false; };
        while (goOn(xa, -1)) xa--;
        while (goOn(xb, 1)) xb++;
        for (let k = 0; k < 6 && !byX[xa - 1] && xa > 0; k++) xa--;   /* and over columns not read next to it (filled only where the cut lacks) */
        for (let k = 0; k < 6 && !byX[xb + 1] && xb < W - 1; k++) xb++;
        xa -= 3; xb += 3;
        for (let x = Math.max(0, xa); x <= Math.min(W - 1, xb); x++) {
          let c = byX[x];
          if (!c) {                                     /* not read: the photo's band from the columns on each side */
            const l = near(x, -1), r = near(x, 1); if (!l || !r) continue;
            const f = (x - l.x) / (r.x - l.x); c = { x, pTop: l.pTop * (1 - f) + r.pTop * f, pBot: l.pBot * (1 - f) + r.pBot * f, tP: 1, solid: 0 };
            const lim = Math.min(H - 3, Math.round(c.pTop + 3 * mr + 8)); let fb = Math.ceil(c.pTop) + 1;
            while (fb < lim && (P.F[fb * W + x] || P.F[(fb + 1) * W + x])) fb++; c.fBot = fb;
          }
          /* the photo's band -- and on down to where the cut is solid again, if the bite goes deeper (photo frame only) */
          /* from the photo's top outline down to where the cut is fully solid -- never past the end of the photo's unbroken
             frame (an arm seen through the lens below the rim is not rim); below that the cut is left as it is */
          let ys = Math.max(0, Math.floor(c.pTop)); const yMax = Math.min(H - 3, c.fBot);
          while (ys < yMax && !(A[ys * W + x] >= 250 && A[(ys + 1) * W + x] >= 250 && A[(ys + 2) * W + x] >= 250)) ys++;
          const L = c.pTop, Hh = ys - 0.5, mid = (L + Hh) / 2;
          for (let y = ys; y < Math.min(yMax, Math.round(c.pBot)); y++) { const i = y * W + x; if (A[i] >= 250 && odd(i)) paint[i] = 1; }
          /* above the photo's top outline, where the photo shows only the sheet: the robot's light haze is taken away */
          for (let y = Math.max(0, Math.ceil(L - 3.5)); y + 0.5 <= L; y++) { const i = y * W + x; if (A[i] > 0) haze(i, Math.min(H - 1, Math.round(L + 2)) * W + x, y >= 3 ? (y - 3) * W + x : -1); }
          const edgeFrom = () => Math.max(0, Math.min(H - 1, Math.round(L + 2))) * W + x;   /* the rim 2 px under the outline */
          for (let y = Math.max(0, Math.floor(L)); y <= Math.min(H - 1, Math.ceil(Math.max(Hh, L + 1))); y++) {
            const i = y * W + x, cv = cover(y, L, Math.max(Hh, Math.min(c.pBot, L + 2))); if (cv <= 0.02) continue;
            const fi = cv < 0.98 ? edgeFrom() : -1;
            const wantA = Math.round(255 * Math.min(1, cv));
            if (wantA <= A[i] || y >= ys) { if (cv < 0.98 && fringe(i, fi)) { paint[i] = 1; from[i] = fi; } continue; }
            if (wantA > m[i]) m[i] = wantA;
            if (fi >= 0) from[i] = fi;
          }
        } });
    }
    return m;
  }
  /* after the repair, every place measured again on the repaired picture: photo px, what the cut had, what it has now */
  function verify(b, a) {
    return b.places.map(pl => {
      if (pl.dot) { const gone = !(a.dots || []).some(d => Math.abs(d.x - pl.at[0]) <= 2 && Math.abs(d.y - pl.at[1]) <= 2);
        return { lens: pl.lens, where: pl.where, dot: true, gone, photoPx: 0, beforePx: 0, afterPx: 0 }; }
      let after = null, photo = pl.photoPx;
      if (pl.topCols && a.top && a.top.cols && a.top.cols.length) {
        const set = new Set(pl.topCols), cs = a.top.cols.filter(c => set.has(c.x));
        if (cs.length) { after = median(cs.map(c => c.solid)); photo = median(cs.map(c => c.tP)); }
      } else if (pl.ks && a.lenses && a.lenses.length) {
        const lb = b.lenses.find(l => l.name === pl.lens) || b.lenses[0];
        const la = a.lenses.slice().sort((p, q) => Math.hypot(p.cx - lb.cx, p.cy - lb.cy) - Math.hypot(q.cx - lb.cx, q.cy - lb.cy))[0];
        const rs = la && la.rays ? pl.ks.map(k => la.rays[k]).filter(r => r && r.valid) : [];
        if (rs.length) { after = median(rs.map(r => r.tCs)); photo = median(rs.map(r => r.tP)); }
      }
      return { lens: pl.lens, where: pl.where, photoPx: Math.round(photo), beforePx: Math.round(pl.cutPx), afterPx: after == null ? null : Math.round(after) };
    }).reduce((out, v) => {          /* the same part of a lens in several stretches: shown once -- the stretch furthest from the photo after */
      const o = out.find(q => q.lens === v.lens && q.where === v.where && !!q.dot === !!v.dot), gap = q => q.dot ? (q.gone ? 0 : 1e9) : q.afterPx == null ? 1e9 : q.photoPx - q.afterPx;
      if (!o) out.push(v); else if (gap(v) > gap(o) || (gap(v) === gap(o) && v.photoPx - v.beforePx > o.photoPx - o.beforePx)) Object.assign(o, v);
      return out; }, []);
  }
  /* ================= THE ARM ON A 30° PICTURE (d17.189, shop 26 Oct: "for the 30° try-on we need the side only -- the front
     of a 30° picture makes no difference to us -- check only the arm") =================
     Where the arm is: the cut-out's height column by column -- the front with its lenses is tall, the arm is a thin band;
     going in from the arm's end, the arm stops where the picture becomes nearly as tall as the front. Only there:
       - the arm in the photo = where the photo is at least half as dark (or coloured) as the arm's own core;
       - a BITE = arm in the photo, missing or half see-through in the cut, 8 px or more together;
       - DOTS = small bits the cut keeps where the photo shows only the sheet (a clear plastic tip, joined to the arm and
         bigger than a dot, is never taken for one).
     The repair puts the missing arm back from the photo's own pixels (an edge pixel as solid as the photo is dark there)
     and takes the dots away. Nothing outside the arm is touched. */
  function armZone(A, W, H) {
    const ext = new Float32Array(W); let fx0 = -1, fx1 = -1;
    for (let x = 0; x < W; x++) { let y0 = -1, y1 = -1; for (let y = 0; y < H; y++) if (A[y * W + x] > 25) { if (y0 < 0) y0 = y; y1 = y; }
      ext[x] = y0 < 0 ? 0 : y1 - y0 + 1; if (y0 >= 0) { if (fx0 < 0) fx0 = x; fx1 = x; } }
    if (fx0 < 0 || fx1 - fx0 < 60) return null;
    const sm = new Float32Array(W);
    for (let x = fx0; x <= fx1; x++) { const v = []; for (let k = -4; k <= 4; k++) { const q = x + k; if (q >= fx0 && q <= fx1) v.push(ext[q]); } sm[x] = median(v); }
    const fw = fx1 - fx0, part = (a, b) => { const v = []; for (let x = Math.round(fx0 + a * fw); x <= Math.round(fx0 + b * fw); x++) v.push(sm[x]); return median(v); };
    const left = part(0, 0.15) < part(0.85, 1);                       /* the arm's end is the thin side */
    const all = Array.from(sm.slice(fx0, fx1 + 1)).sort((a, b) => a - b), maxE = all[Math.floor(all.length * 0.95)];
    const armMed = left ? part(0.12, 0.30) : part(0.70, 0.88);
    if (!(armMed > 0) || !(maxE > 2.2 * armMed)) return null;          /* no clear front and arm: nothing to check */
    const lim = Math.max(0.45 * maxE, 3 * armMed);
    /* from the arm's end: past the tip (it can bend down a long way), along the thin arm (30 columns or more in a row),
       to where the front begins */
    let hinge = -1, run = 0, onArm = false;
    const step = left ? 1 : -1;
    for (let x = left ? fx0 : fx1; left ? x <= fx1 : x >= fx0; x += step) {
      if (!onArm) { run = sm[x] <= 2 * armMed ? run + 1 : 0; if (run >= 30) onArm = true; if (Math.abs(x - (left ? fx0 : fx1)) > 0.6 * fw) break; }
      else if (sm[x] > lim) { hinge = x; break; }
    }
    if (hinge < 0) return null;
    const x0 = left ? fx0 : hinge + 3, x1 = left ? hinge - 3 : fx1;
    if (x1 - x0 < 40) return null;
    return { x0, x1, left, hinge, armPx: armMed };
  }
  function blobs(mask, W, H, x0, x1) {                                 /* pieces (8 neighbours) of a mask inside columns x0..x1 */
    const lab = new Int32Array(W * H), out = []; let n = 0; const st = [];
    for (let y = 0; y < H; y++) for (let x = x0; x <= x1; x++) { const s0 = y * W + x; if (!mask[s0] || lab[s0]) continue;
      n++; lab[s0] = n; st.push(s0); const pix = [];
      while (st.length) { const q = st.pop(), qx = q % W, qy = (q - qx) / W; pix.push(q);
        for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { if (!dx && !dy) continue; const nx = qx + dx, ny = qy + dy;
          if (nx < x0 || nx > x1 || ny < 0 || ny >= H) continue; const k = ny * W + nx; if (mask[k] && !lab[k]) { lab[k] = n; st.push(k); } } }
      out.push(pix); }
    return out;
  }
  /* the sheet behind the arm, from the photo where the cut-out is see-through (the frame itself never counts: a thick
     arm or the front can make the general sheet estimate look brown or black right next to the arm) */
  function armMaps(A, sd, W, H, z) {
    const N = W * H, CS = 24, gx = Math.ceil((z.x1 - z.x0 + 1) / CS), gy = Math.ceil(H / CS), cells = [];
    const all = [[], [], []];
    for (let cy = 0; cy < gy; cy++) for (let cx = 0; cx < gx; cx++) {
      const r = [], g = [], b = [];
      for (let y = cy * CS; y < Math.min(H, (cy + 1) * CS); y++) for (let x = z.x0 + cx * CS; x < Math.min(z.x1 + 1, z.x0 + (cx + 1) * CS); x++) {
        const i = y * W + x; if (A[i] === 0) { r.push(sd[i * 4]); g.push(sd[i * 4 + 1]); b.push(sd[i * 4 + 2]); } }
      if (r.length >= 30) { cells.push([median(r), median(g), median(b)]); all[0].push(cells[cells.length - 1][0]); all[1].push(cells[cells.length - 1][1]); all[2].push(cells[cells.length - 1][2]); }
      else cells.push(null);
    }
    const glob = all[0].length ? [median(all[0]), median(all[1]), median(all[2])] : [235, 235, 235];
    for (let pass = 0; pass < 6; pass++) {                         /* cells with no sheet in them take a neighbour's */
      let left = 0; const nxt = cells.slice();
      for (let cy = 0; cy < gy; cy++) for (let cx = 0; cx < gx; cx++) { const k = cy * gx + cx; if (cells[k]) continue; left++;
        for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { const qx = cx + dx, qy = cy + dy; if (qx >= 0 && qy >= 0 && qx < gx && qy < gy && cells[qy * gx + qx]) { nxt[k] = cells[qy * gx + qx]; break; } } }
      for (let k = 0; k < cells.length; k++) cells[k] = nxt[k];
      if (!left) break;
    }
    const D = new Float32Array(N), C = new Float32Array(N);
    for (let y = 0; y < H; y++) for (let x = z.x0; x <= z.x1; x++) {
      const i = y * W + x, c = cells[Math.floor(y / CS) * gx + Math.floor((x - z.x0) / CS)] || glob, r = sd[i * 4], g = sd[i * 4 + 1], b = sd[i * 4 + 2];
      const gray = 0.299 * r + 0.587 * g + 0.114 * b, bgG = 0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2];
      const d = Math.max(Math.abs(r - c[0]), Math.abs(g - c[1]), Math.abs(b - c[2])), sat = (Math.max(r, g, b) - Math.min(r, g, b)) / 255;
      D[i] = Math.max(0, bgG - gray, sat > 0.15 ? d : 0); C[i] = d;
    }
    return { D, C };
  }
  function armMeasure(A, P, W, H, z, M) {
    const N = W * H, x0 = z.x0, x1 = z.x1;
    P = { D: M.D, C: M.C };                                         /* the arm's own sheet, see above */
    const v = []; for (let y = 0; y < H; y++) for (let x = x0; x <= x1; x++) { const i = y * W + x; if (A[i] > 200 && P.D[i] > 25) v.push(P.D[i]); }
    if (v.length < 30) return { measured: false, reason: 'the arm could not be found in the photo' };
    v.sort((a, b) => a - b); const Dc = v[Math.floor(v.length * 0.85)];
    if (Dc < 30) return { measured: false, reason: 'the arm is too pale to measure (clear arm)' };
    const raw = new Uint8Array(N);                                    /* at least a third as dark (or coloured) as the arm's core -- a shadow on the table is not */
    for (let y = 0; y < H; y++) for (let x = x0; x <= x1; x++) { const i = y * W + x; if (P.D[i] >= 0.35 * Dc) raw[i] = 1; }
    /* only the pieces that are the arm: most of each also in the cut-out (a tag's print or a shadow is not) */
    const Mp = new Uint8Array(N);
    blobs(raw, W, H, x0, x1).forEach(pix => { if (pix.length < 20) return; let o = 0; pix.forEach(q => { if (A[q] >= 128) o++; }); if (o >= 0.3 * pix.length) pix.forEach(q => { Mp[q] = 1; }); });
    /* a light line or shine INSIDE the arm (a groove, a highlight) is arm too: holes in it are filled */
    { const out = new Uint8Array(N), st = [];
      const push = i => { if (!out[i] && !Mp[i]) { out[i] = 1; st.push(i); } };
      for (let x = x0; x <= x1; x++) { push(x); push((H - 1) * W + x); }
      for (let y = 0; y < H; y++) { push(y * W + x0); push(y * W + x1); }
      while (st.length) { const q = st.pop(), qx = q % W, qy = (q - qx) / W;
        if (qx > x0) push(q - 1); if (qx < x1) push(q + 1); if (qy > 0) push(q - W); if (qy < H - 1) push(q + W); }
      for (let y = 0; y < H; y++) for (let x = x0; x <= x1; x++) { const i = y * W + x; if (!out[i]) Mp[i] = 1; } }
    const core = new Uint8Array(N);
    for (let y = 1; y < H - 1; y++) for (let x = Math.max(1, x0); x <= Math.min(W - 2, x1); x++) { const i = y * W + x; if (Mp[i] && Mp[i - 1] && Mp[i + 1] && Mp[i - W] && Mp[i + W]) core[i] = 1; }
    const miss = new Uint8Array(N); for (let i = 0; i < N; i++) if (core[i] && A[i] < 160) miss[i] = 1;
    /* DOTS: separate little pieces of the cut-out (not joined to the arm) where the photo shows no arm;
       HAZE: a light, part see-through edge the robot left along the arm, just outside the photo's own arm (the sheet there) */
    const cutBits = new Uint8Array(N); for (let y = 0; y < H; y++) for (let x = x0; x <= x1; x++) { const i = y * W + x; if (A[i] >= 100) cutBits[i] = 1; }
    const dots = [], hingeX = z.left ? x1 : x0, atHinge = q => Math.abs(q % W - hingeX) <= 40;   /* the hinge end (the end piece joins there): dots and haze left alone */
    blobs(cutBits, W, H, x0, x1).forEach(pix => { if (pix.length < 2 || pix.some(atHinge)) return; let o = 0, sh = 0; pix.forEach(q => { if (Mp[q]) o++; if (P.C[q] < 30 && P.D[q] < 0.2 * Dc) sh++; });
      /* a small bit not on the arm, or a bigger loose patch where the photo shows only the sheet (a table reflection) */
      if ((pix.length <= 60 && o <= 0.3 * pix.length) || (o <= 0.1 * pix.length && sh >= 0.8 * pix.length)) dots.push(pix); });
    /* a reflection or shadow on the table UNDER the arm that the cut kept (joined to the tip): below the photo's own arm in
       that column, where the photo shows only the sheet */
    { const bot = new Int32Array(W).fill(-1); for (let x = x0; x <= x1; x++) for (let y = H - 1; y >= 0; y--) if (Mp[y * W + x]) { bot[x] = y; break; }
      const under = new Uint8Array(N);
      for (let x = x0; x <= x1; x++) for (let y = bot[x] + 3; y < H; y++) { const i = y * W + x; if (bot[x] >= 0 && A[i] >= 30 && P.C[i] < 35 && P.D[i] < 0.2 * Dc) under[i] = 1; }
      const joined = dilate(under, W, H, 2);                          /* a speckled patch is one patch */
      blobs(joined, W, H, x0, x1).forEach(pix => { if (pix.length < 30 || pix.some(atHinge)) return; const mine = pix.filter(q => under[q]); if (mine.length >= 12) dots.push(mine); }); }
    const M1 = dilate(Mp, W, H, 1), M4 = dilate(Mp, W, H, 4), haze = [];
    for (let y = 0; y < H; y++) for (let x = x0; x <= x1; x++) { const i = y * W + x; if (A[i] > 20 && !M1[i] && M4[i] && P.D[i] < 0.15 * Dc && P.C[i] < 30 && !atHinge(i)) haze.push(i); }
    const colThick = x => { let ph = 0, ct = 0; for (let y = 0; y < H; y++) { const i = y * W + x; if (Mp[i]) { ph++; ct += A[i] / 255; } } return [ph, ct]; };
    const ths = []; for (let x = x0; x <= x1; x++) { const t = colThick(x); if (t[0] > 0) ths.push(t); }
    const armPhoto = median(ths.map(t => t[0])), armCut = median(ths.map(t => t[1]));
    const whereAt = cx => { const t = (cx - x0) / Math.max(1, x1 - x0), u = z.left ? t : 1 - t; return u < 0.25 ? 'at the end' : u > 0.75 ? 'near the hinge' : 'in the middle'; };
    const places = [];
    blobs(miss, W, H, x0, x1).forEach(pix => { if (pix.length < 8) return;
      let a = 1e9, b = -1; pix.forEach(q => { const x = q % W; a = Math.min(a, x); b = Math.max(b, x); });
      const cs = []; for (let x = a; x <= b; x++) cs.push(colThick(x));
      places.push({ lens: 'arm', where: whereAt((a + b) / 2), photoPx: median(cs.map(t => t[0])), cutPx: median(cs.map(t => t[1])), arcPx: b - a + 1, px: pix.length, cols: [a, b] }); });
    if (dots.length) places.push({ lens: 'arm', where: 'beside the arm', dot: true, n: dots.length, photoPx: 0, cutPx: 0, arcPx: 0, at: [0, 0] });
    if (haze.length >= 40) places.push({ lens: 'arm', where: 'along the edge of the arm', dot: true, halo: true, n: 1, photoPx: 0, cutPx: 0, arcPx: haze.length, at: [0, 0] });
    return { measured: true, ok: !places.length, kind: 'arm', zone: z, Dc, Mp, dots, haze, places, armPx: armPhoto, cutPx: armCut, M };
  }
  function checkArm(cutImg, srcImg, opts) {
    opts = opts || {};
    const W = cutImg.naturalWidth || cutImg.width, H = cutImg.naturalHeight || cutImg.height;
    if (!(W > 32 && H > 32)) return { measured: false, reason: 'no picture', summary: { measured: false, reason: 'no picture' } };
    const cd = data(cutImg, W, H), sd = data(srcImg, W, H).data, N = W * H, A = new Uint8Array(N);
    for (let i = 0; i < N; i++) A[i] = cd.data[i * 4 + 3];
    const P = null, z = armZone(A, W, H), M = z ? armMaps(A, sd, W, H, z) : null;
    const res = z ? armMeasure(A, P, W, H, z, M) : { measured: false, reason: 'no arm found in this picture' };
    res.w = W; res.h = H;
    if (res.measured && !res.ok && (opts.marks || opts.repair)) {
      const fill = (Ac, Mp, Dc) => {                                   /* what to put back, pixel by pixel: as solid as the photo is dark */
        const want = new Int16Array(N).fill(-1), from = new Int32Array(N).fill(-1), M1 = dilate(Mp, W, H, 1);
        for (let y = 0; y < H; y++) for (let x = z.x0; x <= z.x1; x++) { const i = y * W + x; if (!M1[i]) continue;
          /* inside the arm (a light gold strip, a shine, a groove too): fully solid; on its edge: as solid as the photo is dark */
          const inner = Mp[i] && Mp[i - 1] && Mp[i + 1] && Mp[i - W] && Mp[i + W];
          const t = inner ? 255 : Math.round(255 * Math.max(0, Math.min(1, M.D[i] / Dc))); if (t < 40 || t <= Ac[i] + 20) continue;
          want[i] = t;
          if (t < 200) { let best = -1, bv = -1; for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) { const q = i + dy * W + dx; if (q >= 0 && q < N && Mp[q] && M.D[q] > bv) { bv = M.D[q]; best = q; } } from[i] = best; } }
        return { want, from };
      };
      const f0 = fill(A, res.Mp, res.Dc);
      if (opts.marks) {
        const c = document.createElement('canvas'); c.width = W; c.height = H; const id = new ImageData(new Uint8ClampedArray(cd.data), W, H);
        for (let i = 0; i < N; i++) if (f0.want[i] >= 0) { const j = i * 4; id.data[j] = 235; id.data[j + 1] = 25; id.data[j + 2] = 25; id.data[j + 3] = 255; }
        res.dots.forEach(pix => pix.forEach(q => { const j = q * 4; id.data[j] = 30; id.data[j + 1] = 90; id.data[j + 2] = 255; id.data[j + 3] = 255; }));
        if (res.haze.length >= 40) res.haze.forEach(q => { const j = q * 4; id.data[j] = 30; id.data[j + 1] = 90; id.data[j + 2] = 255; id.data[j + 3] = 255; });
        c.getContext('2d').putImageData(id, 0, 0); res.marks = c;
      }
      if (opts.repair) {
        const out = new Uint8ClampedArray(cd.data), A2 = new Uint8Array(A); let added = 0, cur = res, f = f0;
        for (let pass = 0; pass < 4; pass++) {
          let n = 0;
          for (let i = 0; i < N; i++) if (f.want[i] >= 0 && f.want[i] > out[i * 4 + 3] + 2) { const j = i * 4, js = (f.from[i] >= 0 ? f.from[i] : i) * 4;
            out[j] = sd[js]; out[j + 1] = sd[js + 1]; out[j + 2] = sd[js + 2]; out[j + 3] = f.want[i]; A2[i] = f.want[i]; n++; }
          cur.dots.forEach(pix => pix.forEach(q => { if (out[q * 4 + 3]) { out[q * 4 + 3] = 0; A2[q] = 0; n++; } }));
          if (cur.haze.length >= 40) cur.haze.forEach(q => { if (out[q * 4 + 3]) { out[q * 4 + 3] = 0; A2[q] = 0; n++; } });
          added += n;
          cur = armMeasure(A2, P, W, H, z, M);
          if (!n || !cur.measured || cur.ok) break;
          f = fill(A2, cur.Mp, cur.Dc);
        }
        const c = document.createElement('canvas'); c.width = W; c.height = H; c.getContext('2d').putImageData(new ImageData(out, W, H), 0, 0);
        res.repair = c; res.added = added; res.after = armSummary(cur);
        res.verify = res.places.map(pl => {
          if (pl.dot) return Object.assign({ lens: 'arm', where: pl.where, dot: true, gone: !!(cur.measured && !(cur.places || []).some(q => q.dot && !!q.halo === !!pl.halo)), photoPx: 0, beforePx: 0, afterPx: 0 }, pl.halo ? { halo: true } : {});
          let after = null;
          if (cur.measured) { const v2 = []; for (let x = pl.cols[0]; x <= pl.cols[1]; x++) { let ct = 0; for (let y = 0; y < H; y++) { const i = y * W + x; if (cur.Mp[i]) ct += A2[i] / 255; } v2.push(ct); } after = median(v2); }
          return { lens: 'arm', where: pl.where, photoPx: Math.round(pl.photoPx), beforePx: Math.round(pl.cutPx), afterPx: after == null ? null : Math.round(after) };
        }).reduce((out, v) => {                                          /* one line per part of the arm (end, middle, near the hinge) */
          const o = out.find(q => q.where === v.where && !!q.dot === !!v.dot && !!q.halo === !!v.halo);
          if (!o) out.push(v);
          else if (!v.dot && (v.afterPx == null || o.afterPx == null || v.afterPx - v.photoPx < o.afterPx - o.photoPx)) Object.assign(o, v);
          return out; }, []);
      }
    }
    res.summary = armSummary(res);
    return res;
  }
  function armSummary(res) {
    if (!res.measured) return { measured: false, reason: res.reason, kind: 'arm' };
    return { measured: true, ok: res.ok, kind: 'arm', verify: res.verify, armPx: Math.round(res.armPx), cutPx: Math.round(res.cutPx),
      lenses: [{ name: 'arm', photoPx: Math.round(res.armPx), cutPx: Math.round(res.cutPx) }],
      places: merged(res.places).slice(0, 8).map(p => Object.assign({ lens: 'arm', where: p.where, photoPx: Math.round(p.photoPx), cutPx: Math.round(p.cutPx), arcPx: p.arcPx }, p.dot ? { dot: true, n: p.n || 1 } : {}, p.halo ? { halo: true } : {})) };
  }
  function check(cutImg, srcImg, opts) {
    opts = opts || {};
    const W = cutImg.naturalWidth || cutImg.width, H = cutImg.naturalHeight || cutImg.height;
    if (!(W > 32 && H > 32)) return { measured: false, reason: 'no picture' };
    const cd = data(cutImg, W, H), sd = data(srcImg, W, H).data, N = W * H, A = new Uint8Array(N);
    for (let i = 0; i < N; i++) A[i] = cd.data[i * 4 + 3];
    const P = photoMaps(sd, W, H);
    const res = measure(A, P, W, H, cd.data);
    res.w = W; res.h = H;
    if (opts.debug) res.debugP = P;
    if (!res.measured) { res.summary = summary(res); return res; }
    if ((opts.marks || opts.repair) && !res.ok) {
      const m = missingMask(res, A, P, W, H, cd.data, sd);
      if (opts.marks) {
        const c = document.createElement('canvas'); c.width = W; c.height = H; const x = c.getContext('2d');
        const id = new ImageData(new Uint8ClampedArray(cd.data), W, H);
        for (let i = 0; i < N; i++) if (m[i] || m.paint[i]) { const j = i * 4; id.data[j] = 235; id.data[j + 1] = 25; id.data[j + 2] = 25; id.data[j + 3] = 255; }
        x.putImageData(id, 0, 0); res.marks = c;
      }
      if (opts.repair) {
        /* put back, measure again, and once more where it is still short (up to 3 rounds) */
        const out = new Uint8ClampedArray(cd.data), A2 = new Uint8Array(A); let added = 0, cur = res, mm = m;
        for (let pass = 0; pass < 3; pass++) {
          let n = 0;
          for (let i = 0; i < N; i++) {
            if (mm[i] && mm.paint[i] !== 2) { const j = i * 4, want = mm[i], fr = mm.from[i], js = (fr >= 0 ? fr : i) * 4;
              if (want > out[j + 3] + 2) { out[j] = sd[js]; out[j + 1] = sd[js + 1]; out[j + 2] = sd[js + 2]; out[j + 3] = want; A2[i] = want; n++; } }
            else if (mm.paint[i] === 2) { if (mm[i] > out[i * 4 + 3] + 2) { out[i * 4 + 3] = mm[i]; A2[i] = mm[i]; }   /* a white dot: the rim's colour */ const j = i * 4, c = mm.rgb[i]; out[j] = (c >> 16) & 255; out[j + 1] = (c >> 8) & 255; out[j + 2] = c & 255; n++; }
            else if (mm.paint[i]) { const j = i * 4, js = (mm.from[i] >= 0 ? mm.from[i] : i) * 4; out[j] = sd[js]; out[j + 1] = sd[js + 1]; out[j + 2] = sd[js + 2]; n++; }
            else if (mm.setA[i] >= 0) { const j = i * 4, js = (mm.from[i] >= 0 ? mm.from[i] : i) * 4; out[j] = sd[js]; out[j + 1] = sd[js + 1]; out[j + 2] = sd[js + 2]; out[j + 3] = mm.setA[i]; A2[i] = mm.setA[i]; n++; }
            else if (mm.clear[i] && out[i * 4 + 3] > 0) { out[i * 4 + 3] = 0; A2[i] = 0; n++; } }
          added += n;
          cur = measure(A2, P, W, H, out);
          if (!n || !cur.measured || cur.ok) break;
          mm = missingMask(cur, A2, P, W, H, out, sd);
        }
        const c = document.createElement('canvas'); c.width = W; c.height = H; c.getContext('2d').putImageData(new ImageData(out, W, H), 0, 0);
        res.repair = c; res.added = added; res.after = summary(cur); res.verify = verify(res, cur);
      }
    }
    /* small enough to save with the frame */
    res.summary = summary(res);
    return res;
  }
  function summary(res) {
    if (!res.measured) return { measured: false, reason: res.reason };
    return { measured: true, ok: res.ok, thinPct: res.thinPct, medRim: res.medRim, broken: !!res.broken, verify: res.verify,
      lenses: res.lenses.map(l => ({ name: l.name, photoPx: Math.round(l.photoPx), cutPx: Math.round(l.cutPx) })),
      places: merged(res.places).slice(0, 8).map(p => Object.assign({ lens: p.lens, where: p.where, photoPx: Math.round(p.photoPx), cutPx: Math.round(p.cutPx), arcPx: p.arcPx }, p.dot ? { dot: true, n: p.n || 1 } : {})) };
  }
  /* the same part of the same lens in several stretches is shown once: the stretch that lost the most, the length of all */
  function merged(places) {
    const out = [];
    places.forEach(p => { const o = out.find(q => q.lens === p.lens && q.where === p.where && !!q.dot === !!p.dot);
      if (!o) { out.push(Object.assign({}, p)); return; }
      if (p.dot) { o.n = (o.n || 1) + 1; return; }
      o.arcPx = (o.arcPx || 0) + (p.arcPx || 0);
      if (p.photoPx - p.cutPx > o.photoPx - o.cutPx) { o.photoPx = p.photoPx; o.cutPx = p.cutPx; } });
    return out;
  }
  g.VGRim = { check, checkArm, _maps: photoMaps, _armZone: armZone, VERSION: 'd17.189' };
})(window);
